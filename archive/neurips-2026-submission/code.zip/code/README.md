# Neuro-Inspired Inverse Learning — Code Bundle

This bundle accompanies the NeurIPS 2026 submission *Neuro-Inspired Inverse
Learning for Planning and Control*. It contains the core code and training /
deployment configs for the Inverter framework: forward-model (FM) training,
inverse-world-model (IWM) training, and the deployment-time navigation /
gate-synthesis pipelines reported in the paper.

We have intentionally **excluded** auxiliary scaffolding: D4RL evaluation
harnesses (these are not specific to this paper), the CORL baselines, and
figure / table / analysis scripts. The dump focuses on the components that
*define* the method: the FM and IWM models and their training rules
(Eq. 4 in the paper), and the deployment-time controllers.

All paths in configs and scripts have been sanitized — no absolute paths
remain. Placeholders `<REPO_ROOT>`, `<PYTHON>`, `<HOME>`, `<MUJOCO_BIN>`
appear where machine-specific paths originally lived.

## Layout

```
code/
├── README.md
├── src/                       Shared model code (used by maze2d)
│   ├── data/dataset.py
│   ├── envs/pointmass2d.py
│   └── models/
│       ├── universal_transformer_fm.py    Causal-transformer FM
│       ├── iwm_transformer.py             Transformer IWM (chunk action emitter)
│       ├── iwm_v2.py                      MultipleShooting loss + occupancy grid
│       ├── transformer_forward_model.py   Earlier transformer FM variant
│       └── chunk_forward_model.py         Earlier MLP/CNN FM variant
├── common/
│   └── cardinal_bfs_planner.py            Algorithmic Path Inverter (Level-2)
│
├── maze2d/                    maze2d-{umaze,medium,large} (Sec. 5.1–5.2)
│   ├── train_fm.py            Trains UniversalTransformerFM
│   ├── train_iwm.py           Trains the Motor Inverter (IWM_Transformer)
│   ├── navigate_maze2d.py     Deployment driver (Inverter + optional Path Inverter)
│   ├── maze_layouts.py
│   └── configs/{umaze,medium,large}/{fm,iwm,navigate}.json
│
├── antmaze/                   antmaze-v2 — six variants (Sec. 5.3)
│   ├── train_fm_<env>_L16.py  29-D AntMaze FM trainer (one per maze variant)
│   ├── train_iwm_<env>_L16.py Motor Inverter trainer (with BC + yaw aux losses)
│   ├── navigate_cardinal.py   Deployment with Path Inverter (cardinal BFS)
│   ├── configs/<env>/{fm,iwm,navigate}.json   for env in
│   │     {umaze, umaze_diverse, medium_play, medium_diverse,
│   │      large_play, large_diverse}
│   │
│   └── antman/                Hierarchical n=2 Inverter — AntMan task (Sec. 5.4)
│       ├── antman.py                  Game environment (Pac-Man-style)
│       ├── antman_learned.py          Hierarchical evaluation driver
│       ├── antman_sim.py              Lightweight simulator
│       ├── eval_antman_learned.py     Eval entry point (Game Inverter ↔ Locomotion Inverter)
│       ├── game.py / game_state.py    Game logic and 58-D state representation
│       ├── strategy.py                Heuristic baseline strategies
│       ├── render.py                  ASCII / matplotlib rendering
│       ├── train_game_fm_v2.py        Game FM trainer (causal transformer)
│       ├── train_iwm_tfm_dir.py       Game Inverter trainer (direction transformer)
│       ├── sim/
│       │   ├── generate_random_data.py     Random training-data generator
│       │   └── generate_parallel_data.py   Parallel game-data generator
│       └── configs/
│           ├── data_random_mixed_100k.json     100k random-walk games (FM/IWM data)
│           ├── data_heuristic_mixed_100k.json  100k heuristic-policy games (control)
│           ├── fm_random.json / fm_heuristic.json
│           └── iwm_random.json / iwm_heuristic.json
│
└── quantum/                   Pulse Inverter on a 3-level transmon (Sec. 5.5)
    ├── inverter/{mlp.py,arch_2q.py,mlp_2q.py}     Inverter networks
    ├── sim/{transmon.py,two_qubit.py}              Differentiable Lindblad sims
    ├── grape/{grape.py,grape_pub.py,grape_2q.py}   GRAPE baseline (LBFGS+x64)
    ├── utils/{experiment.py,bloch.py}              Logging, Bloch utilities
    ├── data/sampling.py                            Haar U(2) / SU(4) sampling
    ├── scripts/
    │   ├── train_inverter.py        Train 1-qubit Pulse Inverter
    │   ├── train_inverter_2q.py     Train 2-qubit Pulse Inverter
    │   ├── phase3_data.py           Build 1-qubit GRAPE reference set
    │   ├── phase7_data.py           Build 2-qubit GRAPE reference set
    │   ├── phase2_grape.py          1-qubit GRAPE baseline
    │   └── phase7_grape.py          2-qubit GRAPE baseline
    └── configs/
        ├── phase4_inverter_default.yml   1-qubit defaults
        └── phase7_inverter_default.yml   2-qubit defaults
```

## Mapping configs → paper sections

| Paper section | Configs |
|---|---|
| Sec. 5.1 (umaze) — Tab. 1, Fig. 2, Fig. 3 | `maze2d/configs/umaze/{fm,iwm,navigate}.json` |
| Sec. 5.2 (medium / large) — Tab. 1, Fig. 7 | `maze2d/configs/{medium,large}/{fm,iwm,navigate}.json` |
| Sec. 5.3 (antmaze, all six variants) — Tab. 2 | `antmaze/configs/<env>/{fm,iwm,navigate}.json` |
| Sec. 5.4 (AntMan, hierarchical n=2) — Fig. 6 | `antmaze/antman/configs/{fm,iwm}_{random,heuristic}.json` |
| Sec. 5.5 (Pulse Inverter) — Fig. 7 | `quantum/configs/phase4_inverter_default.yml` |

## Notes on reproducibility

- `<REPO_ROOT>` should be set to the unzipped bundle root when running.
- The maze2d / antmaze training scripts use `gym + d4rl-v1` for environment
  loading and load the corresponding D4RL offline datasets.
- The 29-D AntMaze FM trainer expects pre-extracted episode data at
  `<REPO_ROOT>/data/antmaze/<env>/`; extraction code uses the standard D4RL
  iterators and is not included here.
- All Pulse Inverter code runs on CPU (JAX/diffrax). The maze2d / antmaze
  pipelines run on a single GPU.
- Multiple `train_iwm_*_L16.py` and `train_fm_*_L16.py` files exist because
  the per-environment IWM auxiliary losses (yaw regulariser, BC anchor) and
  FM dimension groupings differ slightly across maze variants; we kept them
  separate rather than merging into one script with branches.
