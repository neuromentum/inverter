"""
Hard-coded D4RL maze2d-v1 layouts (umaze, medium, large) + an orientation
helper.

The raw D4RL ``maze_arr`` is row-major in env-frame orientation. Occupancy
planning in this codebase uses a top-down layout where row 0 corresponds
to the highest y value, so ``raw_env_maze_arr_to_occupancy`` flips/transposes
the raw layout into that convention.

Cell codes: WALL=10, EMPTY=11, GOAL=12 (matching D4RL).
"""
from __future__ import annotations

import numpy as np


WALL = 10
EMPTY = 11
GOAL = 12


# D4RL exposes maze_arr in raw env orientation. For occupancy planning we use a
# top-down row-major layout where row 0 corresponds to the highest y value.
UMAZE_RAW_ENV_MAZE_ARR = [
    [10, 10, 10, 10, 10],
    [10, 12, 11, 11, 10],
    [10, 10, 10, 11, 10],
    [10, 11, 11, 11, 10],
    [10, 10, 10, 10, 10],
]


def raw_env_maze_arr_to_occupancy(maze_arr) -> np.ndarray:
    arr = np.asarray(maze_arr, dtype=np.int32)
    return np.flipud(arr.T).copy()


UMAZE_OCCUPANCY_MAZE_ARR = raw_env_maze_arr_to_occupancy(UMAZE_RAW_ENV_MAZE_ARR).tolist()