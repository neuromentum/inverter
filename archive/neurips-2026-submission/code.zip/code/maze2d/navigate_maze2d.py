#!/usr/bin/env python3
"""
MPC-style navigation evaluation for maze2d-v1 with live monitoring.

Writes incremental progress.json output during the run, enabling a live monitor.

Execution modes:
  - actions_iwm: Execute first K IWM-planned actions, then re-plan.
  - actions:     Same but break early when goal reached within a replan chunk.
  - waypoint:    PD-control to FM-predicted endpoint of first K steps.
  - mppi:        MPPI sampling around IWM plan, scored by FM.
  - cem:         CEM iterative refinement around IWM plan, scored by FM.

Goal planners:
    - direct:       Plan each chunk directly toward the final goal.
    - cardinal_bfs: BFS on the maze grid, then execute the IWM toward short,
                                    axis-aligned waypoint targets.

Output structure:
  maze2d/umaze/navigate/<exp_name>/
    config.json       — full experiment config
    progress.json     — incremental results (read by monitor)
    results.json      — final summary
    monitor.png       — auto-refreshing dashboard
    monitor.log       — monitor stdout
    episodes/         — per-episode detail plots

Usage:
    source "$(conda info --base)/etc/profile.d/conda.sh" && conda activate d4rl
    export LD_LIBRARY_PATH="$HOME/.mujoco/mujoco210/bin:/usr/lib/nvidia"
    export MUJOCO_PY_FORCE_CPU=1

    python -u maze2d/navigate_maze2d.py \\
        --model maze2d/umaze/iwm/L16/repro/repro_origFM_dense10_bnd30_flat_20260331_150406 \\
        --maze umaze --gpu 0 --replan_steps 64 --exec_mode actions_iwm \\
        --exp_name my_eval_run

    # Open-loop (no replanning):
    python -u maze2d/navigate_maze2d.py \\
        --model <path> --maze umaze --gpu 0 --replan_steps 9999 \\
        --exec_mode actions_iwm --exp_name openloop_test
"""

import sys, os, argparse, json, time, subprocess
from collections import deque
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ['D4RL_SUPPRESS_IMPORT_ERROR'] = '1'

import torch
import numpy as np
from pathlib import Path
from datetime import datetime

from src.models.iwm_transformer import IWM_Transformer
from src.models.chunk_forward_model import ChunkForwardModelFull
from src.models.transformer_forward_model import TransformerForwardModel
from src.models.universal_transformer_fm import UniversalTransformerFM
from common.cardinal_bfs_planner import CardinalBFSPlanner

# ─── Timing utilities ─────────────────────────────────────────────────

class TimingStats:
    """Accumulates wall-clock durations for a named event."""

    def __init__(self, name):
        self.name = name
        self.times = []

    def record(self, duration_sec):
        self.times.append(float(duration_sec))

    @property
    def n(self):
        return len(self.times)

    def to_dict(self):
        if not self.times:
            return {'calls': 0, 'total_sec': 0.0, 'mean_ms': 0.0,
                    'std_ms': 0.0, 'min_ms': 0.0, 'max_ms': 0.0, 'p50_ms': 0.0,
                    'p90_ms': 0.0, 'p99_ms': 0.0}
        arr_ms = np.asarray(self.times, dtype=np.float64) * 1000.0
        return {
            'calls': int(self.n),
            'total_sec': float(sum(self.times)),
            'mean_ms': float(arr_ms.mean()),
            'std_ms': float(arr_ms.std()),
            'min_ms': float(arr_ms.min()),
            'max_ms': float(arr_ms.max()),
            'p50_ms': float(np.percentile(arr_ms, 50)),
            'p90_ms': float(np.percentile(arr_ms, 90)),
            'p99_ms': float(np.percentile(arr_ms, 99)),
        }


# Module-level trackers populated when --timing is on.
_timing_enabled = False
_iwm_time = TimingStats('iwm_forward')
_fm_time = TimingStats('fm_rollout')
_env_step_time = TimingStats('env_step')
# Full replan cycle: from top of outer loop (waypoint mgmt + optional BFS +
# tensor prep + IWM + FM + any .cpu().numpy()) until we start executing
# actions. This is the "total wall time per chunk to decide the next K
# actions" — the headline number for the zero-iteration-per-chunk claim.
_plan_cycle_time = TimingStats('plan_cycle')
# Full-BFS replan (fires only when stuck_check triggers; not every chunk).
_bfs_replan_time = TimingStats('bfs_replan')
# End-to-end wall time per episode (env.reset → end of the eval loop) — the
# real "compute budget" including all Python / numpy housekeeping that sits
# outside the IWM and env.step measurements above.
_episode_total_time = TimingStats('episode_total')


def _cuda_sync():
    """Sync CUDA so wall-clock timings measure the actual GPU work."""
    if _timing_enabled and torch.cuda.is_available():
        torch.cuda.synchronize()


# ─── Maze configs (d4rl v1) ───────────────────────────────────────────

MAZE_CONFIGS = {
    'umaze': {
        'env_id': 'maze2d-umaze-v1',
        'eval_max_steps': 300,
        'd4rl_random': 23.85,
        'd4rl_expert': 161.86,
    },
    'medium': {
        'env_id': 'maze2d-medium-v1',
        'eval_max_steps': 600,
        'd4rl_random': 13.13,
        'd4rl_expert': 277.39,
    },
    'large': {
        'env_id': 'maze2d-large-v1',
        'eval_max_steps': 800,
        'd4rl_random': 6.7,
        'd4rl_expert': 273.99,
    },
}

# ─── Args ──────────────────────────────────────────────────────────────

parser = argparse.ArgumentParser(description='Maze2D MPC Navigation Eval with Live Monitor')
parser.add_argument('--gpu', type=int, default=0)
parser.add_argument('--model', type=str, required=True,
                    help='Path to IWM model directory containing best_model.pt')
parser.add_argument('--maze', type=str, default=None, choices=['umaze', 'medium', 'large'])
parser.add_argument('--fm_path', type=str, default=None,
                    help='Override FM checkpoint (auto-loaded from IWM checkpoint if omitted)')
parser.add_argument('--no_fm', action='store_true',
                    help='Skip FM loading (IWM-only timing)')
parser.add_argument('--n_goals', type=int, default=100)
parser.add_argument('--seed', type=int, default=42)
parser.add_argument('--max_steps', type=int, default=None)
parser.add_argument('--goal_threshold', type=float, default=0.45)
parser.add_argument('--K_p', type=float, default=10.0)
parser.add_argument('--K_d', type=float, default=5.0)
parser.add_argument('--replan_steps', type=int, default=64,
                    help='Execute first K steps then re-plan (multiple of FM chunk=16)')
parser.add_argument('--waypoint_threshold', type=float, default=0.15)
parser.add_argument('--exec_mode', type=str, default='actions_iwm',
                    choices=['actions', 'waypoint', 'actions_iwm', 'mppi', 'cem'])
parser.add_argument('--planner', type=str, default='direct',
                choices=['direct', 'cardinal_bfs'],
                help='Goal planner: direct final-goal targeting or '
                    'cardinal BFS waypoint chain')
parser.add_argument('--wp_spacing', type=float, default=None,
                help='Cardinal BFS: spacing between axis-aligned waypoints '
                    '(0 = use horizon-tuned default)')
parser.add_argument('--wp_sampling_mode', type=str, default='axis_aligned',
                choices=['axis_aligned', 'centerline'],
                help='Cardinal BFS waypoint sampling: axis_aligned keeps turn '
                    'waypoints, centerline samples fixed arc length along the '
                    'corridor center so successive target directions may be diagonal')
parser.add_argument('--wp_advance_dist', type=float, default=None,
                help='Cardinal BFS: advance once within this distance of '
                    'the current waypoint (0 = use default)')
parser.add_argument('--wp_skip_dist', type=float, default=None,
                help='Cardinal BFS: skip ahead if a later waypoint is '
                    'within this distance (0 = use default)')
parser.add_argument('--stuck_threshold', type=int, default=None,
                help='Cardinal BFS: full BFS replan after this many chunks '
                    'without waypoint progress (0 = use default)')
parser.add_argument('--max_replans', type=int, default=0,
                help='Cardinal BFS: max number of full BFS replans per episode '
                     '(0 = unlimited, default). When the agent is stuck a fresh '
                     'BFS is cheap (~1ms), so there is no benefit to capping it.')
parser.add_argument('--target_dist_min', type=float, default=None,
                help='Cardinal BFS: if >0, randomize target distance along '
                    'the current waypoint direction (minimum)')
parser.add_argument('--target_dist_max', type=float, default=None,
                help='Cardinal BFS: if >0, randomize target distance along '
                    'the current waypoint direction (maximum)')
parser.add_argument('--planner_impl', type=str, default='unified',
                    choices=['legacy', 'unified'],
                    help='Which planner implementation to use. "unified" '
                         '(default) instantiates common.cardinal_bfs_planner.'
                         'CardinalBFSPlanner. "legacy" instantiates the '
                         'maze2d-local DataOccupancyGrid class. Provided as '
                         'an A/B switch for the unification regression sweep.')
parser.add_argument('--data_states_path', type=str, default=None,
                    help='DataOccupancy: path to training-data states.npy '
                         '(default: data/maze2d_v1/<maze>/states.npy).')
parser.add_argument('--data_resolution', type=float, default=0.5,
                    help='DataOccupancy: cell size in qpos units (default 0.5, '
                         'i.e. 2 cells per maze cell — fine enough to see walls).')
parser.add_argument('--data_min_visits', type=int, default=10,
                    help='DataOccupancy: minimum training points per cell for '
                         'it to count as free (default 10).')
parser.add_argument('--data_origin_mode', type=str, default='auto',
                    choices=['auto', 'floor'],
                    help='DataOccupancy grid origin: "auto" aligns cell '
                         'centers to the qpos density peaks (recommended); '
                         '"floor" uses floor(min) which can cut through peaks.')
parser.add_argument('--min_leg', type=float, default=1.0,
                    help='Minimum polyline leg length (qpos units, default 1.0 '
                         '= one maze cell). Shorter legs are merged out — they '
                         'are sub-cell wobbles that the IWM cannot track. Set '
                         'to 0 to disable.')
parser.add_argument('--timing', action='store_true',
                    help='Record detailed timing: IWM forward, FM rollout, '
                         'env.step separately (adds cuda.synchronize around '
                         'each GPU call, ~microseconds overhead). Writes '
                         '`timing` summary block to results.json.')
parser.add_argument('--n_samples', type=int, default=64, help='MPPI/CEM samples')
parser.add_argument('--mppi_sigma', type=float, default=0.2)
parser.add_argument('--mppi_temperature', type=float, default=0.1)
parser.add_argument('--cem_elite_frac', type=float, default=0.1)
parser.add_argument('--cem_iters', type=int, default=5)
parser.add_argument('--exp_name', type=str, default=None,
                    help='Experiment name (auto-generated if omitted)')
parser.add_argument('--out_dir', type=str, default=None,
                    help='Override output directory')
parser.add_argument('--no_monitor', action='store_true',
                    help='Skip auto-starting the monitor')
parser.add_argument('--no_episodes', action='store_true',
                    help='Skip per-episode detail plots in monitor')
parser.add_argument('--no_pd_hold', action='store_true',
                    help='Keep replanning with IWM for all MAX_STEPS instead of '
                         'PD-holding after reaching goal')
parser.add_argument('--d4rl_official', action='store_true',
                    help='Official D4RL eval: fixed target (no set_target), '
                         'run full max_episode_steps, use env.get_normalized_score()')
parser.add_argument('--iwm_offset', type=float, default=0.0,
                    help='Add this offset to x,y of state/goal before IWM planning. '
                         'Use 0.2 when running centered (body_pos=1.0) with an IWM '
                         'trained on uncentered (body_pos=1.2) data.')
parser.add_argument('--iwm_offset_state_only', action='store_true',
                    help='Apply --iwm_offset only to state, not to goal.')
parser.add_argument('--iwm_offset_goal_only', action='store_true',
                    help='Apply --iwm_offset only to goal, not to state.')
args = parser.parse_args()

os.environ['CUDA_VISIBLE_DEVICES'] = str(args.gpu)
DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
_timing_enabled = bool(args.timing)

import gym
import d4rl  # noqa: F401


def _get_maze2d_body_pos():
    """Return the MuJoCo body_pos used by the current maze2d eval env."""
    raw = os.environ.get('MAZE2D_BODY_POS')
    if raw is not None:
        try:
            return float(raw)
        except ValueError:
            pass
    if os.environ.get('MAZE2D_CENTERED') == '1':
        return 1.0
    return 1.2

PROJECT_ROOT = Path(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
MAZE2D_BODY_POS = _get_maze2d_body_pos()


# ─── Occupancy grid ───────────────────────────────────────────────────

class OccupancyGrid:
    """Check if (x, y) is in free space based on d4rl maze_arr."""

    def __init__(self, maze_arr, body_pos=1.2):
        self.arr = np.array(maze_arr, dtype=np.int32)
        self.nrows, self.ncols = self.arr.shape
        self.body_pos = float(body_pos)
        # maze_arr / XML live in world coords; trajectories live in qpos.
        # For maze2d-v1, qpos = world - body_pos, so cell centers in qpos are
        # shifted by (1 - body_pos) relative to integer world cell centers.
        self.qpos_center_shift = 1.0 - self.body_pos
        self.qpos_index_shift = self.body_pos - 1.0
        self.free_centres = []
        self.free_cells = []
        for r in range(self.nrows):
            for c in range(self.ncols):
                if self.arr[r, c] != 10:
                    sx, sy = self.cell_to_xy(r, c)
                    self.free_centres.append((sx, sy))
                    self.free_cells.append((r, c))
        self.free_centres = np.array(self.free_centres, dtype=np.float32)
        self.free_cells = np.array(self.free_cells, dtype=np.int32)

    def is_free(self, x, y):
        col = round(x + self.qpos_index_shift)
        row = self.nrows - 1 - round(y + self.qpos_index_shift)
        if 0 <= row < self.nrows and 0 <= col < self.ncols:
            return self.arr[row, col] != 10
        return False

    def cell_to_xy(self, row, col):
        return np.array([
            float(col) + self.qpos_center_shift,
            float(self.nrows - 1 - row) + self.qpos_center_shift,
        ], dtype=np.float32)

    def xy_to_cell(self, x, y):
        col = int(round(x + self.qpos_index_shift))
        row = int(self.nrows - 1 - round(y + self.qpos_index_shift))
        if 0 <= row < self.nrows and 0 <= col < self.ncols and self.arr[row, col] != 10:
            return (row, col)
        if len(self.free_centres) == 0:
            return (0, 0)
        dists = np.linalg.norm(self.free_centres - np.array([x, y], dtype=np.float32), axis=1)
        nearest_idx = int(np.argmin(dists))
        row, col = self.free_cells[nearest_idx]
        return (int(row), int(col))

    def get_neighbors(self, row, col):
        nbrs = []
        for dr, dc in ((0, 1), (0, -1), (1, 0), (-1, 0)):
            nr, nc = row + dr, col + dc
            if 0 <= nr < self.nrows and 0 <= nc < self.ncols and self.arr[nr, nc] != 10:
                nbrs.append((nr, nc))
        return nbrs

    def bfs_cell_path(self, start_rc, goal_rc):
        if start_rc == goal_rc:
            return [start_rc]

        queue = deque([start_rc])
        parent = {start_rc: None}

        while queue:
            current = queue.popleft()
            for nbr in self.get_neighbors(*current):
                if nbr in parent:
                    continue
                parent[nbr] = current
                if nbr == goal_rc:
                    path = [nbr]
                    while parent[path[-1]] is not None:
                        path.append(parent[path[-1]])
                    return list(reversed(path))
                queue.append(nbr)

        return None

    def _build_cardinal_polyline(self, start_xy, goal_xy):
        start_xy = np.asarray(start_xy, dtype=np.float32)
        goal_xy = np.asarray(goal_xy, dtype=np.float32)
        start_cell = self.xy_to_cell(start_xy[0], start_xy[1])
        goal_cell = self.xy_to_cell(goal_xy[0], goal_xy[1])

        cell_path = self.bfs_cell_path(start_cell, goal_cell)
        if cell_path is None:
            return None

        # Detect turns from the BFS cell indices directly. The BFS is
        # 4-connected, so each step is a unit move along exactly one axis; a
        # turn is any cell where that axis changes. Working on the grid
        # indices (not the cell_to_xy positions) is robust to whether
        # cell_to_xy returns geometric-grid or data-mean coordinates.
        turn_indices = []
        prev_dir = None
        for i in range(len(cell_path) - 1):
            r1, c1 = cell_path[i]
            r2, c2 = cell_path[i + 1]
            direction = (int(np.sign(r2 - r1)), int(np.sign(c2 - c1)))
            if prev_dir is not None and direction != prev_dir:
                turn_indices.append(i)  # cell[i] sits at the elbow
            prev_dir = direction

        # Keypoints: start + each turn-cell center + goal. For
        # DataOccupancyGrid, `cell_to_xy` returns the density-weighted mean of
        # the data points in that cell, so corners land on the corridor
        # centerline rather than on a geometric grid point.
        keypoints = [start_xy.copy()]
        for i in turn_indices:
            r, c = cell_path[i]
            keypoints.append(self.cell_to_xy(r, c))
        keypoints.append(goal_xy.copy())

        # Insert an explicit L-corner between two keypoints that disagree on
        # both axes by more than TOL — the IWM was trained on axis-aligned
        # targets, so each executed leg should be purely horizontal or
        # vertical. TOL absorbs the small jitter of data-mean cell centers.
        TOL = 0.1
        orthogonal = [keypoints[0]]
        for next_pt in keypoints[1:]:
            current_pt = orthogonal[-1]
            dx = float(next_pt[0] - current_pt[0])
            dy = float(next_pt[1] - current_pt[1])
            if abs(dx) > TOL and abs(dy) > TOL:
                turn_point = np.array([next_pt[0], current_pt[1]], dtype=np.float32)
                if np.linalg.norm(turn_point - current_pt) > 0.05:
                    orthogonal.append(turn_point)
            if np.linalg.norm(next_pt - orthogonal[-1]) > 0.05:
                orthogonal.append(np.asarray(next_pt, dtype=np.float32).copy())

        # Safety-net collinear merge: if three consecutive points are
        # axis-aligned within TOL, drop the middle one. Turn-based extraction
        # should make this a no-op in clean cases but guards against
        # degenerate corner cells.
        simplified = [orthogonal[0]]
        for next_pt in orthogonal[1:]:
            if len(simplified) < 2:
                simplified.append(next_pt.copy())
                continue
            prev_pt = simplified[-2]
            curr_pt = simplified[-1]
            same_x = (abs(float(prev_pt[0] - curr_pt[0])) < TOL and
                      abs(float(curr_pt[0] - next_pt[0])) < TOL)
            same_y = (abs(float(prev_pt[1] - curr_pt[1])) < TOL and
                      abs(float(curr_pt[1] - next_pt[1])) < TOL)
            if same_x or same_y:
                simplified[-1] = next_pt.copy()
            else:
                simplified.append(next_pt.copy())

        # Short-leg wobble filter. A true corridor turn produces legs at least
        # one maze-cell long in either direction; a sub-cell wobble is a
        # waypoint where *both* adjacent legs are shorter than min_leg.
        # Dropping only those leaves the corridor routing intact and only
        # removes staircase artifacts from data-mean snapping. More aggressive
        # filtering (dropping on a single short leg) is unsafe because it
        # can force L-corners into wall cells that the BFS never cleared.
        min_leg = float(getattr(self, 'min_leg', 1.0))
        if min_leg > 0 and len(simplified) > 2:
            pts = [np.asarray(p, dtype=np.float32) for p in simplified]
            changed = True
            while changed and len(pts) > 2:
                changed = False
                new_pts = [pts[0]]
                for i in range(1, len(pts) - 1):
                    incoming = float(np.linalg.norm(pts[i] - new_pts[-1]))
                    outgoing = float(np.linalg.norm(pts[i + 1] - pts[i]))
                    if incoming < min_leg and outgoing < min_leg:
                        changed = True  # drop pts[i], skip
                        continue
                    new_pts.append(pts[i])
                new_pts.append(pts[-1])
                pts = new_pts
            simplified = np.asarray(pts, dtype=np.float32)

        return np.asarray(simplified, dtype=np.float32)

    def _resample_axis_aligned_waypoints(self, keypoints, spacing):
        if spacing <= 0 or len(keypoints) < 2:
            return keypoints

        resampled = [keypoints[0]]
        for idx in range(len(keypoints) - 1):
            seg_start = keypoints[idx]
            seg_end = keypoints[idx + 1]
            seg_vec = seg_end - seg_start
            seg_len = float(np.linalg.norm(seg_vec))
            if seg_len < 1e-6:
                continue

            seg_dir = seg_vec / seg_len
            travel = float(spacing)
            while travel < seg_len - 1e-6:
                pt = seg_start + seg_dir * travel
                if np.linalg.norm(pt - resampled[-1]) > 0.05:
                    resampled.append(pt.astype(np.float32))
                travel += float(spacing)

            if np.linalg.norm(resampled[-1] - seg_end) > 0.05:
                resampled.append(seg_end.astype(np.float32))

        if np.linalg.norm(resampled[-1] - keypoints[-1]) > 0.05:
            resampled.append(keypoints[-1].copy())

        return np.asarray(resampled, dtype=np.float32)

    def _resample_centerline_waypoints(self, keypoints, spacing):
        if spacing <= 0 or len(keypoints) < 2:
            return keypoints

        seg_vecs = keypoints[1:] - keypoints[:-1]
        seg_lens = np.linalg.norm(seg_vecs, axis=1)
        total_len = float(np.sum(seg_lens))
        if total_len < 1e-6:
            return keypoints

        cum_lens = np.concatenate([[0.0], np.cumsum(seg_lens)])
        sample_dists = np.arange(float(spacing), total_len, float(spacing), dtype=np.float32)
        resampled = [keypoints[0]]

        for dist in sample_dists:
            seg_idx = int(np.searchsorted(cum_lens, float(dist), side='right') - 1)
            seg_idx = min(max(seg_idx, 0), len(seg_lens) - 1)
            seg_len = float(seg_lens[seg_idx])
            if seg_len < 1e-6:
                continue
            local_dist = float(dist - cum_lens[seg_idx])
            seg_dir = seg_vecs[seg_idx] / seg_len
            pt = keypoints[seg_idx] + seg_dir * local_dist
            if np.linalg.norm(pt - resampled[-1]) > 0.05:
                resampled.append(pt.astype(np.float32))

        if np.linalg.norm(resampled[-1] - keypoints[-1]) > 0.05:
            resampled.append(keypoints[-1].copy())

        return np.asarray(resampled, dtype=np.float32)

    def plan_cardinal_waypoints(self, start_xy, goal_xy, spacing=1.25,
                                sampling_mode='axis_aligned'):
        """Plan BFS waypoints along the corridor centerline.

        sampling_mode='axis_aligned' preserves turn waypoints so successive
        targets remain horizontal/vertical. sampling_mode='centerline' samples
        fixed arc length along the centerline, allowing diagonal target
        directions across turns while keeping each waypoint on the corridor
        center.
        """
        keypoints = self._build_cardinal_polyline(start_xy, goal_xy)
        if keypoints is None:
            return None

        if sampling_mode == 'centerline':
            return self._resample_centerline_waypoints(keypoints, spacing)
        if sampling_mode != 'axis_aligned':
            raise ValueError(f'Unknown wp sampling mode: {sampling_mode}')
        return self._resample_axis_aligned_waypoints(keypoints, spacing)

    def snap_towards_free(self, x, y, orig_x, orig_y):
        if self.is_free(x, y):
            return x, y
        for alpha in np.linspace(0.9, 0.0, 20):
            px = orig_x + alpha * (x - orig_x)
            py = orig_y + alpha * (y - orig_y)
            if self.is_free(px, py):
                return px, py
        dists = np.linalg.norm(self.free_centres - np.array([x, y]), axis=1)
        nearest = self.free_centres[np.argmin(dists)]
        return float(nearest[0]), float(nearest[1])


class DataOccupancyGrid(OccupancyGrid):
    """Free-space occupancy derived from offline training trajectories.

    The grid lives in qpos coordinates (same frame the trajectories + env
    observations use), so no body_pos transform is needed — a cell is free iff
    enough training data points fall into it. Cell "centers" are the mean of
    the training points in each cell, which naturally follows the corridor
    centerline in the data rather than the geometric maze midline.

    Public API matches OccupancyGrid so plan_cardinal_waypoints, bfs_cell_path,
    get_neighbors, and snap_towards_free all inherit unchanged.
    """

    def __init__(self, qpos_xy, resolution=0.5, min_visits=10, origin_mode='auto'):
        qpos_xy = np.asarray(qpos_xy, dtype=np.float32)
        if qpos_xy.ndim != 2 or qpos_xy.shape[1] < 2:
            raise ValueError(f'qpos_xy must be (N, 2+), got {qpos_xy.shape}')
        qpos_xy = qpos_xy[:, :2]

        self.res = float(resolution)
        self.min_visits = int(min_visits)
        self.origin_mode = str(origin_mode)
        # These two fields exist on OccupancyGrid for legacy reasons
        # (world↔qpos transform). Data grid is already in qpos, so they're zero.
        self.body_pos = 0.0
        self.qpos_center_shift = 0.0
        self.qpos_index_shift = 0.0

        if self.origin_mode == 'auto':
            # Align cell centers to the data's density peaks: find the most
            # common sub-resolution phase of the qpos values, and shift the
            # origin so that phase lands at cell centers. Keeps wall-edge
            # data from leaking across cell boundaries.
            def _phase_offset(vals):
                mods = np.mod(vals, self.res)
                bins = max(10, int(round(self.res / 0.02)))
                hist, edges = np.histogram(mods, bins=bins, range=(0.0, self.res))
                peak_phase = 0.5 * (edges[np.argmax(hist)] + edges[np.argmax(hist) + 1])
                # Origin phase so peak lands at cell center (origin + 0.5*res):
                return float((peak_phase - 0.5 * self.res) % self.res)
            x_phase = _phase_offset(qpos_xy[:, 0])
            y_phase = _phase_offset(qpos_xy[:, 1])
            x_min_adj = float(qpos_xy[:, 0].min()) - x_phase
            y_min_adj = float(qpos_xy[:, 1].min()) - y_phase
            self.x_origin = float(np.floor(x_min_adj / self.res) * self.res + x_phase)
            self.y_origin = float(np.floor(y_min_adj / self.res) * self.res + y_phase)
        elif self.origin_mode == 'floor':
            self.x_origin = float(np.floor(qpos_xy[:, 0].min() / self.res) * self.res)
            self.y_origin = float(np.floor(qpos_xy[:, 1].min() / self.res) * self.res)
        else:
            raise ValueError(f'Unknown origin_mode: {self.origin_mode}')

        col_idx = np.floor((qpos_xy[:, 0] - self.x_origin) / self.res).astype(np.int64)
        row_from_bottom = np.floor((qpos_xy[:, 1] - self.y_origin) / self.res).astype(np.int64)
        self.ncols = int(col_idx.max()) + 1
        self.nrows = int(row_from_bottom.max()) + 1
        row_idx = self.nrows - 1 - row_from_bottom

        counts = np.zeros((self.nrows, self.ncols), dtype=np.int64)
        sum_x = np.zeros((self.nrows, self.ncols), dtype=np.float64)
        sum_y = np.zeros((self.nrows, self.ncols), dtype=np.float64)
        np.add.at(counts, (row_idx, col_idx), 1)
        np.add.at(sum_x, (row_idx, col_idx), qpos_xy[:, 0].astype(np.float64))
        np.add.at(sum_y, (row_idx, col_idx), qpos_xy[:, 1].astype(np.float64))

        self.counts = counts
        # Wall marker 10 matches OccupancyGrid convention (is_free = arr != 10).
        self.arr = np.where(counts >= self.min_visits, 0, 10).astype(np.int32)

        free_mask = counts >= self.min_visits
        safe_counts = np.maximum(counts, 1)
        mean_x = (sum_x / safe_counts).astype(np.float32)
        mean_y = (sum_y / safe_counts).astype(np.float32)
        rr, cc = np.indices((self.nrows, self.ncols))
        geom_x = (self.x_origin + (cc + 0.5) * self.res).astype(np.float32)
        geom_y = (self.y_origin + (self.nrows - 1 - rr + 0.5) * self.res).astype(np.float32)
        self.centers = np.empty((self.nrows, self.ncols, 2), dtype=np.float32)
        self.centers[..., 0] = np.where(free_mask, mean_x, geom_x)
        self.centers[..., 1] = np.where(free_mask, mean_y, geom_y)

        free_rc = np.argwhere(free_mask)
        self.free_cells = free_rc.astype(np.int32)
        if len(free_rc):
            self.free_centres = self.centers[free_rc[:, 0], free_rc[:, 1]].astype(np.float32)
        else:
            self.free_centres = np.zeros((0, 2), dtype=np.float32)

    def cell_to_xy(self, row, col):
        return self.centers[row, col].copy()

    def _raw_cell(self, x, y):
        col = int(np.floor((x - self.x_origin) / self.res))
        row_from_bottom = int(np.floor((y - self.y_origin) / self.res))
        row = self.nrows - 1 - row_from_bottom
        return row, col

    def is_free(self, x, y):
        row, col = self._raw_cell(x, y)
        if 0 <= row < self.nrows and 0 <= col < self.ncols:
            return self.arr[row, col] != 10
        return False

    def xy_to_cell(self, x, y):
        row, col = self._raw_cell(x, y)
        if 0 <= row < self.nrows and 0 <= col < self.ncols and self.arr[row, col] != 10:
            return (row, col)
        if len(self.free_centres) == 0:
            return (0, 0)
        dists = np.linalg.norm(self.free_centres - np.array([x, y], dtype=np.float32), axis=1)
        nearest_idx = int(np.argmin(dists))
        r, c = self.free_cells[nearest_idx]
        return (int(r), int(c))


# ─── Load IWM ─────────────────────────────────────────────────────────

model_dir = Path(args.model)
if not model_dir.is_absolute():
    model_dir = PROJECT_ROOT / model_dir

# Accept either a directory (appends best_model.pt) or a direct .pt file path
if model_dir.suffix == '.pt' and model_dir.is_file():
    model_path = model_dir
    model_dir = model_path.parent
elif model_dir.is_dir():
    model_path = model_dir / 'best_model.pt'
else:
    # Try as-is (might be a .pt path that doesn't exist yet)
    model_path = model_dir
    model_dir = model_path.parent

if not model_path.exists():
    print(f'ERROR: Model not found at {model_path}')
    sys.exit(1)

print(f'Loading IWM from {model_path}...', flush=True)
ckpt = torch.load(model_path, map_location='cpu', weights_only=False)

model_args = ckpt.get('args', {})
horizon = ckpt.get('horizon', model_args.get('horizon', 128))

maze = args.maze or ckpt.get('maze') or model_args.get('maze') or 'umaze'
maze_cfg = MAZE_CONFIGS[maze]
ENV_ID = maze_cfg['env_id']
MAX_STEPS = args.max_steps or maze_cfg['eval_max_steps']

print(f'  Maze: {maze}, Env: {ENV_ID}, Horizon: {horizon}, Max steps: {MAX_STEPS}', flush=True)

iwm = IWM_Transformer(
    state_dim=4, goal_dim=4, action_dim=2,
    horizon=horizon,
    d_model=model_args.get('d_model', 192),
    n_heads=model_args.get('n_heads', 6),
    n_layers=model_args.get('n_layers', 4),
    d_ff=model_args.get('d_ff', 576),
).to(DEVICE)
iwm.load_state_dict(ckpt['model_state_dict'])
iwm.eval()

n_params = sum(p.numel() for p in iwm.parameters())
print(f'  IWM: {n_params:,} params, epoch {ckpt.get("epoch", "?")}', flush=True)


# ─── Load forward model ──────────────────────────────────────────────

fwd_model = None
FM_CHUNK = 16

# Try to find FM path: CLI arg > IWM config > maze default
fm_path_str = None if args.no_fm else (args.fm_path or model_args.get('fm_path'))
if fm_path_str:
    fm_path = Path(fm_path_str)
    if not fm_path.is_absolute():
        fm_path = PROJECT_ROOT / fm_path
else:
    fm_path = None

if fm_path and fm_path.exists():
    print(f'Loading FM from {fm_path}...', flush=True)
    fwd_ckpt = torch.load(fm_path, map_location='cpu', weights_only=False)
    fm_type = fwd_ckpt.get('model_type', 'cnn_film')
    if fm_type == 'universal_transformer':
        fwd_model = UniversalTransformerFM(
            state_dim=fwd_ckpt['state_dim'],
            action_dim=fwd_ckpt['action_dim'],
            chunk_length=fwd_ckpt['chunk_length'],
            output_dim=fwd_ckpt.get('output_dim', fwd_ckpt['state_dim']),
            d_model=fwd_ckpt['d_model'],
            n_heads=fwd_ckpt['n_heads'],
            n_layers=fwd_ckpt['n_layers'],
            ff_mult=fwd_ckpt.get('ff_mult', 4),
            dropout=fwd_ckpt.get('dropout', 0.1),
        )
        print(f'  FM type: UniversalTransformer', flush=True)
    elif fm_type == 'transformer_causal':
        fwd_model = TransformerForwardModel(
            state_dim=fwd_ckpt['state_dim'],
            action_dim=fwd_ckpt['action_dim'],
            chunk_length=fwd_ckpt['chunk_length'],
            d_model=fwd_ckpt['d_model'],
            n_heads=fwd_ckpt['n_heads'],
            n_layers=fwd_ckpt['n_layers'],
            d_ff=fwd_ckpt.get('d_ff', 0),
        )
        print(f'  FM type: Transformer (causal)', flush=True)
    else:
        fwd_model = ChunkForwardModelFull(
            state_dim=fwd_ckpt['state_dim'],
            action_dim=fwd_ckpt['action_dim'],
            chunk_length=fwd_ckpt['chunk_length'],
            hidden_dim=fwd_ckpt['hidden_dim'],
            n_layers=fwd_ckpt['n_layers'],
        )
        print(f'  FM type: CNN+FiLM', flush=True)
    fwd_model.load_state_dict(fwd_ckpt['model_state_dict'])
    fwd_model.to(DEVICE)
    fwd_model.eval()
    FM_CHUNK = fwd_ckpt['chunk_length']
    print(f'  FM loaded: val_loss={fwd_ckpt.get("val_loss","?"):.6f}, '
          f'chunk_length={FM_CHUNK}', flush=True)
elif args.exec_mode in ('waypoint', 'mppi', 'cem'):
    print(f'ERROR: FM required for {args.exec_mode} mode but not found')
    sys.exit(1)
else:
    print(f'  No FM loaded (not needed for {args.exec_mode} mode)', flush=True)


# ─── Output directory ─────────────────────────────────────────────────

timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
if args.exp_name:
    exp_name = f'{args.exp_name}_{timestamp}'
else:
    K = max(FM_CHUNK, (args.replan_steps // FM_CHUNK) * FM_CHUNK)
    exp_name = f'{args.exec_mode}_K{K}_{timestamp}'

if args.out_dir:
    OUT_DIR = Path(args.out_dir)
else:
    OUT_DIR = PROJECT_ROOT / 'maze2d' / maze / 'navigate' / exp_name

OUT_DIR.mkdir(parents=True, exist_ok=True)
print(f'  Output: {OUT_DIR}', flush=True)


# ─── Build occupancy grid ────────────────────────────────────────────

env = gym.make(ENV_ID)
obs = env.reset()

# Monkey-patch env.step to record timing when --timing is on. All subsequent
# env.step calls in the script (action execution, PD-hold) flow through this.
if _timing_enabled:
    _orig_env_step = env.step
    def _timed_env_step(action):
        _t0 = time.perf_counter()
        result = _orig_env_step(action)
        _env_step_time.record(time.perf_counter() - _t0)
        return result
    env.step = _timed_env_step

data_states_path = Path(args.data_states_path) if args.data_states_path else (
    PROJECT_ROOT / 'data' / 'maze2d_v1' / maze / 'states.npy'
)
if not data_states_path.is_absolute():
    data_states_path = PROJECT_ROOT / data_states_path
if not data_states_path.exists():
    print(f'ERROR: training states not found at {data_states_path}', flush=True)
    sys.exit(1)
print(f'Building DataOccupancyGrid from {data_states_path} ...', flush=True)
_states = np.load(data_states_path, mmap_mode='r')
_qpos_xy = np.asarray(_states[:, :2], dtype=np.float32)
print(f'  Training points: {len(_qpos_xy):,}  '
      f'x=[{_qpos_xy[:,0].min():.2f},{_qpos_xy[:,0].max():.2f}]  '
      f'y=[{_qpos_xy[:,1].min():.2f},{_qpos_xy[:,1].max():.2f}]',
      flush=True)
if args.planner_impl == 'unified':
    occ = CardinalBFSPlanner(_qpos_xy,
                             resolution=args.data_resolution,
                             min_visits=args.data_min_visits,
                             origin_mode=args.data_origin_mode,
                             center_weight=1.0)
else:
    occ = DataOccupancyGrid(_qpos_xy,
                            resolution=args.data_resolution,
                            min_visits=args.data_min_visits,
                            origin_mode=args.data_origin_mode)
occ.min_leg = float(args.min_leg)
print(f'  Planner impl: {args.planner_impl}', flush=True)
print(f'  DataOccupancy: {occ.nrows}×{occ.ncols}, {len(occ.free_centres)} free cells '
      f'(res={args.data_resolution}, min_visits={args.data_min_visits}, '
      f'origin_mode={args.data_origin_mode}, '
      f'origin=({occ.x_origin:.2f},{occ.y_origin:.2f}), '
      f'min_leg={args.min_leg})',
      flush=True)
# Compact ASCII preview of the derived topology
if occ.nrows <= 30 and occ.ncols <= 30:
    print('  DataOccupancy map (X=free, .=wall):', flush=True)
    for r in range(occ.nrows):
        print('    ' + ''.join('X' if occ.arr[r, c] != 10 else '.'
                               for c in range(occ.ncols)), flush=True)
del _states, _qpos_xy


def resolve_cardinal_params(plan_horizon):
    """Horizon-tuned defaults for cardinal BFS waypoint execution."""
    if plan_horizon <= 64:
        defaults = {
            'wp_spacing': 1.25,
            'wp_advance_dist': 0.9,
            'wp_skip_dist': 0.7,
            'stuck_threshold': 3,
            'target_dist_min': 0.0,
            'target_dist_max': 0.0,
        }
    elif plan_horizon <= 128:
        defaults = {
            'wp_spacing': 1.75,
            'wp_advance_dist': 1.2,
            'wp_skip_dist': 0.9,
            'stuck_threshold': 4,
            'target_dist_min': 0.0,
            'target_dist_max': 0.0,
        }
    else:
        defaults = {
            'wp_spacing': 2.25,
            'wp_advance_dist': 1.5,
            'wp_skip_dist': 1.1,
            'stuck_threshold': 4,
            'target_dist_min': 0.0,
            'target_dist_max': 0.0,
        }

    return {
        'wp_spacing': args.wp_spacing if args.wp_spacing is not None else defaults['wp_spacing'],
        'wp_sampling_mode': args.wp_sampling_mode,
        'wp_advance_dist': args.wp_advance_dist if args.wp_advance_dist is not None else defaults['wp_advance_dist'],
        'wp_skip_dist': args.wp_skip_dist if args.wp_skip_dist is not None else defaults['wp_skip_dist'],
        'stuck_threshold': args.stuck_threshold if args.stuck_threshold is not None else defaults['stuck_threshold'],
        'target_dist_min': args.target_dist_min if args.target_dist_min is not None else defaults['target_dist_min'],
        'target_dist_max': args.target_dist_max if args.target_dist_max is not None else defaults['target_dist_max'],
    }


# ─── Save config ──────────────────────────────────────────────────────

K = max(FM_CHUNK, (args.replan_steps // FM_CHUNK) * FM_CHUNK)
cardinal_cfg = resolve_cardinal_params(horizon)

config = {
    'experiment': {
        'name': exp_name,
        'created': datetime.now().isoformat(timespec='seconds'),
        'script': 'maze2d/navigate_maze2d.py',
        'env': ENV_ID,
        'iwm_path': str(model_path.relative_to(PROJECT_ROOT)),
        'fm_path': str(fm_path.relative_to(PROJECT_ROOT)) if fm_path else None,
        'horizon': horizon,
        'gpu': args.gpu,
    },
    'navigation': {
        'n_goals': args.n_goals,
        'seed': args.seed,
        'max_steps': MAX_STEPS,
        'goal_threshold': args.goal_threshold,
        'K_p': args.K_p,
        'K_d': args.K_d,
        'replan_steps': K,
        'exec_mode': args.exec_mode,
        'planner': args.planner,
        'no_pd_hold': args.no_pd_hold,
        'wp_spacing': cardinal_cfg['wp_spacing'] if args.planner == 'cardinal_bfs' else None,
        'wp_sampling_mode': cardinal_cfg['wp_sampling_mode'] if args.planner == 'cardinal_bfs' else None,
        'wp_advance_dist': cardinal_cfg['wp_advance_dist'] if args.planner == 'cardinal_bfs' else None,
        'wp_skip_dist': cardinal_cfg['wp_skip_dist'] if args.planner == 'cardinal_bfs' else None,
        'stuck_threshold': cardinal_cfg['stuck_threshold'] if args.planner == 'cardinal_bfs' else None,
        'max_replans': args.max_replans if args.planner == 'cardinal_bfs' else None,
        'target_dist_min': cardinal_cfg['target_dist_min'] if args.planner == 'cardinal_bfs' else None,
        'target_dist_max': cardinal_cfg['target_dist_max'] if args.planner == 'cardinal_bfs' else None,
        'data_resolution': args.data_resolution,
        'data_min_visits': args.data_min_visits,
        'data_origin_mode': args.data_origin_mode,
        'min_leg': args.min_leg,
    },
    'iwm_model': {
        'n_params': n_params,
        'epoch': ckpt.get('epoch', -1),
        'val_loss': float(ckpt.get('val_loss', -1)),
        'd_model': model_args.get('d_model', 192),
        'n_layers': model_args.get('n_layers', 4),
    },
    'raw_args': ' '.join(sys.argv[1:]),
}
(OUT_DIR / 'config.json').write_text(json.dumps(config, indent=2))


# ─── Auto-start monitor ──────────────────────────────────────────────

monitor_proc = None
monitor_script = PROJECT_ROOT / 'maze2d' / 'monitor_navigate_maze2d.py'
if not args.no_monitor and monitor_script.exists():
    monitor_log = OUT_DIR / 'monitor.log'
    monitor_cmd = [
        sys.executable, '-u', str(monitor_script),
        '--out_dir', str(OUT_DIR),
        '--interval', '10',
        '--n_episodes', str(args.n_goals),
        '--maze', maze,
    ]
    if args.no_episodes:
        monitor_cmd.append('--no_episodes')
    _body_pos = os.environ.get('MAZE2D_BODY_POS')
    if _body_pos:
        monitor_cmd.extend(['--coord_offset', _body_pos])
    elif os.environ.get('MAZE2D_CENTERED') == '1':
        monitor_cmd.append('--centered')
    monitor_proc = subprocess.Popen(
        monitor_cmd,
        stdout=open(monitor_log, 'w'), stderr=subprocess.STDOUT,
    )
    print(f'  Auto-started monitor (PID {monitor_proc.pid}) → monitor.log', flush=True)


# ─── Planning helpers ─────────────────────────────────────────────────

def _apply_iwm_offset(state_np, goal_np):
    """Shift state/goal xy by --iwm_offset before IWM planning."""
    if args.iwm_offset != 0.0:
        if not args.iwm_offset_goal_only:
            state_np = state_np.copy()
            state_np[0] += args.iwm_offset
            state_np[1] += args.iwm_offset
        if not args.iwm_offset_state_only:
            goal_np = goal_np.copy()
            goal_np[0] += args.iwm_offset
            goal_np[1] += args.iwm_offset
    return state_np, goal_np


def plan_actions(state_np, goal_np, K):
    """Plan with IWM, return raw actions for first K steps + FM trajectory."""
    state_np, goal_np = _apply_iwm_offset(state_np, goal_np)
    s = torch.tensor(state_np, dtype=torch.float32, device=DEVICE).unsqueeze(0)
    g = torch.tensor(goal_np, dtype=torch.float32, device=DEVICE).unsqueeze(0)

    with torch.no_grad():
        _cuda_sync()
        _iwm_t0 = time.perf_counter()
        actions = iwm(s, g)  # (1, horizon, 2)
        _cuda_sync()
        if _timing_enabled:
            _iwm_time.record(time.perf_counter() - _iwm_t0)
        n_avail = actions.shape[1]  # actual horizon from IWM
        raw_actions = actions[0, :K, :].cpu().numpy()

        pred_traj = None
        if fwd_model is not None:
            fm_steps = min(K, n_avail)  # don't exceed IWM horizon
            n_chunks = fm_steps // FM_CHUNK
            _cuda_sync()
            _fm_t0 = time.perf_counter()
            state = s
            all_states = []
            for k in range(n_chunks):
                seg = actions[:, k * FM_CHUNK:(k + 1) * FM_CHUNK, :]
                seg_states = fwd_model(state, seg)
                all_states.append(seg_states)
                state = seg_states[:, -1, :]
            _cuda_sync()
            if _timing_enabled:
                _fm_time.record(time.perf_counter() - _fm_t0)
            if all_states:
                pred_traj = torch.cat(all_states, dim=1)[0].cpu().numpy()

    return pred_traj, raw_actions


def fm_rollout_batched(state_np, actions_batch, K):
    """Roll out N candidate action sequences through the FM."""
    N = actions_batch.shape[0]
    s = torch.tensor(state_np, dtype=torch.float32, device=DEVICE).unsqueeze(0).expand(N, -1)
    a = torch.tensor(actions_batch, dtype=torch.float32, device=DEVICE)
    with torch.no_grad():
        n_chunks = K // FM_CHUNK
        state = s
        for k in range(n_chunks):
            seg = a[:, k * FM_CHUNK:(k + 1) * FM_CHUNK, :]
            seg_states = fwd_model(state, seg)
            state = seg_states[:, -1, :]
    final_states = state.cpu().numpy()
    return final_states, final_states[:, :2]


def plan_mppi(state_np, goal_np, K):
    """MPPI: Sample N perturbations around IWM plan, score via FM."""
    state_np, goal_np = _apply_iwm_offset(state_np, goal_np)
    N = args.n_samples
    goal_xy = goal_np[:2]
    s = torch.tensor(state_np, dtype=torch.float32, device=DEVICE).unsqueeze(0)
    g = torch.tensor(goal_np, dtype=torch.float32, device=DEVICE).unsqueeze(0)
    with torch.no_grad():
        iwm_actions = iwm(s, g)[0, :K, :].cpu().numpy()
    noise = np.random.randn(N, K, 2).astype(np.float32) * args.mppi_sigma
    candidates = np.clip(iwm_actions[None, :, :] + noise, -1.0, 1.0)
    candidates[0] = iwm_actions
    _, final_xy = fm_rollout_batched(state_np, candidates, K)
    costs = np.linalg.norm(final_xy - goal_xy, axis=1)
    shifted = -(costs - costs.min()) / max(args.mppi_temperature, 1e-8)
    weights = np.exp(shifted)
    weights /= weights.sum() + 1e-8
    best_actions = np.sum(candidates * weights[:, None, None], axis=0)
    return None, np.clip(best_actions, -1.0, 1.0)


def plan_cem(state_np, goal_np, K):
    """CEM: Iteratively refine around IWM warm-start."""
    state_np, goal_np = _apply_iwm_offset(state_np, goal_np)
    N = args.n_samples
    n_elite = max(2, int(N * args.cem_elite_frac))
    goal_xy = goal_np[:2]
    s = torch.tensor(state_np, dtype=torch.float32, device=DEVICE).unsqueeze(0)
    g = torch.tensor(goal_np, dtype=torch.float32, device=DEVICE).unsqueeze(0)
    with torch.no_grad():
        iwm_actions = iwm(s, g)[0, :K, :].cpu().numpy()
    mu = iwm_actions.copy()
    sigma = np.full_like(mu, args.mppi_sigma)
    for it in range(args.cem_iters):
        noise = np.random.randn(N, K, 2).astype(np.float32) * sigma[None, :, :]
        candidates = np.clip(mu[None, :, :] + noise, -1.0, 1.0)
        candidates[0] = np.clip(mu, -1.0, 1.0)
        _, final_xy = fm_rollout_batched(state_np, candidates, K)
        dists = np.linalg.norm(final_xy - goal_xy, axis=1)
        elite_idx = np.argsort(dists)[:n_elite]
        elite = candidates[elite_idx]
        mu = elite.mean(axis=0)
        sigma = elite.std(axis=0) + 1e-4
    return None, np.clip(mu, -1.0, 1.0)


# ─── Evaluate ────────────────────────────────────────────────────────

EXEC_MODE = args.exec_mode
print(f'\nUsing replan_steps={K} (FM chunk multiple), exec_mode={EXEC_MODE}', flush=True)
if args.iwm_offset != 0.0:
    print(f'  IWM offset: +{args.iwm_offset} applied to state/goal xy before planning', flush=True)
if args.planner == 'cardinal_bfs':
    print(f'  Planner: cardinal_bfs | wp_spacing={cardinal_cfg["wp_spacing"]:.2f}, '
          f'mode={cardinal_cfg["wp_sampling_mode"]}, '
          f'advance={cardinal_cfg["wp_advance_dist"]:.2f}, '
          f'skip={cardinal_cfg["wp_skip_dist"]:.2f}, '
          f'stuck={cardinal_cfg["stuck_threshold"]}', flush=True)
if _timing_enabled:
    # GPU warmup — run a few IWM (+ FM) passes before recording, so the
    # reported numbers don't include one-time kernel compile / first-call
    # latency. We discard these timings afterwards.
    print('  Timing ON — warming up IWM (+ FM) on GPU...', flush=True)
    _dummy_state = np.zeros(4, dtype=np.float32)
    _dummy_goal = np.zeros(4, dtype=np.float32)
    for _ in range(10):
        plan_actions(_dummy_state, _dummy_goal, FM_CHUNK)
    _iwm_time.times.clear()
    _fm_time.times.clear()
    _env_step_time.times.clear()
    _plan_cycle_time.times.clear()
    _bfs_replan_time.times.clear()
    _episode_total_time.times.clear()
    print('  Warmup done.', flush=True)

print(f'Evaluating {args.n_goals} goals on {maze}, max_steps={MAX_STEPS}, seed={args.seed}...',
      flush=True)
print('=' * 70)

results = []
successes = 0
progress_file = OUT_DIR / 'progress.json'

if args.d4rl_official:
    print('  *** D4RL OFFICIAL MODE: fixed target, full episode length ***', flush=True)

for i in range(args.n_goals):
    _cuda_sync()
    _ep_t0 = time.perf_counter()
    env.seed(args.seed + i)
    obs = env.reset()
    if not args.d4rl_official:
        env.unwrapped.set_target()
    goal = np.array(env.unwrapped._target, dtype=np.float64).copy()  # (2,)
    state = obs.astype(np.float32)       # (4,)
    final_goal_state = np.array([goal[0], goal[1], 0.0, 0.0], dtype=np.float32)

    # Per-episode tracking
    executed_xy = [state[:2].tolist()]
    executed_states = [state.tolist()]
    planned_trajectories = []  # list of FM-predicted trajectories per replan
    replan_steps_log = []      # step index at each replan
    actions_executed = []
    all_plans = []             # cardinal BFS waypoint chains across replans
    wp_log = []                # per-chunk target waypoint log
    ep_return = 0.0
    success = False
    first_goal_step = None
    n_replans = 0
    n_full_replans = 0
    total_plan_time = 0.0
    step = 0
    waypoints = None
    initial_waypoints = None
    current_waypoints = None
    n_waypoints = 0
    wp_idx = 0
    max_wp_reached = 0
    chunks_since_wp_advance = 0

    if args.planner == 'cardinal_bfs':
        waypoints = occ.plan_cardinal_waypoints(
            state[:2], goal,
            spacing=cardinal_cfg['wp_spacing'],
            sampling_mode=cardinal_cfg['wp_sampling_mode'],
        )
        if waypoints is None or len(waypoints) == 0:
            waypoints = np.array([state[:2], goal], dtype=np.float32)
        initial_waypoints = waypoints.copy()
        current_waypoints = waypoints.copy()
        n_waypoints = len(waypoints)
        wp_idx = 1 if n_waypoints > 1 else 0
        max_wp_reached = wp_idx
        all_plans.append({'step': 0, 'waypoints': waypoints.tolist()})

    # Quick check: start ≈ goal?
    if np.linalg.norm(state[:2] - goal) < args.goal_threshold:
        success = True
        first_goal_step = 0

    keep_mpc = args.no_pd_hold and EXEC_MODE == 'actions_iwm'
    while step < MAX_STEPS and (keep_mpc or not success):
        # Goal check (all modes except actions_iwm break early)
        if EXEC_MODE != 'actions_iwm':
            if np.linalg.norm(state[:2] - goal) < args.goal_threshold:
                success = True
                first_goal_step = step
                break

        # Full replan-cycle timer starts here — covers waypoint mgmt, optional
        # BFS replan, IWM forward, FM rollout, and any CPU/GPU transfers,
        # ending just before the first env.step of this chunk. This is the
        # headline "per-chunk planning cost" number.
        _cuda_sync()
        _plan_cycle_t0 = time.perf_counter()

        plan_goal_state = final_goal_state
        target_xy_for_plan = goal.astype(np.float32)
        if args.planner == 'cardinal_bfs' and waypoints is not None:
            current_xy = state[:2].copy()

            while wp_idx < max(n_waypoints - 1, 0):
                dist_to_wp = float(np.linalg.norm(current_xy - waypoints[wp_idx]))
                if dist_to_wp < cardinal_cfg['wp_advance_dist']:
                    wp_idx += 1
                    max_wp_reached = max(max_wp_reached, wp_idx)
                    chunks_since_wp_advance = 0
                    continue

                if cardinal_cfg['wp_skip_dist'] > 0 and wp_idx + 1 < n_waypoints:
                    best_idx = wp_idx
                    best_dist = dist_to_wp
                    for cand_idx in range(wp_idx + 1, n_waypoints):
                        cand_dist = float(np.linalg.norm(current_xy - waypoints[cand_idx]))
                        if cand_dist < cardinal_cfg['wp_skip_dist'] and cand_dist < best_dist:
                            best_idx = cand_idx
                            best_dist = cand_dist
                    if best_idx > wp_idx:
                        wp_idx = best_idx
                        max_wp_reached = max(max_wp_reached, wp_idx)
                        chunks_since_wp_advance = 0
                        continue
                break

            if chunks_since_wp_advance >= cardinal_cfg['stuck_threshold'] and (args.max_replans <= 0 or n_full_replans < args.max_replans):
                n_full_replans += 1
                _bfs_t0 = time.perf_counter()
                replanned = occ.plan_cardinal_waypoints(
                    current_xy, goal,
                    spacing=cardinal_cfg['wp_spacing'],
                    sampling_mode=cardinal_cfg['wp_sampling_mode'],
                )
                if _timing_enabled:
                    _bfs_replan_time.record(time.perf_counter() - _bfs_t0)
                if replanned is not None and len(replanned) > 0:
                    waypoints = replanned
                    current_waypoints = waypoints.copy()
                    n_waypoints = len(waypoints)
                    wp_idx = 1 if n_waypoints > 1 else 0
                    max_wp_reached = max(max_wp_reached, wp_idx)
                    chunks_since_wp_advance = 0
                    all_plans.append({'step': step, 'waypoints': waypoints.tolist()})

            target_xy_for_plan = waypoints[min(wp_idx, max(n_waypoints - 1, 0))].copy()
            if cardinal_cfg['target_dist_min'] > 0 and cardinal_cfg['target_dist_max'] > 0:
                direction = target_xy_for_plan - current_xy
                dir_norm = float(np.linalg.norm(direction))
                if dir_norm > 1e-6:
                    direction = direction / dir_norm
                    rand_dist = np.random.uniform(cardinal_cfg['target_dist_min'],
                                                  cardinal_cfg['target_dist_max'])
                    if wp_idx >= n_waypoints - 1:
                        rand_dist = min(rand_dist, dir_norm)
                    target_xy_for_plan = current_xy + direction * rand_dist

            wp_log.append({
                'step': step,
                'wp_idx': int(wp_idx),
                'target_xy': target_xy_for_plan.tolist(),
                'waypoint_xy': waypoints[min(wp_idx, max(n_waypoints - 1, 0))].tolist(),
                'pos_xy': current_xy.tolist(),
            })
            plan_goal_state = np.array([target_xy_for_plan[0], target_xy_for_plan[1], 0.0, 0.0], dtype=np.float32)

        # Plan
        t0 = time.time()
        if EXEC_MODE == 'mppi':
            pred_traj, raw_actions = plan_mppi(state, plan_goal_state, K)
        elif EXEC_MODE == 'cem':
            pred_traj, raw_actions = plan_cem(state, plan_goal_state, K)
        else:
            pred_traj, raw_actions = plan_actions(state, plan_goal_state, K)
        plan_time = time.time() - t0
        total_plan_time += plan_time

        # Close the per-chunk replan-cycle timer. Everything above is the cost
        # of "decide what to do next"; everything below is env.step execution.
        _cuda_sync()
        if _timing_enabled:
            _plan_cycle_time.record(time.perf_counter() - _plan_cycle_t0)

        replan_steps_log.append(step)
        n_replans += 1

        # Save predicted trajectory (xy only) for visualization
        if pred_traj is not None:
            planned_trajectories.append({
                'step': step,
                'start_xy': state[:2].tolist(),
                'predicted_xy': pred_traj[:, :2].tolist(),
                'target_xy': target_xy_for_plan.tolist(),
            })

        if EXEC_MODE in ('actions', 'actions_iwm', 'mppi', 'cem'):
            # Execute raw actions
            for sub_step in range(min(K, len(raw_actions))):
                if step >= MAX_STEPS:
                    break

                if EXEC_MODE == 'actions':
                    if np.linalg.norm(state[:2] - goal) < args.goal_threshold:
                        success = True
                        first_goal_step = step
                        break

                action = np.clip(raw_actions[sub_step], -1.0, 1.0)
                obs, reward, done, info = env.step(action.astype(np.float32))
                state = obs.astype(np.float32)
                ep_return += reward
                executed_xy.append(state[:2].tolist())
                executed_states.append(state.tolist())
                actions_executed.append(action.tolist())
                step += 1

                if EXEC_MODE == 'actions_iwm' and not success:
                    if np.linalg.norm(state[:2] - goal) < args.goal_threshold:
                        success = True
                        first_goal_step = step
                        if not args.no_pd_hold:
                            break

                if done:
                    break

            # Stop replanning if close
            if EXEC_MODE in ('actions_iwm', 'mppi', 'cem'):
                if np.linalg.norm(state[:2] - goal) < args.goal_threshold:
                    if not success:
                        success = True
                        first_goal_step = step
                    if not args.no_pd_hold:
                        break

        else:
            # Waypoint mode: PD-control to endpoint
            wp_x, wp_y = float(pred_traj[-1, 0]), float(pred_traj[-1, 1])
            wp_x, wp_y = occ.snap_towards_free(wp_x, wp_y, state[0], state[1])

            for sub_step in range(K):
                if step >= MAX_STEPS:
                    break
                if np.linalg.norm(state[:2] - goal) < args.goal_threshold:
                    success = True
                    first_goal_step = step
                    break
                dist_wp = np.linalg.norm(state[:2] - np.array([wp_x, wp_y]))
                if dist_wp < args.waypoint_threshold and sub_step > 0:
                    break
                target = np.array([wp_x, wp_y], dtype=np.float32)
                action = args.K_p * (target - state[:2]) + args.K_d * (0.0 - state[2:])
                action = np.clip(action, -1.0, 1.0)
                obs, reward, done, info = env.step(action.astype(np.float32))
                state = obs.astype(np.float32)
                ep_return += reward
                executed_xy.append(state[:2].tolist())
                executed_states.append(state.tolist())
                actions_executed.append(action.tolist())
                step += 1
                if done:
                    break

        if success and not keep_mpc:
            break

        if args.planner == 'cardinal_bfs':
            chunks_since_wp_advance += 1

    # PD-hold for remaining steps (maximize reward)
    hold_steps = 0
    if success and step < MAX_STEPS and not args.no_pd_hold:
        if EXEC_MODE in ('actions_iwm', 'mppi', 'cem'):
            hold_target = state[:2].copy()
        else:
            hold_target = goal.astype(np.float32)
        for _ in range(MAX_STEPS - step):
            action = args.K_p * (hold_target - state[:2]) + args.K_d * (0.0 - state[2:])
            action = np.clip(action, -1.0, 1.0)
            obs, reward, done, info = env.step(action.astype(np.float32))
            state = obs.astype(np.float32)
            ep_return += reward
            executed_xy.append(state[:2].tolist())
            actions_executed.append(action.tolist())
            step += 1
            hold_steps += 1
            if done:
                break

    # Final check
    if not success:
        final_dist_check = np.linalg.norm(state[:2] - goal)
        if final_dist_check < args.goal_threshold:
            success = True
            first_goal_step = step

    final_dist = float(np.linalg.norm(state[:2] - goal))
    if success:
        successes += 1

    # D4RL score for this episode
    d4rl_ref = maze_cfg['d4rl_random']
    d4rl_exp = maze_cfg['d4rl_expert']

    ep_result = {
        'episode': i + 1,
        'seed': args.seed + i,
        'success': bool(success),
        'start_xy': executed_xy[0],
        'goal_xy': goal.tolist(),
        'final_dist': final_dist,
        'return': float(ep_return),
        'steps': step,
        'steps_to_goal': first_goal_step,
        'hold_steps': hold_steps,
        'n_replans': n_replans,
        'total_plan_time_ms': float(total_plan_time * 1000),
        'plan_time_ms': float(total_plan_time * 1000 / n_replans) if n_replans > 0 else 0,
        'trajectory': executed_xy,
        'planned_trajectories': planned_trajectories,
        'waypoints': waypoints.tolist() if waypoints is not None else [],
        'initial_waypoints': initial_waypoints.tolist() if initial_waypoints is not None else [],
        'current_waypoints': current_waypoints.tolist() if current_waypoints is not None else [],
        'all_plans': all_plans,
        'wp_log': wp_log,
        'planner': args.planner,
        'wp_sampling_mode': cardinal_cfg['wp_sampling_mode'] if args.planner == 'cardinal_bfs' else None,
        'n_waypoints': int(n_waypoints),
        'wp_reached': int(max_wp_reached),
        'n_full_replans': int(n_full_replans),
        'actions_executed': actions_executed,
        'velocity': [s[2:] for s in executed_states[:step - hold_steps + 1]]
                    if executed_states else [],
    }
    _cuda_sync()
    if _timing_enabled:
        _episode_total_time.record(time.perf_counter() - _ep_t0)
    results.append(ep_result)

    # Write incremental progress.json
    avg_return = np.mean([r['return'] for r in results])
    d4rl_score = 100.0 * (avg_return - d4rl_ref) / (d4rl_exp - d4rl_ref)
    _progress = {
        'n_goals': args.n_goals,
        'completed': i + 1,
        'successes': successes,
        'success_rate': successes / (i + 1) * 100,
        'd4rl_score': d4rl_score,
        'mean_return': float(avg_return),
        'episodes': results,
    }
    try:
        progress_file.write_text(json.dumps(_progress))
    except Exception:
        pass

    # Console output
    verbose = (i < 5) or ((i + 1) % 10 == 0) or ((i + 1) == args.n_goals)
    if verbose:
        status = 'OK' if success else 'FAIL'
        sr = successes / (i + 1) * 100
        planner_info = ''
        if args.planner == 'cardinal_bfs':
            planner_info = (f' | wp={max_wp_reached}/{max(n_waypoints - 1, 0)} '
                            f'| bfs={n_full_replans}')
        print(f'  [{i+1:3d}/{args.n_goals}] {status} | dist={final_dist:.3f} | '
              f'steps={step} | replans={n_replans} | ret={ep_return:.1f} | '
              f'SR={sr:.0f}% | D4RL={d4rl_score:.1f}{planner_info}',
              flush=True)


# ─── Summary ──────────────────────────────────────────────────────────

env.close()

success_rate = successes / args.n_goals * 100
all_returns = [r['return'] for r in results]
mean_return = float(np.mean(all_returns))
std_return = float(np.std(all_returns))
if args.d4rl_official:
    _score_env = gym.make(ENV_ID)
    d4rl_score = float(_score_env.get_normalized_score(mean_return) * 100.0)
    _score_env.close()
else:
    d4rl_score = 100.0 * (mean_return - maze_cfg['d4rl_random']) / (maze_cfg['d4rl_expert'] - maze_cfg['d4rl_random'])

final_dists = [r['final_dist'] for r in results]
all_steps = [r['steps'] for r in results]
replan_counts = [r['n_replans'] for r in results]
full_replan_counts = [r.get('n_full_replans', 0) for r in results]
succ_steps = [r['steps_to_goal'] for r in results if r['success'] and r['steps_to_goal'] is not None]

print(f'\n{"="*70}')
print(f'RESULTS: {maze} — {args.n_goals} goals ({args.planner}, {EXEC_MODE}, K={K})')
print(f'{"="*70}')
print(f'  Success Rate:  {success_rate:.1f}% ({successes}/{args.n_goals})')
print(f'  D4RL Score:    {d4rl_score:.1f}')
print(f'  Mean Return:   {mean_return:.1f} ± {std_return:.1f}')
print(f'  Mean Dist:     {np.mean(final_dists):.3f} ± {np.std(final_dists):.3f}')
if succ_steps:
    print(f'  Steps to Goal: {np.mean(succ_steps):.0f} (success only)')
print(f'  Avg Replans:   {np.mean(replan_counts):.1f}')
if args.planner == 'cardinal_bfs':
    print(f'  BFS Replans:   {np.mean(full_replan_counts):.1f}')
print(f'{"="*70}')

# Save final results
method_tag = 'cardinal_bfs' if args.planner == 'cardinal_bfs' else 'MPC'
summary = {
    'method': f'IWM_v1_{method_tag}_K{K}_{EXEC_MODE}',
    'maze': maze,
    'env_id': ENV_ID,
    'model_path': str(model_path),
    'fm_path': str(fm_path) if fm_path else None,
    'model_epoch': ckpt.get('epoch', -1),
    'n_params': n_params,
    'horizon': horizon,
    'replan_steps': K,
    'exec_mode': EXEC_MODE,
    'planner': args.planner,
    'n_goals': args.n_goals,
    'seed': args.seed,
    'max_steps': MAX_STEPS,
    'goal_threshold': args.goal_threshold,
    'K_p': args.K_p,
    'K_d': args.K_d,
    'wp_spacing': cardinal_cfg['wp_spacing'] if args.planner == 'cardinal_bfs' else None,
    'wp_sampling_mode': cardinal_cfg['wp_sampling_mode'] if args.planner == 'cardinal_bfs' else None,
    'wp_advance_dist': cardinal_cfg['wp_advance_dist'] if args.planner == 'cardinal_bfs' else None,
    'wp_skip_dist': cardinal_cfg['wp_skip_dist'] if args.planner == 'cardinal_bfs' else None,
    'stuck_threshold': cardinal_cfg['stuck_threshold'] if args.planner == 'cardinal_bfs' else None,
    'max_replans': args.max_replans if args.planner == 'cardinal_bfs' else None,
    'success_rate': success_rate,
    'n_successes': successes,
    'mean_return': mean_return,
    'std_return': std_return,
    'd4rl_score': d4rl_score,
    'mean_final_dist': float(np.mean(final_dists)),
    'std_final_dist': float(np.std(final_dists)),
    'mean_steps_to_goal': float(np.mean(succ_steps)) if succ_steps else -1,
    'mean_replans': float(np.mean(replan_counts)),
    'mean_full_replans': float(np.mean(full_replan_counts)),
    'timestamp': timestamp,
    'timing': ({
        'enabled': True,
        'device': DEVICE,
        'episode_total': _episode_total_time.to_dict(),
        'plan_cycle':  _plan_cycle_time.to_dict(),
        'iwm_forward': _iwm_time.to_dict(),
        'fm_rollout':  _fm_time.to_dict(),
        'bfs_replan':  _bfs_replan_time.to_dict(),
        'env_step':    _env_step_time.to_dict(),
    } if _timing_enabled else {'enabled': False}),
    'episodes': results,
}
(OUT_DIR / 'results.json').write_text(json.dumps(summary, indent=2))
print(f'  Saved to: {OUT_DIR / "results.json"}', flush=True)
if _timing_enabled:
    print('\n--- TIMING SUMMARY ---')
    for name, stats in [('episode',     _episode_total_time),
                        ('plan_cycle',  _plan_cycle_time),
                        ('IWM forward', _iwm_time),
                        ('FM rollout',  _fm_time),
                        ('BFS replan',  _bfs_replan_time),
                        ('env.step',    _env_step_time)]:
        d = stats.to_dict()
        print(f'  {name:12s}  calls={d["calls"]:7d}  mean={d["mean_ms"]:7.3f} ms  '
              f'p50={d["p50_ms"]:7.3f}  p90={d["p90_ms"]:7.3f}  p99={d["p99_ms"]:7.3f}  '
              f'total={d["total_sec"]:7.2f} s')
    print('-' * 70, flush=True)

# Stop live monitor and run a blocking --once finalization pass so that every
# episode plot + the dashboard reflect the final results.json. Needed because
# on fast evals the live monitor can't keep up with per-episode rendering and
# gets killed mid-pass (see docs/project-diary/ 2026-04-23 notes).
if monitor_proc is not None:
    monitor_proc.terminate()
    try:
        monitor_proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        monitor_proc.kill()
    print(f'  Live monitor stopped (PID {monitor_proc.pid})', flush=True)

    print('  Running final monitor pass (--once)...', flush=True)
    finalize_cmd = list(monitor_cmd) + ['--once']
    finalize_log = open(OUT_DIR / 'monitor.log', 'a')
    r = subprocess.run(finalize_cmd, stdout=finalize_log, stderr=subprocess.STDOUT)
    finalize_log.close()
    if r.returncode == 0:
        print('  Final monitor pass complete — all plots rendered.', flush=True)
    else:
        print(f'  Final monitor pass failed (exit {r.returncode}) — see monitor.log',
              flush=True)
