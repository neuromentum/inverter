"""2-qubit MLP inverter: U_target ∈ U(4) → (4-channel piecewise-constant pulse).

Input encodings
---------------
- "real32": Re/Im flatten of the 4×4 complex unitary. Includes global phase;
  the network has to learn invariance. Dim = 32.
- "real32_su4": project to SU(4) by dividing by det(U)^(1/4) (with canonical
  sign convention chosen to fix the Z_4 ambiguity), then Re/Im flatten.
  Global-phase-invariant. Dim = 32.

Output
------
4 * n_slices reals, reshaped as (4, n_slices) — drives (Ω_x_1, Ω_y_1, Ω_x_2, Ω_y_2).
The training loop applies tanh × omega_max to enforce the amplitude cap.
"""
from __future__ import annotations

from typing import Sequence

import equinox as eqx
import jax
import jax.numpy as jnp


# --------------------------------------------------------------------------
# Encodings
# --------------------------------------------------------------------------
def encode_real32(U):
    """Flat Re/Im of the 4×4 unitary (no SU(4) projection)."""
    flat = U.reshape(-1)
    return jnp.concatenate([jnp.real(flat), jnp.imag(flat)]).astype(jnp.float32)


def _to_su4(U):
    """Project 4×4 unitary to SU(4) with a canonical sign for the Z_4 ambiguity.

    `U / det(U)^(1/4)` has a 4-fold ambiguity (4 fourth-roots of det(U)).
    We pick the root where the SU(4) matrix's first non-near-zero "Pauli
    coefficient" (in a fixed canonical order) is positive. This is the d=4
    analog of Phase 4's SU(2) sign canonicalization.
    """
    det = jnp.linalg.det(U)
    abs_det = jnp.abs(det)
    arg_det = jnp.angle(det)
    # 4 candidate roots: arg/4 + k*π/2 for k=0,1,2,3
    candidates = jnp.stack([
        U / (jnp.power(abs_det, 0.25) * jnp.exp(1j * (arg_det / 4 + k * jnp.pi / 2)))
        for k in range(4)
    ])
    # Score each candidate by Re of trace; picking the largest gives a deterministic
    # canonical choice. (Equivalent to lex-positive in the trace coordinate.)
    scores = jnp.real(jax.vmap(jnp.trace)(candidates))
    idx = jnp.argmax(scores)
    return candidates[idx]


def encode_real32_su4(U):
    """SU(4)-projected Re/Im flatten. Global-phase invariant, 32 dims."""
    U_su = _to_su4(U)
    flat = U_su.reshape(-1)
    return jnp.concatenate([jnp.real(flat), jnp.imag(flat)]).astype(jnp.float32)


def encode_kak_basic(U):
    """KAK-flavored encoding: Makhlin local-equivalence invariants of the
    SU(4)-projected unitary, plus magic-basis trace features.

    Steps:
      U_su = U / det(U)^(1/4)    (canonical sign for the Z_4 ambiguity)
      m = B† U_su B              (B = magic basis)
      γ = m m^T                  (complex symmetric; for SU(4) U, γ ∈ SO(4)_C)
      G_1 = Tr(γ)² / 16          (Makhlin; invariant under local SU(2) gates)
      G_2 = Tr(γ²) / 4           (Makhlin)
      Eigenvalue phases of γ:    4 angles summing to 0 (det γ = 1 for SU(4))

    Global-phase invariant (SU(4) projection) and local-SU(2)-invariant
    (the Makhlin construction). Returns 8 real features per unitary.
    """
    U_su = _to_su4(U)
    B = (1.0 / jnp.sqrt(2.0)) * jnp.array([
        [1, 0,    0,  1j],
        [0, 1j,   1,   0],
        [0, 1j,  -1,   0],
        [1, 0,    0, -1j],
    ], dtype=jnp.complex64)
    m = B.conj().T @ U_su @ B
    gamma = m @ m.T
    tr1 = jnp.trace(gamma)
    tr2 = jnp.trace(gamma @ gamma)
    G1 = tr1 * tr1 / 16.0
    G2 = tr2 / 4.0
    feats = jnp.stack([
        jnp.real(G1), jnp.imag(G1),
        jnp.real(G2), jnp.imag(G2),
        jnp.real(tr1), jnp.imag(tr1),
        jnp.real(tr2), jnp.imag(tr2),
    ])
    return feats.astype(jnp.float32)




def encode_kak_inv(U):
    """real32_su4 + KAK basic invariants (40 dims).

    Adds the 8 magic-basis features to the raw SU(4) flatten so the network
    has explicit access to local-equivalence invariants without losing the
    raw structural encoding it already learns from.
    """
    raw = encode_real32_su4(U)               # (32,)
    inv = encode_kak_basic(U)                # (8,)
    return jnp.concatenate([raw, inv]).astype(jnp.float32)


_ENCODERS_2Q = {
    "real32":     (encode_real32,      32),
    "real32_su4": (encode_real32_su4,  32),
    "kak_basic":  (encode_kak_basic,    8),
    "kak_inv":    (encode_kak_inv,     40),
}


def get_encoder_2q(name: str):
    if name not in _ENCODERS_2Q:
        raise ValueError(f"unknown 2q encoding: {name}; choose from {list(_ENCODERS_2Q)}")
    return _ENCODERS_2Q[name]


# --------------------------------------------------------------------------
# MLP
# --------------------------------------------------------------------------
class MLPInverter2Q(eqx.Module):
    layers: list
    n_slices: int = eqx.field(static=True)
    n_channels: int = eqx.field(static=True)
    activation: str = eqx.field(static=True)
    input_encoding: str = eqx.field(static=True)

    def __init__(
        self,
        hidden_dims: Sequence[int],
        n_slices: int,
        *,
        n_channels: int = 4,
        activation: str = "gelu",
        input_encoding: str = "real32",
        key,
    ):
        self.n_slices = n_slices
        self.n_channels = n_channels
        self.activation = activation
        self.input_encoding = input_encoding
        _, in_dim = get_encoder_2q(input_encoding)
        out_dim = n_channels * n_slices
        dims = [in_dim, *hidden_dims, out_dim]
        keys = jax.random.split(key, len(dims) - 1)
        self.layers = [
            eqx.nn.Linear(dims[i], dims[i + 1], key=keys[i])
            for i in range(len(dims) - 1)
        ]

    def __call__(self, U: jnp.ndarray) -> jnp.ndarray:
        encode_fn, _ = get_encoder_2q(self.input_encoding)
        x = encode_fn(U)
        act_fn = {"gelu": jax.nn.gelu, "relu": jax.nn.relu, "tanh": jnp.tanh}[
            self.activation
        ]
        for lin in self.layers[:-1]:
            x = act_fn(lin(x))
        x = self.layers[-1](x)
        return x.reshape(self.n_channels, self.n_slices)


def build_inverter_2q(arch: str, hidden_dims, n_slices, activation, key,
                       input_encoding: str = "real32", n_channels: int = 4):
    if arch == "mlp":
        return MLPInverter2Q(
            hidden_dims, n_slices,
            n_channels=n_channels,
            activation=activation,
            input_encoding=input_encoding, key=key,
        )
    raise ValueError(f"unknown arch: {arch}")
