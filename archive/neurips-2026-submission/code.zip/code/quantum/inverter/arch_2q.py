"""Architectures for the 2-qubit inverter.

All architectures share the same I/O contract:
    input  : 4×4 complex unitary U
    output : (n_channels, n_slices) raw scores (pre-tanh)

Encoding is shared via `inverter.mlp_2q.get_encoder_2q`.

Architectures
-------------
- mlp        : flat MLP (baseline, equivalent to MLPInverter2Q in mlp_2q.py)
- gru        : GRU rolling over n_slices steps; one pulse step per timestep
- transformer: position-embedded slice tokens + self-attention, conditioned on encoded U
- conv       : 1D conv stack over the slice axis with broadcast U context
- unet       : U-Net over the slice axis (down/up sampling with skip connections)

All factory entries are wired through `build_inverter_2q_arch(...)`.
"""
from __future__ import annotations

from typing import Sequence

import equinox as eqx
import jax
import jax.numpy as jnp

from inverter.mlp_2q import get_encoder_2q


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------
def _act(name: str):
    return {"gelu": jax.nn.gelu, "relu": jax.nn.relu, "tanh": jnp.tanh}[name]


def _encode(U, input_encoding):
    encode_fn, _ = get_encoder_2q(input_encoding)
    return encode_fn(U)


def _bumpup_output_bias(layer, key, scale: float = 0.5):
    """Re-initialize a Linear/Conv1d layer's bias with U(-scale, scale).

    Used to escape the F=0.25 'identity-gate' trivial minimum on 2-qubit:
    the default tiny bias init produces near-zero initial pulses which lie
    in a flat region of the loss landscape.
    """
    new_bias = jax.random.uniform(key, layer.bias.shape, minval=-scale, maxval=scale)
    return eqx.tree_at(lambda l: l.bias, layer, new_bias)


# --------------------------------------------------------------------------
# MLP (baseline)
# --------------------------------------------------------------------------
class MLPInverter(eqx.Module):
    layers: list
    n_slices: int = eqx.field(static=True)
    n_channels: int = eqx.field(static=True)
    activation: str = eqx.field(static=True)
    input_encoding: str = eqx.field(static=True)

    def __init__(
        self, hidden_dims: Sequence[int], n_slices: int,
        *, n_channels: int = 4, activation: str = "gelu",
        input_encoding: str = "real32_su4", key,
    ):
        self.n_slices = n_slices
        self.n_channels = n_channels
        self.activation = activation
        self.input_encoding = input_encoding
        _, in_dim = get_encoder_2q(input_encoding)
        out_dim = n_channels * n_slices
        dims = [in_dim, *hidden_dims, out_dim]
        keys = jax.random.split(key, len(dims) - 1)
        self.layers = [eqx.nn.Linear(dims[i], dims[i+1], key=keys[i]) for i in range(len(dims)-1)]

    def __call__(self, U):
        x = _encode(U, self.input_encoding)
        f = _act(self.activation)
        for lin in self.layers[:-1]:
            x = f(lin(x))
        x = self.layers[-1](x)
        return x.reshape(self.n_channels, self.n_slices)


# --------------------------------------------------------------------------
# GRU
# --------------------------------------------------------------------------
class GRUInverter(eqx.Module):
    """GRU rolling over n_slices steps. Context vector (encoded U) plus a
    learnable per-step embedding are used as the input at each timestep
    (the per-step embedding breaks the temporal symmetry, so the network
    doesn't collapse to a constant pulse)."""
    encoder: eqx.nn.MLP
    step_embed: jnp.ndarray
    cell: eqx.nn.GRUCell
    proj: eqx.nn.Linear
    out_bias_per_pos: jnp.ndarray
    n_slices: int = eqx.field(static=True)
    n_channels: int = eqx.field(static=True)
    input_encoding: str = eqx.field(static=True)

    def __init__(
        self, hidden_dim: int, n_slices: int,
        *, n_channels: int = 4, n_encode_layers: int = 3,
        input_encoding: str = "real32_su4", key,
    ):
        self.n_slices = n_slices
        self.n_channels = n_channels
        self.input_encoding = input_encoding
        _, in_dim = get_encoder_2q(input_encoding)
        k1, k2, k3, k4, k5 = jax.random.split(key, 5)
        self.encoder = eqx.nn.MLP(
            in_size=in_dim, out_size=hidden_dim, width_size=hidden_dim,
            depth=n_encode_layers, activation=jax.nn.gelu, key=k1,
        )
        self.step_embed = jax.random.normal(k2, (n_slices, hidden_dim)) * 0.3
        self.cell = eqx.nn.GRUCell(input_size=hidden_dim, hidden_size=hidden_dim, key=k3)
        proj = eqx.nn.Linear(hidden_dim, n_channels, key=k4)
        self.proj = _bumpup_output_bias(proj, jax.random.fold_in(k4, 1), scale=0.5)
        # Per-position output bias (breaks position-shared output collapse)
        self.out_bias_per_pos = jax.random.uniform(
            k5, (n_slices, n_channels), minval=-0.5, maxval=0.5,
        )

    def __call__(self, U):
        x = _encode(U, self.input_encoding)
        ctx = self.encoder(x)
        inputs = ctx[None, :] + self.step_embed

        def step(h, inp):
            h_new = self.cell(inp, h)
            return h_new, self.proj(h_new)

        h0 = jnp.zeros_like(ctx)
        _, outputs = jax.lax.scan(step, h0, inputs)   # (n_slices, n_channels)
        outputs = outputs + self.out_bias_per_pos
        return outputs.T   # (n_channels, n_slices)


# --------------------------------------------------------------------------
# Transformer
# --------------------------------------------------------------------------
class TransformerBlock(eqx.Module):
    attn: eqx.nn.MultiheadAttention
    ln1: eqx.nn.LayerNorm
    mlp: eqx.nn.MLP
    ln2: eqx.nn.LayerNorm

    def __init__(self, d_model: int, n_heads: int, ff_mult: int, key):
        k1, k2 = jax.random.split(key, 2)
        self.attn = eqx.nn.MultiheadAttention(num_heads=n_heads, query_size=d_model, key=k1)
        self.ln1 = eqx.nn.LayerNorm(d_model)
        self.mlp = eqx.nn.MLP(
            in_size=d_model, out_size=d_model, width_size=d_model * ff_mult,
            depth=1, activation=jax.nn.gelu, key=k2,
        )
        self.ln2 = eqx.nn.LayerNorm(d_model)

    def __call__(self, x):
        # x: (n_slices, d_model)
        h = jax.vmap(self.ln1)(x)
        h = self.attn(h, h, h)
        x = x + h
        h = jax.vmap(self.ln2)(x)
        h = jax.vmap(self.mlp)(h)
        return x + h


class TransformerInverter(eqx.Module):
    encoder: eqx.nn.MLP
    pos_embed: jnp.ndarray
    blocks: list
    proj: eqx.nn.Linear
    out_bias_per_pos: jnp.ndarray
    n_slices: int = eqx.field(static=True)
    n_channels: int = eqx.field(static=True)
    input_encoding: str = eqx.field(static=True)

    def __init__(
        self, d_model: int, n_layers: int, n_heads: int, n_slices: int,
        *, n_channels: int = 4, ff_mult: int = 4,
        input_encoding: str = "real32_su4", key,
    ):
        self.n_slices = n_slices
        self.n_channels = n_channels
        self.input_encoding = input_encoding
        _, in_dim = get_encoder_2q(input_encoding)
        keys = jax.random.split(key, n_layers + 4)
        self.encoder = eqx.nn.MLP(
            in_size=in_dim, out_size=d_model, width_size=d_model,
            depth=2, activation=jax.nn.gelu, key=keys[0],
        )
        self.pos_embed = jax.random.normal(keys[1], (n_slices, d_model)) * 0.3
        self.blocks = [TransformerBlock(d_model, n_heads, ff_mult, keys[2+i]) for i in range(n_layers)]
        proj = eqx.nn.Linear(d_model, n_channels, key=keys[-2])
        self.proj = _bumpup_output_bias(proj, jax.random.fold_in(keys[-2], 1), scale=0.5)
        # Per-position output bias (breaks output-position symmetry)
        self.out_bias_per_pos = jax.random.uniform(
            keys[-1], (n_slices, n_channels), minval=-0.5, maxval=0.5,
        )

    def __call__(self, U):
        x = _encode(U, self.input_encoding)
        ctx = self.encoder(x)
        h = self.pos_embed + ctx[None, :]
        for block in self.blocks:
            h = block(h)
        out = jax.vmap(self.proj)(h) + self.out_bias_per_pos
        return out.T                                    # (n_channels, n_slices)


# --------------------------------------------------------------------------
# 1D Conv
# --------------------------------------------------------------------------
class ConvInverter(eqx.Module):
    encoder: eqx.nn.MLP
    pos_bias: jnp.ndarray
    convs: list
    proj: eqx.nn.Conv1d
    out_bias_per_pos: jnp.ndarray   # (n_channels, n_slices); breaks output-position symmetry
    n_slices: int = eqx.field(static=True)
    n_channels: int = eqx.field(static=True)
    input_encoding: str = eqx.field(static=True)
    activation: str = eqx.field(static=True)

    def __init__(
        self, d_model: int, n_layers: int, kernel_size: int, n_slices: int,
        *, n_channels: int = 4, activation: str = "gelu",
        input_encoding: str = "real32_su4", key,
    ):
        self.n_slices = n_slices
        self.n_channels = n_channels
        self.input_encoding = input_encoding
        self.activation = activation
        _, in_dim = get_encoder_2q(input_encoding)
        keys = jax.random.split(key, n_layers + 4)
        self.encoder = eqx.nn.MLP(
            in_size=in_dim, out_size=d_model, width_size=d_model,
            depth=2, activation=jax.nn.gelu, key=keys[0],
        )
        # Per-position bias on the *input* field (time-symmetry breaker on input)
        self.pos_bias = jax.random.normal(keys[1], (d_model, n_slices)) * 0.3
        pad = kernel_size // 2
        self.convs = [
            eqx.nn.Conv1d(d_model, d_model, kernel_size, padding=pad, key=keys[i+2])
            for i in range(n_layers)
        ]
        proj = eqx.nn.Conv1d(d_model, n_channels, 1, padding=0, key=keys[-2])
        self.proj = _bumpup_output_bias(proj, jax.random.fold_in(keys[-2], 1), scale=0.5)
        # Per-position output bias — adds (n_channels × n_slices) free params.
        # This is the actual fix for escape: translation-equivariant convs
        # alone produce constant pulses, which sit at the F=0.25 saddle. The
        # per-position output bias gives a non-trivial initial pulse that varies
        # across BOTH channels and time, providing a non-zero gradient signal.
        self.out_bias_per_pos = jax.random.uniform(
            keys[-1], (n_channels, n_slices), minval=-0.5, maxval=0.5,
        )

    def __call__(self, U):
        x = _encode(U, self.input_encoding)
        ctx = self.encoder(x)
        h = ctx[:, None] + self.pos_bias
        f = _act(self.activation)
        for conv in self.convs:
            h = f(conv(h))
        return self.proj(h) + self.out_bias_per_pos


# --------------------------------------------------------------------------
# U-Net (1D)
# --------------------------------------------------------------------------
class UNetInverter(eqx.Module):
    """U-Net over the slice axis. n_slices must be divisible by 2**n_levels.

    Each down step halves the time axis and doubles the feature dim.
    Skip connections are additive (cleanest dim-tracking).
    """
    encoder: eqx.nn.MLP
    in_conv: eqx.nn.Conv1d
    down_blocks: list
    bottleneck: eqx.nn.Conv1d
    up_blocks: list
    out_conv: eqx.nn.Conv1d
    n_slices: int = eqx.field(static=True)
    n_channels: int = eqx.field(static=True)
    input_encoding: str = eqx.field(static=True)
    base_dim: int = eqx.field(static=True)
    n_levels: int = eqx.field(static=True)
    activation: str = eqx.field(static=True)

    def __init__(
        self, base_dim: int, n_levels: int, n_slices: int,
        *, n_channels: int = 4, activation: str = "gelu",
        input_encoding: str = "real32_su4", key,
    ):
        self.n_slices = n_slices
        self.n_channels = n_channels
        self.input_encoding = input_encoding
        self.base_dim = base_dim
        self.n_levels = n_levels
        self.activation = activation
        _, in_dim = get_encoder_2q(input_encoding)
        keys = jax.random.split(key, 2 * n_levels + 4)
        self.encoder = eqx.nn.MLP(
            in_size=in_dim, out_size=base_dim, width_size=base_dim,
            depth=2, activation=jax.nn.gelu, key=keys[0],
        )
        self.in_conv = eqx.nn.Conv1d(base_dim, base_dim, kernel_size=3, padding=1, key=keys[1])
        # Down: stride-2 conv that doubles channels
        self.down_blocks = [
            eqx.nn.Conv1d(base_dim * (2 ** i), base_dim * (2 ** (i + 1)),
                          kernel_size=4, stride=2, padding=1, key=keys[2 + i])
            for i in range(n_levels)
        ]
        bot_dim = base_dim * (2 ** n_levels)
        self.bottleneck = eqx.nn.Conv1d(bot_dim, bot_dim, kernel_size=3, padding=1, key=keys[2 + n_levels])
        # Up: stride-2 transpose conv that halves channels
        self.up_blocks = [
            eqx.nn.ConvTranspose1d(
                base_dim * (2 ** (n_levels - i)), base_dim * (2 ** (n_levels - i - 1)),
                kernel_size=4, stride=2, padding=1, key=keys[3 + n_levels + i],
            )
            for i in range(n_levels)
        ]
        self.out_conv = eqx.nn.Conv1d(base_dim, n_channels, kernel_size=1, padding=0, key=keys[-1])

    def __call__(self, U):
        x = _encode(U, self.input_encoding)
        ctx = self.encoder(x)                                # (base_dim,)
        h = jnp.broadcast_to(ctx[:, None], (ctx.shape[0], self.n_slices))
        f = _act(self.activation)
        h = f(self.in_conv(h))
        skips = []
        for down in self.down_blocks:
            skips.append(h)
            h = f(down(h))
        h = f(self.bottleneck(h))
        for up, skip in zip(self.up_blocks, reversed(skips)):
            h = f(up(h))
            # Equal sizes by construction (n_slices % 2**n_levels == 0); add skip.
            h = h[:, : skip.shape[1]] + skip
        return self.out_conv(h)


# --------------------------------------------------------------------------
# Factory
# --------------------------------------------------------------------------
# --------------------------------------------------------------------------
# MLP with LayerNorm (pre-norm)
# --------------------------------------------------------------------------
class MLPLNInverter(eqx.Module):
    in_lin: eqx.nn.Linear
    norms: list
    linears: list
    n_slices: int = eqx.field(static=True)
    n_channels: int = eqx.field(static=True)
    activation: str = eqx.field(static=True)
    input_encoding: str = eqx.field(static=True)

    def __init__(
        self, hidden_dims: Sequence[int], n_slices: int,
        *, n_channels: int = 4, activation: str = "gelu",
        input_encoding: str = "real32_su4", key,
    ):
        self.n_slices = n_slices
        self.n_channels = n_channels
        self.activation = activation
        self.input_encoding = input_encoding
        _, in_dim = get_encoder_2q(input_encoding)
        out_dim = n_channels * n_slices
        keys = jax.random.split(key, len(hidden_dims) + 2)
        self.in_lin = eqx.nn.Linear(in_dim, hidden_dims[0], key=keys[0])
        self.norms, self.linears = [], []
        dims = list(hidden_dims) + [out_dim]
        for i in range(len(dims) - 1):
            self.norms.append(eqx.nn.LayerNorm(dims[i]))
            self.linears.append(eqx.nn.Linear(dims[i], dims[i + 1], key=keys[i + 1]))

    def __call__(self, U):
        x = _encode(U, self.input_encoding)
        f = _act(self.activation)
        x = f(self.in_lin(x))
        for i, (ln, lin) in enumerate(zip(self.norms, self.linears)):
            h = lin(ln(x))
            if i < len(self.linears) - 1:
                x = f(h)
            else:
                x = h
        return x.reshape(self.n_channels, self.n_slices)


# --------------------------------------------------------------------------
# MLP with residual blocks (pre-norm + 2-layer Linear with skip)
# --------------------------------------------------------------------------
class _ResBlock(eqx.Module):
    ln: eqx.nn.LayerNorm
    lin1: eqx.nn.Linear
    lin2: eqx.nn.Linear
    activation: str = eqx.field(static=True)

    def __init__(self, dim, key, activation="gelu"):
        self.ln = eqx.nn.LayerNorm(dim)
        k1, k2 = jax.random.split(key)
        self.lin1 = eqx.nn.Linear(dim, dim, key=k1)
        self.lin2 = eqx.nn.Linear(dim, dim, key=k2)
        self.activation = activation

    def __call__(self, x):
        h = self.ln(x)
        h = _act(self.activation)(self.lin1(h))
        h = self.lin2(h)
        return x + h


class MLPResNetInverter(eqx.Module):
    in_lin: eqx.nn.Linear
    blocks: list
    out_norm: eqx.nn.LayerNorm
    out_lin: eqx.nn.Linear
    n_slices: int = eqx.field(static=True)
    n_channels: int = eqx.field(static=True)
    activation: str = eqx.field(static=True)
    input_encoding: str = eqx.field(static=True)

    def __init__(
        self, dim: int, n_blocks: int, n_slices: int,
        *, n_channels: int = 4, activation: str = "gelu",
        input_encoding: str = "real32_su4", key,
    ):
        self.n_slices = n_slices
        self.n_channels = n_channels
        self.activation = activation
        self.input_encoding = input_encoding
        _, in_dim = get_encoder_2q(input_encoding)
        out_dim = n_channels * n_slices
        keys = jax.random.split(key, n_blocks + 2)
        self.in_lin = eqx.nn.Linear(in_dim, dim, key=keys[0])
        self.blocks = [_ResBlock(dim, keys[i + 1], activation) for i in range(n_blocks)]
        self.out_norm = eqx.nn.LayerNorm(dim)
        self.out_lin = eqx.nn.Linear(dim, out_dim, key=keys[-1])

    def __call__(self, U):
        x = _encode(U, self.input_encoding)
        f = _act(self.activation)
        x = f(self.in_lin(x))
        for blk in self.blocks:
            x = blk(x)
        x = self.out_lin(self.out_norm(x))
        return x.reshape(self.n_channels, self.n_slices)


# --------------------------------------------------------------------------
# MLP with Fourier-cosine output: emit K coefficients per channel,
# synthesize pulse via fixed cosine basis. Smoother by construction.
# --------------------------------------------------------------------------
class MLPFourierInverter(eqx.Module):
    layers: list
    fourier_basis: jnp.ndarray   # (n_slices, K)
    n_slices: int = eqx.field(static=True)
    n_channels: int = eqx.field(static=True)
    K: int = eqx.field(static=True)
    activation: str = eqx.field(static=True)
    input_encoding: str = eqx.field(static=True)

    def __init__(
        self, hidden_dims: Sequence[int], n_slices: int, K: int,
        *, n_channels: int = 4, activation: str = "gelu",
        input_encoding: str = "real32_su4", key,
    ):
        self.n_slices = n_slices
        self.n_channels = n_channels
        self.K = K
        self.activation = activation
        self.input_encoding = input_encoding
        _, in_dim = get_encoder_2q(input_encoding)
        out_dim = n_channels * K
        dims = [in_dim, *hidden_dims, out_dim]
        keys = jax.random.split(key, len(dims) - 1)
        self.layers = [eqx.nn.Linear(dims[i], dims[i + 1], key=keys[i]) for i in range(len(dims) - 1)]
        # DCT-II basis: cos(pi k (t + 0.5) / N), k = 0..K-1, t = 0..N-1
        t = jnp.arange(n_slices)[:, None].astype(jnp.float32)
        k = jnp.arange(K)[None, :].astype(jnp.float32)
        self.fourier_basis = jnp.cos(jnp.pi * k * (t + 0.5) / n_slices)   # (N, K)

    def __call__(self, U):
        x = _encode(U, self.input_encoding)
        f = _act(self.activation)
        for lin in self.layers[:-1]:
            x = f(lin(x))
        x = self.layers[-1](x)
        coeffs = x.reshape(self.n_channels, self.K)
        # pulse[c, t] = sum_k coeffs[c, k] * basis[t, k]
        return coeffs @ self.fourier_basis.T


def build_inverter_2q_arch(
    arch: str, n_slices: int, *, key,
    n_channels: int = 4, input_encoding: str = "real32_su4",
    arch_config: dict | None = None,
):
    arch_config = arch_config or {}
    if arch == "mlp":
        return MLPInverter(
            hidden_dims=tuple(arch_config.get("hidden_dims", [512, 512, 512, 512])),
            n_slices=n_slices, n_channels=n_channels,
            activation=arch_config.get("activation", "gelu"),
            input_encoding=input_encoding, key=key,
        )
    if arch == "mlp_ln":
        return MLPLNInverter(
            hidden_dims=tuple(arch_config.get("hidden_dims", [512, 512, 512, 512])),
            n_slices=n_slices, n_channels=n_channels,
            activation=arch_config.get("activation", "gelu"),
            input_encoding=input_encoding, key=key,
        )
    if arch == "mlp_resnet":
        return MLPResNetInverter(
            dim=int(arch_config.get("dim", 512)),
            n_blocks=int(arch_config.get("n_blocks", 4)),
            n_slices=n_slices, n_channels=n_channels,
            activation=arch_config.get("activation", "gelu"),
            input_encoding=input_encoding, key=key,
        )
    if arch == "mlp_fourier":
        return MLPFourierInverter(
            hidden_dims=tuple(arch_config.get("hidden_dims", [512, 512, 512, 512])),
            n_slices=n_slices, n_channels=n_channels,
            K=int(arch_config.get("K", 16)),
            activation=arch_config.get("activation", "gelu"),
            input_encoding=input_encoding, key=key,
        )
    if arch == "gru":
        return GRUInverter(
            hidden_dim=int(arch_config.get("hidden_dim", 384)),
            n_slices=n_slices, n_channels=n_channels,
            n_encode_layers=int(arch_config.get("n_encode_layers", 3)),
            input_encoding=input_encoding, key=key,
        )
    if arch == "transformer":
        return TransformerInverter(
            d_model=int(arch_config.get("d_model", 192)),
            n_layers=int(arch_config.get("n_layers", 4)),
            n_heads=int(arch_config.get("n_heads", 6)),
            n_slices=n_slices, n_channels=n_channels,
            ff_mult=int(arch_config.get("ff_mult", 4)),
            input_encoding=input_encoding, key=key,
        )
    if arch == "conv":
        return ConvInverter(
            d_model=int(arch_config.get("d_model", 224)),
            n_layers=int(arch_config.get("n_layers", 5)),
            kernel_size=int(arch_config.get("kernel_size", 5)),
            n_slices=n_slices, n_channels=n_channels,
            activation=arch_config.get("activation", "gelu"),
            input_encoding=input_encoding, key=key,
        )
    if arch == "unet":
        return UNetInverter(
            base_dim=int(arch_config.get("base_dim", 64)),
            n_levels=int(arch_config.get("n_levels", 3)),
            n_slices=n_slices, n_channels=n_channels,
            activation=arch_config.get("activation", "gelu"),
            input_encoding=input_encoding, key=key,
        )
    raise ValueError(f"unknown arch: {arch}")
