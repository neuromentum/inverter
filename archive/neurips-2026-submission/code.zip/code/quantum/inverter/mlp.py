"""MLP inverter: U_target -> piecewise-constant pulse sequence.

Input encodings
---------------
All take a 2x2 complex unitary U and return real features.

- "real8":  Re/Im of (U_00, U_01, U_10, U_11). 8 dims. Includes global phase.
- "trig6":  axis-angle (gamma, theta, phi) of SU(2) part, sin/cos each → 6 dims.
            Global-phase invariant. Same encoding as Lipaei et al. (2026).
- "ck4":    Cayley-Klein (a, b, c, d) with U_SU(2) = a I + i (b σx + c σy + d σz),
            a^2 + b^2 + c^2 + d^2 = 1. 4 dims. Global-phase invariant; lives on S^3.

Output
------
2 * n_slices real numbers, reshaped as (2, n_slices). The training script squashes
them through tanh(*) * omega_max to enforce the amplitude cap.
"""
from __future__ import annotations

from typing import Sequence

import equinox as eqx
import jax
import jax.numpy as jnp


# --------------------------------------------------------------------------
# Encodings
# --------------------------------------------------------------------------
_SX = jnp.array([[0, 1], [1, 0]], dtype=jnp.complex64)
_SY = jnp.array([[0, -1j], [1j, 0]], dtype=jnp.complex64)
_SZ = jnp.array([[1, 0], [0, -1]], dtype=jnp.complex64)


def _to_su2(U):
    """Project a 2x2 unitary onto SU(2) with canonical sign.

    `U / sqrt(det U)` has a ±1 ambiguity (two square roots → two SU(2) reps that
    differ by an overall sign).  We pick the rep whose first non-near-zero
    Pauli coefficient is positive — equivalent to the convention `gamma ∈ [0, π]`
    in the axis-angle picture.
    """
    det = jnp.linalg.det(U)
    U_su = U / jnp.sqrt(det)
    a = jnp.real(jnp.trace(U_su)) * 0.5
    b = -jnp.imag(jnp.trace(_SX @ U_su)) * 0.5
    c = -jnp.imag(jnp.trace(_SY @ U_su)) * 0.5
    d = -jnp.imag(jnp.trace(_SZ @ U_su)) * 0.5
    eps = 1e-5
    use_a = jnp.abs(a) > eps
    use_b = (~use_a) & (jnp.abs(b) > eps)
    use_c = (~use_a) & (~use_b) & (jnp.abs(c) > eps)
    sgn = jnp.where(use_a, jnp.sign(a),
          jnp.where(use_b, jnp.sign(b),
          jnp.where(use_c, jnp.sign(c), jnp.sign(d))))
    return U_su * sgn


def encode_real8(U):
    """Plain Re/Im flatten — keeps global phase, 8 dims."""
    flat = U.reshape(-1)
    return jnp.concatenate([jnp.real(flat), jnp.imag(flat)]).astype(jnp.float32)


def encode_trig6(U):
    """Trigonometric axis-angle of the SU(2) part (Lipaei et al. 2026)."""
    U_su = _to_su2(U)
    cos_half_gamma = jnp.clip(jnp.real(jnp.trace(U_su)) * 0.5, -1.0, 1.0)
    gamma = 2.0 * jnp.arccos(cos_half_gamma)
    sin_half_gamma = jnp.sin(gamma * 0.5)
    nx = -0.5 * jnp.imag(jnp.trace(_SX @ U_su)) / (sin_half_gamma + 1e-9)
    ny = -0.5 * jnp.imag(jnp.trace(_SY @ U_su)) / (sin_half_gamma + 1e-9)
    nz = -0.5 * jnp.imag(jnp.trace(_SZ @ U_su)) / (sin_half_gamma + 1e-9)
    theta = jnp.arccos(jnp.clip(nz, -1.0, 1.0))
    phi = jnp.arctan2(ny, nx)
    feats = jnp.stack([
        jnp.cos(gamma), jnp.sin(gamma),
        jnp.cos(theta), jnp.sin(theta),
        jnp.cos(phi),   jnp.sin(phi),
    ])
    return feats.astype(jnp.float32)


def encode_ck4(U):
    """Cayley-Klein (a, b, c, d) of SU(2) part: U_SU = a I + i(b σx + c σy + d σz)."""
    U_su = _to_su2(U)
    a = jnp.real(jnp.trace(U_su)) * 0.5
    b = -jnp.imag(jnp.trace(_SX @ U_su)) * 0.5
    c = -jnp.imag(jnp.trace(_SY @ U_su)) * 0.5
    d = -jnp.imag(jnp.trace(_SZ @ U_su)) * 0.5
    return jnp.stack([a, b, c, d]).astype(jnp.float32)


_ENCODERS = {
    "real8": (encode_real8, 8),
    "trig6": (encode_trig6, 6),
    "ck4":   (encode_ck4,   4),
}


def get_encoder(name: str):
    if name not in _ENCODERS:
        raise ValueError(f"unknown input_encoding: {name}; choose from {list(_ENCODERS)}")
    return _ENCODERS[name]


# --------------------------------------------------------------------------
# MLP
# --------------------------------------------------------------------------
class MLPInverter(eqx.Module):
    layers: list
    n_slices: int = eqx.field(static=True)
    activation: str = eqx.field(static=True)
    input_encoding: str = eqx.field(static=True)

    def __init__(
        self,
        hidden_dims: Sequence[int],
        n_slices: int,
        *,
        activation: str = "gelu",
        input_encoding: str = "real8",
        key,
    ):
        self.n_slices = n_slices
        self.activation = activation
        self.input_encoding = input_encoding
        _, in_dim = get_encoder(input_encoding)
        out_dim = 2 * n_slices
        dims = [in_dim, *hidden_dims, out_dim]
        keys = jax.random.split(key, len(dims) - 1)
        self.layers = [
            eqx.nn.Linear(dims[i], dims[i + 1], key=keys[i])
            for i in range(len(dims) - 1)
        ]

    def __call__(self, U: jnp.ndarray) -> jnp.ndarray:
        encode_fn, _ = get_encoder(self.input_encoding)
        x = encode_fn(U)
        act_fn = {"gelu": jax.nn.gelu, "relu": jax.nn.relu, "tanh": jnp.tanh}[
            self.activation
        ]
        for lin in self.layers[:-1]:
            x = act_fn(lin(x))
        x = self.layers[-1](x)
        return x.reshape(2, self.n_slices)


def build_inverter(
    arch: str, hidden_dims, n_slices, activation, key, input_encoding: str = "real8"
):
    if arch == "mlp":
        return MLPInverter(
            hidden_dims, n_slices,
            activation=activation, input_encoding=input_encoding, key=key,
        )
    raise ValueError(f"unknown arch: {arch}")
