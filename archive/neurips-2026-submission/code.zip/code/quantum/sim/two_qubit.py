"""Two-qubit Lindblad simulator (JAX + slice-expm Liouvillian).

Conventions
-----------
- d = 4 for the qubit-only model (no transmon leakage). 9-dim with leakage is
  a future extension; the Liouvillian dim grows to 81×81 — still tractable
  but ~10× slower per slice expm.
- Tensor convention: H_q1 = A ⊗ I, H_q2 = I ⊗ A; basis order is |q1 q2⟩
  with q1 the most significant index.
- Drift Hamiltonian: always-on ZZ coupling, J σ_z^(1) σ_z^(2) / 2 (in the
  rotating frame at each qubit's free frequency, the σ_z's are gone except
  for the coupling — same as our single-qubit convention).
- Drive: per-qubit X and Y in the rotating frame; 4 channels total
  (Ω_x_1, Ω_y_1, Ω_x_2, Ω_y_2). Pulse shape: (4, n_slices).
- Lindblad ops: T1 (σ_-) and Tφ (σ_z) on each qubit independently;
  4 ops total stacked into L_stack of shape (4, 4, 4).
- Time / amplitude units: same as the single-qubit conventions
  (Ω_max = 1, T_gate measured in 1/Ω_max).

The two-qubit pipeline reuses `_hamiltonian_super` and `lindblad_super_static`
from `sim.transmon`, so the slice-expm path is identical aside from operator
shape.
"""
from __future__ import annotations

import jax
import jax.numpy as jnp
import diffrax

from sim.transmon import _hamiltonian_super, lindblad_super_static


# --------------------------------------------------------------------------
# Single-qubit Pauli operators (used to lift to 2-qubit)
# --------------------------------------------------------------------------
_I2 = jnp.eye(2, dtype=jnp.complex64)
_SX = jnp.array([[0, 1], [1, 0]], dtype=jnp.complex64)
_SY = jnp.array([[0, -1j], [1j, 0]], dtype=jnp.complex64)
_SZ = jnp.array([[1, 0], [0, -1]], dtype=jnp.complex64)
_SM = jnp.array([[0, 1], [0, 0]], dtype=jnp.complex64)  # lowering (sigma_-)


def kron(A, B):
    return jnp.kron(A, B)


# --------------------------------------------------------------------------
# Static system operators
# --------------------------------------------------------------------------
def static_operators_2q(J: float, T1: float, Tphi: float):
    """Build (H_drift, H_drives, L_stack) for two coupled qubits with ZZ.

    Parameters
    ----------
    J     : ZZ coupling strength (units of Omega_max).
    T1    : single-qubit energy relaxation time (same on both qubits).
    Tphi  : single-qubit pure dephasing time.

    Returns
    -------
    H_drift   : (4, 4) complex
    H_drives  : (4, 4, 4) complex — stack of [Hx_1, Hy_1, Hx_2, Hy_2] / 2
    L_stack   : (4, 4, 4) complex — Lindblad ops on the 4-dim 2-qubit space
    """
    Sx1 = kron(_SX, _I2); Sy1 = kron(_SY, _I2); Sz1 = kron(_SZ, _I2); Sm1 = kron(_SM, _I2)
    Sx2 = kron(_I2, _SX); Sy2 = kron(_I2, _SY); Sz2 = kron(_I2, _SZ); Sm2 = kron(_I2, _SM)

    H_drift = (J / 2.0) * (Sz1 @ Sz2)
    H_drives = jnp.stack([Sx1 / 2.0, Sy1 / 2.0, Sx2 / 2.0, Sy2 / 2.0])

    L_T1_1 = jnp.sqrt(1.0 / T1) * Sm1
    L_T1_2 = jnp.sqrt(1.0 / T1) * Sm2
    L_phi_1 = jnp.sqrt(1.0 / (2.0 * Tphi)) * Sz1
    L_phi_2 = jnp.sqrt(1.0 / (2.0 * Tphi)) * Sz2
    L_stack = jnp.stack([L_T1_1, L_T1_2, L_phi_1, L_phi_2])

    return H_drift.astype(jnp.complex64), H_drives.astype(jnp.complex64), L_stack.astype(jnp.complex64)


# --------------------------------------------------------------------------
# Diffrax adaptive integrator (high-accuracy reference path)
# --------------------------------------------------------------------------
def _piecewise_idx(t, T_gate, N):
    return jnp.clip(jnp.floor(t / T_gate * N).astype(jnp.int32), 0, N - 1)


def _lindblad_rhs_2q(t, rho, args):
    H_drift, H_drives, L_stack, pulse, T_gate = args
    N = pulse.shape[1]
    idx = _piecewise_idx(t, T_gate, N)
    omegas = pulse[:, idx]                          # (4,)
    H_t = H_drift + jnp.einsum("c,cij->ij", omegas, H_drives)
    drho = -1j * (H_t @ rho - rho @ H_t)

    def diss(L):
        Ldag = L.conj().T
        LdL = Ldag @ L
        return L @ rho @ Ldag - 0.5 * (LdL @ rho + rho @ LdL)

    drho = drho + jnp.sum(jax.vmap(diss)(L_stack), axis=0)
    return drho


def evolve_2q(rho0, pulse, T_gate, H_drift, H_drives, L_stack,
              *, n_save: int = 2, rtol: float = 1e-6, atol: float = 1e-8,
              max_steps: int = 1_000_000):
    """High-accuracy Lindblad evolution via diffrax (Tsit5 + adaptive PID)."""
    args = (H_drift, H_drives, L_stack, pulse, T_gate)
    saveat = diffrax.SaveAt(ts=jnp.linspace(0.0, T_gate, n_save))
    sol = diffrax.diffeqsolve(
        diffrax.ODETerm(_lindblad_rhs_2q),
        diffrax.Tsit5(),
        t0=0.0, t1=T_gate, dt0=T_gate / 200.0,
        y0=rho0, args=args, saveat=saveat,
        max_steps=max_steps,
        stepsize_controller=diffrax.PIDController(rtol=rtol, atol=atol),
    )
    return sol.ts, sol.ys


# --------------------------------------------------------------------------
# Fast slice-expm Liouvillian path (used by GRAPE & the inverter)
# --------------------------------------------------------------------------
def channel_propagator_2q(pulse, T_gate, H_drift, H_drives, L_stack):
    """Build the (d², d²) superoperator for a piecewise-constant 4-channel pulse.

    pulse shape: (n_channels, n_slices). For our model n_channels = 4.

    Dtype is derived from `H_drift` so the same code works at complex64 (the
    default x32 mode) and complex128 (after `jax_enable_x64=True`).
    """
    d = H_drift.shape[0]
    cdtype = H_drift.dtype
    eye_d = jnp.eye(d, dtype=cdtype)
    n_slices = pulse.shape[1]
    dt = T_gate / n_slices
    L_diss = lindblad_super_static(L_stack, d).astype(cdtype)

    def slice_propagator(omegas):
        H_t = H_drift + jnp.einsum("c,cij->ij", omegas.astype(cdtype), H_drives)
        L_super = _hamiltonian_super(H_t, eye_d) + L_diss
        return jax.scipy.linalg.expm(L_super * dt)

    Us = jax.vmap(slice_propagator)(pulse.T)        # (n_slices, d², d²)

    def step(M, U):
        return U @ M, None

    M0 = jnp.eye(d * d, dtype=cdtype)
    M_final, _ = jax.lax.scan(step, M0, Us)
    return M_final


def evolve_pwc_final_2q(rho0, pulse, T_gate, H_drift, H_drives, L_stack):
    """Apply the channel to rho0 and return the final density matrix."""
    d = rho0.shape[0]
    M = channel_propagator_2q(pulse, T_gate, H_drift, H_drives, L_stack)
    rho_vec = rho0.T.reshape(-1)
    out_vec = M @ rho_vec
    return out_vec.reshape(d, d).T


# --------------------------------------------------------------------------
# State helpers
# --------------------------------------------------------------------------
def basis_2q(j: int):
    """|q1 q2> for j in {0=00, 1=01, 2=10, 3=11}."""
    v = jnp.zeros(4, dtype=jnp.complex64).at[j].set(1.0)
    return v


def ket_to_dm(psi):
    psi = psi.reshape(-1, 1)
    return psi @ psi.conj().T


def population(rho, j: int):
    """P(|j>) = ⟨j|ρ|j⟩."""
    return jnp.real(rho[j, j])


# --------------------------------------------------------------------------
# Standard 2-qubit target unitaries
# --------------------------------------------------------------------------
def U_CNOT():
    """CNOT with control=q1, target=q2 (in our basis order |q1 q2>)."""
    return jnp.array([
        [1, 0, 0, 0],
        [0, 1, 0, 0],
        [0, 0, 0, 1],
        [0, 0, 1, 0],
    ], dtype=jnp.complex64)


def U_iSWAP():
    return jnp.array([
        [1, 0, 0, 0],
        [0, 0, 1j, 0],
        [0, 1j, 0, 0],
        [0, 0, 0, 1],
    ], dtype=jnp.complex64)


def U_sqrt_iSWAP():
    s = 1.0 / jnp.sqrt(2.0)
    return jnp.array([
        [1, 0,    0,    0],
        [0, s,    1j*s, 0],
        [0, 1j*s, s,    0],
        [0, 0,    0,    1],
    ], dtype=jnp.complex64)


def U_CZ():
    return jnp.diag(jnp.array([1, 1, 1, -1], dtype=jnp.complex64))


def U_SWAP():
    return jnp.array([
        [1, 0, 0, 0],
        [0, 0, 1, 0],
        [0, 1, 0, 0],
        [0, 0, 0, 1],
    ], dtype=jnp.complex64)
