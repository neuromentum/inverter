"""3-level transmon simulator with Lindblad noise (JAX + diffrax).

Conventions
-----------
- Time and frequency in natural units: Omega_max = 1, time in 1/Omega_max.
- Rotating frame at the qubit |0>->|1> transition frequency.
- Anharmonicity alpha < 0 (typical transmon: alpha/Omega_max ~ -4).
- Drive Hamiltonian (RWA): H_drive(t) = (Ox(t)/2)(a + a^dag) + (Oy(t)/2) i(a^dag - a).
- Drift: H_drift = (alpha/2) n(n-1)  [eigenvalues 0, 0, alpha for n=0,1,2].
- Lindblad ops:
    L_T1  = sqrt(1/T1)  * a       (energy relaxation)
    L_phi = sqrt(2/Tphi) * a^dag a (pure dephasing).
  These reproduce the qubit-subspace 1/T2 = 1/(2 T1) + 1/Tphi.

The integrator (diffrax Tsit5 with adaptive steps) preserves trace and
hermiticity to ~1e-8.
"""
from __future__ import annotations

import jax
import jax.numpy as jnp
import diffrax


def ladder_operators(d: int):
    """Annihilation, creation, and number operators for a d-level oscillator."""
    a = jnp.diag(jnp.sqrt(jnp.arange(1, d, dtype=jnp.float32)), k=1).astype(jnp.complex64)
    adag = a.conj().T
    n = adag @ a
    return a, adag, n


def static_operators(d: int, alpha: float, T1: float, Tphi: float):
    """Build (H_drift, Hx, Hy, L_stack) for a d-level transmon.

    Returns
    -------
    H_drift, Hx, Hy : (d, d) complex arrays
    L_stack : (2, d, d) complex array — Lindblad ops [L_T1, L_phi]
    """
    a, adag, n = ladder_operators(d)
    eye = jnp.eye(d, dtype=jnp.complex64)
    H_drift = (alpha / 2.0) * n @ (n - eye)
    Hx = 0.5 * (a + adag)
    Hy = 0.5j * (adag - a)
    L_T1 = jnp.sqrt(1.0 / T1) * a
    L_phi = jnp.sqrt(2.0 / Tphi) * n
    L_stack = jnp.stack([L_T1, L_phi])
    return H_drift, Hx, Hy, L_stack


def _piecewise_idx(t, T_gate, N):
    return jnp.clip(jnp.floor(t / T_gate * N).astype(jnp.int32), 0, N - 1)


def _lindblad_rhs(t, rho, args):
    H_drift, Hx, Hy, L_stack, pulse_x, pulse_y, T_gate = args
    N = pulse_x.shape[0]
    idx = _piecewise_idx(t, T_gate, N)
    Ox = pulse_x[idx]
    Oy = pulse_y[idx]
    H = H_drift + Ox * Hx + Oy * Hy
    drho = -1j * (H @ rho - rho @ H)

    def diss(L):
        Ldag = L.conj().T
        LdL = Ldag @ L
        return L @ rho @ Ldag - 0.5 * (LdL @ rho + rho @ LdL)

    drho = drho + jnp.sum(jax.vmap(diss)(L_stack), axis=0)
    return drho


def evolve(
    rho0,
    pulse_x,
    pulse_y,
    T_gate,
    H_drift,
    Hx,
    Hy,
    L_stack,
    *,
    n_save: int = 2,
    rtol: float = 1e-6,
    atol: float = 1e-8,
    max_steps: int = 1_000_000,
):
    """Integrate Lindblad ME from t=0 to T_gate with piecewise-constant pulse.

    Parameters
    ----------
    rho0 : (d, d) complex — initial density matrix
    pulse_x, pulse_y : (N,) float — piecewise-constant drive amplitudes
    T_gate : float — total gate duration
    H_drift, Hx, Hy : (d, d) complex — static Hamiltonian operators
    L_stack : (n_lindblad, d, d) complex — Lindblad operators

    Returns
    -------
    ts : (n_save,) float
    rhos : (n_save, d, d) complex
    """
    args = (H_drift, Hx, Hy, L_stack, pulse_x, pulse_y, T_gate)
    saveat = diffrax.SaveAt(ts=jnp.linspace(0.0, T_gate, n_save))
    sol = diffrax.diffeqsolve(
        diffrax.ODETerm(_lindblad_rhs),
        diffrax.Tsit5(),
        t0=0.0,
        t1=T_gate,
        dt0=T_gate / 200.0,
        y0=rho0,
        args=args,
        saveat=saveat,
        max_steps=max_steps,
        stepsize_controller=diffrax.PIDController(rtol=rtol, atol=atol),
    )
    return sol.ts, sol.ys


def evolve_final(rho0, pulse_x, pulse_y, T_gate, H_drift, Hx, Hy, L_stack):
    """Same as evolve(), but returns only the final density matrix.

    Convenient for jit/vmap when only the endpoint is needed (gate fidelity).
    """
    _, rhos = evolve(rho0, pulse_x, pulse_y, T_gate, H_drift, Hx, Hy, L_stack, n_save=2)
    return rhos[-1]


# --------------------------------------------------------------------------
# Fast piecewise-constant evolution via per-slice Liouvillian exponential
# --------------------------------------------------------------------------
# For piecewise-constant pulses this is exact (no integrator error), much
# faster than diffrax (no per-step overhead), and vmap/jit-friendly.
#
# Vectorization: rho is column-stacked into vec(rho), so
#   d/dt vec(rho) = L_super vec(rho)
# with the standard column-stacking identity vec(A B C) = (C^T ⊗ A) vec(B).
# --------------------------------------------------------------------------


def _hamiltonian_super(H, eye):
    """Vectorized Hamiltonian commutator as a (d², d²) superoperator."""
    return -1j * (jnp.kron(eye, H) - jnp.kron(H.T, eye))


def _lindblad_super(L, eye):
    """Vectorized single Lindblad dissipator as a (d², d²) superoperator."""
    Ldag = L.conj().T
    LdL = Ldag @ L
    return jnp.kron(L.conj(), L) - 0.5 * (jnp.kron(eye, LdL) + jnp.kron(LdL.T, eye))


def lindblad_super_static(L_stack, d):
    """Build the static (pulse-independent) Lindblad part of the Liouvillian.

    Returns a (d², d²) matrix that does not depend on the drive amplitudes.
    """
    eye = jnp.eye(d, dtype=jnp.complex64)
    diss = jax.vmap(lambda L: _lindblad_super(L, eye))(L_stack)
    return jnp.sum(diss, axis=0)


def evolve_pwc_final(
    rho0,
    pulse_x,
    pulse_y,
    T_gate,
    H_drift,
    Hx,
    Hy,
    L_stack,
):
    """Evolve under piecewise-constant pulses via matrix exponential per slice.

    Returns the final density matrix only. Exact for piecewise-constant inputs
    (no integrator tolerance — the only approximation is `expm`).

    Cost per pulse: O(N · d⁶) for N slices and Hilbert dim d. For d=3, N=100
    this is ~1-5 ms on CPU after jit.
    """
    d = rho0.shape[0]
    eye = jnp.eye(d, dtype=jnp.complex64)
    N = pulse_x.shape[0]
    dt = T_gate / N
    L_diss = lindblad_super_static(L_stack, d)

    def slice_propagator(ox, oy):
        H = H_drift + ox * Hx + oy * Hy
        L_super = _hamiltonian_super(H, eye) + L_diss
        return jax.scipy.linalg.expm(L_super * dt)

    Us = jax.vmap(slice_propagator)(pulse_x, pulse_y)  # (N, d², d²)
    rho_vec = rho0.T.reshape(-1)  # column-stacking convention

    def step(rv, U):
        return U @ rv, None

    rho_vec_f, _ = jax.lax.scan(step, rho_vec, Us)
    return rho_vec_f.reshape(d, d).T


# --------------------------------------------------------------------------
# Helpers for state and Bloch-sphere visualization (qubit subspace)
# --------------------------------------------------------------------------


def basis(d: int, j: int):
    v = jnp.zeros(d, dtype=jnp.complex64).at[j].set(1.0)
    return v


def ket_to_dm(psi):
    psi = psi.reshape(-1, 1)
    return psi @ psi.conj().T


def bloch_vector(rho):
    """Bloch vector from the {|0>, |1>} subspace of a (d, d) density matrix."""
    bx = 2.0 * jnp.real(rho[0, 1])
    by = -2.0 * jnp.imag(rho[0, 1])
    bz = jnp.real(rho[0, 0] - rho[1, 1])
    return jnp.array([bx, by, bz])


def qubit_subspace_population(rho):
    """Total population in the computational subspace (1 - leakage)."""
    return jnp.real(rho[0, 0] + rho[1, 1])
