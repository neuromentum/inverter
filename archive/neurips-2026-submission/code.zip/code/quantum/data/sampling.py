"""Haar-random sampling on U(2) / SU(2) and helpers for coverage diagnostics.

Convention: we sample U(2) (no global-phase quotient). Average gate fidelity is
invariant under a global phase on U_target, so for our learning problem U(2) and
SU(2) are equivalent. The diagnostic helpers project to SU(2) when needed
(e.g. for the rotation-angle / rotation-axis Haar tests).
"""
from __future__ import annotations

import jax
import jax.numpy as jnp


# --------------------------------------------------------------------------
# Haar sampler on U(2) via QR
# --------------------------------------------------------------------------
def haar_unitary(key, d: int = 2):
    """Haar-uniform sample from U(d).

    Standard QR construction: take Z ~ complex Gaussian iid, QR-decompose,
    then phase-correct the diagonal so Q is uniform on U(d).
    """
    k1, k2 = jax.random.split(key)
    Z = jax.random.normal(k1, (d, d)) + 1j * jax.random.normal(k2, (d, d))
    Q, R = jnp.linalg.qr(Z)
    Lambda = jnp.diag(jnp.diag(R) / jnp.abs(jnp.diag(R)))
    return (Q @ Lambda).astype(jnp.complex64)


def haar_unitary_batch(key, n: int, d: int = 2):
    """Batch of n Haar-random U(d) matrices, shape (n, d, d)."""
    keys = jax.random.split(key, n)
    return jax.vmap(lambda k: haar_unitary(k, d))(keys)


def haar_su4_batch(key, n: int):
    """Batch of n Haar-random SU(4) matrices (used for 2-qubit reference set)."""
    Us = haar_unitary_batch(key, n, d=4)
    # Project to SU(4) by removing global phase. (For our process-fidelity loss,
    # global phase is invariant anyway, but this keeps targets canonical.)
    dets = jnp.linalg.det(Us)
    phase = dets ** (1.0 / 4.0)
    return Us / phase[:, None, None]


# --------------------------------------------------------------------------
# Diagnostic helpers
# --------------------------------------------------------------------------
def to_su2(U):
    """Project a 2x2 unitary onto SU(2) by removing the global phase
    (divide by sqrt(det)).
    """
    det = jnp.linalg.det(U)
    return U / jnp.sqrt(det)


def axis_angle(U):
    """For a 2x2 unitary, return (n_hat, theta) where n_hat is the rotation
    axis on S^2 and theta is the rotation angle (in [0, 2π)).

    SU(2) form: U_su = cos(theta/2) I - i sin(theta/2) (n . sigma).
    """
    U_su = to_su2(U)
    cos_half = 0.5 * jnp.real(jnp.trace(U_su))
    cos_half = jnp.clip(cos_half, -1.0, 1.0)
    theta = 2.0 * jnp.arccos(cos_half)
    sin_half = jnp.sin(theta / 2.0)
    # Pauli expansion of -i sin(theta/2) (n . sigma)
    pauli_x = jnp.array([[0, 1], [1, 0]], dtype=jnp.complex64)
    pauli_y = jnp.array([[0, -1j], [1j, 0]], dtype=jnp.complex64)
    pauli_z = jnp.array([[1, 0], [0, -1]], dtype=jnp.complex64)
    nx = -0.5 * jnp.imag(jnp.trace(pauli_x @ U_su)) / (sin_half + 1e-9)
    ny = -0.5 * jnp.imag(jnp.trace(pauli_y @ U_su)) / (sin_half + 1e-9)
    nz = -0.5 * jnp.imag(jnp.trace(pauli_z @ U_su)) / (sin_half + 1e-9)
    n = jnp.array([nx, ny, nz])
    return n, theta


def haar_su2_trace_pdf(x):
    """Analytic PDF of Re(Tr(U)/2) for Haar SU(2): semicircle (2/pi) sqrt(1-x²).

    Useful for KS-style tests: Tr(U)/2 = cos(theta/2) with theta ~ sin²(theta/2).
    """
    return (2.0 / jnp.pi) * jnp.sqrt(jnp.clip(1.0 - x * x, 0.0, 1.0))


def haar_su2_trace_cdf(x):
    """CDF of Re(Tr(U)/2) for Haar SU(2): F(x) = (1/2) + (x sqrt(1-x²) + arcsin(x)) / π."""
    x = jnp.clip(x, -1.0, 1.0)
    return 0.5 + (x * jnp.sqrt(1.0 - x * x) + jnp.arcsin(x)) / jnp.pi


# --------------------------------------------------------------------------
# Embed a 2x2 qubit unitary into a d-level transmon (block-diag with identity
# on leakage subspace).  Used to map Phase-3 samples into the simulator.
# --------------------------------------------------------------------------
def embed_qubit_unitary(U_qubit, d: int):
    eye = jnp.eye(d, dtype=jnp.complex64)
    return eye.at[:2, :2].set(U_qubit.astype(jnp.complex64))
