"""Autodiff GRAPE for gate synthesis under Lindbladian dynamics.

The pulse is parametrized as N piecewise-constant slices of (Omega_x, Omega_y).
Loss = 1 - F_avg where F_avg is the average gate fidelity over a single-qubit
2-design (the four states |0>, |1>, |+>, |+i>). For unitary noise-free dynamics
this is exact; for Lindbladian dynamics it's a tight surrogate for process
fidelity, much cheaper than the full Choi computation, and clean to autodiff.

Performance
-----------
The whole optimizer (Adam + N steps) runs as a single jax.lax.scan inside a
jit'd function, so cost per restart is one compile (~5-10 s on CPU for d=3,
n_slices=80) plus negligible per-step overhead. T_gate and U_target_qubit are
*arguments* (not closed-over), so the same compiled artifact is reused across
the gate-time sweep — no recompile per call.
"""
from __future__ import annotations

from functools import partial
from typing import NamedTuple

import jax
import jax.numpy as jnp
import optax

from sim.transmon import (
    lindblad_super_static,
    _hamiltonian_super,
    basis,
    ket_to_dm,
)


# --------------------------------------------------------------------------
# Single-qubit 2-design
# --------------------------------------------------------------------------
def two_design_states(d: int):
    """Four kets in C^d whose density matrices form a single-qubit 2-design
    on {|0>, |1>}; higher levels are zero-padded for use in a 3-level transmon.
    """
    e0 = basis(d, 0)
    e1 = basis(d, 1)
    plus = (e0 + e1) / jnp.sqrt(2.0)
    plus_i = (e0 + 1j * e1) / jnp.sqrt(2.0)
    return jnp.stack([e0, e1, plus, plus_i])  # (4, d)


def apply_unitary_to_states(U_qubit: jnp.ndarray, kets: jnp.ndarray):
    """Apply a 2x2 qubit unitary to each ket (zero-padded to d-dim)."""
    d = kets.shape[-1]
    U_ext = jnp.eye(d, dtype=jnp.complex64)
    U_ext = U_ext.at[:2, :2].set(U_qubit.astype(jnp.complex64))
    return jnp.einsum("ij,kj->ki", U_ext, kets)


# --------------------------------------------------------------------------
# Channel propagator under piecewise-constant pulse
# --------------------------------------------------------------------------
def channel_propagator(pulse_x, pulse_y, T_gate, H_drift, Hx, Hy, L_stack):
    """Build the (d², d²) superoperator for the full channel of the pulse.

    Dtype is derived from `H_drift` so the same code works under both
    `jax_enable_x64=False` (default complex64) and =True (complex128).
    """
    d = H_drift.shape[0]
    cdtype = H_drift.dtype
    eye_d = jnp.eye(d, dtype=cdtype)
    N = pulse_x.shape[0]
    dt = T_gate / N
    L_diss = lindblad_super_static(L_stack, d).astype(cdtype)

    def slice_propagator(ox, oy):
        H = H_drift + ox * Hx + oy * Hy
        L_super = _hamiltonian_super(H, eye_d) + L_diss
        return jax.scipy.linalg.expm(L_super * dt)

    Us = jax.vmap(slice_propagator)(pulse_x, pulse_y)  # (N, d², d²)

    def step(M, U):
        return U @ M, None

    M0 = jnp.eye(d * d, dtype=cdtype)
    M_final, _ = jax.lax.scan(step, M0, Us)
    return M_final


def apply_channel_to_dm(M_super, rho, d):
    rho_vec = rho.T.reshape(-1)
    out_vec = M_super @ rho_vec
    return out_vec.reshape(d, d).T


# --------------------------------------------------------------------------
# Loss
# --------------------------------------------------------------------------
def average_gate_fidelity(
    pulse_x, pulse_y, T_gate, U_target_qubit, H_drift, Hx, Hy, L_stack
):
    d = H_drift.shape[0]
    M = channel_propagator(pulse_x, pulse_y, T_gate, H_drift, Hx, Hy, L_stack)
    in_kets = two_design_states(d)
    target_kets = apply_unitary_to_states(U_target_qubit, in_kets)

    def fid_one(ket_in, ket_target):
        rho_in = ket_to_dm(ket_in)
        rho_out = apply_channel_to_dm(M, rho_in, d)
        return jnp.real(jnp.conj(ket_target) @ rho_out @ ket_target)

    fids = jax.vmap(fid_one)(in_kets, target_kets)
    return jnp.mean(fids)


def grape_loss(
    params, T_gate, U_target_qubit, H_drift, Hx, Hy, L_stack, omega_max=1.0
):
    pulse_x = omega_max * jnp.tanh(params[0])
    pulse_y = omega_max * jnp.tanh(params[1])
    F = average_gate_fidelity(
        pulse_x, pulse_y, T_gate, U_target_qubit, H_drift, Hx, Hy, L_stack
    )
    return 1.0 - F


def params_to_pulse(params, omega_max=1.0):
    return omega_max * jnp.tanh(params[0]), omega_max * jnp.tanh(params[1])


# --------------------------------------------------------------------------
# Optimizer: Adam + jax.lax.scan inside JIT
# --------------------------------------------------------------------------
class GrapeResult(NamedTuple):
    pulse_x: jnp.ndarray
    pulse_y: jnp.ndarray
    fidelity: float
    history: jnp.ndarray
    n_steps: int


def make_grape_runner(n_slices: int, n_steps: int, lr: float, omega_max: float):
    """Build a jit'd run_one(params_init, T_gate, U_target, system_ops) -> (params, history).

    The returned function is shape-stable across T_gate, U_target, and noise levels,
    so it compiles once and is reused for the entire gate-time / gate-library sweep.

    Returned `params` are the best-of-trajectory params (the iterate that
    achieved the highest fidelity at any point during the optimization), not
    the final-step params. Adam can drift past the optimum, and the final
    step is not always the best — tracking the best inside the scan lets us
    report a fidelity that corresponds to a real, returned pulse rather than
    a pulse the optimizer has since walked away from.
    """
    optimizer = optax.adam(lr)

    def step_fn(carry, _):
        params, opt_state, T_gate, U_target, ops, best_params, best_F = carry
        loss, grads = jax.value_and_grad(grape_loss)(
            params, T_gate, U_target, *ops, omega_max
        )
        F = 1.0 - loss
        better = F > best_F
        best_params = jax.tree_util.tree_map(
            lambda b, n: jnp.where(better, n, b), best_params, params,
        )
        best_F = jnp.where(better, F, best_F)
        updates, opt_state = optimizer.update(grads, opt_state)
        params = optax.apply_updates(params, updates)
        return (params, opt_state, T_gate, U_target, ops, best_params, best_F), F

    @jax.jit
    def run_one(params_init, T_gate, U_target, H_drift, Hx, Hy, L_stack):
        ops = (H_drift, Hx, Hy, L_stack)
        opt_state = optimizer.init(params_init)
        best_F0 = jnp.array(-jnp.inf, dtype=jnp.float32)
        carry0 = (params_init, opt_state, T_gate, U_target, ops, params_init, best_F0)
        carry_final, history = jax.lax.scan(
            step_fn, carry0, None, length=n_steps,
        )
        best_params = carry_final[5]
        return best_params, history

    return run_one


def grape_optimize(
    T_gate,
    U_target_qubit,
    H_drift,
    Hx,
    Hy,
    L_stack,
    *,
    n_slices: int = 80,
    n_steps: int = 400,
    n_restarts: int = 10,
    lr: float = 0.05,
    omega_max: float = 1.0,
    seed: int = 0,
    init_scale: float = 0.1,
    runner=None,
) -> GrapeResult:
    """Multi-restart Adam GRAPE.

    Pass `runner` from `make_grape_runner` to avoid recompiling between calls;
    otherwise one is built on the fly. The selected restart is the one whose
    *best* trajectory point (not its last step) has the highest fidelity —
    Adam can drift after the optimum, and the final step is not always the
    best-ever. Returned `pulse_x`/`pulse_y` and `history` correspond to that
    restart; `fidelity` is the best-ever fidelity across the trajectory of
    that restart, not the final-step value.

    For *publication-grade* benchmark targets (sub-noise-floor, near-speed-
    limit, or any "inverter vs GRAPE" reference set), use
    `grape.grape_pub.grape_optimize_pub_1q` instead — it uses scipy
    L-BFGS-B at complex128/float64 and converges to deeper minima.
    """
    if runner is None:
        runner = make_grape_runner(n_slices, n_steps, lr, omega_max)

    key = jax.random.PRNGKey(seed)
    best_F = -jnp.inf
    best_pulse = None
    best_history = None

    for r in range(n_restarts):
        key, sub = jax.random.split(key)
        params0 = init_scale * jax.random.normal(sub, (2, n_slices))
        params, history = runner(
            params0,
            jnp.asarray(T_gate, dtype=jnp.float32),
            U_target_qubit,
            H_drift, Hx, Hy, L_stack,
        )
        F_best_traj = float(jnp.max(history))
        if F_best_traj > best_F:
            best_F = F_best_traj
            px, py = params_to_pulse(params, omega_max)
            best_pulse = (px, py)
            best_history = history

    return GrapeResult(
        pulse_x=best_pulse[0],
        pulse_y=best_pulse[1],
        fidelity=best_F,
        history=best_history,
        n_steps=n_steps,
    )


# --------------------------------------------------------------------------
# Standard target unitaries on the qubit subspace
# --------------------------------------------------------------------------
def U_X():
    return jnp.array([[0, 1], [1, 0]], dtype=jnp.complex64)


def U_Y():
    return jnp.array([[0, -1j], [1j, 0]], dtype=jnp.complex64)


def U_H():
    return jnp.array([[1, 1], [1, -1]], dtype=jnp.complex64) / jnp.sqrt(2.0)


def U_T():
    return jnp.array(
        [[1, 0], [0, jnp.exp(1j * jnp.pi / 4)]], dtype=jnp.complex64
    )


def U_S():
    return jnp.array([[1, 0], [0, 1j]], dtype=jnp.complex64)


# --------------------------------------------------------------------------
# Batched GRAPE: vmap over (init params, target unitary). Multiple restarts
# per target are flattened into the batch dim and reduced at the end.
# --------------------------------------------------------------------------
def make_batched_grape(n_slices: int, n_steps: int, lr: float, omega_max: float):
    """Returns `run_batch(params_init_b, T_gate, U_targets_b, ops) -> (params_b, history_b)`.

    All batched inputs have leading dim B; system operators are shared.
    """
    runner = make_grape_runner(n_slices, n_steps, lr, omega_max)
    batched = jax.vmap(runner, in_axes=(0, None, 0, None, None, None, None))
    return jax.jit(batched)


def grape_batch_optimize(
    U_targets,
    H_drift,
    Hx,
    Hy,
    L_stack,
    *,
    T_gate: float,
    n_slices: int = 80,
    n_steps: int = 400,
    n_restarts: int = 10,
    lr: float = 0.05,
    omega_max: float = 1.0,
    seed: int = 0,
    init_scale: float = 0.1,
    batched_runner=None,
):
    """Run GRAPE on a batch of targets.

    U_targets : (B, 2, 2) complex
    Returns
    -------
    pulses_x : (B, n_slices) float       — best-of-trajectory pulse for each target
    pulses_y : (B, n_slices) float
    fidelities : (B,) float              — best fidelity across restarts and trajectory
    histories  : (B, n_steps) float      — per-step fidelity of the winning restart
    """
    B = U_targets.shape[0]
    R = n_restarts
    if batched_runner is None:
        batched_runner = make_batched_grape(n_slices, n_steps, lr, omega_max)

    key = jax.random.PRNGKey(seed)
    keys = jax.random.split(key, B * R)
    inits = jax.vmap(
        lambda k: init_scale * jax.random.normal(k, (2, n_slices))
    )(keys)  # (B*R, 2, n_slices)
    targets_rep = jnp.repeat(U_targets, R, axis=0)  # (B*R, 2, 2)

    params_b, history_b = batched_runner(
        inits,
        jnp.asarray(T_gate, dtype=jnp.float32),
        targets_rep,
        H_drift, Hx, Hy, L_stack,
    )  # (B*R, 2, n_slices)  — params are best-of-trajectory inside each restart
       # (B*R, n_steps)      — per-step fidelity

    # Reduce over restarts: pick the restart with the highest *best-of-trajectory*
    # fidelity (max over its history), not its last-step fidelity. This matches
    # the semantics of the runner returning best-of-trajectory params.
    histories = history_b.reshape(B, R, -1)              # (B, R, n_steps)
    best_F_per_restart = histories.max(axis=2)            # (B, R)
    best_idx = jnp.argmax(best_F_per_restart, axis=1)     # (B,)
    params_grouped = params_b.reshape(B, R, 2, n_slices)
    best_params = params_grouped[jnp.arange(B), best_idx]
    best_history = histories[jnp.arange(B), best_idx]
    best_F = best_F_per_restart[jnp.arange(B), best_idx]

    px = omega_max * jnp.tanh(best_params[:, 0])
    py = omega_max * jnp.tanh(best_params[:, 1])
    return px, py, best_F, best_history
