"""Publication-quality GRAPE for the inverter benchmark.

Replaces Adam with scipy `L-BFGS-B` (the textbook GRAPE optimizer; Khaneja
2005, QuTiP, Qiskit-Pulse), runs multi-restart with the strict-monotone
final iterate as the per-restart winner, optionally warm-starts the first
restart from a previous optimal pulse, and runs the channel propagator at
complex128 / float64 precision so reported infidelities below ~1e-4 are not
floor-limited by single-precision expm error.

Slower per call than the JIT-batched Adam path in `grape.grape` (no batching
across targets), but converges to deeper local optima — appropriate for any
"inverter vs GRAPE" reference set where optimization quality matters.

Caller MUST enable x64 BEFORE importing JAX-using callables here::

    import jax
    jax.config.update("jax_enable_x64", True)
    from grape.grape_pub import grape_optimize_pub_1q, grape_optimize_pub_2q
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import jax
import jax.numpy as jnp
import numpy as np
import scipy.optimize as so

from sim.transmon import (
    _hamiltonian_super,
    lindblad_super_static,
    basis,
    ket_to_dm,
)


C128 = jnp.complex128
F64 = jnp.float64


# --------------------------------------------------------------------------
# Single-qubit publication GRAPE
# --------------------------------------------------------------------------
def _two_design_states_64(d: int):
    e0 = jnp.zeros(d, dtype=C128).at[0].set(1.0)
    e1 = jnp.zeros(d, dtype=C128).at[1].set(1.0)
    plus = (e0 + e1) / jnp.sqrt(jnp.asarray(2.0, dtype=F64))
    plus_i = (e0 + 1j * e1) / jnp.sqrt(jnp.asarray(2.0, dtype=F64))
    return jnp.stack([e0, e1, plus, plus_i])


def _apply_unitary_64(U_qubit, kets):
    d = kets.shape[-1]
    U_ext = jnp.eye(d, dtype=C128).at[:2, :2].set(U_qubit.astype(C128))
    return jnp.einsum("ij,kj->ki", U_ext, kets)


def _channel_1q_64(pulse_x, pulse_y, T_gate, H_drift, Hx, Hy, L_stack):
    d = H_drift.shape[0]
    eye_d = jnp.eye(d, dtype=C128)
    N = pulse_x.shape[0]
    dt = T_gate / N
    L_diss = lindblad_super_static(L_stack, d).astype(C128)

    def slice_propagator(ox, oy):
        H = H_drift + ox * Hx + oy * Hy
        L_super = _hamiltonian_super(H, eye_d) + L_diss
        return jax.scipy.linalg.expm(L_super * dt)

    Us = jax.vmap(slice_propagator)(pulse_x, pulse_y)  # (N, d², d²)
    M0 = jnp.eye(d * d, dtype=C128)

    def step(M, U):
        return U @ M, None

    M_final, _ = jax.lax.scan(step, M0, Us)
    return M_final


def _avg_fid_1q_64(
    pulse_x, pulse_y, T_gate, U_target, H_drift, Hx, Hy, L_stack,
):
    d = H_drift.shape[0]
    M = _channel_1q_64(pulse_x, pulse_y, T_gate, H_drift, Hx, Hy, L_stack)
    in_kets = _two_design_states_64(d)
    target_kets = _apply_unitary_64(U_target, in_kets)

    def fid_one(ket_in, ket_target):
        rho_in = (ket_in.reshape(-1, 1) @ ket_in.reshape(1, -1).conj()).astype(C128)
        rho_vec = rho_in.T.reshape(-1)
        out_vec = M @ rho_vec
        rho_out = out_vec.reshape(d, d).T
        return jnp.real(jnp.conj(ket_target) @ rho_out @ ket_target)

    fids = jax.vmap(fid_one)(in_kets, target_kets)
    return jnp.mean(fids)


def _make_loss_grad_1q(n_slices: int, omega_max: float):
    """Build a jit'd value+grad closure suitable for scipy L-BFGS-B.

    Returns a function `vag_np(params_flat_np, U_target, T_gate, ops_c)`
    -> (loss_float, grad_np). The jit caches across calls because the
    operator shapes are fixed; only the values vary per call."""

    @jax.jit
    def loss_and_grad(params_flat, U_target, T_gate, H_d, Hx, Hy, L):
        params = params_flat.reshape(2, n_slices)
        pulse_x = omega_max * jnp.tanh(params[0])
        pulse_y = omega_max * jnp.tanh(params[1])
        F = _avg_fid_1q_64(pulse_x, pulse_y, T_gate, U_target, H_d, Hx, Hy, L)
        loss = 1.0 - F
        return loss

    vag = jax.jit(jax.value_and_grad(loss_and_grad))

    def vag_np(p_np, U_target_c, T_gate_f, ops_c):
        v, g = vag(jnp.asarray(p_np, dtype=F64), U_target_c, T_gate_f, *ops_c)
        return float(v), np.asarray(g, dtype=np.float64).reshape(-1)

    return vag_np


@dataclass
class GrapePubResult:
    pulse_x: np.ndarray            # (n_slices,) float64
    pulse_y: np.ndarray            # (n_slices,) float64
    fidelity: float                # best F across restarts (= 1 - res.fun for winner)
    restart_fids: np.ndarray       # (n_restarts,) per-restart final F
    restart_iters: np.ndarray      # (n_restarts,) L-BFGS-B iterations
    n_fevals: int                  # total scipy function evaluations
    converged_mask: np.ndarray     # (n_restarts,) bool — scipy convergence flag


def grape_optimize_pub_1q(
    T_gate: float,
    U_target,
    H_drift, Hx, Hy, L_stack,
    *,
    n_slices: int = 80,
    n_restarts: int = 10,
    omega_max: float = 1.0,
    seed: int = 0,
    init_scale: float = 0.1,
    warmstart_params: Optional[np.ndarray] = None,
    maxiter: int = 500,
    gtol: float = 1e-9,
    ftol: float = 1e-12,
    vag_np=None,
) -> GrapePubResult:
    """Single-qubit publication GRAPE: scipy L-BFGS-B at float64.

    Pass `vag_np` (from `_make_loss_grad_1q(n_slices, omega_max)`) to share
    one JIT compile across many targets in a sweep; otherwise one is built
    on the fly.

    `warmstart_params`: if provided, used as the init for the first restart
    (remaining restarts use random Gaussian inits). Useful for sweeping over
    T_gate by interpolating the previous gate-time's optimum onto the new
    slice grid.
    """
    if vag_np is None:
        vag_np = _make_loss_grad_1q(n_slices, omega_max)

    U_target_c = jnp.asarray(U_target, dtype=C128)
    T_gate_f = jnp.asarray(T_gate, dtype=F64)
    ops_c = (
        jnp.asarray(H_drift, dtype=C128),
        jnp.asarray(Hx, dtype=C128),
        jnp.asarray(Hy, dtype=C128),
        jnp.asarray(L_stack, dtype=C128),
    )

    rng = np.random.default_rng(seed)
    n_params = 2 * n_slices

    best_F = -np.inf
    best_params = None
    restart_fids = np.empty(n_restarts, dtype=np.float64)
    restart_iters = np.empty(n_restarts, dtype=np.int32)
    converged = np.empty(n_restarts, dtype=bool)
    n_fevals_total = 0

    for r in range(n_restarts):
        if r == 0 and warmstart_params is not None:
            p0 = np.asarray(warmstart_params, dtype=np.float64).reshape(-1)
            assert p0.size == n_params, (
                f"warmstart_params size {p0.size} != expected {n_params}"
            )
        else:
            p0 = init_scale * rng.standard_normal(n_params).astype(np.float64)

        res = so.minimize(
            lambda p: vag_np(p, U_target_c, T_gate_f, ops_c),
            x0=p0, jac=True, method="L-BFGS-B",
            options={"maxiter": maxiter, "gtol": gtol, "ftol": ftol},
        )
        F_r = 1.0 - float(res.fun)
        restart_fids[r] = F_r
        restart_iters[r] = int(res.nit)
        converged[r] = bool(res.success)
        n_fevals_total += int(res.nfev)

        if F_r > best_F:
            best_F = F_r
            best_params = res.x.copy()

    px = float(omega_max) * np.tanh(best_params.reshape(2, n_slices)[0])
    py = float(omega_max) * np.tanh(best_params.reshape(2, n_slices)[1])
    return GrapePubResult(
        pulse_x=px.astype(np.float64),
        pulse_y=py.astype(np.float64),
        fidelity=float(best_F),
        restart_fids=restart_fids,
        restart_iters=restart_iters,
        n_fevals=n_fevals_total,
        converged_mask=converged,
    )


# --------------------------------------------------------------------------
# Two-qubit publication GRAPE
# --------------------------------------------------------------------------
def _channel_2q_64(pulse, T_gate, H_drift, H_drives, L_stack):
    d = H_drift.shape[0]
    eye_d = jnp.eye(d, dtype=C128)
    n_slices = pulse.shape[1]
    dt = T_gate / n_slices
    L_diss = lindblad_super_static(L_stack, d).astype(C128)

    def slice_propagator(omegas):
        H_t = H_drift + jnp.einsum("c,cij->ij", omegas.astype(C128), H_drives)
        L_super = _hamiltonian_super(H_t, eye_d) + L_diss
        return jax.scipy.linalg.expm(L_super * dt)

    Us = jax.vmap(slice_propagator)(pulse.T)
    M0 = jnp.eye(d * d, dtype=C128)

    def step(M, U):
        return U @ M, None

    M_final, _ = jax.lax.scan(step, M0, Us)
    return M_final


def _avg_fid_2q_64(pulse, T_gate, U_target, H_drift, H_drives, L_stack):
    d = U_target.shape[0]
    M = _channel_2q_64(pulse, T_gate, H_drift, H_drives, L_stack)
    M_target = jnp.kron(U_target.conj(), U_target)
    F_pro = jnp.real(jnp.trace(M_target.conj().T @ M)) / (d ** 2)
    F_avg = (d * F_pro + 1.0) / (d + 1.0)
    return F_avg


def _make_loss_grad_2q(n_channels: int, n_slices: int, omega_max: float):
    @jax.jit
    def loss_fn(params_flat, U_target, T_gate, H_d, H_dr, L):
        params = params_flat.reshape(n_channels, n_slices)
        pulse = omega_max * jnp.tanh(params)
        F = _avg_fid_2q_64(pulse, T_gate, U_target, H_d, H_dr, L)
        return 1.0 - F

    vag = jax.jit(jax.value_and_grad(loss_fn))

    def vag_np(p_np, U_target_c, T_gate_f, ops_c):
        v, g = vag(jnp.asarray(p_np, dtype=F64), U_target_c, T_gate_f, *ops_c)
        return float(v), np.asarray(g, dtype=np.float64).reshape(-1)

    return vag_np


@dataclass
class GrapePubResult2Q:
    pulse: np.ndarray              # (n_channels, n_slices) float64
    fidelity: float
    restart_fids: np.ndarray
    restart_iters: np.ndarray
    n_fevals: int
    converged_mask: np.ndarray


def grape_optimize_pub_2q(
    T_gate: float,
    U_target,
    H_drift, H_drives, L_stack,
    *,
    n_channels: int = 4,
    n_slices: int = 80,
    n_restarts: int = 10,
    omega_max: float = 1.0,
    seed: int = 0,
    init_scale: float = 0.1,
    warmstart_params: Optional[np.ndarray] = None,
    maxiter: int = 1000,
    gtol: float = 1e-9,
    ftol: float = 1e-12,
    vag_np=None,
) -> GrapePubResult2Q:
    """Two-qubit publication GRAPE: scipy L-BFGS-B at float64.

    Default `maxiter=1000` (vs 500 for 1Q) because the 2Q loss surface is
    higher-dimensional (n_channels=4 vs 2) and harder to fully converge.
    """
    if vag_np is None:
        vag_np = _make_loss_grad_2q(n_channels, n_slices, omega_max)

    U_target_c = jnp.asarray(U_target, dtype=C128)
    T_gate_f = jnp.asarray(T_gate, dtype=F64)
    ops_c = (
        jnp.asarray(H_drift, dtype=C128),
        jnp.asarray(H_drives, dtype=C128),
        jnp.asarray(L_stack, dtype=C128),
    )

    rng = np.random.default_rng(seed)
    n_params = n_channels * n_slices

    best_F = -np.inf
    best_params = None
    restart_fids = np.empty(n_restarts, dtype=np.float64)
    restart_iters = np.empty(n_restarts, dtype=np.int32)
    converged = np.empty(n_restarts, dtype=bool)
    n_fevals_total = 0

    for r in range(n_restarts):
        if r == 0 and warmstart_params is not None:
            p0 = np.asarray(warmstart_params, dtype=np.float64).reshape(-1)
            assert p0.size == n_params, (
                f"warmstart_params size {p0.size} != expected {n_params}"
            )
        else:
            p0 = init_scale * rng.standard_normal(n_params).astype(np.float64)

        res = so.minimize(
            lambda p: vag_np(p, U_target_c, T_gate_f, ops_c),
            x0=p0, jac=True, method="L-BFGS-B",
            options={"maxiter": maxiter, "gtol": gtol, "ftol": ftol},
        )
        F_r = 1.0 - float(res.fun)
        restart_fids[r] = F_r
        restart_iters[r] = int(res.nit)
        converged[r] = bool(res.success)
        n_fevals_total += int(res.nfev)

        if F_r > best_F:
            best_F = F_r
            best_params = res.x.copy()

    pulse = float(omega_max) * np.tanh(best_params.reshape(n_channels, n_slices))
    return GrapePubResult2Q(
        pulse=pulse.astype(np.float64),
        fidelity=float(best_F),
        restart_fids=restart_fids,
        restart_iters=restart_iters,
        n_fevals=n_fevals_total,
        converged_mask=converged,
    )
