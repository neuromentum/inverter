"""GRAPE for 2-qubit gate synthesis under Lindbladian dynamics.

Loss = 1 − F_avg(channel, U_target). For 2-qubit (d=4) we compute average
gate fidelity from the process fidelity:

    F_pro(M, U) = (1/d²) Re Tr((U^* ⊗ U)^† M)
    F_avg(M, U) = (d * F_pro + 1) / (d + 1)

This is exact, ~free once the channel superoperator M is built (just a trace
of two d²×d² matrices), and it's the textbook averaging that we'd otherwise
approximate with state-fidelity over a 2-design. For unitary M the formula
reduces to (d + |Tr(U^† V)|²)/(d² + d) where M = (V^* ⊗ V).
"""
from __future__ import annotations

from typing import NamedTuple

import jax
import jax.numpy as jnp
import optax

from sim.two_qubit import channel_propagator_2q


# --------------------------------------------------------------------------
# Fidelity
# --------------------------------------------------------------------------
def average_gate_fidelity_2q(pulse, T_gate, U_target, H_drift, H_drives, L_stack):
    """Average gate fidelity between the 4-channel pulse channel and U_target.

    pulse: (n_channels, n_slices) real
    U_target: (d, d) complex unitary on the 2-qubit Hilbert space (d=4)
    """
    d = U_target.shape[0]
    M = channel_propagator_2q(pulse, T_gate, H_drift, H_drives, L_stack)  # (d², d²)
    M_target = jnp.kron(U_target.conj(), U_target)                         # (d², d²)
    F_pro = jnp.real(jnp.trace(M_target.conj().T @ M)) / (d ** 2)
    F_avg = (d * F_pro + 1.0) / (d + 1.0)
    return F_avg


def grape_loss_2q(params, T_gate, U_target, H_drift, H_drives, L_stack, omega_max=1.0):
    """params: (n_channels, n_slices) raw, squashed via tanh to ±omega_max."""
    pulse = omega_max * jnp.tanh(params)
    F = average_gate_fidelity_2q(pulse, T_gate, U_target, H_drift, H_drives, L_stack)
    return 1.0 - F


def params_to_pulse_2q(params, omega_max=1.0):
    return omega_max * jnp.tanh(params)


# --------------------------------------------------------------------------
# Optimizer
# --------------------------------------------------------------------------
class GrapeResult2Q(NamedTuple):
    pulse: jnp.ndarray   # (n_channels, n_slices)
    fidelity: float
    history: jnp.ndarray
    n_steps: int


def make_grape_runner_2q(n_channels: int, n_slices: int, n_steps: int,
                          lr: float, omega_max: float):
    """Build a jit'd run_one(params_init, T_gate, U_target, ops) -> (params, history).

    The same compile is reused across T_gate / U_target / system-op variations.

    Returned `params` are the best-of-trajectory iterate (not the final step):
    Adam's last step is not always the best-fidelity step, and tracking the
    best inside the scan keeps the returned pulse consistent with the
    reported fidelity.
    """
    optimizer = optax.adam(lr)

    def step_fn(carry, _):
        params, opt_state, T_gate, U_target, ops, best_params, best_F = carry
        loss, grads = jax.value_and_grad(grape_loss_2q)(
            params, T_gate, U_target, *ops, omega_max
        )
        F = 1.0 - loss
        better = F > best_F
        best_params = jax.tree_util.tree_map(
            lambda b, n: jnp.where(better, n, b), best_params, params,
        )
        best_F = jnp.where(better, F, best_F)
        updates, opt_state = optimizer.update(grads, opt_state)
        params = optax.apply_updates(params, updates)
        return (params, opt_state, T_gate, U_target, ops, best_params, best_F), F

    @jax.jit
    def run_one(params_init, T_gate, U_target, H_drift, H_drives, L_stack):
        ops = (H_drift, H_drives, L_stack)
        opt_state = optimizer.init(params_init)
        best_F0 = jnp.array(-jnp.inf, dtype=jnp.float32)
        carry0 = (params_init, opt_state, T_gate, U_target, ops, params_init, best_F0)
        carry_final, history = jax.lax.scan(
            step_fn, carry0, None, length=n_steps,
        )
        best_params = carry_final[5]
        return best_params, history

    return run_one


def grape_optimize_2q(
    T_gate,
    U_target,
    H_drift,
    H_drives,
    L_stack,
    *,
    n_channels: int = 4,
    n_slices: int = 80,
    n_steps: int = 400,
    n_restarts: int = 10,
    lr: float = 0.05,
    omega_max: float = 1.0,
    seed: int = 0,
    init_scale: float = 0.1,
    runner=None,
) -> GrapeResult2Q:
    """Multi-restart 2-qubit GRAPE.

    Restart selection uses best-of-trajectory fidelity (Adam can drift past
    the optimum, so the final-step value is not always the best). Returned
    `pulse` and `fidelity` come from the same iterate.

    For publication-grade benchmark targets, use
    `grape.grape_pub.grape_optimize_pub_2q` instead — scipy L-BFGS-B at
    complex128/float64 reaches deeper minima than Adam.
    """
    if runner is None:
        runner = make_grape_runner_2q(n_channels, n_slices, n_steps, lr, omega_max)

    key = jax.random.PRNGKey(seed)
    best_F = -jnp.inf
    best_params = None
    best_history = None

    for r in range(n_restarts):
        key, sub = jax.random.split(key)
        params0 = init_scale * jax.random.normal(sub, (n_channels, n_slices))
        params, history = runner(
            params0,
            jnp.asarray(T_gate, dtype=jnp.float32),
            U_target,
            H_drift, H_drives, L_stack,
        )
        F_best_traj = float(jnp.max(history))
        if F_best_traj > best_F:
            best_F = F_best_traj
            best_params = params
            best_history = history

    return GrapeResult2Q(
        pulse=params_to_pulse_2q(best_params, omega_max),
        fidelity=best_F,
        history=best_history,
        n_steps=n_steps,
    )


def make_batched_grape_2q(n_channels: int, n_slices: int, n_steps: int,
                           lr: float, omega_max: float):
    runner = make_grape_runner_2q(n_channels, n_slices, n_steps, lr, omega_max)
    batched = jax.vmap(runner, in_axes=(0, None, 0, None, None, None))
    return jax.jit(batched)


def grape_batch_optimize_2q(
    U_targets,
    H_drift,
    H_drives,
    L_stack,
    *,
    T_gate: float,
    n_channels: int = 4,
    n_slices: int = 80,
    n_steps: int = 400,
    n_restarts: int = 10,
    lr: float = 0.05,
    omega_max: float = 1.0,
    seed: int = 0,
    init_scale: float = 0.1,
    batched_runner=None,
):
    B = U_targets.shape[0]
    R = n_restarts
    if batched_runner is None:
        batched_runner = make_batched_grape_2q(n_channels, n_slices, n_steps, lr, omega_max)

    key = jax.random.PRNGKey(seed)
    keys = jax.random.split(key, B * R)
    inits = jax.vmap(
        lambda k: init_scale * jax.random.normal(k, (n_channels, n_slices))
    )(keys)
    targets_rep = jnp.repeat(U_targets, R, axis=0)

    params_b, history_b = batched_runner(
        inits,
        jnp.asarray(T_gate, dtype=jnp.float32),
        targets_rep,
        H_drift, H_drives, L_stack,
    )

    # Reduce over restarts: pick the restart with the highest *best-of-
    # trajectory* fidelity, matching the runner's best-of-trajectory params.
    histories = history_b.reshape(B, R, -1)
    best_F_per_restart = histories.max(axis=2)
    best_idx = jnp.argmax(best_F_per_restart, axis=1)
    params_grouped = params_b.reshape(B, R, n_channels, n_slices)
    best_params = params_grouped[jnp.arange(B), best_idx]
    best_history = histories[jnp.arange(B), best_idx]
    best_F = best_F_per_restart[jnp.arange(B), best_idx]

    pulses = omega_max * jnp.tanh(best_params)
    return pulses, best_F, best_history
