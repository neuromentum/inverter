"""Phase 2 — GRAPE baseline.

Tests
-----
1. Noise-free X gate: GRAPE recovers ~analytic pi pulse (F >= 0.999).
2. Under realistic noise (T1, Tphi): GRAPE achieves F >= 0.999 on X, H, T
   given sufficient gate time.
3. Reproduce the speed-vs-fidelity tradeoff curve for X gate (vs gate time).

Plots saved under quantum/figures/phase2/.
"""
import os
import sys
import time
import warnings

os.environ.setdefault("JAX_PLATFORMS", "cpu")
warnings.filterwarnings("ignore", message=".*Complex dtype.*", category=UserWarning)

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)

import jax
import jax.numpy as jnp
import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sim.transmon import static_operators
from grape.grape import (
    grape_optimize,
    make_grape_runner,
    average_gate_fidelity,
    params_to_pulse,
    U_X,
    U_H,
    U_T,
)


FIG_DIR = os.path.join(ROOT, "figures", "phase2")
os.makedirs(FIG_DIR, exist_ok=True)


# System parameters. Phase 1 used T1=100, Tphi=80 to make decoherence visible
# on plot timescales. For Phase 2 we use a realistic transmon ratio
# (T1, Tphi ~ 1000x gate time), which is the regime where >=0.999 fidelity
# is physically achievable.
D = 3
ALPHA = -4.0
T1 = 10000.0       # 1/Omega_max units; gate ~ 2π so T1 ~ 1500x gate
TPHI = 8000.0
T2 = 1.0 / (1.0 / (2.0 * T1) + 1.0 / TPHI)


def banner(s):
    print(f"\n{'='*64}\n{s}\n{'='*64}", flush=True)


# ----------------------------------------------------------------------
# Test 1: Noise-free X gate — GRAPE should recover ~analytic pi pulse.
# ----------------------------------------------------------------------
def test_noiseless_x(runner):
    banner("Test 1: Noiseless X gate (GRAPE should recover ~analytic pi pulse)")
    H_drift, Hx, Hy, L_stack = static_operators(D, ALPHA, 1e8, 1e8)
    T_gate = float(jnp.pi) * 1.5  # generous time
    t0 = time.time()
    res = grape_optimize(
        T_gate, U_X(), H_drift, Hx, Hy, L_stack,
        runner=runner, n_restarts=3, seed=0,
    )
    elapsed = time.time() - t0
    print(f"  T_gate = {T_gate:.3f} (1.5 pi)")
    print(f"  GRAPE fidelity: {res.fidelity:.6f}")
    print(f"  wall-clock:     {elapsed:.1f} s")
    assert res.fidelity > 0.999, f"noiseless X gate fidelity too low: {res.fidelity}"
    print("  PASS (>= 0.999)")
    return res, T_gate


# ----------------------------------------------------------------------
# Test 2: Noisy X / H / T at sufficient gate time
# ----------------------------------------------------------------------
def test_noisy_gate_library(runner, T_gate=2.0 * float(jnp.pi)):
    banner(f"Test 2: Noisy gate library (X, H, T)  T1={T1}, Tphi={TPHI}, T2={T2:.0f}")
    H_drift, Hx, Hy, L_stack = static_operators(D, ALPHA, T1, TPHI)
    targets = {"X": U_X(), "H": U_H(), "T": U_T()}
    results = {}
    for name, U in targets.items():
        t0 = time.time()
        res = grape_optimize(
            T_gate, U, H_drift, Hx, Hy, L_stack,
            runner=runner, n_restarts=3, seed=hash(name) & 0xFFFF,
        )
        elapsed = time.time() - t0
        infidelity = 1.0 - res.fidelity
        print(f"  {name}: F = {res.fidelity:.6f}  (1-F = {infidelity:.2e})  [{elapsed:.1f} s]")
        results[name] = (res, elapsed)
    # Decoherence-limited bound for T_gate=2π and T2~5700 is 1-F ~ 2e-4, so 0.999
    # is achievable.
    for name, (res, _) in results.items():
        assert res.fidelity > 0.999, f"{name} gate F={res.fidelity} below 0.999"
    print("  PASS (all >= 0.999)")
    return results, T_gate


# ----------------------------------------------------------------------
# Plot: pulse waveforms for X, H, T
# ----------------------------------------------------------------------
def plot_pulse_waveforms(results, T_gate):
    fig, axes = plt.subplots(len(results), 1, figsize=(10, 2.5 * len(results)),
                             sharex=True)
    if len(results) == 1:
        axes = [axes]
    for ax, (name, (res, _)) in zip(axes, results.items()):
        N = res.pulse_x.shape[0]
        t = np.linspace(0, float(T_gate), N + 1)[:-1] + 0.5 * float(T_gate) / N
        ax.step(t, np.array(res.pulse_x), where="mid", label=r"$\Omega_x(t)$", lw=2)
        ax.step(t, np.array(res.pulse_y), where="mid", label=r"$\Omega_y(t)$", lw=2)
        ax.axhline(0, color="gray", lw=0.5)
        ax.axhline(1, color="gray", lw=0.5, linestyle=":")
        ax.axhline(-1, color="gray", lw=0.5, linestyle=":")
        ax.set_ylim(-1.1, 1.1)
        ax.set_ylabel("amplitude")
        ax.set_title(rf"GRAPE pulse for {name} gate  (F = {res.fidelity:.5f})")
        ax.legend(loc="upper right")
        ax.grid(alpha=0.3)
    axes[-1].set_xlabel(r"time $[1/\Omega_{\max}]$")
    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, "grape_waveforms.png"), dpi=120)
    plt.close()


# ----------------------------------------------------------------------
# Plot: fidelity vs gate-time for X gate (the headline tradeoff)
# ----------------------------------------------------------------------
def plot_fidelity_vs_gate_time(sweep_runner):
    banner("Plot: Fidelity vs gate time (X gate, GRAPE)")
    H_drift_n, Hx_n, Hy_n, L_n = static_operators(D, ALPHA, T1, TPHI)
    H_drift_c, Hx_c, Hy_c, L_c = static_operators(D, ALPHA, 1e8, 1e8)
    T_gates = jnp.linspace(0.6, 6.0, 12) * jnp.pi
    fids_n = []
    fids_c = []
    times = []
    for T_g in T_gates:
        t0 = time.time()
        res_c = grape_optimize(
            float(T_g), U_X(), H_drift_c, Hx_c, Hy_c, L_c,
            runner=sweep_runner, n_restarts=2, seed=1,
        )
        res_n = grape_optimize(
            float(T_g), U_X(), H_drift_n, Hx_n, Hy_n, L_n,
            runner=sweep_runner, n_restarts=2, seed=1,
        )
        elapsed = time.time() - t0
        times.append(elapsed)
        fids_c.append(res_c.fidelity)
        fids_n.append(res_n.fidelity)
        print(f"  T_g = {float(T_g)/np.pi:.2f} pi:  F_clean = {res_c.fidelity:.5f}  F_noisy = {res_n.fidelity:.5f}  ({elapsed:.1f}s)")

    Tg = np.array(T_gates) / np.pi
    fids_c = np.array(fids_c)
    fids_n = np.array(fids_n)

    fig, ax = plt.subplots(1, 2, figsize=(12, 4))
    ax[0].plot(Tg, 1 - fids_c, "o-", label="noiseless")
    ax[0].plot(Tg, 1 - fids_n, "s-", label=rf"$T_1$={T1:g}, $T_\varphi$={TPHI:g}")
    ax[0].set_yscale("log")
    ax[0].set_xlabel(r"gate time $[\pi/\Omega_{\max}]$")
    ax[0].set_ylabel(r"$1 - F$  (infidelity)")
    ax[0].set_title("GRAPE: speed-vs-decoherence tradeoff (X gate)")
    ax[0].axhline(1e-3, color="r", linestyle="--", label="0.999 threshold")
    ax[0].legend()
    ax[0].grid(alpha=0.3, which="both")

    ax[1].plot(Tg, times, "o-")
    ax[1].set_xlabel(r"gate time $[\pi/\Omega_{\max}]$")
    ax[1].set_ylabel("wall-clock GRAPE solve [s]")
    ax[1].set_title("GRAPE compute cost per target")
    ax[1].grid(alpha=0.3)

    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, "grape_fidelity_vs_gate_time.png"), dpi=120)
    plt.close()
    return Tg, fids_c, fids_n, times


# ----------------------------------------------------------------------
# Plot: training curves for the noisy gate library
# ----------------------------------------------------------------------
def plot_training_curves(results):
    fig, ax = plt.subplots(figsize=(7, 4))
    for name, (res, _) in results.items():
        infid = 1.0 - np.array(res.history)
        infid = np.clip(infid, 1e-9, None)  # avoid log(0)
        ax.plot(infid, label=f"{name}  (F = {res.fidelity:.5f})", lw=2)
    ax.set_yscale("log")
    ax.set_xlabel("optimizer step (best restart)")
    ax.set_ylabel(r"infidelity $1 - F$")
    ax.axhline(1e-3, color="r", linestyle="--", alpha=0.5, label="0.999 threshold")
    ax.set_title("GRAPE convergence")
    ax.legend()
    ax.grid(alpha=0.3, which="both")
    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, "grape_training_curves.png"), dpi=120)
    plt.close()


# ----------------------------------------------------------------------
def main():
    print(f"JAX {jax.__version__}, devices: {jax.devices()}")
    print(f"Phase 2 settings: d={D}, alpha={ALPHA}, T1={T1}, Tphi={TPHI}, T2={T2:.0f}")

    # Build a single jit-compiled runner for the headline tests (n_slices=80, 400 steps)
    main_runner = make_grape_runner(n_slices=80, n_steps=400, lr=0.05, omega_max=1.0)
    # Smaller runner for the gate-time sweep (n_slices=40, 300 steps).
    sweep_runner = make_grape_runner(n_slices=40, n_steps=300, lr=0.05, omega_max=1.0)

    # 1. Noiseless X
    res_x_clean, T_x = test_noiseless_x(main_runner)

    # 2. Noisy library
    results, T_gate = test_noisy_gate_library(main_runner)
    plot_pulse_waveforms(results, T_gate)
    plot_training_curves(results)

    # 3. Fidelity-vs-gate-time sweep (uses the smaller runner; one compile, fast loop).
    plot_fidelity_vs_gate_time(sweep_runner)

    print(f"\nAll Phase 2 figures saved to: {FIG_DIR}")


if __name__ == "__main__":
    main()
