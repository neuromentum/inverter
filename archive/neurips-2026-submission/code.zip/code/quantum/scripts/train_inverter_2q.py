"""Phase 7.3 — train a 2-qubit inverter (sim-in-the-loop).

Same shape as `train_inverter.py` but for 2-qubit U(4) targets, 4-channel
pulse, and the 2-qubit Lindblad simulator.

Usage:
    python scripts/train_inverter_2q.py configs/phase7_inverter_default.yml
    python scripts/train_inverter_2q.py configs/phase7_inverter_default.yml \
        training.lr=5e-4 inverter.input_encoding=real32
"""
import json
import os
import sys
import time
import warnings

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)

from utils.experiment import (
    load_config, merge_overrides, make_run_dir, snapshot_config,
    JSONLLogger, parse_cli,
)

config_path, overrides = parse_cli()
cfg = merge_overrides(load_config(config_path), overrides)

os.environ.setdefault("JAX_PLATFORMS", cfg.get("platform", "cpu"))
warnings.filterwarnings("ignore", message=".*Complex dtype.*", category=UserWarning)
warnings.filterwarnings("ignore", message=".*Casting complex.*", category=Warning)

import jax
import jax.numpy as jnp
import numpy as np
import equinox as eqx
import optax
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sim.two_qubit import static_operators_2q
from data.sampling import haar_su4_batch
from grape.grape_2q import average_gate_fidelity_2q
from inverter.arch_2q import build_inverter_2q_arch


# ----------------------------------------------------------------------
sys_cfg = cfg["system"]
gate_cfg = cfg["gate"]
inv_cfg = cfg["inverter"]
trn_cfg = cfg["training"]
eval_cfg = cfg["eval"]

T_GATE = float(gate_cfg["T_gate"])
N_SLICES = int(gate_cfg["n_slices"])
OMEGA_MAX = float(sys_cfg["omega_max"])
SEED = int(cfg.get("experiment", {}).get("seed", 0))

H_drift, H_drives, L_stack = static_operators_2q(
    J=float(sys_cfg["J"]),
    T1=float(sys_cfg["T1"]),
    Tphi=float(sys_cfg["Tphi"]),
)

ref_path = eval_cfg["ref_set_path"]
if not os.path.isabs(ref_path):
    ref_path = os.path.join(ROOT, ref_path)


# ----------------------------------------------------------------------
run_dir = make_run_dir(cfg, root=os.path.join(ROOT, "experiments"))
snapshot_config(cfg, run_dir, src_path=config_path)
logger = JSONLLogger(os.path.join(run_dir, "log.jsonl"))

print(f"\nRun directory: {run_dir}")
print(f"JAX {jax.__version__}, devices: {jax.devices()}\n")
logger.log(event="start", run_dir=run_dir, jax=jax.__version__)


# ----------------------------------------------------------------------
key = jax.random.PRNGKey(SEED)
key, init_key = jax.random.split(key)

# Build arch_config from inv_cfg by stripping the dispatch keys
arch_config = {k: v for k, v in inv_cfg.items()
               if k not in ("arch", "input_encoding", "n_channels")}
model = build_inverter_2q_arch(
    arch=inv_cfg["arch"],
    n_slices=N_SLICES,
    n_channels=int(inv_cfg.get("n_channels", 4)),
    input_encoding=inv_cfg.get("input_encoding", "real32_su4"),
    arch_config=arch_config,
    key=init_key,
)

# Optional warm-start from a previous checkpoint
init_ckpt = trn_cfg.get("init_ckpt", None)
if init_ckpt:
    if not os.path.isabs(init_ckpt):
        init_ckpt = os.path.join(ROOT, init_ckpt)
    print(f"Warm-starting from checkpoint: {init_ckpt}")
    model = eqx.tree_deserialise_leaves(init_ckpt, model)

n_steps_total = int(trn_cfg["n_steps"])
lr0 = float(trn_cfg["lr"])
lr_schedule_kind = trn_cfg.get("lr_schedule", "constant")
warmup_steps = int(trn_cfg.get("warmup_steps", 0))
if lr_schedule_kind == "cosine":
    lr_min = float(trn_cfg.get("lr_min", lr0 * 1e-2))
    cosine = optax.cosine_decay_schedule(
        lr0, decay_steps=max(1, n_steps_total - warmup_steps),
        alpha=lr_min / lr0,
    )
    if warmup_steps > 0:
        warmup = optax.linear_schedule(0.0, lr0, warmup_steps)
        schedule = optax.join_schedules([warmup, cosine], boundaries=[warmup_steps])
    else:
        schedule = cosine
elif lr_schedule_kind == "constant":
    schedule = lr0
else:
    raise ValueError(f"unknown lr_schedule: {lr_schedule_kind}")

opt_name = trn_cfg.get("optimizer", "adam")
weight_decay = float(trn_cfg.get("weight_decay", 0.0))
if opt_name == "adam":
    optimizer = optax.adam(schedule)
elif opt_name == "adamw":
    optimizer = optax.adamw(schedule, weight_decay=weight_decay)
else:
    raise ValueError(f"unknown optimizer: {opt_name}")
opt_state = optimizer.init(eqx.filter(model, eqx.is_array))

SMOOTHNESS_LAMBDA = float(trn_cfg.get("smoothness_lambda", 0.0))


# ----------------------------------------------------------------------
TRAIN_MODE = trn_cfg.get("mode", "fidelity")  # "fidelity" or "mse"
PRETRAIN_DATA_PATH = trn_cfg.get("pretrain_data_path", None)


def loss_fn_single(model, U_target, target_pulse=None):
    """Loss for one example.

    `fidelity` mode: simulator-in-the-loop, 1 - F_avg.
    `mse` mode (pretrain): MSE between predicted pulse and target_pulse from
    a GRAPE-generated dataset. Used for the supervised pretraining stage that
    Lipaei et al. consciously avoided.
    """
    pulse_raw = model(U_target)
    pulse = OMEGA_MAX * jnp.tanh(pulse_raw)        # (4, n_slices)
    if TRAIN_MODE == "mse":
        return jnp.mean((pulse - target_pulse) ** 2)
    F = average_gate_fidelity_2q(pulse, T_GATE, U_target,
                                  H_drift, H_drives, L_stack)
    loss = 1.0 - F
    if SMOOTHNESS_LAMBDA > 0:
        smoothness = jnp.mean(jnp.diff(pulse, axis=1) ** 2)
        loss = loss + SMOOTHNESS_LAMBDA * smoothness
    return loss


def loss_fn_batch(model, U_targets_batch, target_pulses_batch=None):
    if TRAIN_MODE == "mse":
        losses = jax.vmap(loss_fn_single, in_axes=(None, 0, 0))(
            model, U_targets_batch, target_pulses_batch
        )
    else:
        losses = jax.vmap(loss_fn_single, in_axes=(None, 0, None))(
            model, U_targets_batch, None
        )
    return jnp.mean(losses), losses


@eqx.filter_jit
def train_step(model, opt_state, U_targets_batch, target_pulses_batch=None):
    (loss, per_target), grads = eqx.filter_value_and_grad(
        loss_fn_batch, has_aux=True
    )(model, U_targets_batch, target_pulses_batch)
    params = eqx.filter(model, eqx.is_array)
    updates, opt_state = optimizer.update(grads, opt_state, params)
    model = eqx.apply_updates(model, updates)
    return model, opt_state, loss, per_target


@eqx.filter_jit
def eval_batch(model, U_targets_batch):
    """Evaluation always uses fidelity loss (1 - F_avg) regardless of TRAIN_MODE."""
    def _fid_loss(model, U):
        pulse = OMEGA_MAX * jnp.tanh(model(U))
        F = average_gate_fidelity_2q(pulse, T_GATE, U, H_drift, H_drives, L_stack)
        return 1.0 - F
    return jax.vmap(_fid_loss, in_axes=(None, 0))(model, U_targets_batch)


# ----------------------------------------------------------------------
print(f"Loading reference set: {ref_path}")
ref = np.load(ref_path)
ref_U = jnp.asarray(ref["U_targets"])
ref_F_grape = jnp.asarray(ref["fidelities"])
print(f"  {ref_U.shape[0]} reference SU(4) targets,  GRAPE mean F = {float(jnp.mean(ref_F_grape)):.5f}")
logger.log(event="ref_loaded", n=int(ref_U.shape[0]), grape_mean_F=float(jnp.mean(ref_F_grape)))


# ----------------------------------------------------------------------
print("\nTraining...")
batch_size = int(trn_cfg["batch_size"])
log_every = int(trn_cfg["log_every"])
eval_every = int(trn_cfg["eval_every"])
ckpt_every = int(trn_cfg["ckpt_every"])
n_eval_haar = int(eval_cfg["n_eval_haar"])

if TRAIN_MODE == "mse":
    if PRETRAIN_DATA_PATH is None:
        raise ValueError("training.mode='mse' requires training.pretrain_data_path")
    pretrain_path = PRETRAIN_DATA_PATH
    if not os.path.isabs(pretrain_path):
        pretrain_path = os.path.join(ROOT, pretrain_path)
    print(f"Loading pretrain dataset: {pretrain_path}")
    pre = np.load(pretrain_path)
    pre_U = jnp.asarray(pre["U_targets"])
    pre_pulses = jnp.asarray(pre["pulses"])    # (N, 4, n_slices)
    print(f"  {pre_U.shape[0]} (U, pulse) pairs;  pulse shape {pre_pulses.shape}")
    logger.log(event="pretrain_loaded", n=int(pre_U.shape[0]))


t0 = time.time()
losses_log, ref_eval_log, haar_eval_log = [], [], []
for step in range(1, n_steps_total + 1):
    key, sub = jax.random.split(key)
    if TRAIN_MODE == "mse":
        # Sample batch_size indices from the pretrain dataset
        idx = jax.random.randint(sub, (batch_size,), 0, pre_U.shape[0])
        U_batch = pre_U[idx]
        pulse_batch = pre_pulses[idx]
        model, opt_state, loss, per_t = train_step(model, opt_state, U_batch, pulse_batch)
    else:
        U_batch = haar_su4_batch(sub, batch_size)
        model, opt_state, loss, per_t = train_step(model, opt_state, U_batch)
    loss = float(loss)
    losses_log.append((step, loss))

    if step % log_every == 0 or step == 1:
        elapsed = time.time() - t0
        rate = step / elapsed
        F_batch = float(1.0 - loss)
        print(f"  step {step:5d}  1-F = {loss:.5e}   F = {F_batch:.5f}   ({rate:.2f} steps/s)", flush=True)
        logger.log(event="train", step=step, loss=loss, fidelity=F_batch, rate=rate)

    if step % eval_every == 0 or step == n_steps_total:
        ref_losses = eval_batch(model, ref_U)
        ref_F = 1.0 - np.asarray(ref_losses)
        ref_mean_F = float(np.mean(ref_F))
        ref_min_F = float(np.min(ref_F))
        ref_above_999 = float(np.mean(ref_F >= 0.999))
        key, sub = jax.random.split(key)
        haar_U = haar_su4_batch(sub, n_eval_haar)
        haar_losses = eval_batch(model, haar_U)
        haar_F = 1.0 - np.asarray(haar_losses)
        haar_mean_F = float(np.mean(haar_F))
        print(f"    [eval] ref:  mean F = {ref_mean_F:.5f}, min F = {ref_min_F:.5f}, ≥0.999 = {ref_above_999*100:.0f}%")
        print(f"           haar: mean F = {haar_mean_F:.5f}", flush=True)
        ref_eval_log.append((step, ref_mean_F, ref_min_F, ref_above_999))
        haar_eval_log.append((step, haar_mean_F))
        logger.log(
            event="eval", step=step,
            ref_mean_F=ref_mean_F, ref_min_F=ref_min_F, ref_above_999=ref_above_999,
            haar_mean_F=haar_mean_F,
        )

    if step % ckpt_every == 0 or step == n_steps_total:
        ckpt_path = os.path.join(run_dir, "checkpoints", f"step_{step:06d}.eqx")
        eqx.tree_serialise_leaves(ckpt_path, model)


final_ckpt = os.path.join(run_dir, "checkpoints", f"step_{n_steps_total:06d}.eqx")
final_link = os.path.join(run_dir, "checkpoints", "final.eqx")
if os.path.lexists(final_link):
    os.remove(final_link)
os.symlink(os.path.basename(final_ckpt), final_link)


# ----------------------------------------------------------------------
print("\nFinal eval...")
ref_losses = eval_batch(model, ref_U)
ref_F = 1.0 - np.asarray(ref_losses)
key, sub = jax.random.split(key)
haar_U_final = haar_su4_batch(sub, max(n_eval_haar, 1024))
haar_losses_final = eval_batch(model, haar_U_final)
haar_F_final = 1.0 - np.asarray(haar_losses_final)

ref_F_grape_np = np.asarray(ref_F_grape)
deltas = ref_F_grape_np - ref_F

eval_results = {
    "ref": {
        "n": int(ref_U.shape[0]),
        "mean_F_inverter": float(np.mean(ref_F)),
        "min_F_inverter": float(np.min(ref_F)),
        "frac_above_999": float(np.mean(ref_F >= 0.999)),
        "mean_F_grape": float(np.mean(ref_F_grape_np)),
        "mean_gap_grape_minus_inverter": float(np.mean(deltas)),
        "median_gap_grape_minus_inverter": float(np.median(deltas)),
    },
    "haar_held_out": {
        "n": int(haar_U_final.shape[0]),
        "mean_F": float(np.mean(haar_F_final)),
        "min_F": float(np.min(haar_F_final)),
        "frac_above_999": float(np.mean(haar_F_final >= 0.999)),
    },
    "wall_clock_s": time.time() - t0,
}
with open(os.path.join(run_dir, "eval_results.json"), "w") as f:
    json.dump(eval_results, f, indent=2)
print(json.dumps(eval_results, indent=2))
logger.log(event="final_eval", **eval_results)


# Plots
fig, ax = plt.subplots(figsize=(8, 4))
steps, losses = zip(*losses_log)
ax.plot(steps, losses, lw=1, alpha=0.6, label="train batch")
if ref_eval_log:
    ev_steps, ev_mean, _, _ = zip(*ref_eval_log)
    ax.plot(ev_steps, [1 - m for m in ev_mean], "o-", color="C1",
            label="ref-set mean 1-F")
ax.set_yscale("log")
ax.set_xlabel("step")
ax.set_ylabel("infidelity 1 - F")
ax.axhline(1e-3, color="r", linestyle="--", alpha=0.5, label="0.999")
grape_floor = 1.0 - float(np.mean(ref_F_grape_np))
ax.axhline(grape_floor, color="g", linestyle=":", alpha=0.7,
           label=f"GRAPE floor = {grape_floor:.4e}")
ax.legend()
ax.grid(alpha=0.3, which="both")
ax.set_title(f"2-qubit inverter training  ({inv_cfg.get('input_encoding', 'real32_su4')})")
plt.tight_layout()
plt.savefig(os.path.join(run_dir, "figures", "train_curve.png"), dpi=120)
plt.close()

fig, ax = plt.subplots(figsize=(8, 4))
ax.hist(np.clip(1 - haar_F_final, 1e-6, 1.0), bins=40, alpha=0.7,
        label=f"inverter Haar (n={haar_F_final.size})")
ax.hist(1 - ref_F_grape_np, bins=40, alpha=0.7,
        label=f"GRAPE refset (n={ref_F_grape_np.size})")
ax.set_xscale("log")
ax.set_xlabel("infidelity 1 - F")
ax.set_ylabel("count")
ax.set_title(f"2-qubit inverter vs GRAPE  inverter mean F: {np.mean(haar_F_final):.5f}")
ax.legend(); ax.grid(alpha=0.3, which="both")
plt.tight_layout()
plt.savefig(os.path.join(run_dir, "figures", "fid_hist.png"), dpi=120)
plt.close()

fig, ax = plt.subplots(figsize=(8, 4))
ax.scatter(1 - ref_F_grape_np, np.clip(1 - ref_F, 1e-9, 1), s=10, alpha=0.7)
lo = float(min((1 - ref_F_grape_np).min(), (np.clip(1 - ref_F, 1e-9, 1)).min()))
hi = float(max((1 - ref_F_grape_np).max(), (np.clip(1 - ref_F, 1e-9, 1)).max()))
ax.plot([lo, hi], [lo, hi], "k--", alpha=0.5, label="parity")
ax.set_xscale("log"); ax.set_yscale("log")
ax.set_xlabel("GRAPE 1-F"); ax.set_ylabel("Inverter 1-F")
ax.set_title("Per-target comparison")
ax.legend(); ax.grid(alpha=0.3, which="both")
plt.tight_layout()
plt.savefig(os.path.join(run_dir, "figures", "per_target_gap.png"), dpi=120)
plt.close()

logger.close()
print(f"\nDone. Outputs in: {run_dir}")
