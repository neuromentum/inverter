"""Phase 7.2 — generate the 2-qubit reference set (Haar SU(4) → GRAPE pulses).

Process-parallel design: each invocation handles a contiguous chunk of targets
(--start_idx, --end_idx). A wrapper shell script launches K parallel workers
across CPU cores, then a final combine step merges the chunk .npz files into
the final reference set.

Targets per chunk are processed by serial calls to `grape_optimize_2q`,
sharing one JIT compile per process. This avoids the giant vmap-of-scan
compile that the previous fully-batched implementation produced.

Usage:
    # single chunk (handy for smoke):
    python scripts/phase7_data.py --start_idx 0 --end_idx 5
    # combine all chunks into the reference .npz:
    python scripts/phase7_data.py --combine
"""
import argparse
import glob
import os
import sys
import time
import warnings

os.environ.setdefault("JAX_PLATFORMS", "cpu")
warnings.filterwarnings("ignore", message=".*Complex dtype.*", category=UserWarning)
warnings.filterwarnings("ignore", message=".*Casting complex.*", category=Warning)

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--n_targets",  type=int,   default=100)
    p.add_argument("--start_idx",  type=int,   default=0)
    p.add_argument("--end_idx",    type=int,   default=None,
                   help="exclusive; if None, process up to n_targets")
    p.add_argument("--T_gate",     type=float, default=4.0 * 3.141592653589793)
    p.add_argument("--n_slices",   type=int,   default=80)
    p.add_argument("--n_steps",    type=int,   default=600)
    p.add_argument("--n_restarts", type=int,   default=3)
    p.add_argument("--J",          type=float, default=0.3)
    p.add_argument("--T1",         type=float, default=10000.0)
    p.add_argument("--Tphi",       type=float, default=8000.0)
    p.add_argument("--seed",       type=int,   default=11)
    p.add_argument("--combine",    action="store_true",
                   help="combine all chunks into the final reference .npz")
    return p.parse_args()


args = parse_args()

import jax
import jax.numpy as jnp
import numpy as np

from sim.two_qubit import static_operators_2q
from data.sampling import haar_su4_batch
from grape.grape_2q import grape_optimize_2q, make_grape_runner_2q


DATA_DIR = os.path.join(ROOT, "data")
# Per-(n_targets, seed) chunks directory so concurrent dataset builds (e.g. the
# 100-target ref set vs the 10k pretrain set) don't clobber each other.
CHUNKS_DIR = os.path.join(DATA_DIR, f"refset_2q_chunks_n{args.n_targets}_seed{args.seed}")
os.makedirs(CHUNKS_DIR, exist_ok=True)
FINAL_PATH = os.path.join(DATA_DIR, f"refset_2q_T4pi_n{args.n_targets}_seed{args.seed}.npz")


def banner(s):
    print(f"\n{'='*64}\n{s}\n{'='*64}", flush=True)


def combine():
    chunks = sorted(glob.glob(os.path.join(CHUNKS_DIR, "chunk_*.npz")))
    if not chunks:
        print("No chunks found in", CHUNKS_DIR)
        sys.exit(1)
    Us, pulses, fids = [], [], []
    for c in chunks:
        d = np.load(c)
        Us.append(d["U_targets"])
        pulses.append(d["pulses"])
        fids.append(d["fidelities"])
    Us_all = np.concatenate(Us, axis=0)
    pulses_all = np.concatenate(pulses, axis=0)
    fids_all = np.concatenate(fids, axis=0)
    print(f"Combined {len(chunks)} chunks → {Us_all.shape[0]} targets")
    print(f"  fidelity stats: mean = {fids_all.mean():.5f}, min = {fids_all.min():.5f}, max = {fids_all.max():.5f}")
    for thr in [0.99, 0.999, 0.9999]:
        print(f"  ≥ {thr}: {(fids_all >= thr).mean()*100:.1f}%")
    np.savez(
        FINAL_PATH,
        U_targets=Us_all,
        pulses=pulses_all,
        fidelities=fids_all,
        T_gate=np.float32(args.T_gate),
        n_slices=np.int32(args.n_slices),
        J=np.float32(args.J),
        T1=np.float32(args.T1),
        Tphi=np.float32(args.Tphi),
        omega_max=np.float32(1.0),
    )
    print(f"Saved {FINAL_PATH}")


def run_chunk(start_idx, end_idx):
    H_d, H_dr, L = static_operators_2q(J=args.J, T1=args.T1, Tphi=args.Tphi)
    # Sample targets deterministically from the global key, then take the chunk.
    U_all = haar_su4_batch(jax.random.PRNGKey(args.seed), args.n_targets)
    U_chunk = U_all[start_idx:end_idx]
    n = U_chunk.shape[0]
    banner(f"Chunk {start_idx}:{end_idx}  ({n} targets)")

    # One runner per process (compile shared across the chunk's targets)
    runner = make_grape_runner_2q(
        n_channels=4, n_slices=args.n_slices,
        n_steps=args.n_steps, lr=0.05, omega_max=1.0,
    )

    pulses = np.zeros((n, 4, args.n_slices), dtype=np.float32)
    fids = np.zeros(n, dtype=np.float32)
    t_chunk_start = time.time()
    for i in range(n):
        U = U_chunk[i]
        t0 = time.time()
        res = grape_optimize_2q(
            args.T_gate, U, H_d, H_dr, L,
            n_channels=4, n_slices=args.n_slices, n_steps=args.n_steps,
            n_restarts=args.n_restarts, seed=args.seed * 1000 + start_idx + i,
            runner=runner,
        )
        pulses[i] = np.asarray(res.pulse)
        fids[i] = float(res.fidelity)
        print(f"  [{start_idx+i:3d}]  F = {fids[i]:.5f}   ({time.time()-t0:.1f}s,  chunk elapsed {time.time()-t_chunk_start:.0f}s)", flush=True)

    out_path = os.path.join(CHUNKS_DIR, f"chunk_{start_idx:03d}_{end_idx:03d}.npz")
    np.savez(out_path,
             U_targets=np.asarray(U_chunk),
             pulses=pulses,
             fidelities=fids,
             start_idx=np.int32(start_idx),
             end_idx=np.int32(end_idx))
    print(f"\nSaved {out_path}")


def main():
    if args.combine:
        combine()
        return
    end = args.end_idx if args.end_idx is not None else args.n_targets
    print(f"JAX {jax.__version__}, devices: {jax.devices()}", flush=True)
    print(f"Process: indices [{args.start_idx}, {end}); J={args.J}, T1={args.T1}, Tphi={args.Tphi}", flush=True)
    run_chunk(args.start_idx, end)


if __name__ == "__main__":
    main()
