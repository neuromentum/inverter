"""Phase 3 — sampling infrastructure + reference dataset.

Builds:
- (3a) Haar U(2) sampler + KS-style test against the analytic semicircle CDF.
- (3b) Batched GRAPE (vmap over targets x restarts).
- (3c) Reference set of 100 (Haar U, GRAPE-optimal pulse) pairs at fixed T_gate=2π.

Saves:
- quantum/data/refset_T2pi_n100.npz
- quantum/figures/phase3/{haar_axis.png, haar_trace_ks.png,
                          fidelity_hist.png, pulse_psd.png, sample_pulses.png}
"""
import os
import sys
import time
import warnings

os.environ.setdefault("JAX_PLATFORMS", "cpu")
warnings.filterwarnings("ignore", message=".*Complex dtype.*", category=UserWarning)

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)

import jax
import jax.numpy as jnp
import numpy as np
from scipy import stats as sp_stats
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sim.transmon import static_operators
from data.sampling import (
    haar_unitary_batch,
    axis_angle,
    haar_su2_trace_cdf,
)
from grape.grape import (
    make_batched_grape,
    grape_batch_optimize,
)


FIG_DIR = os.path.join(ROOT, "figures", "phase3")
DATA_DIR = os.path.join(ROOT, "data")
os.makedirs(FIG_DIR, exist_ok=True)
os.makedirs(DATA_DIR, exist_ok=True)


# Phase-2 system params (realistic transmon ratio)
D = 3
ALPHA = -4.0
T1 = 10000.0
TPHI = 8000.0
T2 = 1.0 / (1.0 / (2.0 * T1) + 1.0 / TPHI)


def banner(s):
    print(f"\n{'='*64}\n{s}\n{'='*64}", flush=True)


# ----------------------------------------------------------------------
# 3a — Haar sampling diagnostics
# ----------------------------------------------------------------------
def test_haar_sampling(n_samples=10_000):
    banner(f"3a — Haar U(2) sampling test (n = {n_samples})")
    key = jax.random.PRNGKey(2026_04_27)
    Us = haar_unitary_batch(key, n_samples, d=2)
    Us_np = np.asarray(Us)

    # KS test: Re(Tr/2) for SU(2) projection should follow semicircle CDF.
    axes_thetas = jax.vmap(axis_angle)(Us)
    n_hat = np.asarray(axes_thetas[0])    # (n, 3)
    theta = np.asarray(axes_thetas[1])    # (n,)
    cos_half = np.cos(theta / 2.0)        # = Tr(U_su)/2

    ks_stat, ks_p = sp_stats.kstest(cos_half, lambda x: np.asarray(haar_su2_trace_cdf(jnp.asarray(x))))
    print(f"  KS stat vs semicircle: D = {ks_stat:.4f}, p = {ks_p:.3f}")
    assert ks_p > 0.01, f"Haar trace KS p-value too low: {ks_p}"
    print("  PASS  (cos(θ/2) ~ Wigner semicircle)")

    # Plot 1: rotation axis on Bloch sphere, should be uniform on S²
    fig = plt.figure(figsize=(7, 7))
    ax = fig.add_subplot(111, projection="3d")
    u, v = np.mgrid[0:2 * np.pi:30j, 0:np.pi:15j]
    sx, sy, sz = np.cos(u) * np.sin(v), np.sin(u) * np.sin(v), np.cos(v)
    ax.plot_wireframe(sx, sy, sz, color="gray", alpha=0.15, linewidth=0.5)
    sub = n_hat[:1500]
    ax.scatter(sub[:, 0], sub[:, 1], sub[:, 2], s=2, alpha=0.5)
    ax.set_xlabel(r"$n_x$")
    ax.set_ylabel(r"$n_y$")
    ax.set_zlabel(r"$n_z$")
    ax.set_title(f"Haar rotation axes on $S^2$  ({n_samples} samples)")
    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, "haar_axis.png"), dpi=120)
    plt.close()

    # Plot 2: empirical CDF of cos(θ/2) vs analytic Haar SU(2) CDF
    fig, ax = plt.subplots(figsize=(7, 4))
    xs = np.linspace(-1, 1, 401)
    cdf_emp = np.searchsorted(np.sort(cos_half), xs) / n_samples
    cdf_haar = np.asarray(haar_su2_trace_cdf(jnp.asarray(xs)))
    ax.plot(xs, cdf_emp, label="empirical", lw=2)
    ax.plot(xs, cdf_haar, "--", label="Haar SU(2)", lw=2)
    ax.set_xlabel(r"$\cos(\theta/2) = \mathrm{Tr}(U_{SU})/2$")
    ax.set_ylabel("CDF")
    ax.set_title(f"Haar trace test (KS D = {ks_stat:.3f}, p = {ks_p:.3f})")
    ax.legend()
    ax.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, "haar_trace_ks.png"), dpi=120)
    plt.close()

    return Us, ks_stat, ks_p


# ----------------------------------------------------------------------
# 3b + 3c — batched GRAPE on Haar-sampled targets
# ----------------------------------------------------------------------
def build_reference_set(n_targets=100, T_gate=None, n_slices=80, n_steps=400, n_restarts=3):
    if T_gate is None:
        T_gate = 2.0 * float(jnp.pi)

    banner(f"3b + 3c — batched GRAPE on {n_targets} Haar U(2)  (T_gate = 2π, n_slices = {n_slices})")
    H_drift, Hx, Hy, L_stack = static_operators(D, ALPHA, T1, TPHI)

    key = jax.random.PRNGKey(7)
    U_targets = haar_unitary_batch(key, n_targets, d=2)

    # Compile-once batched runner
    runner = make_batched_grape(n_slices=n_slices, n_steps=n_steps, lr=0.05, omega_max=1.0)
    print(f"  warming up JIT (B = {n_targets} x {n_restarts} restarts) ...", flush=True)
    t0 = time.time()
    px, py, fids, histories = grape_batch_optimize(
        U_targets, H_drift, Hx, Hy, L_stack,
        T_gate=T_gate,
        n_slices=n_slices, n_steps=n_steps, n_restarts=n_restarts,
        lr=0.05, omega_max=1.0, seed=42,
        batched_runner=runner,
    )
    elapsed = time.time() - t0
    print(f"  done in {elapsed:.1f} s  ({elapsed / n_targets:.2f} s/target)")
    fids_np = np.asarray(fids)
    print(f"  fidelity stats: mean = {fids_np.mean():.5f},  min = {fids_np.min():.5f},  max = {fids_np.max():.5f}")
    print(f"  >= 0.999: {(fids_np >= 0.999).mean() * 100:.1f}%")
    print(f"  >= 0.99 : {(fids_np >= 0.99).mean() * 100:.1f}%")

    # Save
    out_path = os.path.join(DATA_DIR, f"refset_T2pi_n{n_targets}.npz")
    np.savez(
        out_path,
        U_targets=np.asarray(U_targets),
        pulses_x=np.asarray(px),
        pulses_y=np.asarray(py),
        fidelities=fids_np,
        histories=np.asarray(histories),
        T_gate=np.float32(T_gate),
        n_slices=np.int32(n_slices),
        alpha=np.float32(ALPHA),
        T1=np.float32(T1),
        Tphi=np.float32(TPHI),
        omega_max=np.float32(1.0),
    )
    print(f"  saved {out_path}")
    return U_targets, px, py, fids_np, T_gate


# ----------------------------------------------------------------------
# Diagnostics on the reference set
# ----------------------------------------------------------------------
def plot_reference_diagnostics(U_targets, px, py, fids, T_gate):
    banner("Reference-set diagnostics")
    px_np = np.asarray(px)
    py_np = np.asarray(py)
    n_slices = px_np.shape[1]
    fids_np = np.asarray(fids)

    # Fidelity histogram
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.hist(1.0 - fids_np, bins=30, edgecolor="black")
    ax.axvline(1e-3, color="r", linestyle="--", label="0.999 threshold")
    ax.set_xscale("log")
    ax.set_xlabel(r"infidelity $1 - F$")
    ax.set_ylabel("count")
    ax.set_title(
        f"GRAPE infidelity over {len(fids_np)} Haar targets\n"
        rf"mean F = {fids_np.mean():.5f}, $\geq$0.999: {(fids_np >= 0.999).mean() * 100:.0f}%"
    )
    ax.legend()
    ax.grid(alpha=0.3, which="both")
    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, "fidelity_hist.png"), dpi=120)
    plt.close()

    # Pulse PSD averaged over the set
    dt = T_gate / n_slices
    freqs = np.fft.rfftfreq(n_slices, d=dt)
    psds_x = np.abs(np.fft.rfft(px_np, axis=1)) ** 2
    psds_y = np.abs(np.fft.rfft(py_np, axis=1)) ** 2
    mean_psd_x = psds_x.mean(axis=0)
    mean_psd_y = psds_y.mean(axis=0)
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.plot(freqs, mean_psd_x, label=r"$\Omega_x$", lw=2)
    ax.plot(freqs, mean_psd_y, label=r"$\Omega_y$", lw=2)
    ax.set_yscale("log")
    ax.set_xlabel(r"frequency $[\Omega_{\max}/(2\pi)]$")
    ax.set_ylabel("mean power")
    ax.set_title("Average pulse PSD over reference set")
    ax.legend()
    ax.grid(alpha=0.3, which="both")
    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, "pulse_psd.png"), dpi=120)
    plt.close()

    # A few sample pulses
    n_show = 4
    fig, axes = plt.subplots(n_show, 1, figsize=(10, 2.0 * n_show), sharex=True)
    t_axis = np.linspace(0, float(T_gate), n_slices + 1)[:-1] + 0.5 * float(T_gate) / n_slices
    for i, ax in enumerate(axes):
        ax.step(t_axis, px_np[i], where="mid", label=r"$\Omega_x$", lw=1.5)
        ax.step(t_axis, py_np[i], where="mid", label=r"$\Omega_y$", lw=1.5)
        ax.axhline(0, color="gray", lw=0.5)
        ax.set_ylim(-1.1, 1.1)
        ax.set_ylabel("amp")
        ax.set_title(f"Target {i}, F = {fids_np[i]:.5f}", fontsize=10)
        ax.legend(loc="upper right", fontsize=9)
        ax.grid(alpha=0.3)
    axes[-1].set_xlabel(r"time $[1/\Omega_{\max}]$")
    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, "sample_pulses.png"), dpi=120)
    plt.close()
    print(f"  saved 3 figures to {FIG_DIR}/")


# ----------------------------------------------------------------------
def main():
    print(f"JAX {jax.__version__}, devices: {jax.devices()}")
    print(f"System: d={D}, alpha={ALPHA}, T1={T1}, Tphi={TPHI}, T2={T2:.0f}")

    # 3a — Haar sampling diagnostics
    test_haar_sampling(n_samples=10_000)

    # 3b + 3c — reference set
    U_targets, px, py, fids, T_gate = build_reference_set(n_targets=100)

    # Diagnostics on the reference set
    plot_reference_diagnostics(U_targets, px, py, fids, T_gate)

    print(f"\nAll Phase 3 figures saved to: {FIG_DIR}")


if __name__ == "__main__":
    main()
