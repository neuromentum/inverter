"""Phase 7.1 — 2-qubit GRAPE on standard library (CNOT, iSWAP, sqrt-iSWAP).

Tests
-----
1. Noiseless CNOT, iSWAP, sqrt-iSWAP at ample gate time: F ≥ 0.999
2. Noisy versions at the same gate time: F ≥ some realistic floor.
3. Headline: fidelity vs gate-time tradeoff for CNOT.

Plots saved under quantum/figures/phase7/.
"""
import os
import sys
import time
import warnings

os.environ.setdefault("JAX_PLATFORMS", "cpu")
warnings.filterwarnings("ignore", message=".*Complex dtype.*", category=UserWarning)

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)

import jax
import jax.numpy as jnp
import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sim.two_qubit import (
    static_operators_2q,
    U_CNOT, U_iSWAP, U_sqrt_iSWAP,
)
from grape.grape_2q import grape_optimize_2q, make_grape_runner_2q


FIG_DIR = os.path.join(ROOT, "figures", "phase7")
os.makedirs(FIG_DIR, exist_ok=True)


# Settings
# J = 0.3 with T_gate = 4π gives JT/2 ≈ π (one full ZZ-π rotation budget),
# enough entangling power for CNOT/iSWAP. Drive dominates drift (Ω_max = 1
# vs |H_drift| ≈ J/2 = 0.15), realistic ratio.
J = 0.3
T1_NOMINAL = 10000.0
TPHI_NOMINAL = 8000.0


def banner(s):
    print(f"\n{'='*64}\n{s}\n{'='*64}", flush=True)


def test_noiseless_library():
    banner("Test 1: Noiseless 2-qubit GRAPE on CNOT, iSWAP, sqrt-iSWAP")
    H_d, H_dr, L = static_operators_2q(J=J, T1=1e8, Tphi=1e8)
    runner = make_grape_runner_2q(n_channels=4, n_slices=80, n_steps=1000, lr=0.05, omega_max=1.0)
    targets = {"CNOT": U_CNOT(), "iSWAP": U_iSWAP(), "sqrt-iSWAP": U_sqrt_iSWAP()}
    T_gate = 4.0 * float(jnp.pi)    # generous time budget; 2-qubit gates need more time
    results = {}
    for name, U in targets.items():
        t0 = time.time()
        res = grape_optimize_2q(T_gate, U, H_d, H_dr, L, runner=runner, n_restarts=3, seed=hash(name) & 0xFFFF)
        elapsed = time.time() - t0
        print(f"  {name:11s}: F = {res.fidelity:.6f}  (1-F = {1-res.fidelity:.2e})  [{elapsed:.1f} s]")
        results[name] = (res, elapsed)
    return results, T_gate


def test_noisy_library(T_gate):
    banner("Test 2: Noisy 2-qubit GRAPE  (T1, Tphi nominal)")
    H_d, H_dr, L = static_operators_2q(J=J, T1=T1_NOMINAL, Tphi=TPHI_NOMINAL)
    runner = make_grape_runner_2q(n_channels=4, n_slices=80, n_steps=1000, lr=0.05, omega_max=1.0)
    targets = {"CNOT": U_CNOT(), "iSWAP": U_iSWAP(), "sqrt-iSWAP": U_sqrt_iSWAP()}
    results = {}
    for name, U in targets.items():
        t0 = time.time()
        res = grape_optimize_2q(T_gate, U, H_d, H_dr, L, runner=runner, n_restarts=3, seed=hash(name) & 0xFFFF)
        elapsed = time.time() - t0
        print(f"  {name:11s}: F = {res.fidelity:.6f}  (1-F = {1-res.fidelity:.2e})  [{elapsed:.1f} s]")
        results[name] = (res, elapsed)
    return results, T_gate


def plot_pulse_waveforms(results, T_gate, fname):
    fig, axes = plt.subplots(len(results), 1, figsize=(11, 3.0 * len(results)), sharex=True)
    if len(results) == 1:
        axes = [axes]
    chan_labels = [r"$\Omega_{x,1}$", r"$\Omega_{y,1}$", r"$\Omega_{x,2}$", r"$\Omega_{y,2}$"]
    chan_colors = ["C0", "C1", "C2", "C3"]
    for ax, (name, (res, _)) in zip(axes, results.items()):
        N = res.pulse.shape[1]
        t = np.linspace(0, float(T_gate), N + 1)[:-1] + 0.5 * float(T_gate) / N
        for ch in range(4):
            ax.step(t, np.array(res.pulse[ch]), where="mid", lw=1.2,
                    label=chan_labels[ch], color=chan_colors[ch])
        ax.axhline(0, color="gray", lw=0.4)
        ax.set_ylim(-1.1, 1.1)
        ax.set_ylabel("amp")
        ax.set_title(f"GRAPE pulse for {name}  (F = {res.fidelity:.5f})")
        ax.legend(loc="upper right", fontsize=8, ncol=4)
        ax.grid(alpha=0.3)
    axes[-1].set_xlabel(r"time $[1/\Omega_{\max}]$")
    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, fname), dpi=120)
    plt.close()


def plot_training_curves(results, fname):
    fig, ax = plt.subplots(figsize=(7, 4))
    for name, (res, _) in results.items():
        infid = 1.0 - np.array(res.history)
        infid = np.clip(infid, 1e-9, None)
        ax.plot(infid, label=f"{name}  (F = {res.fidelity:.5f})", lw=2)
    ax.set_yscale("log")
    ax.set_xlabel("optimizer step (best restart)")
    ax.set_ylabel(r"infidelity $1 - F$")
    ax.axhline(1e-3, color="r", linestyle="--", alpha=0.5, label="0.999 threshold")
    ax.set_title("2-qubit GRAPE convergence")
    ax.legend()
    ax.grid(alpha=0.3, which="both")
    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, fname), dpi=120)
    plt.close()


def plot_fidelity_vs_gate_time():
    banner("Plot: 2-qubit fidelity vs gate-time (CNOT)")
    H_dn, H_dr_n, L_n = static_operators_2q(J=J, T1=T1_NOMINAL, Tphi=TPHI_NOMINAL)
    H_dc, H_dr_c, L_c = static_operators_2q(J=J, T1=1e8, Tphi=1e8)
    runner = make_grape_runner_2q(n_channels=4, n_slices=40, n_steps=400, lr=0.05, omega_max=1.0)
    T_gates = jnp.linspace(0.5, 8.0, 12) * jnp.pi
    fids_n = []
    fids_c = []
    for T_g in T_gates:
        t0 = time.time()
        res_c = grape_optimize_2q(float(T_g), U_CNOT(), H_dc, H_dr_c, L_c, runner=runner, n_restarts=2, seed=1)
        res_n = grape_optimize_2q(float(T_g), U_CNOT(), H_dn, H_dr_n, L_n, runner=runner, n_restarts=2, seed=1)
        fids_c.append(res_c.fidelity); fids_n.append(res_n.fidelity)
        print(f"  T_g = {float(T_g)/np.pi:.2f}π:  F_clean = {res_c.fidelity:.5f}  F_noisy = {res_n.fidelity:.5f}  ({time.time()-t0:.1f}s)")

    Tg = np.array(T_gates) / np.pi
    fids_c = np.array(fids_c); fids_n = np.array(fids_n)
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.plot(Tg, 1 - fids_c, "o-", label="noiseless")
    ax.plot(Tg, 1 - fids_n, "s-", label=rf"$T_1$={T1_NOMINAL:g}, $T_\varphi$={TPHI_NOMINAL:g}")
    ax.set_yscale("log")
    ax.set_xlabel(r"gate time $[\pi/\Omega_{\max}]$")
    ax.set_ylabel(r"$1 - F$")
    ax.set_title("2-qubit GRAPE: speed-vs-decoherence tradeoff (CNOT)")
    ax.axhline(1e-3, color="r", linestyle="--", alpha=0.5, label="0.999 threshold")
    ax.legend()
    ax.grid(alpha=0.3, which="both")
    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, "grape_2q_fidelity_vs_gate_time.png"), dpi=120)
    plt.close()


def main():
    print(f"JAX {jax.__version__}, devices: {jax.devices()}")
    print(f"2-qubit params: J={J}, T1={T1_NOMINAL}, Tphi={TPHI_NOMINAL}")

    res_clean, T_g = test_noiseless_library()
    plot_pulse_waveforms(res_clean, T_g, "grape_2q_waveforms_clean.png")
    plot_training_curves(res_clean, "grape_2q_training_clean.png")

    res_noisy, _ = test_noisy_library(T_g)
    plot_pulse_waveforms(res_noisy, T_g, "grape_2q_waveforms_noisy.png")
    plot_training_curves(res_noisy, "grape_2q_training_noisy.png")

    plot_fidelity_vs_gate_time()
    print(f"\nAll Phase 7.1 figures saved to: {FIG_DIR}")


if __name__ == "__main__":
    main()
