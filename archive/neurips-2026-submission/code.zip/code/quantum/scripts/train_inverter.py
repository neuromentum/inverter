"""Phase 4 — train an inverter U_target -> pulse with simulator-in-the-loop.

Usage:
    python quantum/scripts/train_inverter.py configs/phase4_inverter_default.yml
    python quantum/scripts/train_inverter.py configs/phase4_inverter_default.yml \
        training.lr=5e-4 training.batch_size=128

Each run creates a timestamped directory under quantum/experiments/ with:
    config.yml        — resolved config (after CLI overrides)
    log.jsonl         — per-step training metrics
    eval_results.json — final eval on held-out Haar + reference set
    figures/          — training curves, fidelity histograms
    checkpoints/      — eqx model snapshots
"""
import os
import sys
import time
import warnings
import json

# CWD-independent imports
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)

from utils.experiment import (
    load_config,
    merge_overrides,
    make_run_dir,
    snapshot_config,
    JSONLLogger,
    parse_cli,
)

config_path, overrides = parse_cli()
cfg = merge_overrides(load_config(config_path), overrides)

os.environ.setdefault("JAX_PLATFORMS", cfg.get("platform", "cpu"))
warnings.filterwarnings("ignore", message=".*Complex dtype.*", category=UserWarning)

import jax
import jax.numpy as jnp
import numpy as np
import equinox as eqx
import optax
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sim.transmon import static_operators
from data.sampling import haar_unitary_batch
from grape.grape import average_gate_fidelity
from inverter.mlp import build_inverter


# ----------------------------------------------------------------------
# Resolve config
# ----------------------------------------------------------------------
sys_cfg = cfg["system"]
gate_cfg = cfg["gate"]
inv_cfg = cfg["inverter"]
trn_cfg = cfg["training"]
eval_cfg = cfg["eval"]

D = int(sys_cfg["d"])
T_GATE = float(gate_cfg["T_gate"])
N_SLICES = int(gate_cfg["n_slices"])
OMEGA_MAX = float(sys_cfg["omega_max"])
SEED = int(cfg.get("experiment", {}).get("seed", 0))

H_drift, Hx, Hy, L_stack = static_operators(
    D,
    float(sys_cfg["alpha"]),
    float(sys_cfg["T1"]),
    float(sys_cfg["Tphi"]),
)

# Resolve absolute paths relative to the quantum/ root for portability.
ref_path = eval_cfg["ref_set_path"]
if not os.path.isabs(ref_path):
    ref_path = os.path.join(ROOT, ref_path)


# ----------------------------------------------------------------------
# Run dir + log setup
# ----------------------------------------------------------------------
run_dir = make_run_dir(cfg, root=os.path.join(ROOT, "experiments"))
snapshot_config(cfg, run_dir, src_path=config_path)
logger = JSONLLogger(os.path.join(run_dir, "log.jsonl"))

print(f"\nRun directory: {run_dir}")
print(f"JAX {jax.__version__}, devices: {jax.devices()}\n")
logger.log(event="start", run_dir=run_dir, jax=jax.__version__)


# ----------------------------------------------------------------------
# Build inverter + optimizer
# ----------------------------------------------------------------------
key = jax.random.PRNGKey(SEED)
key, init_key = jax.random.split(key)
model = build_inverter(
    arch=inv_cfg["arch"],
    hidden_dims=tuple(inv_cfg["hidden_dims"]),
    n_slices=N_SLICES,
    activation=inv_cfg["activation"],
    input_encoding=inv_cfg.get("input_encoding", "real8"),
    key=init_key,
)

# Optimizer: Adam, optionally with cosine learning-rate decay.
# Set training.lr_schedule = 'cosine' to enable; default 'constant' preserves
# the original behavior.
n_steps_total = int(trn_cfg["n_steps"])
lr0 = float(trn_cfg["lr"])
lr_schedule_kind = trn_cfg.get("lr_schedule", "constant")
if lr_schedule_kind == "cosine":
    lr_min = float(trn_cfg.get("lr_min", lr0 * 1e-2))
    schedule = optax.cosine_decay_schedule(lr0, decay_steps=n_steps_total, alpha=lr_min / lr0)
elif lr_schedule_kind == "constant":
    schedule = lr0
else:
    raise ValueError(f"unknown lr_schedule: {lr_schedule_kind}")
optimizer = optax.adam(schedule)
opt_state = optimizer.init(eqx.filter(model, eqx.is_array))


# ----------------------------------------------------------------------
# Loss + train step (jitted)
# ----------------------------------------------------------------------
def pulse_from_model_output(out):
    """(2, N) raw -> tanh-squashed (Omega_x, Omega_y)."""
    return OMEGA_MAX * jnp.tanh(out[0]), OMEGA_MAX * jnp.tanh(out[1])


def loss_fn_single(model, U_target):
    out = model(U_target)
    px, py = pulse_from_model_output(out)
    F = average_gate_fidelity(px, py, T_GATE, U_target, H_drift, Hx, Hy, L_stack)
    return 1.0 - F


def loss_fn_batch(model, U_targets_batch):
    losses = jax.vmap(loss_fn_single, in_axes=(None, 0))(model, U_targets_batch)
    return jnp.mean(losses), losses


@eqx.filter_jit
def train_step(model, opt_state, U_targets_batch):
    (loss, per_target), grads = eqx.filter_value_and_grad(
        loss_fn_batch, has_aux=True
    )(model, U_targets_batch)
    updates, opt_state = optimizer.update(grads, opt_state)
    model = eqx.apply_updates(model, updates)
    return model, opt_state, loss, per_target


@eqx.filter_jit
def eval_batch(model, U_targets_batch):
    return jax.vmap(loss_fn_single, in_axes=(None, 0))(model, U_targets_batch)


# ----------------------------------------------------------------------
# Reference set (held-out, fixed across runs)
# ----------------------------------------------------------------------
print(f"Loading reference set: {ref_path}")
ref = np.load(ref_path)
ref_U = jnp.asarray(ref["U_targets"])
ref_F_grape = jnp.asarray(ref["fidelities"])
print(f"  {ref_U.shape[0]} reference targets,  GRAPE mean F = {float(jnp.mean(ref_F_grape)):.5f}")
logger.log(event="ref_loaded", n=int(ref_U.shape[0]), grape_mean_F=float(jnp.mean(ref_F_grape)))


# ----------------------------------------------------------------------
# Training loop
# ----------------------------------------------------------------------
print("\nTraining...")
batch_size = int(trn_cfg["batch_size"])
n_steps = int(trn_cfg["n_steps"])
log_every = int(trn_cfg["log_every"])
eval_every = int(trn_cfg["eval_every"])
ckpt_every = int(trn_cfg["ckpt_every"])
n_eval_haar = int(eval_cfg["n_eval_haar"])

t0 = time.time()
losses_log = []
ref_eval_log = []
haar_eval_log = []
for step in range(1, n_steps + 1):
    key, sub = jax.random.split(key)
    U_batch = haar_unitary_batch(sub, batch_size, d=2)
    model, opt_state, loss, per_t = train_step(model, opt_state, U_batch)
    loss = float(loss)
    losses_log.append((step, loss))

    if step % log_every == 0 or step == 1:
        elapsed = time.time() - t0
        rate = step / elapsed
        F_batch = float(1.0 - loss)
        print(f"  step {step:5d}  1-F = {loss:.5e}   F = {F_batch:.5f}   ({rate:.1f} steps/s)", flush=True)
        logger.log(event="train", step=step, loss=loss, fidelity=F_batch, rate=rate)

    if step % eval_every == 0 or step == n_steps:
        # Eval on reference set
        ref_losses = eval_batch(model, ref_U)
        ref_F = 1.0 - np.asarray(ref_losses)
        ref_mean_F = float(np.mean(ref_F))
        ref_min_F = float(np.min(ref_F))
        ref_above_999 = float(np.mean(ref_F >= 0.999))
        # Eval on fresh Haar
        key, sub = jax.random.split(key)
        haar_U = haar_unitary_batch(sub, n_eval_haar, d=2)
        haar_losses = eval_batch(model, haar_U)
        haar_F = 1.0 - np.asarray(haar_losses)
        haar_mean_F = float(np.mean(haar_F))
        print(f"    [eval] ref:  mean F = {ref_mean_F:.5f}, min F = {ref_min_F:.5f}, ≥0.999 = {ref_above_999*100:.0f}%")
        print(f"           haar: mean F = {haar_mean_F:.5f}", flush=True)
        ref_eval_log.append((step, ref_mean_F, ref_min_F, ref_above_999))
        haar_eval_log.append((step, haar_mean_F))
        logger.log(
            event="eval",
            step=step,
            ref_mean_F=ref_mean_F, ref_min_F=ref_min_F, ref_above_999=ref_above_999,
            haar_mean_F=haar_mean_F,
        )

    if step % ckpt_every == 0 or step == n_steps:
        ckpt_path = os.path.join(run_dir, "checkpoints", f"step_{step:06d}.eqx")
        eqx.tree_serialise_leaves(ckpt_path, model)


# Final ckpt symlink
final_ckpt = os.path.join(run_dir, "checkpoints", f"step_{n_steps:06d}.eqx")
final_link = os.path.join(run_dir, "checkpoints", "final.eqx")
if os.path.lexists(final_link):
    os.remove(final_link)
os.symlink(os.path.basename(final_ckpt), final_link)


# ----------------------------------------------------------------------
# Final eval + plots
# ----------------------------------------------------------------------
print("\nFinal eval...")
ref_losses = eval_batch(model, ref_U)
ref_F = 1.0 - np.asarray(ref_losses)
key, sub = jax.random.split(key)
haar_U_final = haar_unitary_batch(sub, max(n_eval_haar, 1024), d=2)
haar_losses_final = eval_batch(model, haar_U_final)
haar_F_final = 1.0 - np.asarray(haar_losses_final)

ref_F_grape_np = np.asarray(ref_F_grape)
ref_F_inv = ref_F
deltas = ref_F_grape_np - ref_F_inv  # GRAPE - inverter

eval_results = {
    "ref": {
        "n": int(ref_U.shape[0]),
        "mean_F_inverter": float(np.mean(ref_F_inv)),
        "min_F_inverter": float(np.min(ref_F_inv)),
        "frac_above_999": float(np.mean(ref_F_inv >= 0.999)),
        "mean_F_grape": float(np.mean(ref_F_grape_np)),
        "mean_gap_grape_minus_inverter": float(np.mean(deltas)),
        "median_gap_grape_minus_inverter": float(np.median(deltas)),
    },
    "haar_held_out": {
        "n": int(haar_U_final.shape[0]),
        "mean_F": float(np.mean(haar_F_final)),
        "min_F": float(np.min(haar_F_final)),
        "frac_above_999": float(np.mean(haar_F_final >= 0.999)),
    },
    "wall_clock_s": time.time() - t0,
}
with open(os.path.join(run_dir, "eval_results.json"), "w") as f:
    json.dump(eval_results, f, indent=2)
print(json.dumps(eval_results, indent=2))
logger.log(event="final_eval", **eval_results)


# Training curve
fig, ax = plt.subplots(figsize=(8, 4))
steps, losses = zip(*losses_log)
ax.plot(steps, losses, lw=1, alpha=0.7, label="train batch")
if ref_eval_log:
    ev_steps, ev_mean, ev_min, _ = zip(*ref_eval_log)
    ax.plot(ev_steps, [1 - m for m in ev_mean], "o-", color="C1", label="ref-set mean 1-F")
ax.set_yscale("log")
ax.set_xlabel("step")
ax.set_ylabel("infidelity 1 - F")
ax.axhline(1e-3, color="r", linestyle="--", alpha=0.5, label="0.999 threshold")
grape_floor = 1.0 - float(np.mean(ref_F_grape_np))
ax.axhline(grape_floor, color="g", linestyle=":", alpha=0.7, label=f"GRAPE floor (mean) = {grape_floor:.4e}")
ax.legend()
ax.grid(alpha=0.3, which="both")
ax.set_title("Inverter training (simulator-in-the-loop)")
plt.tight_layout()
plt.savefig(os.path.join(run_dir, "figures", "train_curve.png"), dpi=120)
plt.close()

# Final fidelity histogram on Haar held-out
fig, ax = plt.subplots(figsize=(8, 4))
ax.hist(np.clip(1 - haar_F_final, 1e-6, 1.0), bins=40, alpha=0.7, label=f"inverter (Haar n={haar_F_final.size})")
ax.hist(1 - ref_F_grape_np, bins=40, alpha=0.7, label=f"GRAPE (refset n={ref_F_grape_np.size})")
ax.set_xscale("log")
ax.set_xlabel("infidelity 1 - F")
ax.set_ylabel("count")
ax.set_title(f"Inverter vs GRAPE infidelity\nmean F: inverter {np.mean(haar_F_final):.5f}, GRAPE {np.mean(ref_F_grape_np):.5f}")
ax.legend()
ax.grid(alpha=0.3, which="both")
plt.tight_layout()
plt.savefig(os.path.join(run_dir, "figures", "fid_hist.png"), dpi=120)
plt.close()

# Per-target gap on the reference set
fig, ax = plt.subplots(figsize=(8, 4))
ax.scatter(1 - ref_F_grape_np, 1 - ref_F_inv, s=10, alpha=0.7)
lo = min(np.min(1 - ref_F_grape_np), np.min(np.clip(1 - ref_F_inv, 1e-9, 1)))
hi = max(np.max(1 - ref_F_grape_np), np.max(np.clip(1 - ref_F_inv, 1e-9, 1)))
ax.plot([lo, hi], [lo, hi], "k--", alpha=0.5, label="parity")
ax.set_xscale("log")
ax.set_yscale("log")
ax.set_xlabel("GRAPE  1 - F")
ax.set_ylabel("Inverter  1 - F")
ax.set_title("Per-target comparison (above parity = inverter worse)")
ax.legend()
ax.grid(alpha=0.3, which="both")
plt.tight_layout()
plt.savefig(os.path.join(run_dir, "figures", "per_target_gap.png"), dpi=120)
plt.close()

logger.close()
print(f"\nDone. Outputs in: {run_dir}")
