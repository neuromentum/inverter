"""Configurable Bloch-sphere plotter for 3D matplotlib axes.

Single entry point: ``draw_bloch_sphere(ax, **opts)`` — see ``BLOCH_PRESETS``
below for ready-made parameter bundles.

Style selection: ``style="glassy"`` (default), ``"translucent"``, ``"wireframe"``,
``"outline"``, ``"dotted"``, ``"gradient"``.

Tunable parameters:
- view_elev, view_azim                    — camera angles
- surface_alpha                            — surface transparency (0..1)
- light_az, light_alt                      — light direction (degrees, sensible 0..360 / 0..90)
- specular_dir, specular_power, specular_strength — for glassy hotspot
- cmap                                    — surface color (Greys, Blues_r, custom)
- ax_lim                                   — axis bounds (default 1.15)
- show_axis_labels                         — x/y/z text labels
- show_pole_markers                        — small dots at ±z poles
- show_great_circles, n_meridians, n_parallels  — extra equator / circles / parallels
- additional_lines                         — list of dicts {"points": (N,3), "color": ..., "lw": ..., "alpha": ..., "linestyle": ...}
- title                                    — axes title (None = no title)

Presets — pass ``preset="paper_glassy"`` to ``apply_preset()`` to start from a
named bundle and override individual fields:

    from utils.bloch import apply_preset, draw_bloch_sphere
    opts = apply_preset("paper_glassy", surface_alpha=0.35, n_meridians=4)
    draw_bloch_sphere(ax, **opts)

The function returns nothing; the caller can layer trajectories on top.
"""
from __future__ import annotations

from typing import Iterable, Optional, Sequence

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import LightSource, LinearSegmentedColormap


# Built-in colormaps for the various styles
_ICY = LinearSegmentedColormap.from_list(
    "icy", [(0.10, 0.18, 0.32), (0.45, 0.65, 0.85), (0.90, 0.95, 1.00)]
)


def _great_circle(plane: str, n: int = 200):
    """Return points (n, 3) along a unit great circle in the named plane."""
    t = np.linspace(0, 2 * np.pi, n)
    if plane == "xy":
        return np.stack([np.cos(t), np.sin(t), np.zeros_like(t)], axis=1)
    if plane == "xz":
        return np.stack([np.cos(t), np.zeros_like(t), np.sin(t)], axis=1)
    if plane == "yz":
        return np.stack([np.zeros_like(t), np.cos(t), np.sin(t)], axis=1)
    raise ValueError(f"unknown plane: {plane}")


def _draw_surface(ax, *, style, n_grid, surface_alpha,
                  light_az, light_alt, cmap,
                  specular_dir, specular_power, specular_strength,
                  wireframe_color, wireframe_alpha, wireframe_lw):
    """Draw the surface portion of the sphere according to style. Returns nothing."""
    if style == "wireframe":
        u, v = np.mgrid[0:2 * np.pi:32j, 0:np.pi:17j]
        sx, sy, sz = np.cos(u) * np.sin(v), np.sin(u) * np.sin(v), np.cos(v)
        ax.plot_wireframe(sx, sy, sz, color=wireframe_color or "0.55",
                          alpha=wireframe_alpha, linewidth=wireframe_lw)
        return
    if style == "outline":
        return  # no surface; outline is drawn via great circles
    if style == "dotted":
        u, v = np.mgrid[0:2 * np.pi:32j, 0:np.pi:17j]
        sx, sy, sz = np.cos(u) * np.sin(v), np.sin(u) * np.sin(v), np.cos(v)
        ax.plot_wireframe(sx, sy, sz, color=wireframe_color or "0.65",
                          alpha=wireframe_alpha * 0.7, linewidth=wireframe_lw * 0.7,
                          linestyle=(0, (1, 2)))
        return

    # Solid-surface styles: translucent / glassy / gradient
    n = n_grid
    u = np.linspace(0, 2 * np.pi, n); v = np.linspace(0, np.pi, n)
    sx = np.outer(np.cos(u), np.sin(v))
    sy = np.outer(np.sin(u), np.sin(v))
    sz = np.outer(np.ones_like(u), np.cos(v))

    if cmap is None:
        cmap = plt.cm.Greys if style == "translucent" else _ICY if style == "glassy" else plt.cm.Blues_r

    if style == "gradient":
        norm = (sz - sz.min()) / max(sz.max() - sz.min(), 1e-9)
        rgb = cmap(0.25 + 0.5 * norm)
        rgb[..., 3] = surface_alpha
    else:
        ls = LightSource(azdeg=light_az, altdeg=light_alt)
        if style == "glassy":
            ls2 = LightSource(azdeg=(light_az + 180) % 360, altdeg=max(10, light_alt - 25))
            rgb1 = ls.shade(sz, cmap=cmap, blend_mode="soft", vert_exag=1.0)
            rgb2 = ls2.shade(sz, cmap=cmap, blend_mode="overlay", vert_exag=1.0)
            rgb = 0.55 * rgb1 + 0.45 * rgb2
            # specular hotspot
            d = np.array(specular_dir, dtype=float)
            d = d / max(np.linalg.norm(d), 1e-9)
            cos_a = sx * d[0] + sy * d[1] + sz * d[2]
            spec = np.clip(cos_a, 0, 1) ** specular_power
            rgb[..., :3] = np.clip(rgb[..., :3] + specular_strength * spec[..., None], 0, 1)
            rgb[..., 3] = surface_alpha
        else:  # translucent
            rgb = ls.shade(sz, cmap=cmap, blend_mode="soft", vert_exag=1.0)
            rgb[..., 3] = surface_alpha

    ax.plot_surface(sx, sy, sz, facecolors=rgb, linewidth=0,
                    antialiased=True, shade=False, rstride=1, cstride=1)


def _draw_lines(ax, *,
                show_great_circles, n_meridians, n_parallels,
                line_color, line_lw, line_alpha):
    """Equator + xz & yz great circles, plus optional extra meridians and parallels."""
    if show_great_circles:
        for plane, alpha_mult in [("xy", 1.0), ("xz", 0.85), ("yz", 0.85)]:
            p = _great_circle(plane)
            ax.plot(p[:, 0], p[:, 1], p[:, 2],
                    color=line_color, lw=line_lw, alpha=line_alpha * alpha_mult)
    if n_meridians > 0:
        # extra longitude lines
        t = np.linspace(0, np.pi, 100)
        for i in range(n_meridians):
            phi = (np.pi / n_meridians) * i
            x = np.cos(phi) * np.sin(t)
            y = np.sin(phi) * np.sin(t)
            z = np.cos(t)
            ax.plot(x, y, z, color=line_color, lw=line_lw * 0.7,
                    alpha=line_alpha * 0.55)
    if n_parallels > 0:
        # latitude lines (excluding equator at the half-way value)
        for i in range(1, n_parallels + 1):
            colat = np.pi * i / (n_parallels + 1)   # ∈ (0, π)
            r = np.sin(colat); z0 = np.cos(colat)
            t = np.linspace(0, 2 * np.pi, 200)
            ax.plot(r * np.cos(t), r * np.sin(t), z0 * np.ones_like(t),
                    color=line_color, lw=line_lw * 0.7, alpha=line_alpha * 0.45)


def draw_bloch_sphere(
    ax,
    *,
    style: str = "glassy",
    # camera
    view_elev: float = 22,
    view_azim: float = 42,
    # surface params (used by translucent / glassy / gradient)
    surface_alpha: float = 0.28,
    light_az: float = 210,
    light_alt: float = 45,
    cmap=None,
    n_grid: int = 100,
    # specular (glassy only)
    specular_dir: Sequence[float] = (0.4, 0.3, 0.85),
    specular_power: float = 25,
    specular_strength: float = 0.45,
    # wireframe / dotted params
    wireframe_color: Optional[str] = None,
    wireframe_alpha: float = 0.45,
    wireframe_lw: float = 0.5,
    # great-circle / mesh-line params
    show_great_circles: bool = True,
    n_meridians: int = 0,
    n_parallels: int = 0,
    line_color: str = "0.30",
    line_lw: float = 0.85,
    line_alpha: float = 0.55,
    # additional user-supplied lines: list of dicts with keys:
    #   "points": (N, 3) array, "color", "lw", "alpha", "linestyle"
    additional_lines: Optional[Iterable[dict]] = None,
    # axes / labels
    ax_lim: float = 1.15,
    show_axis_labels: bool = True,
    show_pole_markers: bool = False,
    title: Optional[str] = None,
):
    """Draw a Bloch sphere on a 3D matplotlib axis.

    Returns the axis (so the caller can layer trajectories on top, e.g.::
        draw_bloch_sphere(ax, style="glassy")
        ax.plot(*traj.T, color="C0")
    """
    ax.set_box_aspect([1, 1, 1])
    ax.set_xlim(-ax_lim, ax_lim)
    ax.set_ylim(-ax_lim, ax_lim)
    ax.set_zlim(-ax_lim, ax_lim)
    ax.set_xticks([]); ax.set_yticks([]); ax.set_zticks([])
    ax.set_xlabel(""); ax.set_ylabel(""); ax.set_zlabel("")
    ax.view_init(elev=view_elev, azim=view_azim)

    _draw_surface(
        ax, style=style, n_grid=n_grid, surface_alpha=surface_alpha,
        light_az=light_az, light_alt=light_alt, cmap=cmap,
        specular_dir=specular_dir, specular_power=specular_power,
        specular_strength=specular_strength,
        wireframe_color=wireframe_color, wireframe_alpha=wireframe_alpha,
        wireframe_lw=wireframe_lw,
    )

    _draw_lines(
        ax, show_great_circles=show_great_circles,
        n_meridians=n_meridians, n_parallels=n_parallels,
        line_color=line_color, line_lw=line_lw, line_alpha=line_alpha,
    )

    if additional_lines:
        for spec in additional_lines:
            pts = np.asarray(spec["points"])
            ax.plot(pts[:, 0], pts[:, 1], pts[:, 2],
                    color=spec.get("color", "k"),
                    lw=spec.get("lw", 1.0),
                    alpha=spec.get("alpha", 0.8),
                    linestyle=spec.get("linestyle", "-"))

    if show_axis_labels:
        for end, lab in [
            ((ax_lim - 0.02, 0, 0), "x"),
            ((0, ax_lim - 0.02, 0), "y"),
            ((0, 0, ax_lim - 0.02), "z"),
        ]:
            ax.text(*end, lab, fontsize=10, ha="center")
    if show_pole_markers:
        ax.scatter([0, 0], [0, 0], [-1, 1], color="0.20", s=18, alpha=0.8)

    if title is not None:
        ax.set_title(title)

    return ax


# --------------------------------------------------------------------------
# Presets
# --------------------------------------------------------------------------
BLOCH_PRESETS: dict[str, dict] = {
    # The default we shipped: glassy + specular hotspot. Best "polished" look,
    # matches the user's pick.
    "paper_glassy": dict(
        style="glassy",
        view_elev=22, view_azim=42,
        surface_alpha=0.28,
        light_az=210, light_alt=45,
        specular_dir=(0.4, 0.3, 0.85),
        specular_power=25, specular_strength=0.45,
        show_great_circles=True,
        n_meridians=0, n_parallels=0,
        show_axis_labels=True, show_pole_markers=False,
    ),
    # Soft translucent — less dramatic, more conservative for a paper figure.
    "paper_translucent": dict(
        style="translucent",
        view_elev=22, view_azim=42,
        surface_alpha=0.18,
        light_az=210, light_alt=45,
        show_great_circles=True,
        n_meridians=0, n_parallels=0,
        show_axis_labels=True,
    ),
    # Minimalist outline — used in many QC textbooks. No surface, just 3 great circles.
    "paper_minimal": dict(
        style="outline",
        view_elev=22, view_azim=42,
        line_color="0.20", line_lw=1.2, line_alpha=0.6,
        show_great_circles=True,
        n_meridians=0, n_parallels=0,
        show_axis_labels=True,
    ),
    # Talk / slides — bigger view angle, more meridians for orientation cues.
    "presentation_glassy": dict(
        style="glassy",
        view_elev=18, view_azim=55,
        surface_alpha=0.32,
        light_az=210, light_alt=55,
        specular_dir=(0.35, 0.35, 0.85),
        specular_power=18, specular_strength=0.55,
        show_great_circles=True,
        n_meridians=6, n_parallels=2,
        show_axis_labels=True, show_pole_markers=True,
    ),
    # Diagnostic / debugging — show every great circle and parallel, opaque surface.
    "diagnostic_full_grid": dict(
        style="wireframe",
        view_elev=22, view_azim=42,
        wireframe_color="0.45", wireframe_alpha=0.50, wireframe_lw=0.6,
        show_great_circles=True,
        n_meridians=8, n_parallels=4,
        show_axis_labels=True, show_pole_markers=True,
    ),
}


def apply_preset(name: str, **overrides) -> dict:
    """Return a kwargs dict combining the named preset with any overrides."""
    if name not in BLOCH_PRESETS:
        raise KeyError(f"unknown preset {name!r}; available: {list(BLOCH_PRESETS)}")
    out = dict(BLOCH_PRESETS[name])
    out.update(overrides)
    return out
