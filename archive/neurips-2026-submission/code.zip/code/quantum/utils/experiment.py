"""Experiment-dir scaffolding: load YAML config, create timestamped run dir,
log metrics as JSONL, snapshot the config used."""
from __future__ import annotations

import datetime
import json
import os
import shutil
import sys
from typing import Any

import yaml


def load_config(path: str) -> dict:
    with open(path, "r") as f:
        cfg = yaml.safe_load(f)
    return cfg


def merge_overrides(cfg: dict, overrides: list[str]) -> dict:
    """Apply a list of `key.path=value` overrides to a nested dict (in-place).

    Example: ['training.lr=1e-4', 'inverter.hidden_dims=[128,128]'].
    """
    for ov in overrides:
        if "=" not in ov:
            raise ValueError(f"Bad override (need key=value): {ov}")
        key, val = ov.split("=", 1)
        # Best-effort YAML parse for the RHS so that lists / numbers / bools work.
        try:
            val = yaml.safe_load(val)
        except yaml.YAMLError:
            pass
        keys = key.split(".")
        d = cfg
        for k in keys[:-1]:
            d = d.setdefault(k, {})
        d[keys[-1]] = val
    return cfg


def make_run_dir(cfg: dict, root: str = "experiments") -> str:
    name = cfg.get("experiment", {}).get("name", "run")
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = os.path.join(root, f"{name}_{ts}")
    os.makedirs(run_dir, exist_ok=False)
    os.makedirs(os.path.join(run_dir, "figures"), exist_ok=True)
    os.makedirs(os.path.join(run_dir, "checkpoints"), exist_ok=True)
    return run_dir


def snapshot_config(cfg: dict, run_dir: str, src_path: str | None = None):
    """Save the resolved config (after overrides) as config.yml in the run dir.
    Optionally also copy the original source config for reference.
    """
    out_path = os.path.join(run_dir, "config.yml")
    with open(out_path, "w") as f:
        yaml.safe_dump(cfg, f, sort_keys=False)
    if src_path is not None and os.path.abspath(src_path) != os.path.abspath(out_path):
        shutil.copy(src_path, os.path.join(run_dir, "config.source.yml"))


class JSONLLogger:
    """Append-only JSONL metrics log. One dict per line."""

    def __init__(self, path: str):
        self.path = path
        self._f = open(path, "a", buffering=1)  # line-buffered

    def log(self, **kw):
        kw.setdefault("ts", datetime.datetime.now().isoformat(timespec="seconds"))
        self._f.write(json.dumps(kw, default=_json_default) + "\n")

    def close(self):
        self._f.close()


def _json_default(o):
    # numpy / jax arrays → list ; otherwise str
    try:
        import numpy as np
        import jax.numpy as jnp
        if isinstance(o, (np.ndarray, jnp.ndarray)):
            arr = np.asarray(o)
            if arr.size == 1:
                return arr.item()
            return arr.tolist()
        if isinstance(o, (np.floating, np.integer)):
            return o.item()
    except ImportError:
        pass
    return str(o)


# ----------------------------------------------------------------------
# CLI helper
# ----------------------------------------------------------------------
def parse_cli(argv=None):
    """Parse: `script.py path/to/config.yml [key.path=value ...]`."""
    if argv is None:
        argv = sys.argv[1:]
    if len(argv) < 1:
        print("Usage: <script> <config.yml> [key.path=value ...]")
        sys.exit(1)
    config_path = argv[0]
    overrides = argv[1:]
    return config_path, overrides
