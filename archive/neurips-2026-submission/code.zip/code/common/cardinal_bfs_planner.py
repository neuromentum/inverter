"""Unified data-derived cardinal-BFS waypoint planner.

Single source of truth for the cardinal sequencer used by both
`maze2d/navigate_maze2d.py` and `antmaze/navigate_cardinal.py`. The
planner is **coordinate-frame-agnostic**: feed it 2-D points from
whatever frame the rest of the pipeline uses (qpos for maze2d-v1, world
for antmaze) and it does its work entirely in that frame.

The pipeline produces strictly axis-aligned (cardinal: ±x, ±y) sub-goal
sequences:

  1. Bin training data into a cell grid; cells with at least
     ``min_visits`` points are free, all others are walls. Cell centers
     are the density-weighted means of the points in that cell.
  2. 4-connected BFS shortest path with optional centerline tie-break:
     among all equally-short paths pick the one whose interior cells
     have the highest cumulative ``dist_to_wall`` (taxicab distance to
     the nearest wall, computed once at construction).
  3. Turn-based polyline: keep only the corner cells of the BFS path
     (where the cell-index direction changes).
  4. Per-segment perpendicular snap: each remaining leg between two
     turn cells is forced onto a single shared row or column so the
     leg becomes exactly axis-aligned.
  5. L-corner insertion (longer-axis-first heuristic) for any residual
     diagonal segment from start/goal not lying on a corridor center.
  6. Final-approach axis lock: the very last leg into the goal is
     projected onto the preceding axis-aligned segment so both legs
     into the goal are perpendicular.
  7. Optional sub-cell wobble filter (``min_leg > 0``): drop a
     waypoint whose incoming and outgoing legs are both shorter than
     ``min_leg``.
  8. Resample at fixed ``spacing`` in either ``axis_aligned`` mode
     (default) or ``centerline`` mode (sample by arc length along the
     polyline; allowed to produce diagonal segments across turns).

Public API is the union of the legacy ``DataOccupancy`` (antmaze) and
``DataOccupancyGrid`` (maze2d) classes, so both navigate scripts can
substitute the unified class without further changes.
"""

from __future__ import annotations

from collections import deque

import numpy as np


class CardinalBFSPlanner:
    """Data-derived cardinal-BFS waypoint planner. See module docstring."""

    # ----- construction -----------------------------------------------------

    def __init__(self, xy, resolution=1.0, min_visits=100, origin_mode='auto',
                 center_weight=1.0):
        xy = np.asarray(xy, dtype=np.float32)
        if xy.ndim != 2 or xy.shape[1] < 2:
            raise ValueError(f'xy must be (N, 2+), got {xy.shape}')
        xy = xy[:, :2]

        self.res = float(resolution)
        self.min_visits = int(min_visits)
        self.origin_mode = str(origin_mode)
        self.center_weight = float(center_weight)

        # Grid origin: align cell centers to the data's density peaks ('auto'),
        # or fall back to floor(min) ('floor'). Auto is essential when corridor
        # widths are smaller than ``resolution`` --- it keeps the wall-edge
        # samples from leaking across cell boundaries.
        if self.origin_mode == 'auto':
            x_phase = self._phase_offset(xy[:, 0])
            y_phase = self._phase_offset(xy[:, 1])
            x_min_adj = float(xy[:, 0].min()) - x_phase
            y_min_adj = float(xy[:, 1].min()) - y_phase
            self.x_origin = float(np.floor(x_min_adj / self.res) * self.res + x_phase)
            self.y_origin = float(np.floor(y_min_adj / self.res) * self.res + y_phase)
        elif self.origin_mode == 'floor':
            self.x_origin = float(np.floor(xy[:, 0].min() / self.res) * self.res)
            self.y_origin = float(np.floor(xy[:, 1].min() / self.res) * self.res)
        else:
            raise ValueError(f'Unknown origin_mode: {self.origin_mode}')

        col = np.floor((xy[:, 0] - self.x_origin) / self.res).astype(np.int64)
        row_from_bottom = np.floor((xy[:, 1] - self.y_origin) / self.res).astype(np.int64)
        self.ncols = int(col.max()) + 1
        self.nrows = int(row_from_bottom.max()) + 1
        # Top-down row indexing (row 0 = top); internal-only convention.
        row = self.nrows - 1 - row_from_bottom

        counts = np.zeros((self.nrows, self.ncols), dtype=np.int64)
        sum_x = np.zeros((self.nrows, self.ncols), dtype=np.float64)
        sum_y = np.zeros((self.nrows, self.ncols), dtype=np.float64)
        np.add.at(counts, (row, col), 1)
        np.add.at(sum_x, (row, col), xy[:, 0].astype(np.float64))
        np.add.at(sum_y, (row, col), xy[:, 1].astype(np.float64))
        self.counts = counts

        free_mask = counts >= self.min_visits
        self.free_mask = free_mask
        # `arr` mirrors the maze2d convention (10 = wall, 0 = free) so legacy
        # callers that read it directly keep working.
        self.arr = np.where(free_mask, 0, 10).astype(np.int32)

        rr, cc = np.indices((self.nrows, self.ncols))
        safe = np.maximum(counts, 1)
        mean_x = (sum_x / safe).astype(np.float32)
        mean_y = (sum_y / safe).astype(np.float32)
        geom_x = (self.x_origin + (cc + 0.5) * self.res).astype(np.float32)
        geom_y = (self.y_origin + (self.nrows - 1 - rr + 0.5) * self.res).astype(np.float32)
        self.centers = np.empty((self.nrows, self.ncols, 2), dtype=np.float32)
        self.centers[..., 0] = np.where(free_mask, mean_x, geom_x)
        self.centers[..., 1] = np.where(free_mask, mean_y, geom_y)

        free_rc = np.argwhere(free_mask)
        self.free_cells = free_rc.astype(np.int32)
        if len(free_rc):
            self.free_centres = self.centers[free_rc[:, 0], free_rc[:, 1]].astype(np.float32)
        else:
            self.free_centres = np.zeros((0, 2), dtype=np.float32)

        # Distance-to-wall (taxicab; grid border treated as wall). Used by the
        # BFS centerline tie-break.
        from scipy.ndimage import distance_transform_cdt
        wall_mask = ~free_mask
        padded = np.pad(wall_mask, 1, mode='constant', constant_values=True)
        self.dist_to_wall = distance_transform_cdt(
            ~padded, metric='taxicab',
        )[1:-1, 1:-1].astype(np.int32)

    def _phase_offset(self, vals):
        mods = np.mod(vals, self.res)
        bins = max(10, int(round(self.res / 0.02)))
        hist, edges = np.histogram(mods, bins=bins, range=(0.0, self.res))
        peak_phase = 0.5 * (edges[np.argmax(hist)] + edges[np.argmax(hist) + 1])
        return float((peak_phase - 0.5 * self.res) % self.res)

    # ----- cell <-> world (or qpos) coordinates ----------------------------

    def world_to_cell(self, xy):
        xy = np.asarray(xy, dtype=np.float32).reshape(-1)
        col = int(np.floor((float(xy[0]) - self.x_origin) / self.res))
        row_from_bottom = int(np.floor((float(xy[1]) - self.y_origin) / self.res))
        row = self.nrows - 1 - row_from_bottom
        if 0 <= row < self.nrows and 0 <= col < self.ncols and self.free_mask[row, col]:
            return (row, col)
        if len(self.free_centres) == 0:
            return (0, 0)
        d = np.linalg.norm(self.free_centres - xy[:2], axis=1)
        idx = int(np.argmin(d))
        return (int(self.free_cells[idx, 0]), int(self.free_cells[idx, 1]))

    def cell_to_world(self, row, col):
        return self.centers[row, col].copy()

    # maze2d-flavored aliases (drop-in API)
    def xy_to_cell(self, x, y):
        return self.world_to_cell(np.asarray([x, y], dtype=np.float32))

    def cell_to_xy(self, row, col):
        return self.cell_to_world(row, col)

    def is_free(self, x, y):
        col = int(np.floor((float(x) - self.x_origin) / self.res))
        row_from_bottom = int(np.floor((float(y) - self.y_origin) / self.res))
        row = self.nrows - 1 - row_from_bottom
        if 0 <= row < self.nrows and 0 <= col < self.ncols:
            return bool(self.free_mask[row, col])
        return False

    def get_open_cells(self):
        return [(int(r), int(c)) for r, c in self.free_cells]

    def get_neighbors(self, row, col):
        nbrs = []
        for dr, dc in ((0, 1), (0, -1), (1, 0), (-1, 0)):
            nr, nc = row + dr, col + dc
            if (0 <= nr < self.nrows and 0 <= nc < self.ncols
                    and self.free_mask[nr, nc]):
                nbrs.append((nr, nc))
        return nbrs

    # ----- BFS with centerline tie-break -----------------------------------

    def bfs_cell_path(self, start_rc, goal_rc):
        """4-connected BFS shortest path with centerline tie-break.

        The result is a strictly shortest path in number of cells. Among
        all equally-short paths, ties are broken in favour of the one
        whose interior cells maximise the cumulative ``dist_to_wall``
        (set ``self.center_weight = 0`` to disable the tie-break).
        """
        if start_rc == goal_rc:
            return [start_rc]

        # Forward BFS: distances + every valid predecessor on a shortest path
        dist = {start_rc: 0}
        parents = {}
        queue = deque([start_rc])
        goal_found = False
        while queue:
            u = queue.popleft()
            if u == goal_rc:
                goal_found = True
            for v in self.get_neighbors(*u):
                if v not in dist:
                    dist[v] = dist[u] + 1
                    parents[v] = [u]
                    queue.append(v)
                elif dist[v] == dist[u] + 1:
                    parents[v].append(u)

        if not goal_found:
            return None

        if float(self.center_weight) <= 0:
            path = [goal_rc]
            while path[-1] != start_rc:
                path.append(parents[path[-1]][0])
            return list(reversed(path))

        # Forward DP over BFS layers maximising cumulative dist_to_wall.
        best_score = {start_rc: 0.0}
        best_pred = {start_rc: None}
        cells_by_depth = {}
        for cell, d in dist.items():
            cells_by_depth.setdefault(d, []).append(cell)
        for d in sorted(cells_by_depth):
            if d == 0:
                continue
            for u in cells_by_depth[d]:
                cands = parents[u]
                best_p = max(cands, key=lambda p: best_score[p])
                best_score[u] = best_score[best_p] + float(self.dist_to_wall[u[0], u[1]])
                best_pred[u] = best_p
        path = [goal_rc]
        while path[-1] != start_rc:
            path.append(best_pred[path[-1]])
        return list(reversed(path))

    # ----- polyline construction (turn-based, per-segment-snapped) ---------

    def _build_polyline(self, start_xy, goal_xy, min_leg=0.0):
        start_xy = np.asarray(start_xy, dtype=np.float32).reshape(-1)[:2]
        goal_xy = np.asarray(goal_xy, dtype=np.float32).reshape(-1)[:2]
        start_cell = self.world_to_cell(start_xy)
        goal_cell = self.world_to_cell(goal_xy)

        cell_path = self.bfs_cell_path(start_cell, goal_cell)
        if cell_path is None:
            return None

        # 1. Turn-based extraction at the cell-index level (4-connected, so each
        #    BFS step changes exactly one of (row, col) by ±1; a "turn" is an
        #    index where that direction changes).
        if len(cell_path) >= 3:
            turn_cells = [cell_path[0]]
            for i in range(1, len(cell_path) - 1):
                prev_d = (cell_path[i][0] - cell_path[i - 1][0],
                          cell_path[i][1] - cell_path[i - 1][1])
                next_d = (cell_path[i + 1][0] - cell_path[i][0],
                          cell_path[i + 1][1] - cell_path[i][1])
                if prev_d != next_d:
                    turn_cells.append(cell_path[i])
            turn_cells.append(cell_path[-1])
            cell_path = turn_cells

        cell_centers = np.array([self.cell_to_world(r, c) for r, c in cell_path],
                                dtype=np.float32)

        # 2. Per-segment perpendicular snap. Density-mean centers jitter
        #    perpendicular to the corridor; force each leg onto a shared
        #    row/col so the leg is exactly axis-aligned. Adjacent legs are
        #    perpendicular (turn-cell extraction guarantees this), so the
        #    snaps don't conflict at the shared corner cell.
        if len(cell_path) >= 2:
            snapped = cell_centers.copy()
            for i in range(len(cell_path) - 1):
                rA, cA = cell_path[i]
                rB, cB = cell_path[i + 1]
                if rA == rB:           # horizontal segment → share y
                    shared_y = 0.5 * (snapped[i, 1] + snapped[i + 1, 1])
                    snapped[i, 1] = shared_y
                    snapped[i + 1, 1] = shared_y
                elif cA == cB:         # vertical segment → share x
                    shared_x = 0.5 * (snapped[i, 0] + snapped[i + 1, 0])
                    snapped[i, 0] = shared_x
                    snapped[i + 1, 0] = shared_x
            cell_centers = snapped

        # 3. Build piecewise-linear keypoints: start_xy → ... cell centers ...
        #    → goal_xy. Skip a cell center if start/goal already sits on it.
        keypoints = [start_xy.copy()]
        for i, cc in enumerate(cell_centers):
            if i == 0 and np.linalg.norm(cc - start_xy) < 0.3:
                continue
            if i == len(cell_centers) - 1 and np.linalg.norm(cc - goal_xy) < 0.3:
                continue
            keypoints.append(cc)
        keypoints.append(goal_xy.copy())

        # 4. L-corner insertion (longer-axis-first). Any remaining diagonal
        #    segment is split into two cardinal legs by inserting an explicit
        #    L-corner; the longer axis is traversed first because that is the
        #    axis the BFS came along, so the corner stays inside free cells.
        TOL = 0.1
        ortho = [np.asarray(keypoints[0], dtype=np.float32)]
        for next_pt in keypoints[1:]:
            next_pt = np.asarray(next_pt, dtype=np.float32)
            cur = ortho[-1]
            dx = float(next_pt[0] - cur[0])
            dy = float(next_pt[1] - cur[1])
            if abs(dx) > TOL and abs(dy) > TOL:
                if abs(dx) >= abs(dy):
                    corner = np.array([next_pt[0], cur[1]], dtype=np.float32)
                else:
                    corner = np.array([cur[0], next_pt[1]], dtype=np.float32)
                if np.linalg.norm(corner - cur) > 0.05:
                    ortho.append(corner)
            if np.linalg.norm(next_pt - ortho[-1]) > 0.05:
                ortho.append(next_pt.copy())
        keypoints = ortho

        # 5. Final-approach axis lock. If the last leg into the goal is still
        #    diagonal, project the goal onto the preceding axis-aligned
        #    segment so both legs into the goal are cardinal.
        if len(keypoints) >= 3:
            prev = keypoints[-3]
            last_kp = keypoints[-2]
            goal_kp = keypoints[-1]
            dx = abs(float(goal_kp[0] - last_kp[0]))
            dy = abs(float(goal_kp[1] - last_kp[1]))
            if dx > 0.05 and dy > 0.05:
                seg = last_kp - prev
                if abs(float(seg[0])) > abs(float(seg[1])):
                    turn_x = float(np.clip(goal_kp[0],
                                           min(prev[0], last_kp[0]),
                                           max(prev[0], last_kp[0])))
                    turn_point = np.array([turn_x, last_kp[1]], dtype=np.float32)
                else:
                    turn_y = float(np.clip(goal_kp[1],
                                           min(prev[1], last_kp[1]),
                                           max(prev[1], last_kp[1])))
                    turn_point = np.array([last_kp[0], turn_y], dtype=np.float32)
                if np.linalg.norm(turn_point - last_kp) > 0.05:
                    keypoints[-2] = turn_point

        # 6. Optional sub-cell wobble filter: drop a waypoint whose incoming
        #    *and* outgoing legs are both shorter than ``min_leg``. Single-
        #    leg shortness is unsafe to filter because it can force an
        #    L-corner into a wall the BFS never cleared.
        if min_leg > 0 and len(keypoints) > 2:
            pts = [np.asarray(p, dtype=np.float32) for p in keypoints]
            changed = True
            while changed and len(pts) > 2:
                changed = False
                new_pts = [pts[0]]
                for i in range(1, len(pts) - 1):
                    incoming = float(np.linalg.norm(pts[i] - new_pts[-1]))
                    outgoing = float(np.linalg.norm(pts[i + 1] - pts[i]))
                    if incoming < min_leg and outgoing < min_leg:
                        changed = True
                        continue
                    new_pts.append(pts[i])
                new_pts.append(pts[-1])
                pts = new_pts
            keypoints = pts

        return np.asarray(keypoints, dtype=np.float32)

    # ----- resampling ------------------------------------------------------

    def _resample_axis_aligned(self, keypoints, spacing):
        if spacing <= 0 or len(keypoints) < 2:
            return keypoints
        resampled = [keypoints[0]]
        for i in range(len(keypoints) - 1):
            seg_start = keypoints[i]
            seg_end = keypoints[i + 1]
            seg_vec = seg_end - seg_start
            seg_len = float(np.linalg.norm(seg_vec))
            if seg_len < 1e-6:
                continue
            seg_dir = seg_vec / seg_len
            n_pts = int(seg_len / spacing)
            for j in range(1, n_pts + 1):
                pt = seg_start + seg_dir * (j * spacing)
                if np.linalg.norm(pt - resampled[-1]) > 0.05:
                    resampled.append(pt.astype(np.float32))
            if np.linalg.norm(resampled[-1] - seg_end) > 0.05:
                resampled.append(seg_end.astype(np.float32))
        if np.linalg.norm(resampled[-1] - keypoints[-1]) > 0.05:
            resampled.append(keypoints[-1].copy())
        return np.asarray(resampled, dtype=np.float32)

    def _resample_centerline(self, keypoints, spacing):
        if spacing <= 0 or len(keypoints) < 2:
            return keypoints
        seg_vecs = keypoints[1:] - keypoints[:-1]
        seg_lens = np.linalg.norm(seg_vecs, axis=1)
        total_len = float(np.sum(seg_lens))
        if total_len < 1e-6:
            return keypoints
        cum_lens = np.concatenate([[0.0], np.cumsum(seg_lens)])
        sample_dists = np.arange(float(spacing), total_len, float(spacing),
                                 dtype=np.float32)
        resampled = [keypoints[0]]
        for d in sample_dists:
            seg_idx = int(np.searchsorted(cum_lens, float(d), side='right') - 1)
            seg_idx = min(max(seg_idx, 0), len(seg_lens) - 1)
            seg_len = float(seg_lens[seg_idx])
            if seg_len < 1e-6:
                continue
            local_dist = float(d - cum_lens[seg_idx])
            seg_dir = seg_vecs[seg_idx] / seg_len
            pt = keypoints[seg_idx] + seg_dir * local_dist
            if np.linalg.norm(pt - resampled[-1]) > 0.05:
                resampled.append(pt.astype(np.float32))
        if np.linalg.norm(resampled[-1] - keypoints[-1]) > 0.05:
            resampled.append(keypoints[-1].copy())
        return np.asarray(resampled, dtype=np.float32)

    # ----- top-level entry points ------------------------------------------

    def plan(self, start_xy, goal_xy, spacing=1.0,
             sampling_mode='axis_aligned', min_leg=None):
        """Return cardinal waypoint sequence from start to goal.

        Parameters
        ----------
        start_xy, goal_xy : (2,) array-like
            Start / goal in the same coordinate frame as the data fed to
            ``__init__``.
        spacing : float
            Resample spacing along the polyline. ``≤0`` disables
            resampling and returns just the polyline keypoints.
        sampling_mode : ``'axis_aligned'`` or ``'centerline'``
            ``axis_aligned`` (default) keeps every leg cardinal; sampled
            points lie on a single row or column of the polyline.
            ``centerline`` samples by arc length and may produce
            diagonal sub-targets across turns.
        min_leg : float or None
            Sub-cell wobble filter (drop waypoints whose incoming and
            outgoing legs are both shorter). ``None`` falls back to
            ``self.min_leg`` if set, else ``0`` (disabled).
        """
        if min_leg is None:
            min_leg = float(getattr(self, 'min_leg', 0.0))

        keypoints = self._build_polyline(start_xy, goal_xy, min_leg=min_leg)
        if keypoints is None:
            return None
        if sampling_mode == 'centerline':
            return self._resample_centerline(keypoints, spacing)
        if sampling_mode != 'axis_aligned':
            raise ValueError(f'Unknown sampling_mode: {sampling_mode}')
        return self._resample_axis_aligned(keypoints, spacing)

    # maze2d-flavored alias
    def plan_cardinal_waypoints(self, start_xy, goal_xy, spacing=1.0,
                                sampling_mode='axis_aligned', min_leg=None):
        return self.plan(start_xy, goal_xy, spacing=spacing,
                         sampling_mode=sampling_mode, min_leg=min_leg)

    # ----- helpers ---------------------------------------------------------

    def snap_towards_free(self, x, y, orig_x, orig_y):
        """Walk back from ``(x, y)`` toward ``(orig_x, orig_y)`` until free."""
        if self.is_free(x, y):
            return float(x), float(y)
        for alpha in np.linspace(0.9, 0.0, 20):
            px = orig_x + alpha * (x - orig_x)
            py = orig_y + alpha * (y - orig_y)
            if self.is_free(px, py):
                return float(px), float(py)
        if len(self.free_centres) == 0:
            return float(orig_x), float(orig_y)
        d = np.linalg.norm(self.free_centres - np.array([x, y], dtype=np.float32),
                           axis=1)
        nearest = self.free_centres[int(np.argmin(d))]
        return float(nearest[0]), float(nearest[1])
