"""
PointMass2D Environment for Inverse World Model experiments.

A 2D point-mass agent navigates to goal positions through an obstacle field.

State: (x, y, dx, dy) — position and velocity (4D)
Action: (Fx, Fy) — force applied (2D)
Physics: m*ddx = Fx - mu*dx,  m*ddy = Fy - mu*dy  (damped Newtonian)
Goals: Target (x*, y*) positions
Obstacles: Circular barriers with known positions
"""

import numpy as np
import gymnasium as gym
from gymnasium import spaces
from typing import Optional


class PointMass2D(gym.Env):
    """2D Point-mass navigation with obstacles and goal-conditioning."""

    metadata = {"render_modes": ["rgb_array"], "render_fps": 30}

    def __init__(
        self,
        mass: float = 1.0,
        damping: float = 0.5,
        dt: float = 0.05,
        max_force: float = 5.0,
        arena_size: float = 5.0,
        max_steps: int = 200,
        goal_threshold: float = 0.2,
        n_obstacles: int = 3,
        obstacle_radius: float = 0.4,
        seed: Optional[int] = None,
        fixed_obstacles: Optional[list] = None,
    ):
        super().__init__()

        self.mass = mass
        self.damping = damping
        self.dt = dt
        self.max_force = max_force
        self.arena_size = arena_size
        self.max_steps = max_steps
        self.goal_threshold = goal_threshold
        self.n_obstacles = n_obstacles
        self.obstacle_radius = obstacle_radius

        # State: (x, y, dx, dy)
        high_state = np.array([arena_size, arena_size, 10.0, 10.0], dtype=np.float32)
        self.observation_space = spaces.Dict(
            {
                "observation": spaces.Box(-high_state, high_state, dtype=np.float32),
                "desired_goal": spaces.Box(
                    -np.array([arena_size, arena_size], dtype=np.float32),
                    np.array([arena_size, arena_size], dtype=np.float32),
                    dtype=np.float32,
                ),
                "achieved_goal": spaces.Box(
                    -np.array([arena_size, arena_size], dtype=np.float32),
                    np.array([arena_size, arena_size], dtype=np.float32),
                    dtype=np.float32,
                ),
            }
        )

        # Action: (Fx, Fy)
        self.action_space = spaces.Box(
            -max_force, max_force, shape=(2,), dtype=np.float32
        )

        # Internal state
        self._state = np.zeros(4, dtype=np.float32)
        self._goal = np.zeros(2, dtype=np.float32)
        self._step_count = 0
        self._rng = np.random.default_rng(seed)

        # Obstacles: list of (cx, cy, r)
        if fixed_obstacles is not None:
            self.obstacles = [
                (float(o[0]), float(o[1]), float(o[2])) for o in fixed_obstacles
            ]
        else:
            self.obstacles = []  # generated on reset

    def _generate_obstacles(self):
        """Generate random obstacle positions, avoiding start and goal."""
        obstacles = []
        for _ in range(self.n_obstacles):
            for _attempt in range(100):
                cx = self._rng.uniform(-self.arena_size * 0.7, self.arena_size * 0.7)
                cy = self._rng.uniform(-self.arena_size * 0.7, self.arena_size * 0.7)
                r = self.obstacle_radius

                # Don't place on start or goal
                dist_start = np.sqrt(
                    (cx - self._state[0]) ** 2 + (cy - self._state[1]) ** 2
                )
                dist_goal = np.sqrt(
                    (cx - self._goal[0]) ** 2 + (cy - self._goal[1]) ** 2
                )
                if dist_start > r + 0.5 and dist_goal > r + 0.5:
                    obstacles.append((cx, cy, r))
                    break
        return obstacles

    def _sample_goal(self):
        """Sample a random goal position within the arena."""
        return self._rng.uniform(
            -self.arena_size * 0.8, self.arena_size * 0.8, size=2
        ).astype(np.float32)

    def _sample_start(self):
        """Sample a random start position with zero velocity."""
        pos = self._rng.uniform(
            -self.arena_size * 0.8, self.arena_size * 0.8, size=2
        ).astype(np.float32)
        return np.concatenate([pos, np.zeros(2, dtype=np.float32)])

    def reset(self, *, seed=None, options=None):
        if seed is not None:
            self._rng = np.random.default_rng(seed)

        # Sample start and goal
        self._state = self._sample_start()
        self._goal = self._sample_goal()

        # Ensure start and goal are far enough apart
        while np.linalg.norm(self._state[:2] - self._goal) < 1.0:
            self._goal = self._sample_goal()

        # Generate obstacles (if not fixed)
        if not hasattr(self, "_fixed_obs") or not self._fixed_obs:
            self.obstacles = self._generate_obstacles()

        self._step_count = 0

        return self._get_obs(), self._get_info()

    def step(self, action):
        action = np.clip(action, -self.max_force, self.max_force).astype(np.float32)

        # Physics: m*ddx = F - mu*dx  →  ddx = (F - mu*dx) / m
        x, y, dx, dy = self._state
        fx, fy = action

        # Acceleration
        ddx = (fx - self.damping * dx) / self.mass
        ddy = (fy - self.damping * dy) / self.mass

        # Semi-implicit Euler integration
        new_dx = dx + ddx * self.dt
        new_dy = dy + ddy * self.dt
        new_x = x + new_dx * self.dt
        new_y = y + new_dy * self.dt

        # Obstacle collision (elastic bounce)
        for cx, cy, r in self.obstacles:
            dist = np.sqrt((new_x - cx) ** 2 + (new_y - cy) ** 2)
            if dist < r:
                # Push out of obstacle
                nx_dir = (new_x - cx) / (dist + 1e-8)
                ny_dir = (new_y - cy) / (dist + 1e-8)
                new_x = cx + nx_dir * r
                new_y = cy + ny_dir * r
                # Reflect velocity
                v_dot_n = new_dx * nx_dir + new_dy * ny_dir
                new_dx -= 2 * v_dot_n * nx_dir
                new_dy -= 2 * v_dot_n * ny_dir
                # Dampen bounce
                new_dx *= 0.5
                new_dy *= 0.5

        # Arena boundaries (elastic)
        if abs(new_x) > self.arena_size:
            new_x = np.clip(new_x, -self.arena_size, self.arena_size)
            new_dx *= -0.5
        if abs(new_y) > self.arena_size:
            new_y = np.clip(new_y, -self.arena_size, self.arena_size)
            new_dy *= -0.5

        # Clip velocities
        max_vel = 10.0
        new_dx = np.clip(new_dx, -max_vel, max_vel)
        new_dy = np.clip(new_dy, -max_vel, max_vel)

        self._state = np.array([new_x, new_y, new_dx, new_dy], dtype=np.float32)
        self._step_count += 1

        # Reward and termination
        dist_to_goal = np.linalg.norm(self._state[:2] - self._goal)
        reached = dist_to_goal < self.goal_threshold
        truncated = self._step_count >= self.max_steps

        reward = -dist_to_goal  # dense reward (negative distance)
        if reached:
            reward += 10.0  # bonus for reaching goal

        return (
            self._get_obs(),
            float(reward),
            bool(reached),
            bool(truncated),
            self._get_info(),
        )

    def _get_obs(self):
        return {
            "observation": self._state.copy(),
            "desired_goal": self._goal.copy(),
            "achieved_goal": self._state[:2].copy(),
        }

    def _get_info(self):
        return {
            "dist_to_goal": float(np.linalg.norm(self._state[:2] - self._goal)),
            "is_success": float(
                np.linalg.norm(self._state[:2] - self._goal) < self.goal_threshold
            ),
        }

    def get_physics_params(self):
        """Return physics parameters (useful for physics-informed models)."""
        return {
            "mass": self.mass,
            "damping": self.damping,
            "dt": self.dt,
        }

    # --- Analytical physics (for physics-informed models) ---

    def analytical_inverse_dynamics(self, s_t, s_tp1):
        """
        Given current state s_t and next state s_tp1,
        compute the action (force) that produced the transition.

        From: new_dx = dx + (F - mu*dx)/m * dt
              new_x = x + new_dx * dt

        Solving for F:
            new_dx = (new_x - x) / dt
            ddx = (new_dx - dx) / dt
            F = m * ddx + mu * dx
        """
        x, y, dx, dy = s_t
        new_x, new_y, new_dx, new_dy = s_tp1

        # Reconstruct accelerations
        ddx = (new_dx - dx) / self.dt
        ddy = (new_dy - dy) / self.dt

        # Reconstruct forces
        fx = self.mass * ddx + self.damping * dx
        fy = self.mass * ddy + self.damping * dy

        return np.array([fx, fy], dtype=np.float32)

    def analytical_forward(self, state, action):
        """
        Pure physics forward step (no obstacles/boundaries).
        Useful as ground truth for forward model evaluation.
        """
        x, y, dx, dy = state
        fx, fy = action

        ddx = (fx - self.damping * dx) / self.mass
        ddy = (fy - self.damping * dy) / self.mass

        new_dx = dx + ddx * self.dt
        new_dy = dy + ddy * self.dt
        new_x = x + new_dx * self.dt
        new_y = y + new_dy * self.dt

        return np.array([new_x, new_y, new_dx, new_dy], dtype=np.float32)

    # --- Rendering ---

    def render(self):
        """Render environment as RGB array."""
        import matplotlib.pyplot as plt
        from matplotlib.patches import Circle

        fig, ax = plt.subplots(1, 1, figsize=(5, 5))
        ax.set_xlim(-self.arena_size - 0.5, self.arena_size + 0.5)
        ax.set_ylim(-self.arena_size - 0.5, self.arena_size + 0.5)
        ax.set_aspect("equal")
        ax.grid(True, alpha=0.3)

        # Arena boundary
        rect = plt.Rectangle(
            (-self.arena_size, -self.arena_size),
            2 * self.arena_size,
            2 * self.arena_size,
            fill=False,
            edgecolor="black",
            linewidth=2,
        )
        ax.add_patch(rect)

        # Obstacles
        for cx, cy, r in self.obstacles:
            circle = Circle((cx, cy), r, color="red", alpha=0.5)
            ax.add_patch(circle)

        # Goal
        ax.plot(self._goal[0], self._goal[1], "g*", markersize=20, label="Goal")

        # Agent
        ax.plot(self._state[0], self._state[1], "bo", markersize=10, label="Agent")

        # Velocity arrow
        ax.arrow(
            self._state[0],
            self._state[1],
            self._state[2] * 0.2,
            self._state[3] * 0.2,
            head_width=0.1,
            head_length=0.05,
            fc="blue",
            ec="blue",
        )

        ax.legend(loc="upper right")
        ax.set_title(f"Step {self._step_count}")

        fig.canvas.draw()
        img = np.frombuffer(fig.canvas.buffer_rgba(), dtype=np.uint8)
        img = img.reshape(fig.canvas.get_width_height()[::-1] + (4,))[:, :, :3]
        plt.close(fig)

        return img
