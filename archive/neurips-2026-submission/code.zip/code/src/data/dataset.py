"""
Trajectory dataset, data collection, and DataLoader utilities for IWM.

Provides:
- TrajectoryDataset: stores transitions and full trajectories
- collect_random_trajectories: random policy data collection
- collect_directed_trajectories: P-controller + noise (goal-reaching)
- make_dataloaders: train/val split with PyTorch DataLoaders
"""

import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader, random_split
from pathlib import Path
from typing import Optional, Tuple, List
from tqdm import tqdm


class TrajectoryDataset:
    """
    Stores transition-level data (s, a, s') and full trajectories.

    Trajectories are stored as dicts:
        {
            'states': np.array (T+1, state_dim),
            'actions': np.array (T, action_dim),
            'goal': np.array (goal_dim,),
        }
    """

    def __init__(self):
        self.states: List[np.ndarray] = []       # per-transition
        self.actions: List[np.ndarray] = []      # per-transition
        self.next_states: List[np.ndarray] = []  # per-transition
        self.trajectories: List[dict] = []       # full trajectories

    def __len__(self):
        return len(self.states)

    def add_transition(self, state, action, next_state):
        self.states.append(np.array(state, dtype=np.float32))
        self.actions.append(np.array(action, dtype=np.float32))
        self.next_states.append(np.array(next_state, dtype=np.float32))

    def add_trajectory(self, states, actions, goal):
        """Add a full trajectory and extract transitions."""
        states = np.array(states, dtype=np.float32)
        actions = np.array(actions, dtype=np.float32)
        goal = np.array(goal, dtype=np.float32)

        self.trajectories.append({
            'states': states,
            'actions': actions,
            'goal': goal,
        })

        # Extract transitions
        for t in range(len(actions)):
            self.add_transition(states[t], actions[t], states[t + 1])

    def get_transition_tensors(self) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Return all transitions as tensors."""
        s = torch.tensor(np.array(self.states), dtype=torch.float32)
        a = torch.tensor(np.array(self.actions), dtype=torch.float32)
        ns = torch.tensor(np.array(self.next_states), dtype=torch.float32)
        return s, a, ns

    def get_trajectory_tensors(self, max_horizon: int = 50):
        """
        Return trajectory data for inverse model training.

        Returns:
            start_states: (N, state_dim)
            goal_positions: (N, goal_dim) — positions only
            action_sequences: (N, T, action_dim) — padded to max_horizon
            masks: (N, T) — 1 for valid, 0 for padding
            state_sequences: (N, T+1, state_dim) — full state trajectories
        """
        start_states = []
        goal_positions = []
        action_sequences = []
        state_sequences = []
        masks = []

        state_dim = self.trajectories[0]['states'].shape[1] if self.trajectories else 4
        action_dim = self.trajectories[0]['actions'].shape[1] if self.trajectories else 2

        for traj in self.trajectories:
            T = len(traj['actions'])
            if T == 0 or T > max_horizon:
                continue

            s0 = traj['states'][0]
            goal = traj['goal']

            # Pad actions to max_horizon
            padded_actions = np.zeros((max_horizon, action_dim), dtype=np.float32)
            padded_actions[:T] = traj['actions']

            # Pad states to max_horizon + 1
            padded_states = np.zeros((max_horizon + 1, state_dim), dtype=np.float32)
            n_states = min(len(traj['states']), max_horizon + 1)
            padded_states[:n_states] = traj['states'][:n_states]

            # Mask
            mask = np.zeros(max_horizon, dtype=np.float32)
            mask[:T] = 1.0

            start_states.append(s0)
            goal_positions.append(goal)
            action_sequences.append(padded_actions)
            state_sequences.append(padded_states)
            masks.append(mask)

        return (
            torch.tensor(np.array(start_states), dtype=torch.float32),
            torch.tensor(np.array(goal_positions), dtype=torch.float32),
            torch.tensor(np.array(action_sequences), dtype=torch.float32),
            torch.tensor(np.array(masks), dtype=torch.float32),
            torch.tensor(np.array(state_sequences), dtype=torch.float32),
        )

    def add_hindsight_goals(self, fractions=(0.25, 0.5, 0.75)):
        """
        Hindsight relabeling: sub-trajectories with endpoint as goal.

        For each trajectory, take sub-trajectories ending at 25%, 50%, 75%
        of the way through, and relabel the endpoint as the goal.
        """
        new_trajectories = []
        for traj in list(self.trajectories):
            T = len(traj['actions'])
            if T < 4:
                continue

            for frac in fractions:
                end_idx = max(2, int(T * frac))
                sub_states = traj['states'][:end_idx + 1]
                sub_actions = traj['actions'][:end_idx]
                sub_goal = traj['states'][end_idx, :2].copy()  # position as goal

                new_trajectories.append({
                    'states': sub_states,
                    'actions': sub_actions,
                    'goal': sub_goal,
                })

        self.trajectories.extend(new_trajectories)

    def save(self, path: str):
        """Save dataset to disk."""
        path = Path(path)
        path.mkdir(parents=True, exist_ok=True)

        # Save transitions
        if self.states:
            np.save(path / 'states.npy', np.array(self.states))
            np.save(path / 'actions.npy', np.array(self.actions))
            np.save(path / 'next_states.npy', np.array(self.next_states))

        # Save trajectories
        traj_data = []
        for traj in self.trajectories:
            traj_data.append({
                'states': traj['states'],
                'actions': traj['actions'],
                'goal': traj['goal'],
            })
        np.save(path / 'trajectories.npy', traj_data, allow_pickle=True)

        print(f"Saved dataset: {len(self)} transitions, "
              f"{len(self.trajectories)} trajectories to {path}")

    @classmethod
    def load(cls, path: str) -> 'TrajectoryDataset':
        """Load dataset from disk."""
        path = Path(path)
        ds = cls()

        if (path / 'states.npy').exists():
            states = np.load(path / 'states.npy')
            actions = np.load(path / 'actions.npy')
            next_states = np.load(path / 'next_states.npy')
            ds.states = list(states)
            ds.actions = list(actions)
            ds.next_states = list(next_states)

        if (path / 'trajectories.npy').exists():
            traj_data = np.load(path / 'trajectories.npy', allow_pickle=True)
            for t in traj_data:
                ds.trajectories.append({
                    'states': t['states'],
                    'actions': t['actions'],
                    'goal': t['goal'],
                })

        print(f"Loaded dataset: {len(ds)} transitions, "
              f"{len(ds.trajectories)} trajectories from {path}")
        return ds


class TransitionDataset(Dataset):
    """PyTorch Dataset wrapper for transitions."""

    def __init__(self, states, actions, next_states):
        self.states = states
        self.actions = actions
        self.next_states = next_states

    def __len__(self):
        return len(self.states)

    def __getitem__(self, idx):
        return self.states[idx], self.actions[idx], self.next_states[idx]


def make_dataloaders(
    dataset: TrajectoryDataset,
    batch_size: int = 256,
    val_fraction: float = 0.1,
    num_workers: int = 0,
    seed: int = 42,
) -> Tuple[DataLoader, DataLoader, torch.Tensor, torch.Tensor]:
    """
    Create train/val DataLoaders from a TrajectoryDataset.

    Returns:
        train_loader, val_loader, state_mean, state_std
    """
    s, a, ns = dataset.get_transition_tensors()

    # Compute normalization stats
    state_mean = s.mean(dim=0)
    state_std = s.std(dim=0).clamp(min=1e-6)

    # Create PyTorch dataset
    torch_ds = TransitionDataset(s, a, ns)

    # Split
    n_val = max(1, int(len(torch_ds) * val_fraction))
    n_train = len(torch_ds) - n_val
    train_ds, val_ds = random_split(
        torch_ds,
        [n_train, n_val],
        generator=torch.Generator().manual_seed(seed),
    )

    train_loader = DataLoader(
        train_ds, batch_size=batch_size, shuffle=True, num_workers=num_workers,
    )
    val_loader = DataLoader(
        val_ds, batch_size=batch_size, shuffle=False, num_workers=num_workers,
    )

    return train_loader, val_loader, state_mean, state_std


# ---- Data collection functions ----


def collect_random_trajectories(
    env, n_trajectories: int = 1000, seed: int = 0
) -> TrajectoryDataset:
    """Collect trajectories with random actions."""
    dataset = TrajectoryDataset()

    for i in tqdm(range(n_trajectories), desc="Random trajectories"):
        obs, info = env.reset(seed=seed + i)
        state = obs['observation']
        goal = obs['desired_goal']

        states = [state.copy()]
        actions = []

        done = False
        while not done:
            action = env.action_space.sample()
            obs, reward, terminated, truncated, info = env.step(action)
            state = obs['observation']

            states.append(state.copy())
            actions.append(action.copy())

            done = terminated or truncated

        dataset.add_trajectory(states, actions, goal)

    return dataset


def collect_directed_trajectories(
    env,
    n_trajectories: int = 1000,
    noise_scale: float = 1.5,
    seed: int = 0,
    kp: float = 2.0,
    kd: float = 1.0,
) -> TrajectoryDataset:
    """
    Collect goal-directed trajectories using a P-controller + noise.

    Controller: F = kp * (goal - pos) - kd * vel + noise
    """
    dataset = TrajectoryDataset()

    rng = np.random.default_rng(seed)

    for i in tqdm(range(n_trajectories), desc="Directed trajectories"):
        obs, info = env.reset(seed=seed + n_trajectories + i)
        state = obs['observation']
        goal = obs['desired_goal']

        states = [state.copy()]
        actions = []

        done = False
        while not done:
            pos = state[:2]
            vel = state[2:]

            # PD controller
            force = kp * (goal - pos) - kd * vel
            # Add exploration noise
            force += rng.normal(0, noise_scale, size=2).astype(np.float32)
            # Clip to action bounds
            force = np.clip(force, env.action_space.low, env.action_space.high)

            obs, reward, terminated, truncated, info = env.step(force)
            state = obs['observation']

            states.append(state.copy())
            actions.append(force.copy())

            done = terminated or truncated

        dataset.add_trajectory(states, actions, goal)

    return dataset
