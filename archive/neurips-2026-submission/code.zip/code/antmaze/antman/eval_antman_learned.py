#!/usr/bin/env python3
"""
AntMan stacked-IWM MuJoCo evaluation sweep.

Runs N games per difficulty level using the learned high-level strategy IWM
stacked on top of the learned low-level locomotion IWM.

Usage:
    # Quick smoke test
    python -u antmaze/antman/eval_antman_learned.py --gpu 0 --n_games 3 --difficulties easy \
        --iwm_high_path antmaze/antman/iwm/L32/direction/.../best_model.pt

    # Full sweep
    python -u antmaze/antman/eval_antman_learned.py --gpu 0 --n_games 10 \
        --difficulties none,easy,medium,hard \
        --iwm_high_path antmaze/antman/iwm/L32/direction/.../best_model.pt \
        --save_dir antmaze/antman/evals/stacked_bigtest
"""

import sys, os, argparse, json, time
from pathlib import Path

os.environ.setdefault('D4RL_SUPPRESS_IMPORT_ERROR', '1')

import numpy as np
import torch

PROJECT_ROOT = Path(os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__)))))
sys.path.insert(0, str(PROJECT_ROOT))

from antmaze.antman.antman_learned import (
    run_antman_learned,
    DEFAULT_ENV,
    DEFAULT_IWM_LOW,
    DEFAULT_IWM_HIGH,
    HighLevelPlanner,
    load_iwm_high,
    load_iwm_low_navigator,
)
from antmaze.navigate_cardinal import MAZE_CONFIGS, _init_maze_config
import antmaze.navigate_cardinal as _navcard
from antmaze.navigate_cardinal import EnvOccupancy


DIFFICULTIES = {
    'none': {
        'n_ghosts': 0,
        'ghost_interval': 999,
        'max_steps': 6000,
        'label': 'No ghosts',
    },
    'easy': {
        'n_ghosts': 1,
        'ghost_interval': 200,
        'max_steps': 6000,
        'label': '1 ghost (slow)',
    },
    'medium': {
        'n_ghosts': 2,
        'ghost_interval': 100,
        'max_steps': 5000,
        'label': '2 ghosts (medium)',
    },
    'hard': {
        'n_ghosts': 3,
        'ghost_interval': 50,
        'max_steps': 4000,
        'label': '3 ghosts (fast)',
    },
}


def parse_args():
    p = argparse.ArgumentParser(description='AntMan stacked-IWM MuJoCo evaluation')
    p.add_argument('--gpu', type=int, default=0)
    p.add_argument('--n_games', type=int, default=10,
                   help='Games per difficulty level')
    p.add_argument('--difficulties', type=str, default='easy,medium,hard',
                   help='Comma-separated list: none,easy,medium,hard')
    p.add_argument('--iwm_high_path', type=str, default='')
    p.add_argument('--iwm_low_path', type=str, default='')
    p.add_argument('--base_seed', type=int, default=100)
    p.add_argument('--save_dir', type=str, default='',
                   help='Save per-game results (default: no save)')
    p.add_argument('--save_animations', action='store_true',
                   help='Save MP4 animations for each game')
    p.add_argument('--wp_spacing', type=float, default=1.0)
    p.add_argument('--replan_every', type=int, default=4)
    p.add_argument('--stuck_threshold', type=int, default=10)
    return p.parse_args()


def summarize_results(results):
    n = len(results)
    if n == 0:
        return {
            'completed': 0,
            'successes': 0,
            'success_rate': 0.0,
            'cleared': 0,
            'caught': 0,
            'timeout': 0,
            'score_mean': 0.0,
            'score_std': 0.0,
            'steps_mean': 0.0,
            'pellets_mean': 0.0,
            'replans_mean': 0.0,
            'ghosts_mean': 0.0,
        }

    scores = np.array([r['score'] for r in results], dtype=np.float32)
    steps = np.array([r['steps'] for r in results], dtype=np.float32)
    pellets = np.array([r['pellets_eaten'] for r in results], dtype=np.float32)
    replans = np.array([r['total_replans'] for r in results], dtype=np.float32)
    ghosts = np.array([r['ghosts_eaten'] for r in results], dtype=np.float32)
    outcomes = [r['outcome'] for r in results]

    cleared = sum(1 for o in outcomes if o == 'cleared')
    caught = sum(1 for o in outcomes if o == 'caught')
    timeout = sum(1 for o in outcomes if o == 'timeout')

    return {
        'completed': n,
        'successes': cleared,
        'success_rate': float(cleared / n * 100.0),
        'cleared': cleared,
        'caught': caught,
        'timeout': timeout,
        'score_mean': float(scores.mean()),
        'score_std': float(scores.std()),
        'steps_mean': float(steps.mean()),
        'pellets_mean': float(pellets.mean()),
        'replans_mean': float(replans.mean()),
        'ghosts_mean': float(ghosts.mean()),
    }


def flatten_results(all_results, difficulties):
    episodes = []
    episode_idx = 0
    for diff_name in difficulties:
        for result in all_results.get(diff_name, []):
            episode_idx += 1
            ep = dict(result)
            ep['episode'] = episode_idx
            ep['difficulty'] = diff_name
            ep['success'] = result['outcome'] == 'cleared'
            episodes.append(ep)
    return episodes


def write_progress(save_dir, difficulties, args, iwm_low_path, iwm_high_path,
                   model_type_high, all_results, total_games, started_at):
    if not args.save_dir:
        return

    save_dir = Path(save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)

    episodes = flatten_results(all_results, difficulties)
    completed = len(episodes)
    elapsed_total = time.time() - started_at

    by_difficulty = {}
    for diff_name in difficulties:
        diff_results = all_results.get(diff_name, [])
        diff_summary = summarize_results(diff_results)
        preset = DIFFICULTIES[diff_name]
        by_difficulty[diff_name] = {
            'label': preset['label'],
            'n_ghosts': preset['n_ghosts'],
            'ghost_interval': preset['ghost_interval'],
            'max_steps': preset['max_steps'],
            **diff_summary,
        }

    summary = summarize_results(episodes)

    progress = {
        'n_games_total': total_games,
        'n_games_per_difficulty': args.n_games,
        'difficulties': difficulties,
        'completed': completed,
        'remaining': max(total_games - completed, 0),
        'successes': summary['successes'],
        'success_rate': summary['success_rate'],
        'status': 'complete' if completed >= total_games else 'running',
        'total_time_s': round(elapsed_total, 1),
        'summary': summary,
        'by_difficulty': by_difficulty,
        'episodes': episodes,
    }

    with open(save_dir / 'progress.json', 'w') as f:
        json.dump(progress, f, indent=2)

    results_doc = {
        'difficulties': difficulties,
        'n_games': args.n_games,
        'total_games': total_games,
        'iwm_low_path': str(iwm_low_path.relative_to(PROJECT_ROOT)),
        'iwm_high_path': str(iwm_high_path.relative_to(PROJECT_ROOT)),
        'iwm_high_type': model_type_high,
        'summary': summary,
        'by_difficulty': by_difficulty,
        'episodes': episodes,
        'results': all_results,
        'total_time_s': round(elapsed_total, 1),
    }
    with open(save_dir / 'results.json', 'w') as f:
        json.dump(results_doc, f, indent=2)


def run_difficulty(env, navigator, planner, difficulty_name, n_games, base_seed,
                   args, all_results=None, on_update=None):
    preset = DIFFICULTIES[difficulty_name]

    game_args = argparse.Namespace(
        n_ghosts=preset['n_ghosts'],
        ghost_interval=preset['ghost_interval'],
        max_steps=preset['max_steps'],
        wp_spacing=args.wp_spacing,
        replan_every=args.replan_every,
        stuck_threshold=args.stuck_threshold,
        render_ascii=False,
        render_interval=1,
        seed=base_seed,
    )

    results = all_results.setdefault(difficulty_name, []) if all_results is not None else []
    for i in range(n_games):
        seed = base_seed + i
        np.random.seed(seed)
        torch.manual_seed(seed)
        game_args.seed = seed

        env.seed(seed)

        t0 = time.time()
        result = run_antman_learned(env, navigator, planner, game_args,
                                    verbose=False)
        elapsed = time.time() - t0

        summary = {
            'game': i + 1,
            'seed': seed,
            'outcome': result['outcome'],
            'success': result['outcome'] == 'cleared',
            'score': result['score'],
            'steps': result['steps'],
            'chunks': result['chunks'],
            'pellets_eaten': result['pellets_eaten'],
            'pellets_total': result['pellets_total'],
            'ghosts_eaten': result['ghosts_eaten'],
            'total_replans': result['total_replans'],
            'elapsed_s': round(elapsed, 1),
        }
        results.append(summary)

        if on_update is not None:
            on_update()

        if args.save_dir:
            game_dir = Path(args.save_dir) / difficulty_name / f'game_{i:03d}'
            game_dir.mkdir(parents=True, exist_ok=True)
            save_result = {k: v for k, v in result.items() if k != '_game'}
            with open(game_dir / 'results.json', 'w') as f:
                json.dump(save_result, f, indent=2)

            if args.save_animations:
                try:
                    from antmaze.antman.animate_episode import make_animation
                    import matplotlib
                    matplotlib.use('Agg')
                    import matplotlib.pyplot as plt
                    import matplotlib.animation as animation

                    anim_args = argparse.Namespace(
                        fps=30, subsample=8, trail_len=300, dpi=100)
                    fig, anim = make_animation(save_result, anim_args)

                    import imageio_ffmpeg
                    plt.rcParams['animation.ffmpeg_path'] = \
                        imageio_ffmpeg.get_ffmpeg_exe()
                    writer = animation.FFMpegWriter(
                        fps=30, bitrate=2000,
                        extra_args=['-pix_fmt', 'yuv420p'])
                    anim.save(str(game_dir / 'episode.mp4'),
                              writer=writer, dpi=100)
                    plt.close(fig)
                except Exception as e:
                    print(f'  Warning: animation failed: {e}')

        tag = {'cleared': '✓', 'caught': '✗', 'timeout': '◷'}
        print(f'  [{tag.get(result["outcome"], "?")}] Game {i+1:2d}  '
              f'seed={seed}  score={result["score"]:5d}  '
              f'pellets={result["pellets_eaten"]}/{result["pellets_total"]}  '
              f'replans={result["total_replans"]:3d}  '
              f'steps={result["steps"]:5d}  '
              f'{result["outcome"]}  ({elapsed:.1f}s)',
              flush=True)

    return results


def print_summary_table(all_results):
    print()
    print('=' * 109)
    print(f'{"Difficulty":<10} {"Ghosts":>6} {"Interval":>8} {"Games":>5} '
          f'{"Score (mean±std)":>18} {"Cleared":>8} {"Caught":>8} '
          f'{"Timeout":>8} {"Pellets":>10} {"Replans":>10}')
    print('-' * 109)

    for diff_name, results in all_results.items():
        preset = DIFFICULTIES[diff_name]
        n = len(results)
        scores = np.array([r['score'] for r in results])
        pellets = np.array([r['pellets_eaten'] for r in results])
        replans = np.array([r['total_replans'] for r in results])
        outcomes = [r['outcome'] for r in results]

        cleared = sum(1 for o in outcomes if o == 'cleared')
        caught = sum(1 for o in outcomes if o == 'caught')
        timeout = sum(1 for o in outcomes if o == 'timeout')

        print(f'{diff_name:<10} {preset["n_ghosts"]:>6} {preset["ghost_interval"]:>8} '
              f'{n:>5} {scores.mean():>8.0f} ± {scores.std():<7.0f} '
              f'{cleared}/{n:>5} {caught}/{n:>5} {timeout}/{n:>5} '
              f'{pellets.mean():>6.1f}/{results[0]["pellets_total"]:<3d} '
              f'{replans.mean():>8.1f}')

    print('=' * 109)


def main():
    args = parse_args()
    difficulties = [d.strip() for d in args.difficulties.split(',')]
    for d in difficulties:
        if d not in DIFFICULTIES:
            print(f'ERROR: Unknown difficulty "{d}". '
                  f'Choose from: {", ".join(DIFFICULTIES.keys())}',
                  file=sys.stderr)
            sys.exit(1)

    _init_maze_config(DEFAULT_ENV)
    _navcard.OCC = EnvOccupancy()

    if args.gpu >= 0 and torch.cuda.is_available():
        device = f'cuda:{args.gpu}'
    else:
        device = 'cpu'

    iwm_low_path = PROJECT_ROOT / (args.iwm_low_path or DEFAULT_IWM_LOW)
    iwm_high_path = PROJECT_ROOT / (args.iwm_high_path or DEFAULT_IWM_HIGH)
    if not iwm_low_path.exists():
        print(f'ERROR: IWM_low not found: {iwm_low_path}', file=sys.stderr)
        sys.exit(1)
    if not iwm_high_path.exists():
        print(f'ERROR: IWM_high not found: {iwm_high_path}', file=sys.stderr)
        sys.exit(1)

    print(f'Loading IWM_low from {iwm_low_path}', flush=True)
    navigator, horizon_low, n_params_low = load_iwm_low_navigator(iwm_low_path, device)
    print(f'IWM_low: {n_params_low:,} params, horizon={horizon_low}', flush=True)

    print(f'Loading IWM_high from {iwm_high_path}', flush=True)
    iwm_high, pos_mean, pos_std, wp_mean, wp_std, model_type_high = load_iwm_high(
        iwm_high_path, device)
    n_params_high = sum(p.numel() for p in iwm_high.parameters())
    print(f'IWM_high: {n_params_high:,} params, horizon={iwm_high.horizon}, '
          f'type={model_type_high}', flush=True)
    planner = HighLevelPlanner(iwm_high, pos_mean, pos_std, wp_mean, wp_std,
                               device)

    gym_env = MAZE_CONFIGS[DEFAULT_ENV]['gym_env']
    print(f'Creating MuJoCo env ({gym_env})...', flush=True)
    import gym
    import d4rl  # noqa
    env = gym.make(gym_env)
    print('Env ready\n', flush=True)

    total_games = len(difficulties) * args.n_games
    print(f'Evaluation: {len(difficulties)} difficulties × {args.n_games} games '
          f'= {total_games} total games')
    print(f'Difficulties: {", ".join(difficulties)}')
    if args.save_dir:
        print(f'Saving to: {args.save_dir}')
    print(flush=True)

    all_results = {}
    t_start = time.time()

    if args.save_dir:
        Path(args.save_dir).mkdir(parents=True, exist_ok=True)

    def _write_current_progress():
        write_progress(
            args.save_dir,
            difficulties,
            args,
            iwm_low_path,
            iwm_high_path,
            model_type_high,
            all_results,
            total_games,
            t_start,
        )

    _write_current_progress()

    for diff_name in difficulties:
        preset = DIFFICULTIES[diff_name]
        print(f'\n── {diff_name.upper()} ({preset["label"]}) ──')
        results = run_difficulty(
            env,
            navigator,
            planner,
            diff_name,
            args.n_games,
            args.base_seed,
            args,
            all_results=all_results,
            on_update=_write_current_progress,
        )
        all_results[diff_name] = results

    elapsed_total = time.time() - t_start
    print_summary_table(all_results)
    print(f'\nTotal time: {elapsed_total:.0f}s ({elapsed_total / total_games:.1f}s/game)')

    if args.save_dir:
        save_dir = Path(args.save_dir)
        save_dir.mkdir(parents=True, exist_ok=True)
        _write_current_progress()
        summary = {
            'difficulties': difficulties,
            'n_games': args.n_games,
            'total_games': total_games,
            'iwm_low_path': str(iwm_low_path.relative_to(PROJECT_ROOT)),
            'iwm_high_path': str(iwm_high_path.relative_to(PROJECT_ROOT)),
            'iwm_high_type': model_type_high,
            'summary': summarize_results(flatten_results(all_results, difficulties)),
            'results': all_results,
            'total_time_s': round(elapsed_total, 1),
        }
        with open(save_dir / 'eval_summary.json', 'w') as f:
            json.dump(summary, f, indent=2)
        print(f'Summary saved to {save_dir / "eval_summary.json"}')


if __name__ == '__main__':
    main()