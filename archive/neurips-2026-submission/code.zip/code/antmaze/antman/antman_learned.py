#!/usr/bin/env python3
"""
AntMan Learned — Pac-Man with BOTH levels controlled by learned IWMs.

Stage C: replaces the hand-coded strategy with the trained high-level IWM.

Architecture:
  IWM_high (game_state → cell sequence)  →  cardinal waypoints  →  IWM_low (obs → torques)

Every REPLAN_EVERY high-level chunks, the high-level IWM re-evaluates the
game state and produces a fresh 32-step cell plan. The ant walks one cell at
a time using the low-level locomotion IWM + cardinal sub-waypoints.

Usage:
    export LD_LIBRARY_PATH="$HOME/.mujoco/mujoco210/bin:/usr/lib/nvidia"

    python -u antmaze/antman/antman_learned.py --gpu 0 --n_ghosts 1 --ghost_interval 16

    # Custom checkpoints:
    python -u antmaze/antman/antman_learned.py --gpu 0 \
        --iwm_high_path antmaze/antman/iwm/L32/.../best_model.pt \
        --iwm_low_path antmaze/large-diverse/iwm/L8/.../best_model.pt
"""

import sys, os, argparse, json, time, math, random
from pathlib import Path

os.environ.setdefault('D4RL_SUPPRESS_IMPORT_ERROR', '1')

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

PROJECT_ROOT = Path(os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__)))))
sys.path.insert(0, str(PROJECT_ROOT))

from antmaze.antman.game import AntManGame
from antmaze.antman.game_state import (
    encode_game_state, OPEN_CELLS, CELL_TO_IDX, WAYPOINTS,
    N_CELLS, CELL_NEIGHBORS, GAME_STATE_DIM, LEGACY_GAME_STATE_DIM,
    CONTINUOUS_SLICE, cell_to_world,
)
from antmaze.antman.render import render_ascii, render_matplotlib
from antmaze.navigate_cardinal import (
    MAZE_CONFIGS, AntMazeIWM, Navigator,
    plan_cardinal_waypoints, _init_maze_config,
)

# ═════════════════════════════════════════════════════════════════════════
# IWM High model definition (inlined from train_iwm_adj.py)
# ═════════════════════════════════════════════════════════════════════════

MAZE_MAP = [
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1],
    [1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1],
    [1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1],
    [1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1],
    [1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1],
    [1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
]
SCALING = 4.0
TORSO_X = 4.0
TORSO_Y = 4.0

WAYPOINTS_WORLD = np.array(
    [(_c * SCALING - TORSO_X, _r * SCALING - TORSO_Y) for _r, _c in OPEN_CELLS],
    dtype=np.float32,
)

_ADJ_MATRIX = np.zeros((N_CELLS, N_CELLS), dtype=np.float32)
for _i in range(N_CELLS):
    _ADJ_MATRIX[_i, _i] = 1.0
    for _j in CELL_NEIGHBORS[_i]:
        _ADJ_MATRIX[_i, _j] = 1.0


class IWMHighAdjCellCNN(nn.Module):
    def __init__(self, state_dim=55, n_cells=46, horizon=32,
                 latent_dim=128, decoder_channels=(128, 64, 32),
                 dropout=0.1, tau_init=1.0, start_temp=0.01):
        super().__init__()
        self.state_dim = state_dim
        self.n_cells = n_cells
        self.horizon = horizon
        self.latent_dim = latent_dim
        self.tau = tau_init
        self.start_temp = start_temp

        self.encoder = nn.Sequential(
            nn.Linear(state_dim, latent_dim), nn.GELU(),
            nn.LayerNorm(latent_dim), nn.Dropout(dropout),
            nn.Linear(latent_dim, latent_dim), nn.GELU(),
            nn.LayerNorm(latent_dim),
        )

        n_doublings = int(math.log2(horizon))
        ch_list = list(decoder_channels)
        while len(ch_list) < n_doublings:
            ch_list.append(ch_list[-1])
        ch_list = ch_list[:n_doublings]

        decoder_layers = []
        in_ch = latent_dim
        for out_ch in ch_list:
            decoder_layers.append(
                nn.ConvTranspose1d(in_ch, out_ch, kernel_size=4, stride=2, padding=1))
            decoder_layers.append(nn.GELU())
            decoder_layers.append(nn.BatchNorm1d(out_ch))
            decoder_layers.append(nn.Dropout(dropout))
            in_ch = out_ch
        self.decoder = nn.Sequential(*decoder_layers)
        self.output_proj = nn.Conv1d(ch_list[-1], n_cells, kernel_size=3, padding=1)

        self.register_buffer('adj_matrix', torch.tensor(_ADJ_MATRIX))
        self.register_buffer('waypoints_norm', torch.zeros(n_cells, 2))

    def _nearest_cell(self, ant_xy_norm):
        diff = ant_xy_norm.unsqueeze(1) - self.waypoints_norm.unsqueeze(0)
        dist_sq = (diff ** 2).sum(-1)
        return dist_sq.argmin(dim=-1)

    def forward(self, game_state, ant_xy_norm):
        B = game_state.shape[0]
        H = self.horizon

        z = self.encoder(game_state).unsqueeze(-1)
        h = self.decoder(z)
        raw_logits = self.output_proj(h).permute(0, 2, 1)

        weights = torch.zeros(B, H, self.n_cells, device=game_state.device)

        for t in range(H):
            if t == 0:
                prev_cell = self._nearest_cell(ant_xy_norm)
            else:
                prev_cell = weights[:, t-1, :].argmax(dim=-1)

            reachable = self.adj_matrix[prev_cell]
            mask = torch.where(reachable > 0.5, 0.0, -1e9)
            masked_logits = raw_logits[:, t, :] + mask
            w_t = F.softmax(masked_logits / self.tau, dim=-1)
            weights[:, t, :] = w_t

        wp_pred = weights @ self.waypoints_norm
        return wp_pred, weights

    def set_waypoints_norm(self, wp_mean, wp_std, device=None):
        wp_norm = (WAYPOINTS_WORLD - wp_mean) / wp_std
        self.waypoints_norm = torch.tensor(wp_norm, dtype=torch.float32)
        if device is not None:
            self.waypoints_norm = self.waypoints_norm.to(device)

    def get_hard_cells(self, game_state, ant_xy_norm):
        with torch.no_grad():
            _, weights = self.forward(game_state, ant_xy_norm)
        return weights.argmax(dim=-1)


# ═════════════════════════════════════════════════════════════════════════
# Constants
# ═════════════════════════════════════════════════════════════════════════

DEFAULT_ENV = 'large-diverse'
DEFAULT_IWM_LOW = ('antmaze/large-diverse/iwm/L8/'
                   'antmaze_large_diverse_nohealth_v2_disp025_20260410_111959/'
                   'best_model.pt')
DEFAULT_IWM_HIGH = ('antmaze/antman/iwm/L32/'
                    'antman_iwm_adj_L32_v2_20260411_200753/best_model.pt')

WP_SPACING = 1.0
WP_ADVANCE_DIST = 1.0
WP_SKIP_DIST = 0.8
STUCK_THRESHOLD = 10
REPLAN_HIGH_EVERY = 4    # re-invoke IWM_high every N cells reached
MAX_CELLS_PER_PLAN = 32  # IWM_high horizon
TARGET_DIST_MIN = 0.5    # randomized target overshoot (match IWM_low training)
TARGET_DIST_MAX = 1.5


# ═════════════════════════════════════════════════════════════════════════
# Load IWM High
# ═════════════════════════════════════════════════════════════════════════

def infer_iwm_high_model_type(ckpt):
    model_type = ckpt.get('model_type')
    if model_type:
        return model_type
    if 'n_dirs' in ckpt:
        return 'iwm_direction_transformer'
    if 'd_model' in ckpt and 'n_heads' in ckpt and 'n_layers' in ckpt:
        return 'iwm_high_transformer'
    if 'start_temp' in ckpt:
        return 'iwm_high_adj_cell_cnn'
    return 'iwm_high_cell_cnn'


def hydrate_iwm_high_checkpoint(path, ckpt):
    required_keys = (
        'state_dim', 'n_cells', 'horizon',
        'pos_mean', 'pos_std', 'wp_mean', 'wp_std',
    )
    if all(key in ckpt for key in required_keys):
        return ckpt

    path = Path(path)
    for donor_name in ('latest_model.pt', 'best_model.pt'):
        donor_path = path.parent / donor_name
        if donor_path == path or not donor_path.exists():
            continue

        donor = torch.load(donor_path, map_location='cpu', weights_only=False)
        if not isinstance(donor, dict) or 'model_state_dict' not in donor:
            continue

        merged = dict(donor)
        if 'model_state_dict' in ckpt:
            merged['model_state_dict'] = ckpt['model_state_dict']
        for key, value in ckpt.items():
            if key == 'model_state_dict':
                continue
            merged[key] = value
        return merged

    return ckpt


def load_iwm_high(path, device):
    ckpt = torch.load(path, map_location='cpu', weights_only=False)
    ckpt = hydrate_iwm_high_checkpoint(path, ckpt)
    model_type = infer_iwm_high_model_type(ckpt)
    wp_mean = np.array(ckpt['wp_mean'])
    wp_std = np.array(ckpt['wp_std'])
    pos_mean = np.array(ckpt['pos_mean'])
    pos_std = np.array(ckpt['pos_std'])

    if model_type == 'iwm_direction_transformer':
        from antmaze.antman.train_iwm_tfm_dir import IWMDirectionTransformer

        model = IWMDirectionTransformer(
            state_dim=ckpt['state_dim'],
            n_cells=ckpt['n_cells'],
            n_dirs=ckpt.get('n_dirs', 4),
            horizon=ckpt['horizon'],
            d_model=ckpt['d_model'],
            n_heads=ckpt['n_heads'],
            n_layers=ckpt['n_layers'],
            ff_mult=ckpt.get('ff_mult', 3),
            dropout=0.0,
            tau_init=ckpt.get('tau_end', 0.1),
            tau_end=ckpt.get('tau_end', 0.1),
        ).to(device)
    elif model_type == 'iwm_high_transformer':
        try:
            from antmaze.antman.train_iwm_tfm_v2 import IWMHighTransformer
        except ImportError:
            from antmaze.antman.train_iwm_tfm import IWMHighTransformer

        model = IWMHighTransformer(
            state_dim=ckpt['state_dim'],
            n_cells=ckpt['n_cells'],
            horizon=ckpt['horizon'],
            d_model=ckpt['d_model'],
            n_heads=ckpt['n_heads'],
            n_layers=ckpt['n_layers'],
            ff_mult=ckpt.get('ff_mult', 3),
            dropout=0.0,
            tau_init=ckpt.get('tau_end', 0.1),
        ).to(device)
    elif model_type == 'iwm_high_adj_cell_cnn':
        model = IWMHighAdjCellCNN(
            state_dim=ckpt['state_dim'],
            n_cells=ckpt['n_cells'],
            horizon=ckpt['horizon'],
            latent_dim=ckpt['latent_dim'],
            decoder_channels=tuple(ckpt['decoder_channels']),
            dropout=0.0,
            tau_init=ckpt.get('tau_end', 0.1),
            start_temp=ckpt.get('start_temp', 0.01),
        ).to(device)
    elif model_type == 'iwm_high_cell_cnn':
        from antmaze.antman.train_iwm_cell import IWMHighCellCNN

        model = IWMHighCellCNN(
            state_dim=ckpt['state_dim'],
            n_cells=ckpt['n_cells'],
            horizon=ckpt['horizon'],
            latent_dim=ckpt['latent_dim'],
            decoder_channels=tuple(ckpt['decoder_channels']),
            dropout=0.0,
            tau_init=ckpt.get('tau_end', 0.1),
        ).to(device)
    else:
        raise ValueError(f'Unsupported IWM_high model_type: {model_type}')

    model.load_state_dict(ckpt['model_state_dict'])
    model.set_waypoints_norm(wp_mean, wp_std, device)
    model.eval()

    return model, pos_mean, pos_std, wp_mean, wp_std, model_type


def load_iwm_low_navigator(path, device):
    ckpt_low = torch.load(path, map_location='cpu', weights_only=False)

    if isinstance(ckpt_low, dict) and 'model_state_dict' in ckpt_low:
        state_dict_low = ckpt_low['model_state_dict']
        meta_low = ckpt_low
    else:
        state_dict_low = ckpt_low
        meta_low = {}

    config_low_path = path.parent / 'config.json'
    if config_low_path.exists():
        with open(config_low_path) as f:
            cfg_low = json.load(f).get('model', {})
    else:
        cfg_low = {}

    horizon_low = meta_low.get('horizon', 8)

    iwm_low = AntMazeIWM(
        d_model=cfg_low.get('d_model', 192),
        n_heads=cfg_low.get('n_heads', 6),
        n_layers=cfg_low.get('n_layers', 4),
        d_ff=cfg_low.get('d_ff', 576),
        dropout=0.0,
        relative_xy=cfg_low.get('relative_xy', False),
        horizon=horizon_low,
    ).to(device)
    iwm_low.load_state_dict(state_dict_low)
    iwm_low.eval()

    n_params_low = sum(p.numel() for p in iwm_low.parameters())
    return Navigator(iwm_low, device=device), horizon_low, n_params_low


# ═════════════════════════════════════════════════════════════════════════
# IWM High inference wrapper
# ═════════════════════════════════════════════════════════════════════════

class HighLevelPlanner:
    """Wraps IWM_high for game-time inference.

    Given an AntManGame + ant position, encodes state, runs IWM_high,
    returns a list of (row, col) target cells.
    """

    def __init__(self, iwm_high, pos_mean, pos_std, wp_mean, wp_std, device):
        self.iwm_high = iwm_high
        self.pos_mean = pos_mean
        self.pos_std = pos_std
        self.wp_mean = wp_mean
        self.wp_std = wp_std
        self.device = device
        self.state_dim = int(getattr(iwm_high, 'state_dim', GAME_STATE_DIM))
        if self.state_dim not in (LEGACY_GAME_STATE_DIM, GAME_STATE_DIM):
            raise ValueError(f'Unsupported IWM_high state_dim: {self.state_dim}')

    @torch.no_grad()
    def plan(self, game, ant_xy):
        """Produce a cell sequence from the current game state.

        Returns:
            cell_indices: list of ints (indices into OPEN_CELLS)
        """
        # Encode game state using the layout expected by this checkpoint.
        state_raw = encode_game_state(game, ant_xy, state_dim=self.state_dim)

        # Normalize the continuous block only; ghost-presence mask stays binary.
        state_norm = state_raw.copy()
        state_norm[CONTINUOUS_SLICE] = (
            state_norm[CONTINUOUS_SLICE] - self.pos_mean
        ) / self.pos_std

        # Ant xy in waypoint-normalized space
        ant_xy_norm = (ant_xy - self.wp_mean) / self.wp_std

        # To tensors
        s0 = torch.tensor(state_norm, dtype=torch.float32,
                          device=self.device).unsqueeze(0)
        axy = torch.tensor(ant_xy_norm, dtype=torch.float32,
                           device=self.device).unsqueeze(0)

        # Run IWM_high
        cell_indices = self.iwm_high.get_hard_cells(s0, axy)  # (1, H)
        cell_indices = cell_indices[0].cpu().numpy().tolist()

        # Deduplicate consecutive same cells (staying in place)
        deduped = [cell_indices[0]]
        for ci in cell_indices[1:]:
            if ci != deduped[-1]:
                deduped.append(ci)

        return deduped


class RandomNeighborPlanner:
    """High-level planner that matches the training-data random controller.

    At each high-level decision, choose a uniform-random neighboring open cell.
    This mirrors antmaze/antman/sim/generate_random_data.py.
    """

    mode = 'random_neighbor'
    display_name = 'AntMan Random Neighbor Planner'

    def __init__(self, horizon=1, seed=42):
        self.horizon = max(1, int(horizon))
        self._rng = random.Random(seed)

    def set_seed(self, seed):
        self._rng.seed(int(seed))

    def plan(self, game, ant_xy):
        ant_cell = game.get_ant_cell(ant_xy)
        cell_idx = CELL_TO_IDX[ant_cell]
        plan = []

        for _ in range(self.horizon):
            neighbors = CELL_NEIGHBORS.get(cell_idx, ())
            if neighbors:
                cell_idx = self._rng.choice(neighbors)
            plan.append(int(cell_idx))

        return plan


# ═════════════════════════════════════════════════════════════════════════
# Args
# ═════════════════════════════════════════════════════════════════════════

parser = argparse.ArgumentParser(description='AntMan Learned — two-level IWM')

parser.add_argument('--gpu', type=int, default=0)
parser.add_argument('--seed', type=int, default=42)

# Game
parser.add_argument('--n_ghosts', type=int, default=1, choices=[0, 1, 2, 3])
parser.add_argument('--ghost_interval', type=int, default=10)
parser.add_argument('--max_steps', type=int, default=3000)

# Models
parser.add_argument('--iwm_high_path', type=str, default='')
parser.add_argument('--iwm_low_path', type=str, default='')

# Navigation
parser.add_argument('--wp_spacing', type=float, default=WP_SPACING)
parser.add_argument('--replan_every', type=int, default=REPLAN_HIGH_EVERY,
                    help='Re-invoke IWM_high every N cells reached')
parser.add_argument('--stuck_threshold', type=int, default=STUCK_THRESHOLD)

# Output
parser.add_argument('--render_ascii', action='store_true')
parser.add_argument('--render_interval', type=int, default=1)
parser.add_argument('--save_results', action='store_true')
parser.add_argument('--save_figure', action='store_true')
parser.add_argument('--out_dir', type=str, default='')
parser.add_argument('--quiet', action='store_true')


# ═════════════════════════════════════════════════════════════════════════
# Game loop
# ═════════════════════════════════════════════════════════════════════════

def run_antman_learned(env, navigator, planner, args, verbose=True):
    """Run one AntMan game with learned high-level + low-level IWMs.

    Flow:
      1. IWM_high produces cell plan from game state
      2. For each target cell in the plan:
         a. plan_cardinal_waypoints → sub-waypoints to cell center
         b. IWM_low executes sub-waypoints chunk by chunk
         c. Game ticks with each MuJoCo step
      3. Replan when enough cells reached or plan exhausted
    """
    cfg = MAZE_CONFIGS[DEFAULT_ENV]
    game = AntManGame(
        cfg['maze_map'], cfg['scaling'], cfg['torso_x'], cfg['torso_y'],
        n_ghosts=args.n_ghosts,
        ghost_move_interval=args.ghost_interval,
        max_steps=args.max_steps,
    )
    game.reset()

    obs = env.reset()

    # Logging
    ant_trail = [obs[:2].copy()]
    ghost_trails = {g.name: [(g.row, g.col)] for g in game.ghosts}
    pellet_log = []
    plan_log = []

    ghost_names = [g.name.capitalize() for g in game.ghosts]
    if verbose:
        n_regular = sum(1 for p in game.pellets if not p.is_power)
        n_power = sum(1 for p in game.pellets if p.is_power)
        print(f'\n=== AntMan Learned (Two-Level IWM) ===')
        print(f'Ghosts: {args.n_ghosts} ({", ".join(ghost_names)}), '
              f'move every {args.ghost_interval} steps')
        print(f'Pellets: {n_regular} regular + {n_power} power = '
              f'{len(game.pellets)} total')
        print(f'Replan high-level every {args.replan_every} cells')
        print(flush=True)

    steps = 0
    chunk_count = 0
    game_over = False
    total_replans = 0

    # High-level plan state
    cell_plan = []       # list of cell indices from IWM_high
    cell_plan_idx = 0    # next cell to navigate to
    cells_reached = 0    # cells reached since last high-level replan

    # Low-level navigation state (within one cell-to-cell segment)
    wp_chain = None
    wp_idx = 0
    chunks_since_advance = 0

    while steps < args.max_steps and not game_over:
        current_xy = obs[:2].copy()
        ant_cell = game.get_ant_cell(current_xy)

        # ─── High-level: do we need a new cell plan? ───────────────
        need_high_replan = (
            len(cell_plan) == 0
            or cell_plan_idx >= len(cell_plan)
            or cells_reached >= args.replan_every
            or (chunk_count > 0 and chunk_count % 50 == 0)  # time-based fallback
        )

        if need_high_replan:
            cell_plan = planner.plan(game, current_xy)
            cell_plan_idx = 0
            cells_reached = 0
            total_replans += 1

            # Skip cells we're already at
            while (cell_plan_idx < len(cell_plan)
                   and OPEN_CELLS[cell_plan[cell_plan_idx]] == ant_cell):
                cell_plan_idx += 1

            plan_cells_str = ' → '.join(
                f'({OPEN_CELLS[ci][0]},{OPEN_CELLS[ci][1]})'
                for ci in cell_plan[:8]
            )
            if len(cell_plan) > 8:
                plan_cells_str += f' ... ({len(cell_plan)} total)'

            plan_log.append({
                'step': steps,
                'ant_cell': list(ant_cell),
                'plan': [int(c) for c in cell_plan],
            })

            if verbose:
                print(f'[Step {steps:4d}] HIGH REPLAN #{total_replans}: '
                      f'ant@({ant_cell[0]},{ant_cell[1]})  '
                      f'plan: {plan_cells_str}', flush=True)

            # Reset low-level nav
            wp_chain = None
            chunks_since_advance = 0

        # ─── Get current target cell from plan ─────────────────────
        if cell_plan_idx >= len(cell_plan):
            # Plan exhausted — force replan next iteration
            cell_plan = []
            continue

        target_cell_idx = cell_plan[cell_plan_idx]
        target_cell = OPEN_CELLS[target_cell_idx]
        target_world = cell_to_world(*target_cell)

        # ─── Check if we've reached the target cell ────────────────
        dist_to_target = float(np.linalg.norm(current_xy - target_world))
        if dist_to_target < 2.0:  # within cell radius
            cell_plan_idx += 1
            cells_reached += 1
            wp_chain = None
            chunks_since_advance = 0

            # Skip consecutive cells we're already at
            while (cell_plan_idx < len(cell_plan)
                   and float(np.linalg.norm(
                       current_xy - cell_to_world(*OPEN_CELLS[cell_plan[cell_plan_idx]])
                   )) < 2.0):
                cell_plan_idx += 1
                cells_reached += 1

            continue  # Re-evaluate at top of loop

        # ─── Low-level: plan sub-waypoints to target cell ──────────
        if wp_chain is None or chunks_since_advance >= args.stuck_threshold:
            if chunks_since_advance >= args.stuck_threshold:
                # Stuck — try a small escape move
                neighbors = game.get_neighbors(*ant_cell)
                if neighbors:
                    esc_cell = neighbors[np.random.randint(len(neighbors))]
                    esc_world = cell_to_world(*esc_cell)
                    wp_chain = plan_cardinal_waypoints(
                        current_xy, esc_world, spacing=args.wp_spacing)
                else:
                    wp_chain = plan_cardinal_waypoints(
                        current_xy, target_world, spacing=args.wp_spacing)
            else:
                wp_chain = plan_cardinal_waypoints(
                    current_xy, target_world, spacing=args.wp_spacing)
            wp_idx = 1
            chunks_since_advance = 0

        # ─── Waypoint advancement ──────────────────────────────────
        if wp_chain is not None and len(wp_chain) >= 2:
            n_wp = len(wp_chain)
            while wp_idx < n_wp - 1:
                dist_to_wp = float(np.linalg.norm(current_xy - wp_chain[wp_idx]))
                if dist_to_wp < WP_ADVANCE_DIST:
                    wp_idx += 1
                    chunks_since_advance = 0
                elif (wp_idx + 1 < n_wp
                      and float(np.linalg.norm(
                          current_xy - wp_chain[wp_idx + 1])) < WP_SKIP_DIST):
                    wp_idx = min(wp_idx + 2, n_wp - 1)
                    chunks_since_advance = 0
                else:
                    break

            iwm_target = wp_chain[min(wp_idx, n_wp - 1)].copy()
        else:
            iwm_target = target_world.copy()
        # ─── Randomized target distance (matches IWM_low training) ─
        direction = iwm_target - current_xy
        dir_norm = float(np.linalg.norm(direction))
        if dir_norm > 0.01:
            direction = direction / dir_norm
            rand_dist = np.random.uniform(TARGET_DIST_MIN, TARGET_DIST_MAX)
            iwm_target = current_xy + direction * rand_dist
        # ─── IWM_low: generate action chunk ────────────────────────
        actions = navigator.get_actions(obs, iwm_target)

        # ─── Execute in MuJoCo ─────────────────────────────────────
        for a in actions:
            a = np.clip(a, -1.0, 1.0)
            obs, reward, done, info = env.step(a)
            steps += 1
            events = game.tick(obs[:2], obs[15:17], steps)

            ant_trail.append(obs[:2].copy())
            for g in game.ghosts:
                ghost_trails[g.name].append((g.row, g.col))

            if events['pellet_eaten']:
                pellet_log.append({
                    'step': steps,
                    'pos': obs[:2].tolist(),
                    'points': events['points_this_step'],
                    'power': events['power_activated'],
                })

            if events['caught']:
                if verbose:
                    print(f'\nStep {steps}: CAUGHT by {events["caught_by"]}! '
                          f'Score: {game.score}', flush=True)
                game_over = True
                break

            if events['ate_ghost']:
                if verbose:
                    print(f'Step {steps}: ATE {events["ate_ghost_name"]}! +200',
                          flush=True)

            if events['all_cleared']:
                if verbose:
                    print(f'\nStep {steps}: ALL PELLETS CLEARED! '
                          f'Score: {game.score}', flush=True)
                game_over = True
                break

            if steps >= args.max_steps:
                game_over = True

        chunk_count += 1
        chunks_since_advance += 1

        # ─── Snap-to-closest waypoint after each chunk ─────────
        if wp_chain is not None and len(wp_chain) >= 2:
            n_wp = len(wp_chain)
            best_snap = wp_idx
            best_dist = float(np.linalg.norm(
                obs[:2] - wp_chain[min(wp_idx, n_wp - 1)]))
            for si in range(wp_idx + 1, n_wp):
                d = float(np.linalg.norm(obs[:2] - wp_chain[si]))
                if d < best_dist:
                    best_dist = d
                    best_snap = si
            if best_snap != wp_idx:
                wp_idx = best_snap
                chunks_since_advance = 0

            # If too far from all sub-waypoints, replan to current target cell
            if best_dist > WP_SPACING * 3.0:
                wp_chain = plan_cardinal_waypoints(
                    obs[:2], target_world, spacing=WP_SPACING)
                wp_idx = 1
                chunks_since_advance = 0

        # ASCII render
        if args.render_ascii and chunk_count % args.render_interval == 0:
            print()
            print(render_ascii(game, obs[:2], color=True))

        # Periodic status
        if verbose and chunk_count % 25 == 0 and not game_over:
            ghost_info = '  '.join(
                f'{g.name[0].upper()}({g.row},{g.col})'
                for g in game.ghosts
            )
            plan_remaining = len(cell_plan) - cell_plan_idx
            print(f'Chunk {chunk_count:3d} (step {steps:4d}): '
                  f'Ant ({ant_cell[0]},{ant_cell[1]})  {ghost_info}  '
                  f'Score: {game.score:5d}  '
                  f'Pellets: {game.pellets_remaining:2d}  '
                  f'Plan left: {plan_remaining} cells  '
                  f'Replans: {total_replans}',
                  flush=True)

    # Final result
    outcome = ('cleared' if game.all_pellets_eaten()
               else 'caught' if game._caught
               else 'timeout')

    result = {
        'outcome': outcome,
        'score': game.score,
        'steps': steps,
        'chunks': chunk_count,
        'pellets_eaten': game.pellets_total - game.pellets_remaining,
        'pellets_total': game.pellets_total,
        'ghosts_eaten': game._ghosts_eaten_total,
        'n_ghosts': args.n_ghosts,
        'ghost_move_interval': args.ghost_interval,
        'ant_trail': [xy.tolist() for xy in ant_trail],
        'ghost_trails': {k: v for k, v in ghost_trails.items()},
        'pellet_log': pellet_log,
        'plan_log': plan_log,
        'total_replans': total_replans,
        'mode': getattr(planner, 'mode', 'learned'),
    }

    if verbose:
        print(f'\n=== Game Over: {outcome.upper()} ===')
        print(f'Score: {game.score}  |  Steps: {steps}  |  Chunks: {chunk_count}  |  '
              f'Pellets: {game.pellets_total - game.pellets_remaining}/'
              f'{game.pellets_total}  |  Ghosts eaten: {game._ghosts_eaten_total}  |  '
              f'High-level replans: {total_replans}')

    result['_game'] = game
    return result


# ═════════════════════════════════════════════════════════════════════════
# Main
# ═════════════════════════════════════════════════════════════════════════

def main():
    args = parser.parse_args()

    _init_maze_config(DEFAULT_ENV)

    if args.gpu >= 0 and torch.cuda.is_available():
        device = f'cuda:{args.gpu}'
    else:
        device = 'cpu'

    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(args.seed)

    # ─── Load IWM_low (locomotion) ────────────────────────────────

    iwm_low_path_str = args.iwm_low_path or DEFAULT_IWM_LOW
    iwm_low_path = PROJECT_ROOT / iwm_low_path_str
    if not iwm_low_path.exists():
        print(f'ERROR: IWM_low not found: {iwm_low_path}', file=sys.stderr)
        sys.exit(1)

    print(f'Loading IWM_low from {iwm_low_path}', flush=True)
    navigator, horizon_low, n_params_low = load_iwm_low_navigator(
        iwm_low_path, device)
    print(f'IWM_low: {n_params_low:,} params, horizon={horizon_low}', flush=True)

    # ─── Load IWM_high (strategy) ─────────────────────────────────

    iwm_high_path_str = args.iwm_high_path or DEFAULT_IWM_HIGH
    iwm_high_path = PROJECT_ROOT / iwm_high_path_str
    if not iwm_high_path.exists():
        print(f'ERROR: IWM_high not found: {iwm_high_path}', file=sys.stderr)
        sys.exit(1)

    print(f'Loading IWM_high from {iwm_high_path}', flush=True)
    iwm_high, pos_mean, pos_std, wp_mean, wp_std, model_type_high = load_iwm_high(
        iwm_high_path, device)
    n_params_high = sum(p.numel() for p in iwm_high.parameters())
    print(f'IWM_high: {n_params_high:,} params, horizon={iwm_high.horizon}, '
          f'type={model_type_high}', flush=True)

    planner = HighLevelPlanner(iwm_high, pos_mean, pos_std, wp_mean, wp_std,
                               device)

    # ─── Create MuJoCo env ────────────────────────────────────────

    gym_env = MAZE_CONFIGS[DEFAULT_ENV]['gym_env']
    print(f'Creating MuJoCo env ({gym_env})...', flush=True)
    import gym
    import d4rl  # noqa
    env = gym.make(gym_env)
    env.seed(args.seed)
    print('Env ready', flush=True)

    # ─── Run game ─────────────────────────────────────────────────

    result = run_antman_learned(env, navigator, planner, args,
                                verbose=not args.quiet)

    # ─── Save results ─────────────────────────────────────────────

    if args.save_results or args.save_figure:
        if args.out_dir:
            out_dir = Path(args.out_dir)
        else:
            timestamp = time.strftime('%Y%m%d_%H%M%S')
            out_dir = (PROJECT_ROOT / 'antmaze' / 'antman' / 'runs'
                       / f'learned_{timestamp}')
        out_dir.mkdir(parents=True, exist_ok=True)

        if args.save_results:
            save_result = {k: v for k, v in result.items() if k != '_game'}
            with open(out_dir / 'results.json', 'w') as f:
                json.dump(save_result, f, indent=2)
            print(f'Results saved to {out_dir / "results.json"}', flush=True)

        if args.save_figure:
            import matplotlib
            matplotlib.use('Agg')
            game_obj = result['_game']
            final_xy = np.array(result['ant_trail'][-1])
            trail = [np.array(xy) for xy in result['ant_trail']]
            gt_world = {}
            for gname, cells in result['ghost_trails'].items():
                gt_world[gname] = [
                    game_obj.cell_to_world(r, c).tolist() for r, c in cells
                ]
            render_matplotlib(
                game_obj, final_xy, ant_trail=trail,
                ghost_trails=gt_world,
                save_path=str(out_dir / 'episode_summary.png'),
            )
            print(f'Figure saved to {out_dir / "episode_summary.png"}',
                  flush=True)


if __name__ == '__main__':
    main()
