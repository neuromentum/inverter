"""
AntMan hand-coded strategy controller (Stage A baseline).

Every IWM chunk (8 steps), decides the next target cell:
1. Flee if ghost dangerously close
2. Go for power pellet if tactically useful
3. Otherwise, BFS to nearest uneaten pellet
"""

from collections import deque
from typing import Optional, Tuple

from antmaze.antman.game import AntManGame, GHOST_CATCH_DIST

# Strategy constants
DANGER_RADIUS = 3       # BFS cells — flee if any ghost this close
POWER_SEEK_RADIUS = 5   # BFS cells — consider power pellet if within range


class AntManStrategy:
    """Hand-coded reactive strategy for Stage A."""

    def __init__(self, game: AntManGame,
                 danger_radius: int = DANGER_RADIUS,
                 power_seek_radius: int = POWER_SEEK_RADIUS):
        self.game = game
        self.danger_radius = danger_radius
        self.power_seek_radius = power_seek_radius

    def choose_target_cell(self, ant_cell: Tuple[int, int],
                           ant_heading: Tuple[int, int]
                           ) -> Tuple[Tuple[int, int], str]:
        """Returns ((row, col), reason) for the ant's next waypoint.

        reason is one of: 'flee', 'power', 'chase', 'pellet', 'stay'.

        Priority:
        1. Flee if any ghost within danger_radius (BFS distance)
        2. Seek power pellet if ghost in chase range and power pellet nearby
        3. Chase nearest frightened ghost
        4. BFS to nearest uneaten pellet
        """
        g = self.game

        # Compute BFS distances from ant to all reachable cells (once)
        ant_dists = self._bfs_distances(ant_cell)

        # Find nearest ghost (BFS distance)
        nearest_ghost_dist = float('inf')
        nearest_ghost_cell = None
        for ghost in g.ghosts:
            if ghost.eaten:
                continue
            gc = (ghost.row, ghost.col)
            d = ant_dists.get(gc, float('inf'))
            if d < nearest_ghost_dist:
                nearest_ghost_dist = d
                nearest_ghost_cell = gc

        # 1. FLEE if ghost too close (and not frightened)
        if (nearest_ghost_dist <= self.danger_radius
                and nearest_ghost_cell is not None
                and not self._all_ghosts_frightened()):
            target = self._flee_direction(ant_cell, ant_dists)
            if target is not None:
                return target, 'flee'

        # 2. SEEK POWER PELLET if ghost in chase range and power pellet nearby
        if (nearest_ghost_dist <= self.power_seek_radius
                and nearest_ghost_cell is not None
                and not self._all_ghosts_frightened()):
            power_target = self._nearest_power_pellet(ant_cell, ant_dists)
            if power_target is not None:
                return power_target, 'power'

        # 3. If frightened ghosts exist, chase the nearest one
        if g.fright_remaining > 0:
            chase_target = self._nearest_frightened_ghost(ant_cell, ant_dists)
            if chase_target is not None:
                return chase_target, 'chase'

        # 4. Default: BFS to nearest uneaten pellet
        target = self._nearest_pellet(ant_cell, ant_dists)
        if target is not None:
            return target, 'pellet'

        # Fallback: stay put (all pellets eaten or unreachable)
        return ant_cell, 'stay'

    # ─── BFS utilities ─────────────────────────────────────────────

    def _bfs_distances(self, src):
        """BFS from src, return dict {(r,c): distance}."""
        dists = {src: 0}
        queue = deque([src])
        while queue:
            r, c = queue.popleft()
            d = dists[(r, c)]
            for nr, nc in self.game.get_neighbors(r, c):
                if (nr, nc) not in dists:
                    dists[(nr, nc)] = d + 1
                    queue.append((nr, nc))
        return dists

    def _nearest_pellet(self, ant_cell, ant_dists):
        """Find nearest uneaten pellet by BFS distance."""
        best_dist = float('inf')
        best_cell = None
        for p in self.game.pellets:
            if p.eaten:
                continue
            pc = (p.row, p.col)
            d = ant_dists.get(pc, float('inf'))
            if d < best_dist:
                best_dist = d
                best_cell = pc
        return best_cell

    def _nearest_power_pellet(self, ant_cell, ant_dists):
        """Find nearest uneaten power pellet within seek radius."""
        best_dist = float('inf')
        best_cell = None
        for p in self.game.pellets:
            if p.eaten or not p.is_power:
                continue
            pc = (p.row, p.col)
            d = ant_dists.get(pc, float('inf'))
            if d < best_dist and d <= self.power_seek_radius:
                best_dist = d
                best_cell = pc
        return best_cell

    def _nearest_frightened_ghost(self, ant_cell, ant_dists):
        """Find nearest frightened (non-eaten) ghost to chase."""
        best_dist = float('inf')
        best_cell = None
        for ghost in self.game.ghosts:
            if ghost.eaten or not ghost.frightened:
                continue
            gc = (ghost.row, ghost.col)
            d = ant_dists.get(gc, float('inf'))
            if d < best_dist:
                best_dist = d
                best_cell = gc
        return best_cell

    def _flee_direction(self, ant_cell, ant_dists):
        """Find the reachable cell within ~4 cells that maximizes distance
        from the nearest ghost.

        Strategy: BFS from ant up to depth 4. For each candidate, compute
        minimum distance to any active ghost. Pick the candidate with the
        highest min-ghost-distance.
        """
        g = self.game
        flee_depth = 4

        # Gather ghost positions
        ghost_cells = []
        for ghost in g.ghosts:
            if not ghost.eaten and not ghost.frightened:
                ghost_cells.append((ghost.row, ghost.col))
        if not ghost_cells:
            return None

        # BFS from each ghost to get ghost distance maps
        ghost_dists_maps = []
        for gc in ghost_cells:
            ghost_dists_maps.append(self._bfs_distances(gc))

        # Evaluate candidates reachable within flee_depth
        best_min_ghost_dist = -1
        best_cell = None
        for cell, ant_d in ant_dists.items():
            if ant_d > flee_depth:
                continue
            # Min distance from this cell to any ghost
            min_gd = float('inf')
            for gdm in ghost_dists_maps:
                gd = gdm.get(cell, float('inf'))
                min_gd = min(min_gd, gd)
            if min_gd > best_min_ghost_dist:
                best_min_ghost_dist = min_gd
                best_cell = cell

        return best_cell

    def _all_ghosts_frightened(self):
        """True if all active ghosts are frightened."""
        for ghost in self.game.ghosts:
            if not ghost.eaten and not ghost.frightened:
                return False
        return True
