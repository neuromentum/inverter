#!/usr/bin/env python3
"""
Generate FM training data with configurable symbolic controllers.

Default mode is the original 100% random-walk strategy: at each step the ant
picks a uniform-random neighbour cell. The same pipeline can also roll out a
hand-coded heuristic Pacman controller while keeping the mixed-condition 58D
dataset format identical.

Output: <out_dir>/data.npz  (same format as game_fm_data_v3)
    game_states : (N, H+1, 55)
    waypoints   : (N, H, 2)
    alive       : (N, H+1)

Usage:
    python -u antmaze/antman/sim/generate_random_data.py \
        --config antmaze/antman/sim/configs/random_15k.json
    # or override individual args:
    python -u antmaze/antman/sim/generate_random_data.py \
        --n_games 15000 --horizon 32 --n_ghosts 1 --ghost_interval 2
"""

import os, sys, argparse, json, time, random
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent.parent))

# ─── Imports from shared game code ──────────────────────────────────────

from antmaze.antman.game import AntManGame, FRIGHT_DURATION
from antmaze.antman.game_state import (
    MAZE_MAP, SCALING, TORSO_X, TORSO_Y,
    OPEN_CELLS, N_CELLS, CELL_TO_IDX, CELL_NEIGHBORS,
    WAYPOINTS, GAME_STATE_DIM, LEGACY_GAME_STATE_DIM,
    cell_to_world, snap_to_nearest_cell,
    encode_game_state, get_state_layout,
)
from antmaze.antman.strategy import AntManStrategy

# ═══════════════════════════════════════════════════════════════════════
# Ant start cells (same as data-v3)
# ═══════════════════════════════════════════════════════════════════════

ANT_START_CELLS = [
    (1, 1), (1, 4), (1, 6), (1, 10),
    (3, 1), (3, 3), (3, 6), (3, 10),
    (5, 1), (5, 4), (5, 8), (5, 10),
    (7, 1), (7, 5), (7, 9),
]

STATE_FORMAT_TO_DIM = {
    'ghost_mask58': GAME_STATE_DIM,
    'legacy55': LEGACY_GAME_STATE_DIM,
}

DIFFICULTY_PRESETS = {
    'none': {
        'n_ghosts': 0,
        'ghost_interval': 999,
        'max_steps': 6000,
        'label': 'No ghosts',
    },
    'easy': {
        'n_ghosts': 1,
        'ghost_interval': 200,
        'max_steps': 6000,
        'label': '1 ghost (slow)',
    },
    'medium': {
        'n_ghosts': 2,
        'ghost_interval': 100,
        'max_steps': 5000,
        'label': '2 ghosts (medium)',
    },
    'hard': {
        'n_ghosts': 3,
        'ghost_interval': 50,
        'max_steps': 4000,
        'label': '3 ghosts (fast)',
    },
}

DIFFICULTY_TO_ID = {name: idx for idx, name in enumerate(DIFFICULTY_PRESETS)}

CONTROLLER_DESCRIPTIONS = {
    'random_neighbor': 'uniform random neighboring cell',
    'heuristic_pacman': 'hand-coded BFS Pacman controller (flee/power/chase/pellet)',
}


def normalize_difficulty_mix(raw_value):
    if raw_value is None:
        return []
    if isinstance(raw_value, str):
        items = [item.strip() for item in raw_value.split(',') if item.strip()]
    else:
        items = [str(item).strip() for item in raw_value if str(item).strip()]
    for item in items:
        if item not in DIFFICULTY_PRESETS:
            raise ValueError(
                f'Unknown difficulty "{item}". '
                f'Expected one of: {", ".join(DIFFICULTY_PRESETS)}'
            )
    return items


def build_game_schedule(n_games, difficulty_mix, n_ghosts, ghost_interval,
                        max_steps, rng):
    if difficulty_mix:
        names = []
        full_repeats, remainder = divmod(n_games, len(difficulty_mix))
        for _ in range(full_repeats):
            names.extend(difficulty_mix)
        names.extend(difficulty_mix[:remainder])
        rng.shuffle(names)
        return [
            {
                'condition': name,
                **DIFFICULTY_PRESETS[name],
            }
            for name in names
        ]

    return [
        {
            'condition': 'custom',
            'n_ghosts': n_ghosts,
            'ghost_interval': ghost_interval,
            'max_steps': max_steps,
            'label': f'{n_ghosts} ghosts / interval {ghost_interval}',
        }
        for _ in range(n_games)
    ]


# ═══════════════════════════════════════════════════════════════════════
# Simulation
# ═══════════════════════════════════════════════════════════════════════

def choose_random_neighbor_cell(ant_cell, rng):
    idx = CELL_TO_IDX.get(ant_cell)
    if idx is not None and CELL_NEIGHBORS[idx]:
        return OPEN_CELLS[rng.choice(CELL_NEIGHBORS[idx])]
    return ant_cell


def choose_heuristic_pacman_cell(game, ant_cell, ant_heading, strategy):
    target_cell, _reason = strategy.choose_target_cell(ant_cell, ant_heading)
    if target_cell == ant_cell:
        return ant_cell

    path = game.bfs_path(ant_cell, target_cell)
    if path is not None and len(path) > 1:
        return path[1]
    return ant_cell


def simulate_game_controlled(n_ghosts, ghost_move_interval, max_steps, rng,
                             return_summary=False, state_dim=GAME_STATE_DIM,
                             controller='random_neighbor'):
    """Run one cell-level game with the requested symbolic controller.

    When return_summary=True, also returns a dict with outcome/score/game stats.
    """
    if controller not in CONTROLLER_DESCRIPTIONS:
        raise ValueError(
            f'Unknown controller "{controller}". '
            f'Expected one of: {", ".join(sorted(CONTROLLER_DESCRIPTIONS))}'
        )

    game = AntManGame(MAZE_MAP, SCALING, TORSO_X, TORSO_Y,
                      n_ghosts=n_ghosts,
                      ghost_move_interval=ghost_move_interval,
                      max_steps=max_steps)
    game.reset()

    ant_cell = rng.choice(ANT_START_CELLS)
    while ant_cell not in set(OPEN_CELLS):
        ant_cell = rng.choice(list(OPEN_CELLS))
    ant_xy = cell_to_world(*ant_cell)
    ant_heading = (0, 1)
    strategy = AntManStrategy(game) if controller == 'heuristic_pacman' else None

    states = []
    waypoints = []
    alive_flags = []

    for step in range(max_steps):
        state_vec = encode_game_state(game, ant_xy, state_dim=state_dim)
        states.append(state_vec)
        alive_flags.append(True)

        if controller == 'random_neighbor':
            new_cell = choose_random_neighbor_cell(ant_cell, rng)
        else:
            new_cell = choose_heuristic_pacman_cell(
                game, ant_cell, ant_heading, strategy
            )

        waypoint_xy = cell_to_world(*new_cell)
        waypoints.append(waypoint_xy)

        dr = new_cell[0] - ant_cell[0]
        dc = new_cell[1] - ant_cell[1]
        if dr != 0 or dc != 0:
            ant_heading = (dr, dc)

        ant_cell = new_cell
        ant_xy = cell_to_world(*ant_cell)

        events = game.tick(ant_xy,
                           np.array([ant_heading[1], ant_heading[0]],
                                    dtype=np.float32),
                           step)

        if events['caught']:
            states.append(encode_game_state(game, ant_xy, state_dim=state_dim))
            alive_flags.append(False)
            break

        if events['all_cleared'] or game.is_over():
            states.append(encode_game_state(game, ant_xy, state_dim=state_dim))
            alive_flags.append(True)
            break

    # Timeout paths fall off the loop without appending the post-action state.
    # Keep episode tensors aligned as (T+1) states / alive flags for T actions.
    if len(states) == len(waypoints):
        states.append(encode_game_state(game, ant_xy, state_dim=state_dim))
        alive_flags.append(True)

    if len(states) != len(waypoints) + 1 or len(alive_flags) != len(states):
        raise ValueError(
            'Episode tensors are misaligned: '
            f'states={len(states)} waypoints={len(waypoints)} '
            f'alive={len(alive_flags)}'
        )

    pellet_slice = get_state_layout(state_dim)['pellets']
    initial_pellets = int(sum(1 for p in states[0][pellet_slice] if p > 0.5))
    final_pellets = int(sum(1 for p in states[-1][pellet_slice] if p > 0.5))
    pellets_eaten = initial_pellets - final_pellets
    if not alive_flags[-1]:
        outcome = 'caught'
    elif final_pellets == 0:
        outcome = 'cleared'
    else:
        outcome = 'timeout'

    summary = {
        'controller': controller,
        'outcome': outcome,
        'score': int(game.score),
        'steps': int(len(waypoints)),
        'pellets_eaten': int(pellets_eaten),
        'pellets_total': int(initial_pellets),
        'ghosts_eaten': int(game._ghosts_eaten_total),
        'n_ghosts': int(n_ghosts),
        'ghost_move_interval': int(ghost_move_interval),
        'max_steps': int(max_steps),
    }

    if return_summary:
        return states, waypoints, alive_flags, summary
    return states, waypoints, alive_flags


def simulate_game_random(n_ghosts, ghost_move_interval, max_steps, rng,
                         return_summary=False, state_dim=GAME_STATE_DIM):
    """Backward-compatible wrapper for the original random controller."""
    return simulate_game_controlled(
        n_ghosts=n_ghosts,
        ghost_move_interval=ghost_move_interval,
        max_steps=max_steps,
        rng=rng,
        return_summary=return_summary,
        state_dim=state_dim,
        controller='random_neighbor',
    )


def chunk_episode(states, waypoints, alive_flags, horizon, stride):
    """Split episode into overlapping chunks of length H."""
    if len(states) != len(waypoints) + 1 or len(alive_flags) != len(states):
        raise ValueError(
            'Chunk source episode is misaligned: '
            f'states={len(states)} waypoints={len(waypoints)} '
            f'alive={len(alive_flags)}'
        )

    T = len(waypoints)
    chunks_s, chunks_wp, chunks_a = [], [], []

    for start in range(0, T - horizon + 1, stride):
        end = start + horizon
        cs = np.array(states[start:end + 1], dtype=np.float32)
        cw = np.array(waypoints[start:end], dtype=np.float32)
        ca = np.array(alive_flags[start:end + 1], dtype=np.float32)
        if cs.shape[0] != horizon + 1 or cw.shape[0] != horizon or ca.shape[0] != horizon + 1:
            raise ValueError(
                'Malformed chunk shapes: '
                f'states={cs.shape} waypoints={cw.shape} alive={ca.shape} '
                f'for start={start} horizon={horizon}'
            )
        chunks_s.append(cs)
        chunks_wp.append(cw)
        chunks_a.append(ca)

    return chunks_s, chunks_wp, chunks_a


# ═══════════════════════════════════════════════════════════════════════
# Plots & statistics
# ═══════════════════════════════════════════════════════════════════════

def save_plots(game_states, alive_arr, out_dir, n_games, total_caught,
               per_game_steps, per_game_pellets):
    """Save descriptive plots to <out_dir>/plots/."""
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    plot_dir = out_dir / 'plots'
    plot_dir.mkdir(exist_ok=True)

    # 1. Pellets-eaten-per-game distribution
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.hist(per_game_pellets, bins=50, edgecolor='black', alpha=0.75)
    ax.set_xlabel('Pellets eaten per game')
    ax.set_ylabel('Count')
    ax.set_title(f'Pellets-eaten distribution  (mean={np.mean(per_game_pellets):.1f})')
    ax.axvline(np.mean(per_game_pellets), color='red', ls='--', label='mean')
    ax.legend()
    fig.tight_layout()
    fig.savefig(plot_dir / 'pellets_eaten_dist.png', dpi=120)
    plt.close(fig)

    # 2. Game length distribution
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.hist(per_game_steps, bins=50, edgecolor='black', alpha=0.75)
    ax.set_xlabel('Steps per game')
    ax.set_ylabel('Count')
    ax.set_title(f'Game-length distribution  (mean={np.mean(per_game_steps):.1f})')
    ax.axvline(np.mean(per_game_steps), color='red', ls='--', label='mean')
    ax.legend()
    fig.tight_layout()
    fig.savefig(plot_dir / 'game_length_dist.png', dpi=120)
    plt.close(fig)

    # 3. Survival rate over time (fraction alive at each step within chunks)
    alive_mean = alive_arr.mean(axis=0)  # (H+1,)
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.plot(alive_mean, marker='o', markersize=3)
    ax.set_xlabel('In-chunk step')
    ax.set_ylabel('Fraction alive')
    ax.set_title('Survival rate within chunks')
    ax.set_ylim(0, 1.05)
    fig.tight_layout()
    fig.savefig(plot_dir / 'survival_in_chunk.png', dpi=120)
    plt.close(fig)

    # 4. Per-chunk pellet gain distribution
    pellet_slice = get_state_layout(game_states.shape[-1])['pellets']
    pellet_counts = game_states[:, :, pellet_slice].sum(axis=-1)  # (N, H+1)
    pellet_gain = pellet_counts[:, 0] - pellet_counts[:, -1]
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.hist(pellet_gain, bins=range(int(pellet_gain.min()),
            int(pellet_gain.max()) + 2), edgecolor='black', alpha=0.75)
    ax.set_xlabel('Pellets eaten per chunk')
    ax.set_ylabel('Count')
    ax.set_title(f'Per-chunk pellet gain  (mean={pellet_gain.mean():.2f})')
    ax.axvline(pellet_gain.mean(), color='red', ls='--', label='mean')
    ax.legend()
    fig.tight_layout()
    fig.savefig(plot_dir / 'chunk_pellet_gain.png', dpi=120)
    plt.close(fig)

    # 5. Caught-vs-survived pie chart
    fig, ax = plt.subplots(figsize=(5, 5))
    survived = n_games - total_caught
    ax.pie([survived, total_caught],
           labels=[f'Survived ({survived})', f'Caught ({total_caught})'],
           autopct='%1.1f%%', colors=['#4CAF50', '#F44336'])
    ax.set_title('Game outcomes')
    fig.tight_layout()
    fig.savefig(plot_dir / 'outcomes_pie.png', dpi=120)
    plt.close(fig)

    print(f'Plots saved to {plot_dir}/')


# ═══════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description='Generate AntMan FM data with symbolic controllers')
    parser.add_argument('--config', type=str, default=None,
                        help='Path to config.json (overrides below defaults)')
    parser.add_argument('--n_games', type=int, default=15000)
    parser.add_argument('--horizon', type=int, default=32)
    parser.add_argument('--stride', type=int, default=None,
                        help='Chunk stride (default: horizon//4)')
    parser.add_argument('--n_ghosts', type=int, default=1)
    parser.add_argument('--ghost_interval', type=int, default=2)
    parser.add_argument('--difficulty_mix', type=str, default='',
                        help='Comma-separated condition mix, e.g. none,easy,medium,hard')
    parser.add_argument('--controller', type=str, default='random_neighbor',
                        choices=sorted(CONTROLLER_DESCRIPTIONS),
                        help='Symbolic controller used to pick the next cell')
    parser.add_argument('--state_format', type=str, default='ghost_mask58',
                        choices=sorted(STATE_FORMAT_TO_DIM),
                        help='Output state layout: legacy55 or ghost_mask58')
    parser.add_argument('--max_steps', type=int, default=3000)
    parser.add_argument('--out_dir', type=str, default=None)
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--no_plots', action='store_true')
    args = parser.parse_args()

    # Load config file if provided (CLI args override)
    if args.config is not None:
        with open(args.config) as f:
            cfg = json.load(f)
        for k, v in cfg.items():
            if not hasattr(args, k):
                continue
            # CLI-provided args override config
            if k in sys.argv:
                continue
            # Check if user passed --<k> on CLI
            cli_flag = f'--{k}'
            if cli_flag not in sys.argv:
                setattr(args, k, v)

    # Default output dir with timestamp
    if args.out_dir is None:
        ts = time.strftime('%Y%m%d_%H%M%S')
        prefix = 'random' if args.controller == 'random_neighbor' else args.controller
        args.out_dir = f'antmaze/antman/sim/{prefix}_{args.n_games // 1000}k_{ts}'

    stride = args.stride if args.stride is not None else max(1, args.horizon // 4)
    difficulty_mix = normalize_difficulty_mix(args.difficulty_mix)
    state_dim = STATE_FORMAT_TO_DIM[args.state_format]

    random.seed(args.seed)
    np.random.seed(args.seed)

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # Save config
    config = {
        'n_games': args.n_games,
        'horizon': args.horizon,
        'stride': stride,
        'n_ghosts': args.n_ghosts,
        'ghost_interval': args.ghost_interval,
        'difficulty_mix': difficulty_mix,
        'controller': args.controller,
        'controller_description': CONTROLLER_DESCRIPTIONS[args.controller],
        'condition_id_map': {
            'custom': -1,
            **DIFFICULTY_TO_ID,
        },
        'difficulty_presets': {name: DIFFICULTY_PRESETS[name] for name in difficulty_mix},
        'max_steps': args.max_steps,
        'seed': args.seed,
        'strategy': CONTROLLER_DESCRIPTIONS[args.controller],
        'timestamp': time.strftime('%Y%m%d_%H%M%S'),
        'game_state_dim': state_dim,
        'state_format': args.state_format,
        'n_cells': N_CELLS,
    }
    with open(out_dir / 'config.json', 'w') as f:
        json.dump(config, f, indent=2)

    # ─── Generate ───────────────────────────────────────────────────

    all_states = []
    all_waypoints = []
    all_alive = []

    total_chunks = 0
    total_steps = 0
    total_caught = 0
    total_cleared = 0
    per_game_steps = []
    per_game_pellets = []
    chunks_condition_ids = []
    games_per_condition = {}
    chunks_per_condition = {}

    t0 = time.time()
    rng = random.Random(args.seed)
    game_schedule = build_game_schedule(
        args.n_games,
        difficulty_mix,
        args.n_ghosts,
        args.ghost_interval,
        args.max_steps,
        rng,
    )
    pellet_slice = get_state_layout(state_dim)['pellets']

    for game_i, game_cfg in enumerate(game_schedule):
        condition_name = game_cfg['condition']
        games_per_condition[condition_name] = games_per_condition.get(condition_name, 0) + 1

        states, waypoints, alive_flags = simulate_game_controlled(
            n_ghosts=game_cfg['n_ghosts'],
            ghost_move_interval=game_cfg['ghost_interval'],
            max_steps=game_cfg['max_steps'],
            rng=rng,
            state_dim=state_dim,
            controller=args.controller,
        )

        n_steps = len(waypoints)
        total_steps += n_steps
        per_game_steps.append(n_steps)

        # Count pellets eaten: initial bitmap vs final
        initial_pellets = sum(1 for p in states[0][pellet_slice] if p > 0.5)
        final_pellets = sum(1 for p in states[-1][pellet_slice] if p > 0.5)
        pel_eaten = initial_pellets - final_pellets
        per_game_pellets.append(pel_eaten)

        if not alive_flags[-1]:
            total_caught += 1
        if final_pellets == 0:
            total_cleared += 1

        cs, cw, ca = chunk_episode(states, waypoints, alive_flags,
                                    args.horizon, stride)
        all_states.extend(cs)
        all_waypoints.extend(cw)
        all_alive.extend(ca)
        chunks_per_condition[condition_name] = (
            chunks_per_condition.get(condition_name, 0) + len(cs)
        )
        condition_id = DIFFICULTY_TO_ID.get(condition_name, -1)
        chunks_condition_ids.extend([condition_id] * len(cs))
        total_chunks += len(cs)

        if (game_i + 1) % 500 == 0 or game_i == 0:
            elapsed = time.time() - t0
            rate = (game_i + 1) / elapsed
            eta = (args.n_games - game_i - 1) / rate if rate > 0 else 0
            print(f'[{game_i+1}/{args.n_games}] chunks={total_chunks:,}  '
                  f'steps={total_steps:,}  caught={total_caught}  '
                  f'cleared={total_cleared}  '
                  f'{rate:.1f} games/s  ETA {eta:.0f}s')

    elapsed = time.time() - t0

    # ─── Stack and save ─────────────────────────────────────────────

    print(f'\nStacking {total_chunks:,} chunks...')
    game_states = np.stack(all_states, axis=0).astype(np.float32, copy=False)
    waypoints_arr = np.stack(all_waypoints, axis=0).astype(np.float32, copy=False)
    alive_arr = np.stack(all_alive, axis=0).astype(np.float32, copy=False)
    condition_id_arr = np.array(chunks_condition_ids, dtype=np.int16)

    out_path = out_dir / 'data.npz'
    np.savez_compressed(out_path,
                        game_states=game_states,
                        waypoints=waypoints_arr,
                        alive=alive_arr,
                        condition_id=condition_id_arr)

    file_size_mb = out_path.stat().st_size / 1e6

    # ─── Summary ────────────────────────────────────────────────────

    per_game_steps = np.array(per_game_steps)
    per_game_pellets = np.array(per_game_pellets)

    summary = {
        'n_games': args.n_games,
        'controller': args.controller,
        'n_chunks': total_chunks,
        'total_steps': total_steps,
        'avg_steps_per_game': round(total_steps / args.n_games, 1),
        'games_caught': total_caught,
        'caught_pct': round(100 * total_caught / args.n_games, 1),
        'games_cleared': total_cleared,
        'avg_pellets_eaten': round(float(per_game_pellets.mean()), 2),
        'median_pellets_eaten': round(float(np.median(per_game_pellets)), 1),
        'avg_game_length': round(float(per_game_steps.mean()), 1),
        'game_states_shape': list(game_states.shape),
        'waypoints_shape': list(waypoints_arr.shape),
        'alive_shape': list(alive_arr.shape),
        'condition_id_shape': list(condition_id_arr.shape),
        'games_per_condition': games_per_condition,
        'chunks_per_condition': chunks_per_condition,
        'file_size_mb': round(file_size_mb, 1),
        'elapsed_s': round(elapsed, 1),
        'has_nan': bool(np.isnan(game_states).any()),
        'has_inf': bool(np.isinf(game_states).any()),
    }
    with open(out_dir / 'summary.json', 'w') as f:
        json.dump(summary, f, indent=2)

    print(f'\n=== AntMan Data Generation Complete ===')
    print(f'Controller: {args.controller} ({CONTROLLER_DESCRIPTIONS[args.controller]})')
    print(f'Games:   {args.n_games:,}')
    print(f'Chunks:  {total_chunks:,}')
    print(f'Steps:   {total_steps:,} (avg {total_steps/args.n_games:.1f}/game)')
    print(f'Caught:  {total_caught} ({100*total_caught/args.n_games:.1f}%)')
    print(f'Cleared: {total_cleared} ({100*total_cleared/args.n_games:.1f}%)')
    print(f'Pellets: mean={per_game_pellets.mean():.1f}, '
          f'median={np.median(per_game_pellets):.1f}, '
          f'max={per_game_pellets.max()}')
    print(f'Shapes:  states={game_states.shape}, '
          f'waypoints={waypoints_arr.shape}, alive={alive_arr.shape}')
    print(f'File:    {out_path} ({file_size_mb:.1f} MB)')
    print(f'Time:    {elapsed:.1f}s')

    # ─── Validation ─────────────────────────────────────────────────

    print(f'\n--- Validation ---')
    pellet_counts = game_states[:, :, 9:9 + N_CELLS].sum(axis=-1)
    diffs = np.diff(pellet_counts, axis=1)
    increases = (diffs > 0.5).sum()
    print(f'Pellet increases (should be 0): {increases}')

    alive_diffs = np.diff(alive_arr, axis=1)
    resurrections = (alive_diffs > 0.5).sum()
    print(f'Resurrections (should be 0): {resurrections}')

    avg_chunk_gain = (pellet_counts[:, 0] - pellet_counts[:, -1]).mean()
    print(f'Avg pellet gain per chunk: {avg_chunk_gain:.2f}')
    print(f'NaN: {summary["has_nan"]}, Inf: {summary["has_inf"]}')

    # ─── Plots ──────────────────────────────────────────────────────

    if not args.no_plots:
        save_plots(game_states, alive_arr, out_dir, args.n_games,
                   total_caught, per_game_steps, per_game_pellets)


if __name__ == '__main__':
    main()
