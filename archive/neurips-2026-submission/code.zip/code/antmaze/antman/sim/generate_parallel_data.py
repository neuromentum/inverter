#!/usr/bin/env python3
"""Parallel AntMan FM-data generation with configurable symbolic controllers.

Workers generate fixed-size batches of games into compressed shard files. The
main process merges those shards into the standard final `data.npz` artifact,
then runs the same summary, validation, and plot steps used by the serial
generator.
"""

import os

os.environ.setdefault('OMP_NUM_THREADS', '1')
os.environ.setdefault('MKL_NUM_THREADS', '1')
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('NUMEXPR_NUM_THREADS', '1')

import sys
import argparse
import json
import time
import random
import shutil
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import numpy as np
from numpy.lib.format import open_memmap

PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT))

from antmaze.antman.game_state import get_state_layout
from antmaze.antman.sim.generate_random_data import (
    CONTROLLER_DESCRIPTIONS,
    DIFFICULTY_PRESETS,
    DIFFICULTY_TO_ID,
    N_CELLS,
    STATE_FORMAT_TO_DIM,
    build_game_schedule,
    chunk_episode,
    normalize_difficulty_mix,
    save_plots,
    simulate_game_controlled,
)


def _merge_counts(dst, src):
    for key, value in src.items():
        dst[key] = dst.get(key, 0) + int(value)


def _simulate_batch(batch_idx, game_schedule, horizon, stride, state_dim,
                    controller, seed, shard_dir):
    """Generate one shard worth of games and save it to disk."""
    rng = random.Random(seed)
    pellet_slice = get_state_layout(state_dim)['pellets']

    all_states = []
    all_waypoints = []
    all_alive = []
    chunks_condition_ids = []

    total_chunks = 0
    total_steps = 0
    total_caught = 0
    total_cleared = 0
    per_game_steps = []
    per_game_pellets = []
    games_per_condition = {}
    chunks_per_condition = {}

    for game_cfg in game_schedule:
        condition_name = game_cfg['condition']
        games_per_condition[condition_name] = games_per_condition.get(condition_name, 0) + 1

        states, waypoints, alive_flags = simulate_game_controlled(
            n_ghosts=game_cfg['n_ghosts'],
            ghost_move_interval=game_cfg['ghost_interval'],
            max_steps=game_cfg['max_steps'],
            rng=rng,
            state_dim=state_dim,
            controller=controller,
        )

        n_steps = len(waypoints)
        total_steps += n_steps
        per_game_steps.append(n_steps)

        initial_pellets = sum(1 for value in states[0][pellet_slice] if value > 0.5)
        final_pellets = sum(1 for value in states[-1][pellet_slice] if value > 0.5)
        pel_eaten = initial_pellets - final_pellets
        per_game_pellets.append(pel_eaten)

        if not alive_flags[-1]:
            total_caught += 1
        if final_pellets == 0:
            total_cleared += 1

        cs, cw, ca = chunk_episode(states, waypoints, alive_flags, horizon, stride)
        all_states.extend(cs)
        all_waypoints.extend(cw)
        all_alive.extend(ca)

        chunks_per_condition[condition_name] = (
            chunks_per_condition.get(condition_name, 0) + len(cs)
        )
        condition_id = DIFFICULTY_TO_ID.get(condition_name, -1)
        chunks_condition_ids.extend([condition_id] * len(cs))
        total_chunks += len(cs)

    if total_chunks > 0:
        game_states = np.stack(all_states, axis=0).astype(np.float32, copy=False)
        waypoints_arr = np.stack(all_waypoints, axis=0).astype(np.float32, copy=False)
        alive_arr = np.stack(all_alive, axis=0).astype(np.float32, copy=False)
        condition_id_arr = np.array(chunks_condition_ids, dtype=np.int16)
    else:
        game_states = np.empty((0, horizon + 1, state_dim), dtype=np.float32)
        waypoints_arr = np.empty((0, horizon, 2), dtype=np.float32)
        alive_arr = np.empty((0, horizon + 1), dtype=np.float32)
        condition_id_arr = np.empty((0,), dtype=np.int16)

    shard_path = Path(shard_dir) / f'shard_{batch_idx:05d}.npz'
    np.savez_compressed(
        shard_path,
        game_states=game_states,
        waypoints=waypoints_arr,
        alive=alive_arr,
        condition_id=condition_id_arr,
    )

    return {
        'batch_idx': batch_idx,
        'shard_path': str(shard_path),
        'n_games': len(game_schedule),
        'n_chunks': total_chunks,
        'total_steps': total_steps,
        'total_caught': total_caught,
        'total_cleared': total_cleared,
        'per_game_steps': per_game_steps,
        'per_game_pellets': per_game_pellets,
        'games_per_condition': games_per_condition,
        'chunks_per_condition': chunks_per_condition,
    }


def _cleanup_parallel_artifacts(out_dir):
    shutil.rmtree(out_dir / 'shards', ignore_errors=True)
    for path in [
        out_dir / 'data.npz',
        out_dir / 'summary.json',
        out_dir / '_game_states.npy',
        out_dir / '_waypoints.npy',
        out_dir / '_alive.npy',
        out_dir / '_condition_id.npy',
    ]:
        if path.exists():
            path.unlink()


def _merge_shards(shard_results, out_dir, horizon, state_dim, keep_shards):
    total_chunks = sum(result['n_chunks'] for result in shard_results)
    states_path = out_dir / '_game_states.npy'
    waypoints_path = out_dir / '_waypoints.npy'
    alive_path = out_dir / '_alive.npy'
    cond_path = out_dir / '_condition_id.npy'

    if total_chunks > 0:
        states_mm = open_memmap(
            states_path, mode='w+', dtype=np.float32,
            shape=(total_chunks, horizon + 1, state_dim),
        )
        waypoints_mm = open_memmap(
            waypoints_path, mode='w+', dtype=np.float32,
            shape=(total_chunks, horizon, 2),
        )
        alive_mm = open_memmap(
            alive_path, mode='w+', dtype=np.float32,
            shape=(total_chunks, horizon + 1),
        )
        cond_mm = open_memmap(
            cond_path, mode='w+', dtype=np.int16,
            shape=(total_chunks,),
        )

        cursor = 0
        n_shards = len(shard_results)
        for idx, result in enumerate(sorted(shard_results, key=lambda item: item['batch_idx']), start=1):
            with np.load(result['shard_path']) as shard:
                count = shard['condition_id'].shape[0]
                if count > 0:
                    states_mm[cursor:cursor + count] = shard['game_states']
                    waypoints_mm[cursor:cursor + count] = shard['waypoints']
                    alive_mm[cursor:cursor + count] = shard['alive']
                    cond_mm[cursor:cursor + count] = shard['condition_id']
                cursor += count
            if not keep_shards:
                Path(result['shard_path']).unlink(missing_ok=True)
            if idx % 25 == 0 or idx == n_shards:
                print(f'  merged {idx}/{n_shards} shards', flush=True)

        del states_mm
        del waypoints_mm
        del alive_mm
        del cond_mm
    else:
        np.save(states_path, np.empty((0, horizon + 1, state_dim), dtype=np.float32))
        np.save(waypoints_path, np.empty((0, horizon, 2), dtype=np.float32))
        np.save(alive_path, np.empty((0, horizon + 1), dtype=np.float32))
        np.save(cond_path, np.empty((0,), dtype=np.int16))

    game_states = np.load(states_path, mmap_mode='r')
    waypoints_arr = np.load(waypoints_path, mmap_mode='r')
    alive_arr = np.load(alive_path, mmap_mode='r')
    condition_id_arr = np.load(cond_path, mmap_mode='r')
    return game_states, waypoints_arr, alive_arr, condition_id_arr


def main():
    parser = argparse.ArgumentParser(description='Parallel AntMan FM-data generation')
    parser.add_argument('--config', type=str, default=None,
                        help='Path to config.json (overrides below defaults)')
    parser.add_argument('--n_games', type=int, default=15000)
    parser.add_argument('--horizon', type=int, default=32)
    parser.add_argument('--stride', type=int, default=None,
                        help='Chunk stride (default: horizon//4)')
    parser.add_argument('--n_ghosts', type=int, default=1)
    parser.add_argument('--ghost_interval', type=int, default=2)
    parser.add_argument('--difficulty_mix', type=str, default='',
                        help='Comma-separated condition mix, e.g. none,easy,medium,hard')
    parser.add_argument('--controller', type=str, default='random_neighbor',
                        choices=sorted(CONTROLLER_DESCRIPTIONS),
                        help='Symbolic controller used to pick the next cell')
    parser.add_argument('--state_format', type=str, default='ghost_mask58',
                        choices=sorted(STATE_FORMAT_TO_DIM),
                        help='Output state layout: legacy55 or ghost_mask58')
    parser.add_argument('--max_steps', type=int, default=3000)
    parser.add_argument('--out_dir', type=str, default=None)
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--num_workers', type=int, default=8)
    parser.add_argument('--games_per_shard', type=int, default=250)
    parser.add_argument('--keep_shards', action='store_true')
    parser.add_argument('--no_plots', action='store_true')
    args = parser.parse_args()

    if args.config is not None:
        with open(args.config) as f:
            cfg = json.load(f)
        for key, value in cfg.items():
            cli_flag = f'--{key}'
            if hasattr(args, key) and cli_flag not in sys.argv:
                setattr(args, key, value)

    if args.out_dir is None:
        ts = time.strftime('%Y%m%d_%H%M%S')
        prefix = 'random' if args.controller == 'random_neighbor' else args.controller
        args.out_dir = f'antmaze/antman/sim/{prefix}_{args.n_games // 1000}k_{ts}'

    stride = args.stride if args.stride is not None else max(1, args.horizon // 4)
    difficulty_mix = normalize_difficulty_mix(args.difficulty_mix)
    state_dim = STATE_FORMAT_TO_DIM[args.state_format]
    num_workers = max(1, int(args.num_workers))
    games_per_shard = max(1, int(args.games_per_shard))

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    _cleanup_parallel_artifacts(out_dir)
    shard_dir = out_dir / 'shards'
    shard_dir.mkdir(parents=True, exist_ok=True)

    config = {
        'n_games': args.n_games,
        'horizon': args.horizon,
        'stride': stride,
        'n_ghosts': args.n_ghosts,
        'ghost_interval': args.ghost_interval,
        'difficulty_mix': difficulty_mix,
        'controller': args.controller,
        'controller_description': CONTROLLER_DESCRIPTIONS[args.controller],
        'condition_id_map': {
            'custom': -1,
            **DIFFICULTY_TO_ID,
        },
        'difficulty_presets': {name: DIFFICULTY_PRESETS[name] for name in difficulty_mix},
        'max_steps': args.max_steps,
        'seed': args.seed,
        'strategy': CONTROLLER_DESCRIPTIONS[args.controller],
        'timestamp': time.strftime('%Y%m%d_%H%M%S'),
        'game_state_dim': state_dim,
        'state_format': args.state_format,
        'n_cells': N_CELLS,
        'parallel': True,
        'num_workers': num_workers,
        'games_per_shard': games_per_shard,
    }
    with open(out_dir / 'config.json', 'w') as f:
        json.dump(config, f, indent=2)

    parent_rng = random.Random(args.seed)
    game_schedule = build_game_schedule(
        args.n_games,
        difficulty_mix,
        args.n_ghosts,
        args.ghost_interval,
        args.max_steps,
        parent_rng,
    )
    batches = [
        game_schedule[start:start + games_per_shard]
        for start in range(0, len(game_schedule), games_per_shard)
    ]

    print(
        f'Parallel generation: controller={args.controller} '
        f'workers={num_workers} batches={len(batches)} '
        f'games_per_shard={games_per_shard}',
        flush=True,
    )

    shard_results = []
    total_chunks = 0
    total_steps = 0
    total_caught = 0
    total_cleared = 0
    completed_games = 0
    per_game_steps = []
    per_game_pellets = []
    games_per_condition = {}
    chunks_per_condition = {}

    t0 = time.time()
    next_log_games = 500
    with ProcessPoolExecutor(max_workers=num_workers) as pool:
        futures = [
            pool.submit(
                _simulate_batch,
                batch_idx,
                batch,
                args.horizon,
                stride,
                state_dim,
                args.controller,
                args.seed + batch_idx * 1000003,
                str(shard_dir),
            )
            for batch_idx, batch in enumerate(batches)
        ]

        for done_batches, future in enumerate(as_completed(futures), start=1):
            result = future.result()
            shard_results.append(result)
            completed_games += result['n_games']
            total_chunks += result['n_chunks']
            total_steps += result['total_steps']
            total_caught += result['total_caught']
            total_cleared += result['total_cleared']
            per_game_steps.extend(result['per_game_steps'])
            per_game_pellets.extend(result['per_game_pellets'])
            _merge_counts(games_per_condition, result['games_per_condition'])
            _merge_counts(chunks_per_condition, result['chunks_per_condition'])

            if completed_games >= next_log_games or done_batches == len(batches):
                elapsed = time.time() - t0
                rate = completed_games / elapsed if elapsed > 0 else 0.0
                eta = (args.n_games - completed_games) / rate if rate > 0 else 0.0
                print(
                    f'[{completed_games}/{args.n_games}] '
                    f'batches={done_batches}/{len(batches)} '
                    f'chunks={total_chunks:,}  steps={total_steps:,} '
                    f'caught={total_caught}  cleared={total_cleared}  '
                    f'{rate:.1f} games/s  ETA {eta:.0f}s',
                    flush=True,
                )
                while next_log_games <= completed_games:
                    next_log_games += 500

    elapsed = time.time() - t0

    print(f'\nMerging {len(shard_results)} shards...', flush=True)
    game_states, waypoints_arr, alive_arr, condition_id_arr = _merge_shards(
        shard_results,
        out_dir,
        args.horizon,
        state_dim,
        args.keep_shards,
    )

    print(f'\nWriting final archive with {total_chunks:,} chunks...', flush=True)
    out_path = out_dir / 'data.npz'
    np.savez_compressed(
        out_path,
        game_states=game_states,
        waypoints=waypoints_arr,
        alive=alive_arr,
        condition_id=condition_id_arr,
    )
    file_size_mb = out_path.stat().st_size / 1e6

    per_game_steps = np.array(per_game_steps)
    per_game_pellets = np.array(per_game_pellets)
    has_nan = bool(np.isnan(game_states).any())
    has_inf = bool(np.isinf(game_states).any())

    summary = {
        'n_games': args.n_games,
        'controller': args.controller,
        'n_chunks': total_chunks,
        'total_steps': total_steps,
        'avg_steps_per_game': round(total_steps / args.n_games, 1),
        'games_caught': total_caught,
        'caught_pct': round(100 * total_caught / args.n_games, 1),
        'games_cleared': total_cleared,
        'avg_pellets_eaten': round(float(per_game_pellets.mean()), 2),
        'median_pellets_eaten': round(float(np.median(per_game_pellets)), 1),
        'avg_game_length': round(float(per_game_steps.mean()), 1),
        'game_states_shape': list(game_states.shape),
        'waypoints_shape': list(waypoints_arr.shape),
        'alive_shape': list(alive_arr.shape),
        'condition_id_shape': list(condition_id_arr.shape),
        'games_per_condition': games_per_condition,
        'chunks_per_condition': chunks_per_condition,
        'file_size_mb': round(file_size_mb, 1),
        'elapsed_s': round(elapsed, 1),
        'has_nan': has_nan,
        'has_inf': has_inf,
        'parallel': True,
        'num_workers': num_workers,
        'games_per_shard': games_per_shard,
    }
    with open(out_dir / 'summary.json', 'w') as f:
        json.dump(summary, f, indent=2)

    print(f'\n=== AntMan Parallel Data Generation Complete ===')
    print(f'Controller: {args.controller} ({CONTROLLER_DESCRIPTIONS[args.controller]})')
    print(f'Workers: {num_workers}, games/shard: {games_per_shard}')
    print(f'Games:   {args.n_games:,}')
    print(f'Chunks:  {total_chunks:,}')
    print(f'Steps:   {total_steps:,} (avg {total_steps/args.n_games:.1f}/game)')
    print(f'Caught:  {total_caught} ({100*total_caught/args.n_games:.1f}%)')
    print(f'Cleared: {total_cleared} ({100*total_cleared/args.n_games:.1f}%)')
    print(f'Pellets: mean={per_game_pellets.mean():.1f}, median={np.median(per_game_pellets):.1f}, max={per_game_pellets.max()}')
    print(f'Shapes:  states={game_states.shape}, waypoints={waypoints_arr.shape}, alive={alive_arr.shape}')
    print(f'File:    {out_path} ({file_size_mb:.1f} MB)')
    print(f'Time:    {elapsed:.1f}s')

    print(f'\n--- Validation ---')
    pellet_slice = get_state_layout(state_dim)['pellets']
    pellet_counts = game_states[:, :, pellet_slice].sum(axis=-1)
    diffs = np.diff(pellet_counts, axis=1)
    increases = int((diffs > 0.5).sum())
    print(f'Pellet increases (should be 0): {increases}')

    alive_diffs = np.diff(alive_arr, axis=1)
    resurrections = int((alive_diffs > 0.5).sum())
    print(f'Resurrections (should be 0): {resurrections}')

    avg_chunk_gain = float((pellet_counts[:, 0] - pellet_counts[:, -1]).mean())
    print(f'Avg pellet gain per chunk: {avg_chunk_gain:.2f}')
    print(f'NaN: {has_nan}, Inf: {has_inf}')

    if not args.no_plots:
        save_plots(game_states, alive_arr, out_dir, args.n_games,
                   total_caught, per_game_steps, per_game_pellets)

    for temp_path in [
        out_dir / '_game_states.npy',
        out_dir / '_waypoints.npy',
        out_dir / '_alive.npy',
        out_dir / '_condition_id.npy',
    ]:
        temp_path.unlink(missing_ok=True)
    if not args.keep_shards:
        shutil.rmtree(out_dir / 'shards', ignore_errors=True)


if __name__ == '__main__':
    main()