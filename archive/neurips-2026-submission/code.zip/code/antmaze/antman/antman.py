#!/usr/bin/env python3
"""
AntMan — Pac-Man with a physics-grounded ant, controlled by a pre-trained IWM.

Usage:
    export LD_LIBRARY_PATH="$HOME/.mujoco/mujoco210/bin:/usr/lib/nvidia"

    # Easy (1 ghost, slow):
    python -u antmaze/antman/antman.py --gpu 0 --n_ghosts 1 --ghost_interval 16

    # Medium (2 ghosts):
    python -u antmaze/antman/antman.py --gpu 0 --n_ghosts 2 --ghost_interval 10

    # Hard (3 ghosts, fast):
    python -u antmaze/antman/antman.py --gpu 0 --n_ghosts 3 --ghost_interval 6

    # Custom IWM:
    python -u antmaze/antman/antman.py --gpu 0 --iwm_path path/to/best_model.pt
"""

import sys, os, argparse, json, time
from pathlib import Path

os.environ.setdefault('D4RL_SUPPRESS_IMPORT_ERROR', '1')

import numpy as np
import torch

# Project root (two levels up from antmaze/antman/)
PROJECT_ROOT = Path(os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__)))))
sys.path.insert(0, str(PROJECT_ROOT))

from antmaze.antman.game import AntManGame
from antmaze.antman.strategy import AntManStrategy
from antmaze.antman.render import render_ascii, render_matplotlib
from antmaze.navigate_cardinal import (
    MAZE_CONFIGS, AntMazeIWM, Navigator,
    plan_cardinal_waypoints, _init_maze_config,
)

# ═════════════════════════════════════════════════════════════════════════
# Constants
# ═════════════════════════════════════════════════════════════════════════

DEFAULT_ENV = 'large-diverse'
DEFAULT_IWM = ('antmaze/large-diverse/iwm/L8/'
               'antmaze_large_diverse_nohealth_v2_disp025_20260410_111959/'
               'best_model.pt')
ANT_START_CELL = (3, 6)

# Navigation params (from the 95% SR result)
WP_SPACING = 1.0
WP_ADVANCE_DIST = 1.0
WP_SKIP_DIST = 0.8
TARGET_DIST_MIN = 0.5
TARGET_DIST_MAX = 1.5
STUCK_THRESHOLD = 10
MAX_REPLAN = 5
REPLAN_EVERY = 1

HORIZON = 8  # overridden from checkpoint


# ═════════════════════════════════════════════════════════════════════════
# Args
# ═════════════════════════════════════════════════════════════════════════

parser = argparse.ArgumentParser(description='AntMan — Pac-Man with IWM ant')

# Hardware
parser.add_argument('--gpu', type=int, default=0)
parser.add_argument('--seed', type=int, default=42)

# Game
parser.add_argument('--n_ghosts', type=int, default=1, choices=[0, 1, 2, 3])
parser.add_argument('--ghost_interval', type=int, default=10,
                    help='Ghost moves every N MuJoCo steps')
parser.add_argument('--max_steps', type=int, default=3000)

# Model
parser.add_argument('--iwm_path', type=str, default='')

# Navigation tuning
parser.add_argument('--wp_spacing', type=float, default=WP_SPACING)
parser.add_argument('--target_dist_min', type=float, default=TARGET_DIST_MIN)
parser.add_argument('--target_dist_max', type=float, default=TARGET_DIST_MAX)

# Output
parser.add_argument('--render_ascii', action='store_true',
                    help='Print ASCII maze after each IWM chunk')
parser.add_argument('--render_interval', type=int, default=1,
                    help='ASCII render every N chunks (default: 1)')
parser.add_argument('--save_results', action='store_true')
parser.add_argument('--save_figure', action='store_true',
                    help='Save episode summary figure')
parser.add_argument('--out_dir', type=str, default='')
parser.add_argument('--quiet', action='store_true')


# ═════════════════════════════════════════════════════════════════════════
# Game loop
# ═════════════════════════════════════════════════════════════════════════

def run_antman_game(env, navigator, args, verbose=True):
    """Run one full AntMan game with MuJoCo physics.

    Returns:
        dict with outcome, score, steps, trajectory, logs.
    """
    global HORIZON

    cfg = MAZE_CONFIGS[DEFAULT_ENV]
    game = AntManGame(
        cfg['maze_map'], cfg['scaling'], cfg['torso_x'], cfg['torso_y'],
        n_ghosts=args.n_ghosts,
        ghost_move_interval=args.ghost_interval,
        max_steps=args.max_steps,
    )
    game.reset()
    strategy = AntManStrategy(game)

    # Reset MuJoCo env
    obs = env.reset()

    # Logging
    ant_trail = [obs[:2].copy()]
    ghost_trails = {g.name: [(g.row, g.col)] for g in game.ghosts}
    pellet_log = []
    strategy_log = []
    chunk_count = 0

    ghost_names = [g.name.capitalize() for g in game.ghosts]
    if verbose:
        n_regular = sum(1 for p in game.pellets if not p.is_power)
        n_power = sum(1 for p in game.pellets if p.is_power)
        print(f'\n=== AntMan Game ===')
        print(f'Ghosts: {args.n_ghosts} ({", ".join(ghost_names)}), '
              f'move every {args.ghost_interval} steps')
        print(f'Pellets: {n_regular} regular + {n_power} power = '
              f'{len(game.pellets)} total')
        print(f'IWM horizon: {HORIZON}')
        print(flush=True)

    steps = 0
    game_over = False

    # Persistent waypoint chain for multi-chunk navigation to a target
    wp_chain = None      # np array of waypoints (N, 2)
    wp_idx = 0           # current waypoint index
    wp_target_cell = None  # strategy target that generated this chain
    chunks_since_advance = 0

    while steps < args.max_steps and not game_over:
        current_xy = obs[:2].copy()
        vel_xy = obs[15:17].copy()  # vx, vy from obs

        # Strategy: choose target cell
        ant_cell = game.get_ant_cell(current_xy)
        ant_heading = game.get_ant_heading(vel_xy)
        target_cell, reason = strategy.choose_target_cell(ant_cell, ant_heading)
        target_world = game.cell_to_world(*target_cell)

        strategy_log.append({
            'step': steps,
            'ant_cell': list(ant_cell),
            'target_cell': list(target_cell),
            'reason': reason,
        })

        # Replan waypoint chain if target changed or we're stuck
        need_replan = (
            wp_chain is None
            or wp_target_cell != target_cell
            or chunks_since_advance >= STUCK_THRESHOLD
        )
        if need_replan:
            # If deeply stuck (2× threshold), escape to a random neighbor
            if chunks_since_advance >= STUCK_THRESHOLD * 2:
                neighbors = game.get_neighbors(*ant_cell)
                if neighbors:
                    esc_cell = neighbors[np.random.randint(len(neighbors))]
                    esc_world = game.cell_to_world(*esc_cell)
                    wp_chain = plan_cardinal_waypoints(
                        current_xy, esc_world, spacing=args.wp_spacing)
                    wp_target_cell = None  # force replan next chunk
                else:
                    wp_chain = plan_cardinal_waypoints(
                        current_xy, target_world, spacing=args.wp_spacing)
                    wp_target_cell = target_cell
            else:
                wp_chain = plan_cardinal_waypoints(
                    current_xy, target_world, spacing=args.wp_spacing)
                wp_target_cell = target_cell
            wp_idx = 1  # skip start position
            chunks_since_advance = 0

        if wp_chain is None or len(wp_chain) < 2:
            iwm_target = target_world
        else:
            # Waypoint advancement: skip waypoints we've passed
            n_wp = len(wp_chain)
            while wp_idx < n_wp - 1:
                dist_to_wp = float(np.linalg.norm(
                    current_xy - wp_chain[wp_idx]))
                if dist_to_wp < WP_ADVANCE_DIST:
                    wp_idx += 1
                    chunks_since_advance = 0
                # Also skip-ahead if closer to a later waypoint
                elif wp_idx + 1 < n_wp and float(np.linalg.norm(
                        current_xy - wp_chain[wp_idx + 1])) < WP_SKIP_DIST:
                    wp_idx += 2
                    wp_idx = min(wp_idx, n_wp - 1)
                    chunks_since_advance = 0
                else:
                    break

            # Snap-to-closest: check if a further waypoint is closer
            best_snap = wp_idx
            best_dist = float(np.linalg.norm(
                current_xy - wp_chain[min(wp_idx, n_wp - 1)]))
            for si in range(wp_idx + 1, n_wp):
                d = float(np.linalg.norm(current_xy - wp_chain[si]))
                if d < best_dist:
                    best_dist = d
                    best_snap = si
            if best_snap != wp_idx:
                wp_idx = best_snap
                chunks_since_advance = 0

            iwm_target = wp_chain[min(wp_idx, n_wp - 1)].copy()

        # Randomized target distance (matches navigation pipeline)
        if args.target_dist_min > 0 and args.target_dist_max > 0:
            direction = iwm_target - current_xy
            dir_norm = float(np.linalg.norm(direction))
            if dir_norm > 0.01:
                direction = direction / dir_norm
                rand_dist = np.random.uniform(args.target_dist_min,
                                              args.target_dist_max)
                iwm_target = current_xy + direction * rand_dist

        # IWM: generate action chunk
        actions = navigator.get_actions(obs, iwm_target)

        # Execute in MuJoCo
        for ai, a in enumerate(actions):
            a = np.clip(a, -1.0, 1.0)
            obs, reward, done, info = env.step(a)
            steps += 1

            # Game tick
            events = game.tick(obs[:2], obs[15:17], steps)

            # Record trail
            ant_trail.append(obs[:2].copy())
            for g in game.ghosts:
                ghost_trails[g.name].append((g.row, g.col))

            # Handle events
            if events['pellet_eaten']:
                pellet_log.append({
                    'step': steps,
                    'pos': obs[:2].tolist(),
                    'points': events['points_this_step'],
                    'power': events['power_activated'],
                })

            if events['caught']:
                if verbose:
                    print(f'\nStep {steps}: CAUGHT by {events["caught_by"]}! '
                          f'Score: {game.score}', flush=True)
                game_over = True
                break

            if events['ate_ghost']:
                if verbose:
                    print(f'Step {steps}: ATE {events["ate_ghost_name"]}! +200',
                          flush=True)

            if events['all_cleared']:
                if verbose:
                    print(f'\nStep {steps}: ALL PELLETS CLEARED! '
                          f'Score: {game.score}', flush=True)
                game_over = True
                break

            if steps >= args.max_steps:
                game_over = True
                break

        chunk_count += 1
        chunks_since_advance += 1

        # ASCII render
        if args.render_ascii and chunk_count % args.render_interval == 0:
            print()
            print(render_ascii(game, obs[:2], color=True))

        # Periodic status
        if verbose and chunk_count % 25 == 0 and not game_over:
            ghost_info = '  '.join(
                f'{g.name[0].upper()}({g.row},{g.col})'
                for g in game.ghosts
            )
            print(f'Chunk {chunk_count:3d} (step {steps:4d}): '
                  f'Ant ({ant_cell[0]},{ant_cell[1]})  {ghost_info}  '
                  f'Score: {game.score:5d}  '
                  f'Pellets: {game.pellets_remaining:2d}',
                  flush=True)

    # Final result
    outcome = ('cleared' if game.all_pellets_eaten()
               else 'caught' if game._caught
               else 'timeout')

    result = {
        'outcome': outcome,
        'score': game.score,
        'steps': steps,
        'chunks': chunk_count,
        'pellets_eaten': game.pellets_total - game.pellets_remaining,
        'pellets_total': game.pellets_total,
        'ghosts_eaten': game._ghosts_eaten_total,
        'n_ghosts': args.n_ghosts,
        'ghost_move_interval': args.ghost_interval,
        'ant_trail': [xy.tolist() for xy in ant_trail],
        'ghost_trails': {k: v for k, v in ghost_trails.items()},
        'pellet_log': pellet_log,
        'strategy_log': strategy_log,
    }

    if verbose:
        print(f'\n=== Game Over: {outcome.upper()} ===')
        print(f'Score: {game.score}  |  Steps: {steps}  |  Chunks: {chunk_count}  |  '
              f'Pellets: {game.pellets_total - game.pellets_remaining}/'
              f'{game.pellets_total}  |  Ghosts eaten: {game._ghosts_eaten_total}')

    # Attach game instance for figure generation
    result['_game'] = game

    return result


# ═════════════════════════════════════════════════════════════════════════
# Main
# ═════════════════════════════════════════════════════════════════════════

def main():
    global HORIZON

    args = parser.parse_args()

    # Initialize maze config
    _init_maze_config(DEFAULT_ENV)

    if args.gpu >= 0 and torch.cuda.is_available():
        device = f'cuda:{args.gpu}'
    else:
        device = 'cpu'

    # Resolve IWM path
    iwm_path_str = args.iwm_path or DEFAULT_IWM
    iwm_path = PROJECT_ROOT / iwm_path_str
    if not iwm_path.exists():
        print(f'ERROR: IWM checkpoint not found: {iwm_path}', file=sys.stderr)
        sys.exit(1)

    # Seeds
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(args.seed)

    # ─── Load IWM ─────────────────────────────────────────────────────

    print(f'Loading IWM from {iwm_path}', flush=True)
    ckpt = torch.load(iwm_path, map_location='cpu', weights_only=False)

    if isinstance(ckpt, dict) and 'model_state_dict' in ckpt:
        state_dict = ckpt['model_state_dict']
        ckpt_meta = ckpt
    else:
        state_dict = ckpt
        ckpt_meta = {}

    # Read config
    config_path = iwm_path.parent / 'config.json'
    if config_path.exists():
        with open(config_path) as f:
            model_cfg = json.load(f).get('model', {})
    else:
        model_cfg = {}

    ckpt_horizon = ckpt_meta.get('horizon', 8)
    HORIZON = ckpt_horizon

    iwm = AntMazeIWM(
        d_model=model_cfg.get('d_model', 192),
        n_heads=model_cfg.get('n_heads', 6),
        n_layers=model_cfg.get('n_layers', 4),
        d_ff=model_cfg.get('d_ff', 576),
        dropout=0.0,  # inference
        relative_xy=model_cfg.get('relative_xy', False),
        horizon=ckpt_horizon,
    ).to(device)

    iwm.load_state_dict(state_dict)
    iwm.eval()
    n_params = sum(p.numel() for p in iwm.parameters())
    print(f'IWM: {n_params:,} params, horizon={ckpt_horizon}, '
          f'device={device}', flush=True)

    navigator = Navigator(iwm, device=device)

    # ─── Create MuJoCo env ───────────────────────────────────────────

    gym_env = MAZE_CONFIGS[DEFAULT_ENV]['gym_env']
    print(f'Creating MuJoCo env ({gym_env})...', flush=True)
    import gym
    import d4rl  # noqa
    env = gym.make(gym_env)
    env.seed(args.seed)
    print('Env ready', flush=True)

    # ─── Run game ─────────────────────────────────────────────────────

    result = run_antman_game(env, navigator, args, verbose=not args.quiet)

    # ─── Save results ─────────────────────────────────────────────────

    if args.save_results or args.save_figure:
        if args.out_dir:
            out_dir = Path(args.out_dir)
        else:
            timestamp = time.strftime('%Y%m%d_%H%M%S')
            out_dir = PROJECT_ROOT / 'antmaze' / 'antman' / 'runs' / timestamp
        out_dir.mkdir(parents=True, exist_ok=True)

        if args.save_results:
            # Remove non-serializable game object
            save_result = {k: v for k, v in result.items() if k != '_game'}
            with open(out_dir / 'results.json', 'w') as f:
                json.dump(save_result, f, indent=2)
            print(f'Results saved to {out_dir / "results.json"}', flush=True)

        if args.save_figure:
            import matplotlib
            matplotlib.use('Agg')
            game = result['_game']
            final_xy = np.array(result['ant_trail'][-1])
            trail = [np.array(xy) for xy in result['ant_trail']]
            # Ghost trails as world coordinates
            gt_world = {}
            for gname, cells in result['ghost_trails'].items():
                gt_world[gname] = [
                    game.cell_to_world(r, c).tolist() for r, c in cells
                ]
            render_matplotlib(
                game, final_xy, ant_trail=trail,
                ghost_trails=gt_world,
                save_path=str(out_dir / 'episode_summary.png'),
            )
            print(f'Figure saved to {out_dir / "episode_summary.png"}',
                  flush=True)


if __name__ == '__main__':
    main()
