"""
Step 12: Waypoint grid + game state tensor encoding.

Shared definitions used by the high-level FM, IWM_high, and sim data generation.

Current game state encoding (58D with explicit ghost-presence mask):
    [0:2]    ant_xy          — ant world position
    [2:8]    ghost_xys       — 3 ghost world positions (2D each), padded if fewer
    [8]      fright_norm     — fright_remaining / FRIGHT_DURATION
    [9:12]   ghost_present   — 1 if that ghost slot exists in this game, else 0
    [12:58]  pellet_bitmap   — 1=uneaten, 0=eaten (one per open cell)

Legacy checkpoints and datasets still use the older 55D layout without the
ghost_present mask. This module exposes slice helpers and can encode either
layout on demand so runtime code can stay backward-compatible.

Waypoint grid: 46 cell centers (the only valid high-level "actions").
"""

import numpy as np
import torch

from antmaze.antman.game import (
    AntManGame, FRIGHT_DURATION, POWER_PELLET_CELLS,
    GHOST_HOMES, GHOST_ORDER, MAX_STEPS,
)

# ═════════════════════════════════════════════════════════════════════════
# Maze config (copied from navigate_cardinal.py to avoid circular imports)
# ═════════════════════════════════════════════════════════════════════════

MAZE_MAP = [
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1],
    [1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1],
    [1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1],
    [1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1],
    [1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1],
    [1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
]
SCALING = 4.0
TORSO_X = 4.0
TORSO_Y = 4.0
N_ROWS = len(MAZE_MAP)
N_COLS = len(MAZE_MAP[0])

# ═════════════════════════════════════════════════════════════════════════
# Open cells and waypoint grid
# ═════════════════════════════════════════════════════════════════════════

# All open cells in row-major order (deterministic ordering)
OPEN_CELLS = []
for r in range(N_ROWS):
    for c in range(N_COLS):
        if MAZE_MAP[r][c] == 0:
            OPEN_CELLS.append((r, c))
OPEN_CELLS = tuple(OPEN_CELLS)
N_CELLS = len(OPEN_CELLS)  # 46

# Cell index lookup: (row, col) → index in OPEN_CELLS
CELL_TO_IDX = {rc: i for i, rc in enumerate(OPEN_CELLS)}


def cell_to_world(row, col):
    """Convert grid cell (row, col) to world xy at cell center."""
    x = col * SCALING - TORSO_X
    y = row * SCALING - TORSO_Y
    return np.array([x, y], dtype=np.float32)


# Waypoint grid: world xy for each open cell center
WAYPOINTS = np.array([cell_to_world(r, c) for r, c in OPEN_CELLS],
                     dtype=np.float32)  # (N_CELLS, 2)

# Precomputed neighbor adjacency for each cell index
CELL_NEIGHBORS = {}
for i, (r, c) in enumerate(OPEN_CELLS):
    nbrs = []
    for dr, dc in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
        nr, nc = r + dr, c + dc
        if (nr, nc) in CELL_TO_IDX:
            nbrs.append(CELL_TO_IDX[(nr, nc)])
    CELL_NEIGHBORS[i] = tuple(nbrs)


def snap_to_nearest_cell(xy):
    """Snap continuous xy to nearest waypoint. Returns (cell_idx, world_xy)."""
    dists = np.linalg.norm(WAYPOINTS - xy, axis=-1)
    idx = int(np.argmin(dists))
    return idx, WAYPOINTS[idx].copy()


def snap_to_nearest_cell_batch(xys):
    """Snap batch of xy to nearest waypoints. Returns (cell_indices, world_xys)."""
    # xys: (B, 2), WAYPOINTS: (N, 2)
    dists = np.linalg.norm(xys[:, None, :] - WAYPOINTS[None, :, :], axis=-1)  # (B, N)
    indices = np.argmin(dists, axis=-1)  # (B,)
    return indices, WAYPOINTS[indices].copy()


# ═════════════════════════════════════════════════════════════════════════
# Game state encoding
# ═════════════════════════════════════════════════════════════════════════

MAX_GHOSTS = 3

# Shared state layout helpers.
ANT_XY_SLICE = slice(0, 2)
GHOST_XY_SLICE = slice(2, 2 + MAX_GHOSTS * 2)
FRIGHT_IDX = GHOST_XY_SLICE.stop
FRIGHT_SLICE = slice(FRIGHT_IDX, FRIGHT_IDX + 1)
CONTINUOUS_SLICE = slice(0, FRIGHT_SLICE.stop)      # ant_xy + ghost_xys + fright
GHOST_CONTINUOUS_SLICE = slice(GHOST_XY_SLICE.start, FRIGHT_SLICE.stop)

LEGACY_GHOST_PRESENT_SLICE = None
LEGACY_PELLET_SLICE = slice(CONTINUOUS_SLICE.stop, CONTINUOUS_SLICE.stop + N_CELLS)
LEGACY_GAME_STATE_DIM = LEGACY_PELLET_SLICE.stop    # = 55

GHOST_PRESENT_SLICE = slice(CONTINUOUS_SLICE.stop, CONTINUOUS_SLICE.stop + MAX_GHOSTS)
PELLET_SLICE = slice(GHOST_PRESENT_SLICE.stop, GHOST_PRESENT_SLICE.stop + N_CELLS)
GAME_STATE_DIM = PELLET_SLICE.stop                  # = 58


def get_state_layout(state_dim=GAME_STATE_DIM):
    """Return slice metadata for a supported game-state layout."""
    if state_dim == LEGACY_GAME_STATE_DIM:
        return {
            'name': 'legacy55',
            'state_dim': LEGACY_GAME_STATE_DIM,
            'ant_xy': ANT_XY_SLICE,
            'ghost_xys': GHOST_XY_SLICE,
            'fright': FRIGHT_SLICE,
            'fright_idx': FRIGHT_IDX,
            'ghost_present': LEGACY_GHOST_PRESENT_SLICE,
            'pellets': LEGACY_PELLET_SLICE,
            'continuous': CONTINUOUS_SLICE,
            'ghost_continuous': GHOST_CONTINUOUS_SLICE,
            'has_ghost_mask': False,
        }
    if state_dim == GAME_STATE_DIM:
        return {
            'name': 'ghost_mask58',
            'state_dim': GAME_STATE_DIM,
            'ant_xy': ANT_XY_SLICE,
            'ghost_xys': GHOST_XY_SLICE,
            'fright': FRIGHT_SLICE,
            'fright_idx': FRIGHT_IDX,
            'ghost_present': GHOST_PRESENT_SLICE,
            'pellets': PELLET_SLICE,
            'continuous': CONTINUOUS_SLICE,
            'ghost_continuous': GHOST_CONTINUOUS_SLICE,
            'has_ghost_mask': True,
        }
    raise ValueError(f'Unsupported AntMan game_state dim: {state_dim}')


def encode_game_state(game, ant_xy, state_dim=GAME_STATE_DIM):
    """Encode AntManGame into a fixed-size numpy vector.

    Args:
        game: AntManGame instance
        ant_xy: (2,) ant world position

    Returns:
        (state_dim,) float32 array
    """
    layout = get_state_layout(state_dim)
    state = np.zeros(state_dim, dtype=np.float32)

    # Ant position
    state[layout['ant_xy']] = ant_xy

    # Ghost positions (world coords, padded with zeros if fewer than 3).
    for i, ghost in enumerate(game.ghosts):
        if i >= MAX_GHOSTS:
            break
        if ghost.eaten:
            # In the simplified AntMan game, eaten ghosts are removed from play
            # at home immediately and respawn there after a timeout.
            gxy = cell_to_world(ghost.home_row, ghost.home_col)
        else:
            gxy = cell_to_world(ghost.row, ghost.col)
        start = layout['ghost_xys'].start + i * 2
        state[start:start + 2] = gxy

    # Fright timer (normalized)
    state[layout['fright_idx']] = game.fright_remaining / FRIGHT_DURATION

    if layout['has_ghost_mask']:
        for i in range(min(len(game.ghosts), MAX_GHOSTS)):
            state[layout['ghost_present'].start + i] = 1.0

    # Pellet bitmap: 1 = uneaten, 0 = eaten
    for pellet in game.pellets:
        idx = CELL_TO_IDX.get((pellet.row, pellet.col))
        if idx is not None and not pellet.eaten:
            state[layout['pellets'].start + idx] = 1.0

    return state


def encode_game_state_torch(game, ant_xy, device='cpu', state_dim=GAME_STATE_DIM):
    """Encode game state as a torch tensor."""
    return torch.tensor(encode_game_state(game, ant_xy, state_dim=state_dim),
                        dtype=torch.float32, device=device)


def decode_pellet_bitmap(state_vec):
    """Extract pellet bitmap from state vector. Returns (N_CELLS,) bool array."""
    layout = get_state_layout(len(state_vec))
    return state_vec[layout['pellets']] > 0.5


def decode_ant_xy(state_vec):
    """Extract ant position from state vector."""
    layout = get_state_layout(len(state_vec))
    return state_vec[layout['ant_xy']]


def decode_ghost_xys(state_vec, n_ghosts=3):
    """Extract ghost positions from state vector. Returns (n_ghosts, 2) array."""
    layout = get_state_layout(len(state_vec))
    start = layout['ghost_xys'].start
    stop = start + n_ghosts * 2
    return state_vec[start:stop].reshape(n_ghosts, 2)


def decode_ghost_present(state_vec):
    """Extract explicit ghost-presence mask, or None for legacy layouts."""
    layout = get_state_layout(len(state_vec))
    if not layout['has_ghost_mask']:
        return None
    return state_vec[layout['ghost_present']]


def decode_fright(state_vec):
    """Extract normalized fright timer from state vector."""
    layout = get_state_layout(len(state_vec))
    return state_vec[layout['fright_idx']]


def count_pellets(state_vec):
    """Count uneaten pellets in state vector."""
    layout = get_state_layout(len(state_vec))
    return int((state_vec[layout['pellets']] > 0.5).sum())
