#!/usr/bin/env python3
"""
Game FM v2: Full per-cell pellet bitmap prediction.

Causal Transformer: (game_state₀, waypoints₁..₃₂) → per-step predictions:
  - pellet_bitmap(46): BCE per cell — P(pellet_c still remaining at step t)
  - alive(1): BCE — is the ant still alive at step t?
  - ghost_xys(6)+fright(1): MSE — auxiliary ghost tracking

Key difference from v1:
  v1: predicts 1 binary per step ("did ant eat *a* pellet?")
  v2: predicts 46 binaries per step ("which pellets remain?")
  → 46× richer gradient for IWM training

IWM reward: R = Σ_t Σ_c [σ(pel_{c,t-1}) - σ(pel_{c,t})]⁺ × σ(alive_t)
           = number of newly-eaten pellets, weighted by survival

Usage:
    python -u antmaze/antman/train_game_fm_v2.py \
        --config antmaze/antman/fm/L32/.../config.json
"""

import os, sys, argparse, json, time, math
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT_ROOT))

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

from antmaze.antman.game_state import (
    CONTINUOUS_SLICE,
    GAME_STATE_DIM,
    N_CELLS,
    get_state_layout,
)


# ═════════════════════════════════════════════════════════════════════════
# Model
# ═════════════════════════════════════════════════════════════════════════

class GameFM_v2(nn.Module):
    """Game FM v2: predicts full 46-cell pellet bitmap per step.

    Sequence: [s₀_token, wp₀_token, wp₁_token, ..., wp_{H-1}_token]

    Predictions per step t:
      pellet_bitmap(46) → BCE per cell: P(pellet_c remaining at step t)
      alive(1) → BCE: P(alive at step t)
      ghost_xys(6) + fright(1) → MSE (auxiliary)
    """

    CONT_START = 2      # first ghost dim in state
    CONT_END = 9        # last+1 ghost dim in state
    N_CONT = CONT_END - CONT_START
    N_PELLETS = N_CELLS

    def __init__(self, state_dim=GAME_STATE_DIM, action_dim=2, horizon=32,
                 d_model=128, n_heads=4, n_layers=4, ff_mult=3,
                 dropout=0.1):
        super().__init__()
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.horizon = horizon
        self.d_model = d_model
        self.n_heads = n_heads
        self.n_layers_tfm = n_layers
        self.layout = get_state_layout(state_dim)
        self.pellet_slice = self.layout['pellets']

        # Token embeddings
        self.state_embed = nn.Sequential(
            nn.Linear(state_dim, d_model),
            nn.GELU(),
            nn.LayerNorm(d_model),
            nn.Linear(d_model, d_model),
        )
        self.action_embed = nn.Sequential(
            nn.Linear(action_dim, d_model),
            nn.GELU(),
            nn.LayerNorm(d_model),
            nn.Linear(d_model, d_model),
        )

        # Learned positional encoding
        self.pos_embed = nn.Parameter(
            torch.randn(1, horizon + 1, d_model) * 0.02
        )
        # Token type embed: [0]=state, [1]=action
        self.type_embed = nn.Parameter(
            torch.randn(1, 2, d_model) * 0.02
        )

        # Pre-norm causal Transformer
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=n_heads,
            dim_feedforward=d_model * ff_mult,
            dropout=dropout,
            activation='gelu',
            batch_first=True,
            norm_first=True,
        )
        self.transformer = nn.TransformerEncoder(
            encoder_layer, num_layers=n_layers,
            norm=nn.LayerNorm(d_model),
        )

        # Ghost head (auxiliary): ghost_xys + fright (7D), residual from s₀
        self.ghost_head = nn.Sequential(
            nn.Linear(d_model, d_model // 2),
            nn.GELU(),
            nn.Linear(d_model // 2, self.N_CONT),
        )
        # Pellet bitmap head (46D per step): P(pellet_c remaining)
        # Uses a wider hidden layer since this is the primary output
        self.pellet_head = nn.Sequential(
            nn.Linear(d_model, d_model),
            nn.GELU(),
            nn.Linear(d_model, self.N_PELLETS),
        )
        # Alive head (1D per step): P(alive)
        self.alive_head = nn.Sequential(
            nn.Linear(d_model, d_model // 2),
            nn.GELU(),
            nn.Linear(d_model // 2, 1),
        )

        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
        # Zero-init output layers → start at residual = 0
        nn.init.zeros_(self.ghost_head[-1].weight)
        nn.init.zeros_(self.ghost_head[-1].bias)
        nn.init.zeros_(self.alive_head[-1].weight)
        nn.init.zeros_(self.alive_head[-1].bias)
        # Pellet head: init bias from s₀ pellets (will predict "unchanged" at start)
        nn.init.zeros_(self.pellet_head[-1].weight)
        nn.init.zeros_(self.pellet_head[-1].bias)

    def forward(self, state, waypoints):
        """
        Args:
            state:     (B, 55) — game state s₀ (positions normalized, pellets raw)
            waypoints: (B, H, 2) — waypoint sequence (normalized)

        Returns:
            ghost_pred:     (B, H, 7)  — ghost_xys + fright residual
            pellet_logits:  (B, H, 46) — per-cell P(remaining) logits
            alive_logits:   (B, H)     — per-step P(alive) logits
        """
        B = state.shape[0]
        H = self.horizon

        # Embed
        s_tok = self.state_embed(state).unsqueeze(1)     # (B, 1, d)
        a_tok = self.action_embed(waypoints)              # (B, H, d)
        tokens = torch.cat([s_tok, a_tok], dim=1)         # (B, H+1, d)

        # Positional + type encoding
        tokens = tokens + self.pos_embed[:, :H + 1, :]
        tokens[:, 0, :] = tokens[:, 0, :] + self.type_embed[:, 0, :]
        tokens[:, 1:, :] = tokens[:, 1:, :] + self.type_embed[:, 1, :]

        # Causal mask
        causal_mask = torch.triu(
            torch.full((H + 1, H + 1), float('-inf'), device=tokens.device),
            diagonal=1,
        )

        out = self.transformer(tokens, mask=causal_mask)  # (B, H+1, d)
        out_wp = out[:, 1:, :]                             # (B, H, d)

        # Ghost positions (auxiliary): residual from s₀
        ghost_delta = self.ghost_head(out_wp)                # (B, H, 7)
        s0_cont = state[:, self.CONT_START:self.CONT_END].unsqueeze(1)  # (B, 1, 7)
        ghost_pred = s0_cont + ghost_delta

        # Pellet bitmap logits: residual from s₀ pellet state
        # s₀ pellets are 0/1 → convert to logit space, then add learned delta
        s0_pel = state[:, self.pellet_slice]                 # (B, 46)
        # Convert binary → logit: 1→+3, 0→-3 (avoids inf from exact 0/1)
        s0_pel_logit = (s0_pel * 6.0 - 3.0).unsqueeze(1)    # (B, 1, 46)
        pel_delta = self.pellet_head(out_wp)                  # (B, H, 46)
        pellet_logits = s0_pel_logit + pel_delta              # (B, H, 46)

        # Alive logits (scalar per step)
        alive_logits = self.alive_head(out_wp).squeeze(-1)   # (B, H)

        return ghost_pred, pellet_logits, alive_logits


# ═════════════════════════════════════════════════════════════════════════
# Dataset
# ═════════════════════════════════════════════════════════════════════════

class GameFMv2Dataset(Dataset):
    """Dataset for FM v2: targets are full pellet bitmaps per step."""

    def __init__(self, game_states, waypoints, alive,
                 pos_mean, pos_std, wp_mean, wp_std, pellet_slice):
        """
        game_states: (N, H+1, 55)
        waypoints:   (N, H, 2)
        alive:       (N, H+1)
        """
        self.N = game_states.shape[0]
        self.H = waypoints.shape[1]

        # Normalize continuous dims [0:9] only.
        states = game_states.copy()
        states[:, :, CONTINUOUS_SLICE] = (
            game_states[:, :, CONTINUOUS_SLICE] - pos_mean
        ) / pos_std
        # Ghost mask and pellets stay raw/binary.

        # s₀ for state embedding (full 55D)
        self.s0 = states[:, 0].astype(np.float32)

        # Ghost+fright targets (normalized, dims 2:9)
        self.ghost_targets = states[:, 1:, 2:9].astype(np.float32)  # (N, H, 7)

        # Pellet bitmap targets: full 46-cell bitmap at each step
        self.pellet_targets = game_states[:, 1:, pellet_slice].astype(np.float32)

        self.waypoints = ((waypoints - wp_mean) / wp_std).astype(np.float32)
        self.alive = alive[:, 1:].astype(np.float32)       # (N, H)

    def __len__(self):
        return self.N

    def __getitem__(self, idx):
        return (torch.from_numpy(self.s0[idx]),
            torch.from_numpy(self.waypoints[idx]),
            torch.from_numpy(self.ghost_targets[idx]),
            torch.from_numpy(self.pellet_targets[idx]),
            torch.from_numpy(self.alive[idx]))


# ═════════════════════════════════════════════════════════════════════════
# Training
# ═════════════════════════════════════════════════════════════════════════

def get_lr(epoch, warmup, total, base_lr, min_lr):
    if epoch < warmup:
        return base_lr * (epoch + 1) / warmup
    progress = (epoch - warmup) / max(1, total - warmup)
    return min_lr + 0.5 * (base_lr - min_lr) * (1 + math.cos(math.pi * progress))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=str, required=True)
    args = parser.parse_args()

    with open(args.config) as f:
        cfg = json.load(f)

    out_dir = Path(args.config).parent
    tcfg = cfg['training']
    mcfg = cfg['model']
    lcfg = cfg['loss']

    torch.manual_seed(tcfg['seed'])
    np.random.seed(tcfg['seed'])

    device = torch.device(f'cuda:{cfg["gpu"]}' if cfg['gpu'] >= 0
                          and torch.cuda.is_available() else 'cpu')
    print(f'Device: {device}')

    # ─── Load data ─────────────────────────────────────────────────

    print(f'Loading data from {cfg["data_path"]}...')
    data = np.load(cfg['data_path'])
    game_states = data['game_states']   # (N, H+1, 55)
    waypoints = data['waypoints']       # (N, H, 2)
    alive = data['alive']               # (N, H+1)
    N, Hp1, D = game_states.shape
    H = Hp1 - 1
    layout = get_state_layout(D)
    pellet_slice = layout['pellets']
    print(f'  {N:,} chunks, H={H}, state_dim={D}')
    print(f'  state layout: {layout["name"]}, pellet_slice={pellet_slice.start}:{pellet_slice.stop}')
    assert H == cfg['horizon']
    assert D == cfg['game_state_dim']

    # Stats
    pellet_bm = game_states[:, :, pellet_slice]
    pellet_ct = pellet_bm.sum(axis=-1)                     # (N, H+1)
    pel_eaten_per_step = np.clip(pellet_ct[:, :-1] - pellet_ct[:, 1:], 0, 1)
    alive_frac = alive[:, 1:].mean()

    # Per-cell stats
    pel_s0 = pellet_bm[:, 0, :]
    pel_end = pellet_bm[:, -1, :]
    cells_eaten = (pel_s0 - pel_end).clip(0, 1)
    print(f'  pellet-eating events: {pel_eaten_per_step.sum():,.0f} / {N*H:,} steps '
          f'({pel_eaten_per_step.sum()/(N*H)*100:.1f}%)')
    print(f'  mean pellets at s₀: {pel_s0.sum(axis=1).mean():.1f} / 46')
    print(f'  mean pellets eaten per chunk: {cells_eaten.sum(axis=1).mean():.1f}')
    print(f'  alive fraction: {alive_frac:.3f}')
    print(f'  pellet class balance: {pellet_bm[:, 1:].mean():.3f} '
          f'(fraction of cell-steps where pellet remains)')

    # ─── Normalization stats ───────────────────────────────────────

    all_pos = game_states[:, :, CONTINUOUS_SLICE].reshape(-1, CONTINUOUS_SLICE.stop)
    pos_mean = all_pos.mean(axis=0).astype(np.float32)
    pos_std = all_pos.std(axis=0).astype(np.float32)
    pos_std[pos_std < 1e-6] = 1.0

    all_cont = game_states[:, :, 2:9].reshape(-1, 7)
    cont_mean = all_cont.mean(axis=0).astype(np.float32)
    cont_std = all_cont.std(axis=0).astype(np.float32)
    cont_std[cont_std < 1e-6] = 1.0

    all_wp = waypoints.reshape(-1, 2)
    wp_mean = all_wp.mean(axis=0).astype(np.float32)
    wp_std = all_wp.std(axis=0).astype(np.float32)
    wp_std[wp_std < 1e-6] = 1.0

    print(f'  pos_mean: {pos_mean[:4]}...')
    print(f'  wp_mean: {wp_mean}, wp_std: {wp_std}')

    np.savez(out_dir / 'norm_stats.npz',
             pos_mean=pos_mean, pos_std=pos_std,
             cont_mean=cont_mean, cont_std=cont_std,
             wp_mean=wp_mean, wp_std=wp_std,
             state_dim=D)

    # ─── Train/val split ───────────────────────────────────────────

    n_val = int(N * tcfg['val_frac'])
    n_train = N - n_val
    perm = np.random.permutation(N)
    train_idx = perm[:n_train]
    val_idx = perm[n_train:]

    train_ds = GameFMv2Dataset(game_states[train_idx], waypoints[train_idx],
                                                             alive[train_idx], pos_mean, pos_std, wp_mean, wp_std,
                                                             pellet_slice)
    val_ds = GameFMv2Dataset(game_states[val_idx], waypoints[val_idx],
                                                         alive[val_idx], pos_mean, pos_std, wp_mean, wp_std,
                                                         pellet_slice)

    train_num_workers = int(tcfg.get('train_num_workers', 4))
    val_num_workers = int(tcfg.get('val_num_workers', 2))
    pin_memory = bool(tcfg.get('pin_memory', True))
    persistent_workers = bool(tcfg.get('persistent_workers', True))
    prefetch_factor = int(tcfg.get('prefetch_factor', 2))

    train_loader_kwargs = {
        'batch_size': tcfg['batch_size'],
        'shuffle': True,
        'num_workers': train_num_workers,
        'pin_memory': pin_memory,
        'drop_last': True,
    }
    val_loader_kwargs = {
        'batch_size': tcfg['batch_size'],
        'shuffle': False,
        'num_workers': val_num_workers,
        'pin_memory': pin_memory,
    }
    if train_num_workers > 0:
        train_loader_kwargs['persistent_workers'] = persistent_workers
        train_loader_kwargs['prefetch_factor'] = prefetch_factor
    if val_num_workers > 0:
        val_loader_kwargs['persistent_workers'] = persistent_workers
        val_loader_kwargs['prefetch_factor'] = prefetch_factor

    train_loader = DataLoader(train_ds, **train_loader_kwargs)
    val_loader = DataLoader(val_ds, **val_loader_kwargs)

    print(f'  Train: {n_train:,}, Val: {n_val:,}')
    print(f'  loaders: train_workers={train_num_workers}, '
          f'val_workers={val_num_workers}, pin_memory={pin_memory}, '
          f'persistent_workers={persistent_workers}, prefetch_factor={prefetch_factor}')

    # ─── Model ─────────────────────────────────────────────────────

    model = GameFM_v2(
        state_dim=D,
        action_dim=cfg['waypoint_dim'],
        horizon=H,
        d_model=mcfg['d_model'],
        n_heads=mcfg['n_heads'],
        n_layers=mcfg['n_layers'],
        ff_mult=mcfg['ff_mult'],
        dropout=mcfg['dropout'],
    ).to(device)

    n_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f'  Model: {n_params:,} params')

    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=tcfg['lr'],
        weight_decay=tcfg['weight_decay'],
        betas=(0.9, 0.95),
    )

    lam_ghost = lcfg['lambda_ghost']
    lam_pel = lcfg['lambda_pellet']
    lam_alive = lcfg['lambda_alive']

    # ─── Training loop ─────────────────────────────────────────────

    best_val_loss = float('inf')
    best_epoch = 0
    train_history = []
    val_history = []

    for epoch in range(tcfg['epochs']):
        lr_now = get_lr(epoch, tcfg['warmup_epochs'], tcfg['epochs'],
                        tcfg['lr'], tcfg['min_lr'])
        for pg in optimizer.param_groups:
            pg['lr'] = lr_now

        # ── Train ──
        model.train()
        train_loss_sum = 0.0
        train_ghost_sum = 0.0
        train_pel_sum = 0.0
        train_alive_sum = 0.0
        train_n = 0

        for s0, wps, ghost_tgt, pel_tgt, alive_tgt in train_loader:
            s0 = s0.to(device, non_blocking=True)
            wps = wps.to(device, non_blocking=True)
            ghost_tgt = ghost_tgt.to(device, non_blocking=True)        # (B, H, 7)
            pel_tgt = pel_tgt.to(device, non_blocking=True)             # (B, H, 46)
            alive_tgt = alive_tgt.to(device, non_blocking=True)         # (B, H)

            ghost_pred, pel_logits, alive_logits = model(s0, wps)

            # Ghost loss (auxiliary, only on alive steps)
            ghost_loss = F.mse_loss(ghost_pred * alive_tgt.unsqueeze(-1),
                                    ghost_tgt * alive_tgt.unsqueeze(-1))

            # Pellet bitmap loss: BCE per cell per step
            pel_loss = F.binary_cross_entropy_with_logits(pel_logits, pel_tgt)

            # Alive loss
            alive_loss = F.binary_cross_entropy_with_logits(alive_logits, alive_tgt)

            loss = lam_ghost * ghost_loss + lam_pel * pel_loss + lam_alive * alive_loss

            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(),
                                           tcfg['grad_clip'])
            optimizer.step()

            bs = s0.shape[0]
            train_loss_sum += loss.item() * bs
            train_ghost_sum += ghost_loss.item() * bs
            train_pel_sum += pel_loss.item() * bs
            train_alive_sum += alive_loss.item() * bs
            train_n += bs

        train_loss = train_loss_sum / train_n
        train_ghost = train_ghost_sum / train_n
        train_pel = train_pel_sum / train_n
        train_alive = train_alive_sum / train_n

        # ── Validate ──
        model.eval()
        val_loss_sum = 0.0
        val_ghost_sum = 0.0
        val_pel_sum = 0.0
        val_alive_sum = 0.0
        val_n = 0
        # Accuracy counters
        val_pel_correct = 0
        val_pel_total = 0
        val_alive_correct = 0
        val_alive_total = 0
        # Track per-cell accuracy for the "changed" cells
        val_changed_correct = 0
        val_changed_total = 0

        with torch.no_grad():
            for s0, wps, ghost_tgt, pel_tgt, alive_tgt in val_loader:
                s0 = s0.to(device, non_blocking=True)
                wps = wps.to(device, non_blocking=True)
                ghost_tgt = ghost_tgt.to(device, non_blocking=True)
                pel_tgt = pel_tgt.to(device, non_blocking=True)
                alive_tgt = alive_tgt.to(device, non_blocking=True)

                ghost_pred, pel_logits, alive_logits = model(s0, wps)

                ghost_loss = F.mse_loss(ghost_pred * alive_tgt.unsqueeze(-1),
                                        ghost_tgt * alive_tgt.unsqueeze(-1))
                pel_loss = F.binary_cross_entropy_with_logits(pel_logits, pel_tgt)
                alive_loss = F.binary_cross_entropy_with_logits(alive_logits, alive_tgt)
                loss = lam_ghost * ghost_loss + lam_pel * pel_loss + lam_alive * alive_loss

                bs = s0.shape[0]
                val_loss_sum += loss.item() * bs
                val_ghost_sum += ghost_loss.item() * bs
                val_pel_sum += pel_loss.item() * bs
                val_alive_sum += alive_loss.item() * bs
                val_n += bs

                # Per-cell pellet accuracy
                pel_preds = (torch.sigmoid(pel_logits) > 0.5).float()
                val_pel_correct += (pel_preds == pel_tgt).float().sum().item()
                val_pel_total += pel_tgt.numel()

                # Accuracy on cells that CHANGED from s₀
                s0_pel = s0[:, pellet_slice].unsqueeze(1).expand_as(pel_tgt)
                changed_mask = (s0_pel != pel_tgt)  # cells that changed
                if changed_mask.any():
                    val_changed_correct += (pel_preds[changed_mask] == pel_tgt[changed_mask]).float().sum().item()
                    val_changed_total += changed_mask.sum().item()

                # Alive accuracy
                alive_preds = (torch.sigmoid(alive_logits) > 0.5).float()
                val_alive_correct += (alive_preds == alive_tgt).float().sum().item()
                val_alive_total += alive_tgt.numel()

        val_loss = val_loss_sum / val_n
        val_ghost = val_ghost_sum / val_n
        val_pel = val_pel_sum / val_n
        val_alive = val_alive_sum / val_n
        val_pel_acc = val_pel_correct / max(val_pel_total, 1)
        val_alive_acc = val_alive_correct / max(val_alive_total, 1)
        val_changed_acc = val_changed_correct / max(val_changed_total, 1)

        # Ghost RMSE in physical units
        ghost_std = cont_std[:6].mean()
        val_ghost_rmse_phys = math.sqrt(val_ghost) * ghost_std

        train_history.append(train_loss)
        val_history.append(val_loss)

        # ── Logging ──
        improved = ''
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            best_epoch = epoch
            improved = ' *BEST*'

            torch.save({
                'model_state_dict': model.state_dict(),
                'model_type': 'game_fm_v2_bitmap',
                'state_dim': D,
                'action_dim': cfg['waypoint_dim'],
                'horizon': H,
                'd_model': mcfg['d_model'],
                'n_heads': mcfg['n_heads'],
                'n_layers': mcfg['n_layers'],
                'ff_mult': mcfg['ff_mult'],
                'dropout': mcfg['dropout'],
                'state_layout': layout['name'],
                'epoch': epoch,
                'val_loss': best_val_loss,
                'pos_mean': pos_mean.tolist(),
                'pos_std': pos_std.tolist(),
                'cont_mean': cont_mean.tolist(),
                'cont_std': cont_std.tolist(),
                'wp_mean': wp_mean.tolist(),
                'wp_std': wp_std.tolist(),
                'config': cfg,
            }, out_dir / 'best_model.pt')

        print(f'Ep {epoch+1:3d}/{tcfg["epochs"]}  '
              f'lr={lr_now:.1e}  '
              f'train={train_loss:.4f} (ghost={train_ghost:.4f} pel={train_pel:.4f} alive={train_alive:.4f})  '
              f'val={val_loss:.4f} (ghost={val_ghost:.4f} pel={val_pel:.4f} alive={val_alive:.4f})  '
              f'pel_acc={val_pel_acc:.4f} changed_acc={val_changed_acc:.4f} alive_acc={val_alive_acc:.4f}  '
              f'ghost_rmse={val_ghost_rmse_phys:.3f}{improved}')

        # Progress JSON
        progress = {
            'experiment': cfg['experiment'],
            'epoch': epoch + 1,
            'total_epochs': tcfg['epochs'],
            'train_loss': float(train_loss),
            'val_loss': float(val_loss),
            'val_ghost_loss': float(val_ghost),
            'val_pel_loss': float(val_pel),
            'val_alive_loss': float(val_alive),
            'val_pel_acc': float(val_pel_acc),
            'val_changed_acc': float(val_changed_acc),
            'val_alive_acc': float(val_alive_acc),
            'val_ghost_rmse_phys': float(val_ghost_rmse_phys),
            'best_val_loss': float(best_val_loss),
            'best_epoch': best_epoch + 1,
            'lr': float(lr_now),
        }
        with open(out_dir / 'progress.json', 'w') as f:
            json.dump(progress, f, indent=2)

        # Checkpoint every 50 epochs
        if (epoch + 1) % 50 == 0:
            torch.save({
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'epoch': epoch,
                'best_val_loss': best_val_loss,
                'train_history': train_history,
                'val_history': val_history,
            }, out_dir / f'checkpoint_ep{epoch+1}.pt')

    # ── Final summary ──
    print(f'\n=== Training Complete ===')
    print(f'Best val_loss: {best_val_loss:.6f} @ epoch {best_epoch+1}')

    with open(out_dir / 'history.json', 'w') as f:
        json.dump({
            'train_loss': train_history,
            'val_loss': val_history,
        }, f)

    print(f'Output: {out_dir}')


if __name__ == '__main__':
    main()
