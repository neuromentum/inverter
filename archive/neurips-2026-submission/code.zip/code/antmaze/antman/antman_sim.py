#!/usr/bin/env python3
"""
AntMan simulated game — dry-run without MuJoCo.

The ant 'teleports' one cell per step toward its strategy target.
Tests the full game logic, strategy, ghost AI, scoring, and win/loss
without needing IWM or physics.

Usage:
    python antmaze/antman/antman_sim.py --n_ghosts 1 --ghost_interval 10
    python antmaze/antman/antman_sim.py --n_ghosts 3 --ghost_interval 6 --render
"""

import argparse
import numpy as np

from antmaze.antman.game import AntManGame
from antmaze.antman.strategy import AntManStrategy
from antmaze.antman.render import render_ascii
from antmaze.navigate_cardinal import MAZE_CONFIGS


ANT_START_CELL = (3, 6)  # roughly center of large-diverse


def run_simulated_game(n_ghosts=1, ghost_move_interval=10,
                       max_steps=3000, render=False, verbose=True):
    """Simulate a full AntMan game with teleporting ant.

    Returns:
        dict with outcome, score, steps, pellets_eaten, etc.
    """
    cfg = MAZE_CONFIGS['large-diverse']
    game = AntManGame(
        cfg['maze_map'], cfg['scaling'], cfg['torso_x'], cfg['torso_y'],
        n_ghosts=n_ghosts,
        ghost_move_interval=ghost_move_interval,
        max_steps=max_steps,
    )
    game.reset()
    strategy = AntManStrategy(game)

    # Starting position
    ant_cell = ANT_START_CELL
    ant_heading = (0, 1)  # facing right
    target_cell = ant_cell

    ghost_names = [g.name.capitalize() for g in game.ghosts]
    n_regular = sum(1 for p in game.pellets if not p.is_power)
    n_power = sum(1 for p in game.pellets if p.is_power)

    if verbose:
        print(f'=== AntMan Simulated Game ===')
        print(f'Ghosts: {n_ghosts} ({", ".join(ghost_names)}), '
              f'move every {ghost_move_interval} steps')
        print(f'Pellets: {n_regular} regular + {n_power} power = '
              f'{len(game.pellets)} total')
        print()

    # BFS path from ant to target — we follow it one cell at a time
    path = []
    path_idx = 0

    for step in range(max_steps):
        # Get world coords for current cell
        ant_xy = game.cell_to_world(*ant_cell)

        # Re-pick target every step (strategy is reactive)
        target_cell, reason = strategy.choose_target_cell(ant_cell, ant_heading)

        # Plan BFS path to target
        path = game.bfs_path(ant_cell, target_cell)
        if path and len(path) >= 2:
            next_cell = path[1]
            # Update heading
            dr = next_cell[0] - ant_cell[0]
            dc = next_cell[1] - ant_cell[1]
            if dr != 0 or dc != 0:
                ant_heading = (dr, dc)
            ant_cell = next_cell
        # else: already at target, stay put

        # Move ant to new cell
        ant_xy = game.cell_to_world(*ant_cell)

        # Game tick
        events = game.tick(ant_xy, np.array([ant_heading[1], ant_heading[0]],
                                            dtype=np.float32), step)

        # Logging
        if verbose and (step % 50 == 0 or events['pellet_eaten']
                        or events['caught'] or events['ate_ghost']
                        or events['all_cleared']):
            ghost_info = '  '.join(
                f'{g.name.capitalize()} ({g.row},{g.col})'
                for g in game.ghosts
            )
            reason = ''
            if events['caught']:
                reason = f'  ** CAUGHT by {events["caught_by"]}! **'
            elif events['ate_ghost']:
                reason = f'  ** ATE {events["ate_ghost_name"]}! +200 **'
            elif events['power_activated']:
                reason = '  [POWER!]'
            elif events['all_cleared']:
                reason = '  *** ALL PELLETS CLEARED! ***'

            print(f'Step {step:4d}:  Ant ({ant_cell[0]},{ant_cell[1]})  '
                  f'{ghost_info}  Score: {game.score:5d}  '
                  f'Pellets: {game.pellets_remaining:2d}{reason}')

        if render and step % 20 == 0:
            print()
            print(render_ascii(game, ant_xy, color=True))
            print()

        if game.is_over():
            break

    # Final result
    outcome = 'cleared' if game.all_pellets_eaten() else (
        'caught' if game._caught else 'timeout')

    result = {
        'outcome': outcome,
        'score': game.score,
        'steps': step + 1,
        'pellets_eaten': game.pellets_total - game.pellets_remaining,
        'pellets_total': game.pellets_total,
        'ghosts_eaten': game._ghosts_eaten_total,
        'n_ghosts': n_ghosts,
        'ghost_move_interval': ghost_move_interval,
    }

    if verbose:
        print()
        print(f'=== Game Over: {outcome.upper()} ===')
        print(f'Score: {game.score}  |  Steps: {step+1}  |  '
              f'Pellets: {game.pellets_total - game.pellets_remaining}/'
              f'{game.pellets_total}  |  Ghosts eaten: {game._ghosts_eaten_total}')

    return result


def main():
    parser = argparse.ArgumentParser(description='AntMan simulated game')
    parser.add_argument('--n_ghosts', type=int, default=1)
    parser.add_argument('--ghost_interval', type=int, default=10)
    parser.add_argument('--max_steps', type=int, default=3000)
    parser.add_argument('--render', action='store_true',
                        help='Show ASCII rendering every 20 steps')
    parser.add_argument('--quiet', action='store_true')
    args = parser.parse_args()

    run_simulated_game(
        n_ghosts=args.n_ghosts,
        ghost_move_interval=args.ghost_interval,
        max_steps=args.max_steps,
        render=args.render,
        verbose=not args.quiet,
    )


if __name__ == '__main__':
    main()
