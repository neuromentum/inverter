"""
AntMan rendering — ASCII terminal display and matplotlib figures.
"""

import numpy as np
from typing import List, Optional, Tuple

from antmaze.antman.game import AntManGame


# ─── Ghost display names / symbols ────────────────────────────────────

GHOST_ASCII = {
    'blinky': '\033[91m♦\033[0m',  # red
    'pinky':  '\033[95m♦\033[0m',  # magenta
    'inky':   '\033[96m♦\033[0m',  # cyan
}
GHOST_FRIGHT = '\033[94m♦\033[0m'  # blue (frightened)
ANT_CHAR = '\033[92m@\033[0m'      # green

GHOST_ASCII_PLAIN = {'blinky': 'B', 'pinky': 'P', 'inky': 'I'}
GHOST_FRIGHT_PLAIN = 'F'
ANT_CHAR_PLAIN = '@'


def render_ascii(game: AntManGame, ant_xy: np.ndarray,
                 color: bool = True) -> str:
    """Return ASCII art string of the current game state.

    Args:
        game: AntManGame instance
        ant_xy: world [x, y] position of the ant
        color: if True, use ANSI color codes
    """
    ant_cell = game.get_ant_cell(ant_xy)

    # Build lookup maps
    ghost_map = {}  # (r,c) → ghost
    for g in game.ghosts:
        if not g.eaten:
            ghost_map[(g.row, g.col)] = g

    pellet_map = {}  # (r,c) → pellet
    for p in game.pellets:
        if not p.eaten:
            pellet_map[(p.row, p.col)] = p

    # Header
    pellets_left = sum(1 for p in game.pellets if not p.eaten)
    pellets_total = len(game.pellets)
    lines = []
    lines.append(f'Step {game._step:4d} | Score: {game._score:5d} | '
                 f'Pellets: {pellets_left}/{pellets_total} | '
                 f'Fright: {game.fright_remaining}')
    lines.append('')

    # Maze grid
    for r in range(game.n_rows):
        row_chars = []
        for c in range(game.n_cols):
            if game.maze_map[r][c] == 1:
                row_chars.append('█')
            elif (r, c) == ant_cell:
                row_chars.append(ANT_CHAR if color else ANT_CHAR_PLAIN)
            elif (r, c) in ghost_map:
                gh = ghost_map[(r, c)]
                if gh.frightened:
                    row_chars.append(GHOST_FRIGHT if color else GHOST_FRIGHT_PLAIN)
                elif color:
                    row_chars.append(GHOST_ASCII.get(gh.name, '♦'))
                else:
                    row_chars.append(GHOST_ASCII_PLAIN.get(gh.name, '?'))
            elif (r, c) in pellet_map:
                p = pellet_map[(r, c)]
                if p.is_power:
                    row_chars.append('\033[93mO\033[0m' if color else 'O')
                else:
                    row_chars.append('·')
            elif (r, c) in game._open_set:
                row_chars.append(' ')
            else:
                row_chars.append('█')
            row_chars.append(' ')
        lines.append(''.join(row_chars).rstrip())

    return '\n'.join(lines)


def render_matplotlib(game: AntManGame, ant_xy: np.ndarray,
                      ant_trail: Optional[List[np.ndarray]] = None,
                      ghost_trails: Optional[dict] = None,
                      save_path: Optional[str] = None,
                      show: bool = False):
    """Render current frame as a matplotlib figure.

    Args:
        game: AntManGame instance
        ant_xy: world [x, y] position of the ant
        ant_trail: list of previous ant [x,y] positions for trajectory
        ghost_trails: dict {ghost_name: [(x,y), ...]} for ghost paths
        save_path: if set, save figure as PNG
        show: if True, call plt.show()
    """
    import matplotlib.pyplot as plt
    import matplotlib.patches as mpatches
    from matplotlib.collections import PatchCollection

    fig, ax = plt.subplots(1, 1, figsize=(10, 8))
    ax.set_aspect('equal')

    scaling = game.scaling
    tx, ty = game.torso_x, game.torso_y

    # Draw walls
    wall_patches = []
    for r in range(game.n_rows):
        for c in range(game.n_cols):
            if game.maze_map[r][c] == 1:
                x = c * scaling - tx - scaling / 2
                y = r * scaling - ty - scaling / 2
                wall_patches.append(mpatches.Rectangle((x, y), scaling, scaling))
    if wall_patches:
        wall_col = PatchCollection(wall_patches, facecolor='#333333',
                                   edgecolor='#555555', linewidth=0.5)
        ax.add_collection(wall_col)

    # Draw pellets
    for p in game.pellets:
        if p.eaten:
            continue
        x, y = float(p.world_xy[0]), float(p.world_xy[1])
        if p.is_power:
            ax.plot(x, y, 'o', color='gold', markersize=10, zorder=3)
        else:
            ax.plot(x, y, '.', color='white', markersize=5, zorder=3)

    # Draw ant trail
    if ant_trail and len(ant_trail) > 1:
        trail = np.array(ant_trail)
        n = len(trail)
        for i in range(1, n):
            alpha = 0.1 + 0.4 * (i / n)
            ax.plot(trail[i - 1:i + 1, 0], trail[i - 1:i + 1, 1],
                    '-', color='lime', alpha=alpha, linewidth=1.5, zorder=2)

    # Draw ghosts
    ghost_colors = {'blinky': 'red', 'pinky': 'magenta', 'inky': 'cyan'}
    for g in game.ghosts:
        if g.eaten:
            continue
        gx, gy = game.cell_to_world(g.row, g.col)
        c = 'blue' if g.frightened else ghost_colors.get(g.name, 'red')
        ax.plot(float(gx), float(gy), 's', color=c, markersize=14,
                markeredgecolor='white', markeredgewidth=1.5, zorder=5)
        ax.text(float(gx), float(gy), g.name[0].upper(),
                ha='center', va='center', fontsize=8,
                fontweight='bold', color='white', zorder=6)

    # Draw ghost trails
    if ghost_trails:
        for gname, trail in ghost_trails.items():
            if len(trail) > 1:
                t = np.array(trail)
                gc = ghost_colors.get(gname, 'red')
                ax.plot(t[:, 0], t[:, 1], '--', color=gc, alpha=0.3,
                        linewidth=1, zorder=1)

    # Draw ant
    ax.plot(float(ant_xy[0]), float(ant_xy[1]), 'o', color='lime',
            markersize=12, markeredgecolor='darkgreen', markeredgewidth=2,
            zorder=7)

    # Info text
    pellets_left = sum(1 for p in game.pellets if not p.eaten)
    info = (f'Step {game._step}  |  Score: {game._score}  |  '
            f'Pellets: {pellets_left}/{len(game.pellets)}')
    ax.set_title(info, fontsize=12, fontweight='bold', color='white')

    # Styling
    ax.set_facecolor('black')
    fig.patch.set_facecolor('black')
    ax.tick_params(colors='gray')
    for spine in ax.spines.values():
        spine.set_color('gray')

    # Axis limits
    xs = [c * scaling - tx for c in range(game.n_cols)]
    ys = [r * scaling - ty for r in range(game.n_rows)]
    margin = scaling
    ax.set_xlim(min(xs) - margin, max(xs) + margin)
    ax.set_ylim(min(ys) - margin, max(ys) + margin)

    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches='tight',
                    facecolor='black')
    if show:
        plt.show()
    else:
        plt.close(fig)
    return fig


def render_episode_summary(game_log: dict, save_path: str):
    """Render full-episode trajectory + ghost paths on one figure.

    Args:
        game_log: dict with keys 'ant_trail' (list of [x,y]),
                  'ghost_trails' ({name: list of [x,y]}),
                  'game' (AntManGame), 'final_ant_xy' (np.array)
    """
    render_matplotlib(
        game=game_log['game'],
        ant_xy=game_log['final_ant_xy'],
        ant_trail=game_log['ant_trail'],
        ghost_trails=game_log.get('ghost_trails'),
        save_path=save_path,
    )
