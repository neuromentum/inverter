#!/usr/bin/env python3
"""
Train IWM with DIRECTION-BASED outputs (N/S/E/W) instead of 46-cell targets.
Uses FM v2 (per-cell pellet bitmap) for gradient signal.

Key change from train_iwm_tfm_v2.py:
  The output head produces 4 direction logits (Up/Down/Right/Left) instead
  of 46 cell logits. This dramatically reduces output space and eliminates
  the inductive bias where a random/zero-init network freezes in place
  (all 46 logits tied → deterministic argmax → always pick same cell).

  With 4 directions, Gumbel-softmax gives ~25% per valid direction at init,
  producing genuine random-walk exploration from the very first epoch.

Architecture:
  game_state(55D) → MLP encoder → z(d_model)           [context token]
  causal Transformer decoder: z + H learnable queries → H output tokens
  output_proj(d_model → 4) → dir_logits(B, H, 4)
  Gumbel-softmax + valid_dirs mask → dir_weights(B, H, 4)
  cell_weights = dir_weights @ NEXT_CELL_ONEHOT[prev_cell]  (B, H, 46)
  wp_pred = cell_weights @ waypoints_norm                    (B, H, 2)

Usage:
    python -u antmaze/antman/train_iwm_tfm_dir.py \
        --config antmaze/antman/iwm/L32/direction/.../config.json
"""

import os, sys, argparse, json, time, math
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT_ROOT))

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

from antmaze.antman.game_state import (
    CONTINUOUS_SLICE,
    GAME_STATE_DIM,
    N_CELLS as GAME_STATE_N_CELLS,
    get_state_layout,
)

# ─── Maze / waypoint table (inlined for self-containment) ──────────────

MAZE_MAP = [
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1],
    [1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1],
    [1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1],
    [1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1],
    [1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1],
    [1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
]
SCALING = 4.0
TORSO_X = 4.0
TORSO_Y = 4.0

OPEN_CELLS = []
for _r in range(len(MAZE_MAP)):
    for _c in range(len(MAZE_MAP[0])):
        if MAZE_MAP[_r][_c] == 0:
            OPEN_CELLS.append((_r, _c))
OPEN_CELLS = tuple(OPEN_CELLS)
N_CELLS = len(OPEN_CELLS)  # 46

CELL_TO_IDX = {rc: i for i, rc in enumerate(OPEN_CELLS)}
CELL_NEIGHBORS = {}
for _i, (_r, _c) in enumerate(OPEN_CELLS):
    nbrs = []
    for dr, dc in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
        nr, nc = _r + dr, _c + dc
        if (nr, nc) in CELL_TO_IDX:
            nbrs.append(CELL_TO_IDX[(nr, nc)])
    CELL_NEIGHBORS[_i] = tuple(nbrs)

WAYPOINTS_WORLD = np.array(
    [(_c * SCALING - TORSO_X, _r * SCALING - TORSO_Y) for _r, _c in OPEN_CELLS],
    dtype=np.float32,
)

_ADJ_MATRIX = np.zeros((N_CELLS, N_CELLS), dtype=np.float32)
for _i in range(N_CELLS):
    _ADJ_MATRIX[_i, _i] = 1.0
    for _j in CELL_NEIGHBORS[_i]:
        _ADJ_MATRIX[_i, _j] = 1.0

# All-pairs BFS for GT cell sequence extraction
from collections import deque
_DIST = np.full((N_CELLS, N_CELLS), 999, dtype=np.int32)
for _src in range(N_CELLS):
    _DIST[_src, _src] = 0
    _q = deque([_src])
    while _q:
        _u = _q.popleft()
        for _v in CELL_NEIGHBORS.get(_u, []):
            if _DIST[_src, _v] == 999:
                _DIST[_src, _v] = _DIST[_src, _u] + 1
                _q.append(_v)

# ─── Direction lookup tables ────────────────────────────────────

DIR_DELTAS = [(-1, 0), (1, 0), (0, 1), (0, -1)]  # Up, Down, Right, Left
DIR_NAMES = ['Up', 'Down', 'Right', 'Left']
N_DIRS = 4

_VALID_DIRS = np.zeros((N_CELLS, N_DIRS), dtype=np.float32)
_NEXT_CELL = np.zeros((N_CELLS, N_DIRS), dtype=np.int64)

for _i, (_r, _c) in enumerate(OPEN_CELLS):
    for _d, (_dr, _dc) in enumerate(DIR_DELTAS):
        _nr, _nc = _r + _dr, _c + _dc
        if (_nr, _nc) in CELL_TO_IDX:
            _VALID_DIRS[_i, _d] = 1.0
            _NEXT_CELL[_i, _d] = CELL_TO_IDX[(_nr, _nc)]
        else:
            _NEXT_CELL[_i, _d] = _i  # self-loop (masked out in forward)

# One-hot lookup: NEXT_CELL_ONEHOT[cell, dir] = one_hot(next_cell)
_NEXT_CELL_ONEHOT = np.zeros((N_CELLS, N_DIRS, N_CELLS), dtype=np.float32)
for _i in range(N_CELLS):
    for _d in range(N_DIRS):
        _NEXT_CELL_ONEHOT[_i, _d, _NEXT_CELL[_i, _d]] = 1.0

# Cell-pair → direction lookup for GT conversion
# _CELL_PAIR_TO_DIR[prev, next] = direction index, or -1 if not adjacent
_CELL_PAIR_TO_DIR = np.full((N_CELLS, N_CELLS), -1, dtype=np.int64)
for _i in range(N_CELLS):
    for _d in range(N_DIRS):
        if _VALID_DIRS[_i, _d] > 0.5:
            _j = _NEXT_CELL[_i, _d]
            _CELL_PAIR_TO_DIR[_i, _j] = _d


# ═════════════════════════════════════════════════════════════════════════
# GameFM v2 (frozen, from train_game_fm_v2.py — inlined)
# Predicts full 46-cell pellet bitmap per step (not scalar did-eat)
# ═════════════════════════════════════════════════════════════════════════

class GameFM_v2(nn.Module):
    CONT_START = 2
    CONT_END = 9
    N_CONT = CONT_END - CONT_START
    N_PELLETS = GAME_STATE_N_CELLS

    def __init__(self, state_dim=GAME_STATE_DIM, action_dim=2, horizon=32,
                 d_model=128, n_heads=4, n_layers=4, ff_mult=3,
                 dropout=0.1):
        super().__init__()
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.horizon = horizon
        self.d_model = d_model
        self.n_heads = n_heads
        self.n_layers_tfm = n_layers
        self.layout = get_state_layout(state_dim)
        self.pellet_slice = self.layout['pellets']

        self.state_embed = nn.Sequential(
            nn.Linear(state_dim, d_model), nn.GELU(),
            nn.LayerNorm(d_model), nn.Linear(d_model, d_model),
        )
        self.action_embed = nn.Sequential(
            nn.Linear(action_dim, d_model), nn.GELU(),
            nn.LayerNorm(d_model), nn.Linear(d_model, d_model),
        )
        self.pos_embed = nn.Parameter(torch.randn(1, horizon + 1, d_model) * 0.02)
        self.type_embed = nn.Parameter(torch.randn(1, 2, d_model) * 0.02)

        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model, nhead=n_heads,
            dim_feedforward=d_model * ff_mult,
            dropout=dropout, activation='gelu',
            batch_first=True, norm_first=True,
        )
        self.transformer = nn.TransformerEncoder(
            encoder_layer, num_layers=n_layers, norm=nn.LayerNorm(d_model),
        )
        self.ghost_head = nn.Sequential(
            nn.Linear(d_model, d_model // 2), nn.GELU(),
            nn.Linear(d_model // 2, self.N_CONT),
        )
        # Per-cell pellet bitmap: 46 logits per step (P(remaining))
        self.pellet_head = nn.Sequential(
            nn.Linear(d_model, d_model), nn.GELU(),
            nn.Linear(d_model, self.N_PELLETS),
        )
        self.alive_head = nn.Sequential(
            nn.Linear(d_model, d_model // 2), nn.GELU(),
            nn.Linear(d_model // 2, 1),
        )
        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
        nn.init.zeros_(self.ghost_head[-1].weight)
        nn.init.zeros_(self.ghost_head[-1].bias)
        nn.init.zeros_(self.pellet_head[-1].weight)
        nn.init.zeros_(self.pellet_head[-1].bias)
        nn.init.zeros_(self.alive_head[-1].weight)
        nn.init.zeros_(self.alive_head[-1].bias)

    def forward(self, state, waypoints):
        B = state.shape[0]
        H = self.horizon
        s_tok = self.state_embed(state).unsqueeze(1)
        a_tok = self.action_embed(waypoints)
        tokens = torch.cat([s_tok, a_tok], dim=1)
        tokens = tokens + self.pos_embed[:, :H + 1, :]
        tokens[:, 0, :] = tokens[:, 0, :] + self.type_embed[:, 0, :]
        tokens[:, 1:, :] = tokens[:, 1:, :] + self.type_embed[:, 1, :]
        causal_mask = torch.triu(
            torch.full((H + 1, H + 1), float('-inf'), device=tokens.device),
            diagonal=1,
        )
        out = self.transformer(tokens, mask=causal_mask)
        out_wp = out[:, 1:, :]
        ghost_delta = self.ghost_head(out_wp)
        s0_cont = state[:, self.CONT_START:self.CONT_END].unsqueeze(1)
        ghost_pred = s0_cont + ghost_delta
        # Pellet bitmap: residual from s₀ pellet logits
        s0_pel = state[:, self.pellet_slice]                 # (B, 46)
        s0_pel_logit = (s0_pel * 6.0 - 3.0).unsqueeze(1)    # (B, 1, 46)
        pel_delta = self.pellet_head(out_wp)                  # (B, H, 46)
        pellet_logits = s0_pel_logit + pel_delta              # (B, H, 46)
        alive_logits = self.alive_head(out_wp).squeeze(-1)
        return ghost_pred, pellet_logits, alive_logits


# ═════════════════════════════════════════════════════════════════════════
# IWM Direction — Autoregressive Transformer with 4-way Direction Output
# ═════════════════════════════════════════════════════════════════════════

class IWMDirectionTransformer(nn.Module):
    """Autoregressive Transformer IWM with direction-based outputs.

    Instead of choosing among 46 cells, the output head produces 4 logits
    (Up/Down/Right/Left). Invalid directions (walls) are masked to -inf.
    Gumbel-softmax selects a direction, then a precomputed lookup table
    maps (current_cell, direction) → next_cell one-hot → waypoint.

    This eliminates the inductive bias where zero-init over 46 cells causes
    deterministic tie-breaking to freeze the agent in place. With 4 outputs,
    the network starts with ~uniform exploration over valid directions.
    """

    def __init__(self, state_dim=GAME_STATE_DIM, n_cells=46, n_dirs=4, horizon=32,
                 d_model=128, n_heads=4, n_layers=4, ff_mult=3,
                 dropout=0.1, tau_init=1.0, tau_end=0.1):
        super().__init__()
        self.state_dim = state_dim
        self.n_cells = n_cells
        self.n_dirs = n_dirs
        self.horizon = horizon
        self.d_model = d_model
        self.tau = tau_init

        # Encoder: game state → context token
        self.encoder = nn.Sequential(
            nn.Linear(state_dim, d_model), nn.GELU(),
            nn.LayerNorm(d_model), nn.Dropout(dropout),
            nn.Linear(d_model, d_model), nn.GELU(),
            nn.LayerNorm(d_model),
        )

        # Learnable step queries (one per timestep)
        self.step_queries = nn.Parameter(torch.randn(1, horizon, d_model) * 0.02)

        # Positional encoding for [context, step_0, step_1, ..., step_{H-1}]
        self.pos_embed = nn.Parameter(torch.randn(1, horizon + 1, d_model) * 0.02)

        # Causal Transformer decoder
        decoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model, nhead=n_heads,
            dim_feedforward=d_model * ff_mult,
            dropout=dropout, activation='gelu',
            batch_first=True, norm_first=True,
        )
        self.transformer = nn.TransformerEncoder(
            decoder_layer, num_layers=n_layers, norm=nn.LayerNorm(d_model),
        )

        # Output: d_model → N_DIRS (4) logits per step
        self.output_proj = nn.Linear(d_model, n_dirs)

        # Constant buffers
        self.register_buffer('valid_dirs', torch.tensor(_VALID_DIRS))           # (46, 4)
        self.register_buffer('next_cell_onehot', torch.tensor(_NEXT_CELL_ONEHOT))  # (46, 4, 46)
        self.register_buffer('waypoints_norm', torch.zeros(n_cells, 2))         # (46, 2)

        # Causal mask
        mask = torch.triu(
            torch.full((horizon + 1, horizon + 1), float('-inf')),
            diagonal=1,
        )
        self.register_buffer('causal_mask', mask)

        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
        # Zero-init output projection — with 4 outputs, Gumbel-softmax gives
        # ~uniform over valid directions (much better than 46-cell case)
        nn.init.zeros_(self.output_proj.weight)
        nn.init.zeros_(self.output_proj.bias)

    def _nearest_cell(self, ant_xy_norm):
        """Map normalized ant xy to nearest cell index."""
        diff = ant_xy_norm.unsqueeze(1) - self.waypoints_norm.unsqueeze(0)
        dist_sq = (diff ** 2).sum(-1)
        return dist_sq.argmin(dim=-1)

    def forward(self, game_state, ant_xy_norm, hard=None):
        """
        Args:
            game_state: (B, 55) normalized game state
            ant_xy_norm: (B, 2) ant xy in wp-normalized coords
            hard: if True, use hard Gumbel-softmax (straight-through).

        Returns:
            wp_pred: (B, H, 2) predicted waypoints (normalized coords)
            cell_weights: (B, H, N_CELLS) cell one-hot per step
            dir_probs: (B, H, N_DIRS) soft direction probabilities (for entropy)
        """
        B = game_state.shape[0]
        H = self.horizon

        if hard is None:
            hard = not self.training

        # Encode game state → context token
        ctx = self.encoder(game_state).unsqueeze(1)  # (B, 1, d_model)

        # Build input sequence: [context, step_query_0, ..., step_query_{H-1}]
        queries = self.step_queries.expand(B, -1, -1)
        tokens = torch.cat([ctx, queries], dim=1)
        tokens = tokens + self.pos_embed

        # Causal Transformer
        out = self.transformer(tokens, mask=self.causal_mask)
        out_steps = out[:, 1:, :]  # (B, H, d_model)

        # Direction logits (4 per step, not 46)
        raw_logits = self.output_proj(out_steps)  # (B, H, 4)

        # Reverse direction map: Up↔Down, Right↔Left
        # DIR_DELTAS = [(-1,0), (1,0), (0,1), (0,-1)]  → Up=0, Down=1, Right=2, Left=3
        reverse_dir = torch.tensor([1, 0, 3, 2], device=game_state.device)
        use_soft_rollout = self.training and not hard

        # Autoregressive: use a soft cell-distribution rollout during training
        # so future reward gradients can reach earlier decisions. Keep hard
        # discrete rollouts for evaluation/visualization.
        cell_weights = torch.zeros(B, H, self.n_cells, device=game_state.device)
        dir_probs = torch.zeros(B, H, self.n_dirs, device=game_state.device)
        if use_soft_rollout:
            prev_cell_dist = F.one_hot(
                self._nearest_cell(ant_xy_norm), self.n_cells
            ).float()
            prev_dir_dist = None
            valid_count_per_cell = self.valid_dirs.sum(dim=-1)  # (46,)

            for t in range(H):
                # Expected validity under the current soft cell distribution.
                valid_prob = prev_cell_dist @ self.valid_dirs  # (B, 4)
                dir_mask = torch.where(
                    valid_prob > 1e-6,
                    valid_prob.clamp(min=1e-6).log(),
                    torch.full_like(valid_prob, -1e9),
                )

                # Anti-oscillation under a soft previous-direction distribution.
                if prev_dir_dist is not None:
                    rev_penalty = prev_dir_dist[:, reverse_dir]  # (B, 4)
                    exp_n_valid = prev_cell_dist @ valid_count_per_cell  # (B,)
                    penalty_scale = torch.where(
                        exp_n_valid > 1.5,
                        torch.full_like(exp_n_valid, -5.0),
                        torch.zeros_like(exp_n_valid),
                    )
                    dir_mask = dir_mask + rev_penalty * penalty_scale.unsqueeze(-1)

                masked_logits = raw_logits[:, t, :] + dir_mask  # (B, 4)
                dir_probs[:, t, :] = F.softmax(masked_logits, dim=-1)
                dir_weights = F.gumbel_softmax(masked_logits, tau=self.tau, hard=False)

                # Expected transition from current soft cell distribution.
                lookup = torch.einsum(
                    'bn,ndm->bdm', prev_cell_dist, self.next_cell_onehot
                )  # (B, 4, 46)
                cell_w = torch.einsum('bd,bdn->bn', dir_weights, lookup)  # (B, 46)
                cell_w = cell_w / cell_w.sum(dim=-1, keepdim=True).clamp(min=1e-8)

                cell_weights[:, t, :] = cell_w
                prev_cell_dist = cell_w
                prev_dir_dist = dir_probs[:, t, :]
        else:
            prev_dir = None  # track last direction taken

            for t in range(H):
                if t == 0:
                    prev_cell = self._nearest_cell(ant_xy_norm)  # (B,)
                else:
                    prev_cell = cell_weights[:, t-1, :].argmax(dim=-1)  # (B,)

                # Valid direction mask for each sample's current cell
                valid = self.valid_dirs[prev_cell]  # (B, 4)
                dir_mask = torch.where(valid > 0.5, 0.0, -1e9)

                # Anti-oscillation: penalize reverse of last direction
                # Apply a soft penalty (-5) rather than hard mask, so the model
                # CAN go back if it's the only good option (dead-end corridors)
                if prev_dir is not None:
                    rev = reverse_dir[prev_dir]  # (B,)
                    rev_onehot = F.one_hot(rev, self.n_dirs).float()  # (B, 4)
                    # Only penalize if there are other valid directions
                    n_valid = (valid > 0.5).sum(dim=-1, keepdim=True).float()  # (B, 1)
                    # If 2+ valid dirs, apply penalty; if only 1, don't penalize
                    penalty = torch.where(n_valid > 1.5, -5.0, 0.0)
                    dir_mask = dir_mask + rev_onehot * penalty

                masked_logits = raw_logits[:, t, :] + dir_mask  # (B, 4)

                # Store soft probs for entropy (before Gumbel noise)
                dir_probs[:, t, :] = F.softmax(masked_logits, dim=-1)

                if self.training:
                    dir_weights = F.gumbel_softmax(masked_logits, tau=self.tau, hard=hard)
                else:
                    idx = masked_logits.argmax(dim=-1)
                    dir_weights = F.one_hot(idx, self.n_dirs).float()

                # Track which direction was taken
                prev_dir = dir_weights.argmax(dim=-1)  # (B,)

                # Differentiable cell lookup: dir_weights @ next_cell_onehot[prev_cell]
                lookup = self.next_cell_onehot[prev_cell]  # (B, 4, 46)
                cell_w = torch.einsum('bd,bdn->bn', dir_weights, lookup)  # (B, 46)
                cell_weights[:, t, :] = cell_w

        # Weighted sum of waypoints
        wp_pred = cell_weights @ self.waypoints_norm  # (B, H, 2)

        return wp_pred, cell_weights, dir_probs

    def set_waypoints_norm(self, wp_mean, wp_std, device=None):
        wp_norm = (WAYPOINTS_WORLD - wp_mean) / wp_std
        self.waypoints_norm = torch.tensor(wp_norm, dtype=torch.float32)
        if device is not None:
            self.waypoints_norm = self.waypoints_norm.to(device)

    def get_hard_cells(self, game_state, ant_xy_norm):
        with torch.no_grad():
            _, weights, _ = self.forward(game_state, ant_xy_norm)
        return weights.argmax(dim=-1)


# ═════════════════════════════════════════════════════════════════════════
# Dataset — now includes GT cell indices for BC phase
# ═════════════════════════════════════════════════════════════════════════

class GameIWMDataset(Dataset):
    def __init__(self, game_states, waypoints, alive,
                 pos_mean, pos_std, wp_mean, wp_std):
        self.N = game_states.shape[0]

        # Normalize s₀
        s0 = game_states[:, 0].copy()
        s0[:, CONTINUOUS_SLICE] = (s0[:, CONTINUOUS_SLICE] - pos_mean) / pos_std
        self.s0 = s0.astype(np.float32)

        # ant_xy normalized
        self.ant_xy_norm = ((game_states[:, 0, :2] - wp_mean) / wp_std).astype(np.float32)

        # Normalized waypoints (for FM reward phase)
        self.wp_target = ((waypoints - wp_mean) / wp_std).astype(np.float32)

        # Alive mask
        self.alive = alive[:, 1:].astype(np.float32)

        # GT cell indices at each of the 32 waypoint steps
        wp_world = waypoints  # (N, 32, 2) world coords
        wp_flat = wp_world.reshape(-1, 2)
        cell_indices = nearest_waypoint_indices(wp_flat).reshape(self.N, -1)
        self.gt_cells = cell_indices.astype(np.int64)

        # GT direction indices: what direction takes prev_cell → next_cell?
        # Start cell = nearest cell to ant_xy in world coords
        ant_xy_world = game_states[:, 0, :2]  # (N, 2)
        start_cells = nearest_waypoint_indices(ant_xy_world)  # (N,)

        prev_cells = np.concatenate([start_cells[:, None], cell_indices[:, :-1]], axis=1)
        gt_dirs = _CELL_PAIR_TO_DIR[prev_cells, cell_indices].astype(np.int64)
        self.gt_dirs = gt_dirs

        # Stats: how many steps have valid directions (not stays)
        valid_frac = (gt_dirs >= 0).mean()
        print(f'    GT directions: {valid_frac:.1%} valid (rest are stays, masked in BC)')

    def __len__(self):
        return self.N

    def __getitem__(self, idx):
        return (torch.from_numpy(self.s0[idx]),
                torch.from_numpy(self.ant_xy_norm[idx]),
                torch.from_numpy(self.wp_target[idx]),
                torch.from_numpy(self.alive[idx]),
                torch.from_numpy(self.gt_cells[idx]),
                torch.from_numpy(self.gt_dirs[idx]))


# ═════════════════════════════════════════════════════════════════════════
# Helpers
# ═════════════════════════════════════════════════════════════════════════

def get_lr(epoch, warmup, total, base_lr, min_lr):
    if epoch < warmup:
        return base_lr * (epoch + 1) / warmup
    progress = (epoch - warmup) / max(1, total - warmup)
    return min_lr + 0.5 * (base_lr - min_lr) * (1 + math.cos(math.pi * progress))


def nearest_waypoint_indices(points, chunk_size=262144):
    points = np.asarray(points, dtype=np.float32)
    waypoints_world = np.asarray(WAYPOINTS_WORLD, dtype=np.float32)
    nearest = np.empty(points.shape[0], dtype=np.int64)

    for start in range(0, points.shape[0], chunk_size):
        end = min(start + chunk_size, points.shape[0])
        batch = points[start:end]
        diff = batch[:, None, :] - waypoints_world[None, :, :]
        dist_sq = np.sum(diff * diff, axis=2)
        nearest[start:end] = dist_sq.argmin(axis=1)

    return nearest


def load_frozen_fm(fm_path, device):
    ckpt = torch.load(fm_path, map_location=device, weights_only=False)
    fm = GameFM_v2(
        state_dim=ckpt['state_dim'],
        action_dim=ckpt['action_dim'],
        horizon=ckpt['horizon'],
        d_model=ckpt['d_model'],
        n_heads=ckpt['n_heads'],
        n_layers=ckpt['n_layers'],
        ff_mult=ckpt['ff_mult'],
        dropout=ckpt['dropout'],
    )
    fm.load_state_dict(ckpt['model_state_dict'])
    fm.eval()
    for p in fm.parameters():
        p.requires_grad = False
    return fm.to(device)


def fm_reward(fm, s0, wp_pred):
    """Compute reward from FM v2 bitmap predictions.

    Reward = total newly-eaten pellets = Σ_c max(0, p_rem_0(c) - p_rem_T(c))
    where p_rem_0 is the initial pellet bitmap from s0 (ground truth binary)
    and p_rem_T is the FM's predicted P(remaining) at the final step.

    Per-step version (for weighted alive): Σ_t Σ_c (p_rem_{t-1} - p_rem_t)^+ * p_alive_t
    """
    _, pel_logits, alive_logits = fm(s0, wp_pred)
    # pel_logits: (B, H, 46) — logits for P(pellet c remaining at step t)
    p_rem = torch.sigmoid(pel_logits)            # (B, H, 46)
    p_alive = torch.sigmoid(alive_logits)        # (B, H)

    # Initial pellet state from s0 (binary ground truth)
    p_rem_0 = s0[:, fm.pellet_slice]             # (B, 46)

    # Build sequence: [p_rem_0, p_rem_1, ..., p_rem_H]
    p_rem_seq = torch.cat([p_rem_0.unsqueeze(1), p_rem], dim=1)  # (B, H+1, 46)

    # Per-step newly eaten: sum_c max(0, p_rem_{t-1} - p_rem_t)
    delta = (p_rem_seq[:, :-1, :] - p_rem_seq[:, 1:, :]).clamp(min=0)  # (B, H, 46)
    eaten_per_step = delta.sum(dim=-1)            # (B, H)

    # Reward: raw pellet count (no alive weighting)
    reward = eaten_per_step.sum(dim=-1)           # (B,)

    # Summary stats for logging
    total_eaten = delta.sum(dim=(1, 2))           # (B,) total pellets eaten
    mean_p_alive = p_alive.mean(dim=-1)           # (B,)

    return reward, total_eaten, mean_p_alive


# ═════════════════════════════════════════════════════════════════════════
# Main
# ═════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=str, required=True)
    parser.add_argument('--resume_checkpoint', type=str, default=None,
                        help='Path to checkpoint to resume training from')
    args = parser.parse_args()

    with open(args.config) as f:
        cfg = json.load(f)

    out_dir = Path(args.config).parent
    tcfg = cfg['training']
    mcfg = cfg['model']
    lcfg = cfg['loss']

    torch.manual_seed(tcfg['seed'])
    np.random.seed(tcfg['seed'])

    device = torch.device(f'cuda:{cfg["gpu"]}' if cfg['gpu'] >= 0
                          and torch.cuda.is_available() else 'cpu')
    print(f'Device: {device}')

    # ─── Load data ─────────────────────────────────────────────────

    print(f'Loading data from {cfg["data_path"]}...')
    data = np.load(cfg['data_path'])
    game_states = data['game_states']
    waypoints = data['waypoints']
    alive = data['alive']
    N, Hp1, D = game_states.shape
    H = Hp1 - 1
    layout = get_state_layout(D)
    pellet_slice = layout['pellets']
    print(f'  {N:,} chunks, H={H}, state_dim={D}')
    print(f'  state layout: {layout["name"]}, pellet_slice={pellet_slice.start}:{pellet_slice.stop}')

    # Data quality stats
    pellet_bm = game_states[:, :, pellet_slice]
    pellet_ct = pellet_bm.sum(axis=-1)
    pel_eaten = np.clip(pellet_ct[:, :-1] - pellet_ct[:, 1:], 0, 1)
    pels_per_chunk = pel_eaten.sum(axis=1)
    alive_all = (alive[:, 1:].min(axis=1) == 1).mean()
    print(f'  avg pellets/chunk: {pels_per_chunk.mean():.1f} ± {pels_per_chunk.std():.1f}')
    print(f'  chunks fully alive: {alive_all:.1%}')

    # ─── Normalization ─────────────────────────────────────────────

    fm_dir = Path(cfg['fm_checkpoint']).parent
    norm = np.load(fm_dir / 'norm_stats.npz')
    pos_mean = norm['pos_mean']
    pos_std = norm['pos_std']
    wp_mean = norm['wp_mean']
    wp_std = norm['wp_std']
    print(f'  Loaded normalization from {fm_dir / "norm_stats.npz"}')

    # ─── Train/val split ───────────────────────────────────────────

    n_val = int(N * tcfg['val_frac'])
    n_train = N - n_val
    perm = np.random.permutation(N)
    train_idx = perm[:n_train]
    val_idx = perm[n_train:]

    train_ds = GameIWMDataset(game_states[train_idx], waypoints[train_idx],
                              alive[train_idx], pos_mean, pos_std, wp_mean, wp_std)
    val_ds = GameIWMDataset(game_states[val_idx], waypoints[val_idx],
                            alive[val_idx], pos_mean, pos_std, wp_mean, wp_std)

    train_num_workers = int(tcfg.get('train_num_workers', 4))
    val_num_workers = int(tcfg.get('val_num_workers', 2))
    pin_memory = bool(tcfg.get('pin_memory', True))
    persistent_workers = bool(tcfg.get('persistent_workers', True))
    prefetch_factor = int(tcfg.get('prefetch_factor', 2))

    train_loader_kwargs = {
        'batch_size': tcfg['batch_size'],
        'shuffle': True,
        'num_workers': train_num_workers,
        'pin_memory': pin_memory,
        'drop_last': True,
    }
    val_loader_kwargs = {
        'batch_size': tcfg['batch_size'],
        'shuffle': False,
        'num_workers': val_num_workers,
        'pin_memory': pin_memory,
    }
    if train_num_workers > 0:
        train_loader_kwargs['persistent_workers'] = persistent_workers
        train_loader_kwargs['prefetch_factor'] = prefetch_factor
    if val_num_workers > 0:
        val_loader_kwargs['persistent_workers'] = persistent_workers
        val_loader_kwargs['prefetch_factor'] = prefetch_factor

    train_loader = DataLoader(train_ds, **train_loader_kwargs)
    val_loader = DataLoader(val_ds, **val_loader_kwargs)

    print(f'  Train: {n_train:,}, Val: {n_val:,}')
    print(f'  loaders: train_workers={train_num_workers}, '
          f'val_workers={val_num_workers}, pin_memory={pin_memory}, '
          f'persistent_workers={persistent_workers}, prefetch_factor={prefetch_factor}')

    # ─── Model ─────────────────────────────────────────────────────

    model = IWMDirectionTransformer(
        state_dim=D,
        n_cells=N_CELLS,
        n_dirs=N_DIRS,
        horizon=H,
        d_model=mcfg['d_model'],
        n_heads=mcfg['n_heads'],
        n_layers=mcfg['n_layers'],
        ff_mult=mcfg['ff_mult'],
        dropout=mcfg['dropout'],
        tau_init=mcfg['tau_init'],
        tau_end=mcfg['tau_end'],
    ).to(device)

    model.set_waypoints_norm(wp_mean, wp_std, device)

    n_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f'  IWM Direction Transformer: {n_params:,} params, N_DIRS={N_DIRS}, N_CELLS={N_CELLS}')

    avg_valid = _VALID_DIRS.sum() / N_CELLS
    print(f'  Directions: avg {avg_valid:.1f} valid dirs/cell (of {N_DIRS})')

    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=tcfg['lr'],
        weight_decay=tcfg['weight_decay'],
        betas=(0.9, 0.95),
    )

    # ─── Resume from checkpoint (if specified) ─────────────────
    resume_checkpoint = args.resume_checkpoint or cfg.get('resume_checkpoint')
    start_epoch = 0
    best_selection_score = -float('inf')
    best_val_reward = -float('inf')
    best_epoch = 0
    raw_best_val_reward = -float('inf')
    raw_best_epoch = 0
    train_history = []
    val_history = []
    val_entropy_history = []
    selection_history = []

    if resume_checkpoint and Path(resume_checkpoint).exists():
        print(f'\n  === RESUMING from checkpoint: {resume_checkpoint} ===')
        ckpt = torch.load(resume_checkpoint, map_location=device, weights_only=False)
        model.load_state_dict(ckpt['model_state_dict'])
        optimizer.load_state_dict(ckpt['optimizer_state_dict'])
        start_epoch = ckpt.get('epoch', 0) + 1  # Continue from next epoch
        best_selection_score = ckpt.get('best_selection_score', -float('inf'))
        best_val_reward = ckpt.get('best_val_reward', -float('inf'))
        best_epoch = ckpt.get('best_epoch', 0)
        raw_best_val_reward = ckpt.get('raw_best_val_reward', -float('inf'))
        raw_best_epoch = ckpt.get('raw_best_epoch', 0)
        train_history = ckpt.get('train_history', [])
        val_history = ckpt.get('val_history', [])
        val_entropy_history = ckpt.get('val_entropy_history', [])
        selection_history = ckpt.get('selection_history', [])
        print(f'  Resumed at epoch {start_epoch}, best_score={best_selection_score:.3f} @ epoch {best_epoch}')
        print()

    # ─── Temperature annealing ─────────────────────────────────────

    tau_start = mcfg['tau_init']
    tau_end = mcfg['tau_end']
    tau_warmup = mcfg.get('tau_warmup_epochs', 20)

    def get_tau(epoch):
        if epoch < tau_warmup:
            return tau_start
        progress = (epoch - tau_warmup) / max(1, tcfg['epochs'] - tau_warmup)
        return tau_start * (tau_end / tau_start) ** progress

    # ─── Frozen FM (for phase 2) ──────────────────────────────────

    print(f'  Loading frozen FM from {cfg["fm_checkpoint"]}...')
    fm = load_frozen_fm(cfg['fm_checkpoint'], device)
    fm_n = sum(p.numel() for p in fm.parameters())
    print(f'  FM: {fm_n:,} params (frozen)')

    # GT reward on val set (using FM v2 bitmap reward)
    print('  Computing GT reward on val set (FM v2 bitmap)...')
    gt_reward_sum = 0.0
    gt_eaten_sum = 0.0
    gt_n = 0
    with torch.no_grad():
        for batch in val_loader:
            s0 = batch[0].to(device, non_blocking=True)
            ant_xy = batch[1].to(device, non_blocking=True)
            wp_tgt = batch[2].to(device, non_blocking=True)
            r, total_eaten, _ = fm_reward(fm, s0, wp_tgt)
            gt_reward_sum += r.sum().item()
            gt_eaten_sum += total_eaten.sum().item()
            gt_n += s0.shape[0]
    gt_reward = gt_reward_sum / gt_n
    gt_eaten = gt_eaten_sum / gt_n
    print(f'  GT reward (demo waypoints): {gt_reward:.2f} pellets/chunk')
    print(f'  GT total eaten (demo): {gt_eaten:.2f} pellets/chunk')

    # ─── Phase configuration ──────────────────────────────────────

    bc_epochs = lcfg.get('bc_epochs', 50)
    total_epochs = tcfg['epochs']
    lambda_ent = lcfg.get('lambda_entropy', 0.01)
    lambda_bc = lcfg.get('lambda_bc', 1.0)
    lambda_fm = lcfg.get('lambda_fm', 1.0)
    bc_blend_epochs = lcfg.get('bc_blend_epochs', 20)

    # Stabilization A: BC anchor floor — keep small BC loss during FM phase
    lambda_bc_floor = lcfg.get('lambda_bc_floor', 0.0)
    # Stabilization B: separate LR for FM phase (drops by this factor)
    lr_fm_factor = tcfg.get('lr_fm_factor', 1.0)  # e.g. 0.1 = 10x lower LR
    # Stabilization C: reward advantage normalization
    reward_normalize = lcfg.get('reward_normalize', False)

    print(f'\n  Training phases:')
    print(f'    Phase 1 (BC):    epochs 1-{bc_epochs} (pure cross-entropy on GT cells)')
    print(f'    Blend:           epochs {bc_epochs+1}-{bc_epochs+bc_blend_epochs} (BC weight decays → {lambda_bc_floor})')
    print(f'    Phase 2 (FM):    epochs {bc_epochs+bc_blend_epochs+1}-{total_epochs} (FM reward + BC anchor={lambda_bc_floor})')
    print(f'    tau: {tau_start} → {tau_end} (warmup {tau_warmup} epochs)')
    print(f'    lambda_entropy: {lambda_ent}')
    print(f'    lambda_bc_floor: {lambda_bc_floor}')
    print(f'    lr_fm_factor: {lr_fm_factor}')
    print(f'    reward_normalize: {reward_normalize}')

    selection_cfg = cfg.get('selection', {})
    selection_mode = selection_cfg.get('mode', 'val_reward')
    selection_window = max(1, int(selection_cfg.get('window', 1)))
    selection_burnin_epochs = max(0, int(selection_cfg.get('burnin_epochs', 0)))
    selection_stability_penalty = float(selection_cfg.get('stability_penalty', 0.0))
    if selection_mode not in {'val_reward', 'smoothed_val_reward'}:
        raise ValueError(f'Unknown selection.mode: {selection_mode}')
    print(f'    checkpoint selection: {selection_mode}')
    if selection_mode == 'smoothed_val_reward':
        print(f'      window={selection_window}, burnin={selection_burnin_epochs}, '
              f'stability_penalty={selection_stability_penalty}')
    elif selection_burnin_epochs > 0:
        print(f'      burnin={selection_burnin_epochs}')

    # ─── Checkpoint directory for per-epoch saves ─────────────────
    save_every_epoch = tcfg.get('save_every_epoch', False)
    if save_every_epoch:
        ckpt_dir = out_dir / 'checkpoints'
        ckpt_dir.mkdir(exist_ok=True)
        print(f'  Per-epoch checkpoints will be saved to: {ckpt_dir}')

    # ─── Training loop ─────────────────────────────────────────────

    for epoch in range(start_epoch, total_epochs):
        # LR schedule with optional FM-phase drop
        lr_base = get_lr(epoch, tcfg['warmup_epochs'], total_epochs,
                         tcfg['lr'], tcfg['min_lr'])
        if epoch >= bc_epochs and lr_fm_factor < 1.0:
            lr_now = lr_base * lr_fm_factor
        else:
            lr_now = lr_base
        for pg in optimizer.param_groups:
            pg['lr'] = lr_now

        tau_now = get_tau(epoch)
        model.tau = tau_now

        # BC vs FM weight schedule (with BC floor for FM phase)
        if epoch < bc_epochs:
            w_bc = lambda_bc
            w_fm = 0.0
            phase = 'BC'
        elif epoch < bc_epochs + bc_blend_epochs:
            blend = (epoch - bc_epochs) / bc_blend_epochs
            w_bc = lambda_bc * (1.0 - blend) + lambda_bc_floor * blend
            w_fm = lambda_fm * blend
            phase = 'blend'
        else:
            w_bc = lambda_bc_floor
            w_fm = lambda_fm
            phase = 'FM'

        # ── Train ──
        model.train()
        train_reward_sum = 0.0
        train_bc_loss_sum = 0.0
        train_entropy_sum = 0.0
        train_n = 0

        for batch in train_loader:
            s0 = batch[0].to(device, non_blocking=True)
            ant_xy = batch[1].to(device, non_blocking=True)
            wp_tgt = batch[2].to(device, non_blocking=True)      # (B, H, 2)
            alive_mask = batch[3].to(device, non_blocking=True)   # (B, H)
            gt_cells = batch[4].to(device, non_blocking=True)     # (B, H) long
            gt_dirs = batch[5].to(device, non_blocking=True)      # (B, H) long, -1 = stay (masked)

            wp_pred, cell_weights, dir_probs = model(s0, ant_xy)

            loss = torch.tensor(0.0, device=device)

            # BC loss: cross-entropy on direction selection (with teacher forcing)
            if w_bc > 0:
                # Re-run transformer to get raw direction logits (no Gumbel noise)
                ctx = model.encoder(s0).unsqueeze(1)
                queries = model.step_queries.expand(s0.shape[0], -1, -1)
                tokens = torch.cat([ctx, queries], dim=1)
                tokens = tokens + model.pos_embed
                out = model.transformer(tokens, mask=model.causal_mask)
                out_steps = out[:, 1:, :]
                raw_logits = model.output_proj(out_steps)  # (B, H, 4)

                # Apply valid-direction mask per step with teacher forcing
                bc_loss = torch.tensor(0.0, device=device)
                n_valid_steps = 0
                prev_cell = model._nearest_cell(ant_xy)
                for t in range(model.horizon):
                    # Mask invalid directions
                    valid = model.valid_dirs[prev_cell]  # (B, 4)
                    dir_mask = torch.where(valid > 0.5, 0.0, -1e9)
                    masked = raw_logits[:, t, :] + dir_mask  # (B, 4)

                    # Only compute CE on steps with valid GT direction (not stays)
                    valid_mask = gt_dirs[:, t] >= 0  # (B,)
                    if valid_mask.any():
                        # Select only valid samples for this step
                        bc_loss = bc_loss + F.cross_entropy(
                            masked[valid_mask], gt_dirs[:, t][valid_mask]
                        )
                        n_valid_steps += 1

                    # Teacher forcing: advance to GT cell
                    prev_cell = gt_cells[:, t]

                if n_valid_steps > 0:
                    bc_loss = bc_loss / n_valid_steps
                loss = loss + w_bc * bc_loss
                train_bc_loss_sum += bc_loss.item() * s0.shape[0]

            # FM reward loss
            if w_fm > 0:
                reward, p_pel, p_alive = fm_reward(fm, s0, wp_pred)
                if reward_normalize:
                    # Advantage normalization: center and scale reward
                    reward_adv = (reward - reward.mean()) / (reward.std() + 1e-6)
                    loss = loss - w_fm * reward_adv.mean()
                else:
                    loss = loss - w_fm * reward.mean()
                train_reward_sum += reward.sum().item()
            else:
                # Still compute reward for logging
                with torch.no_grad():
                    reward, p_pel, p_alive = fm_reward(fm, s0, wp_pred)
                    train_reward_sum += reward.sum().item()

            # Entropy bonus on direction probs (4-way, not one-hot cell_weights)
            ent = -(dir_probs * (dir_probs + 1e-8).log()).sum(dim=-1).mean()
            loss = loss - lambda_ent * ent

            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), tcfg['grad_clip'])
            optimizer.step()

            train_entropy_sum += ent.item() * s0.shape[0]
            train_n += s0.shape[0]

        train_reward = train_reward_sum / train_n
        train_bc_loss = train_bc_loss_sum / train_n if train_bc_loss_sum > 0 else 0
        train_entropy = train_entropy_sum / train_n

        # ── Validate ──
        model.eval()
        val_reward_sum = 0.0
        val_eaten_sum = 0.0
        val_alive_sum = 0.0
        val_entropy_sum = 0.0
        val_n = 0

        with torch.no_grad():
            for batch in val_loader:
                s0 = batch[0].to(device, non_blocking=True)
                ant_xy = batch[1].to(device, non_blocking=True)

                wp_pred, cell_weights, dir_probs = model(s0, ant_xy)
                reward, total_eaten, mean_alive = fm_reward(fm, s0, wp_pred)
                ent = -(dir_probs * (dir_probs + 1e-8).log()).sum(dim=-1).mean()

                bs = s0.shape[0]
                val_reward_sum += reward.sum().item()
                val_eaten_sum += total_eaten.sum().item()
                val_alive_sum += mean_alive.mean().item() * bs
                val_entropy_sum += ent.item() * bs
                val_n += bs

        val_reward = val_reward_sum / val_n
        val_eaten = val_eaten_sum / val_n
        val_alive = val_alive_sum / val_n
        val_entropy = val_entropy_sum / val_n
        ratio = val_reward / max(gt_reward, 1e-6)

        train_history.append(train_reward)
        val_history.append(val_reward)
        val_entropy_history.append(val_entropy)

        if val_reward > raw_best_val_reward:
            raw_best_val_reward = val_reward
            raw_best_epoch = epoch

        current_epoch = epoch + 1
        selection_score = None
        if selection_mode == 'val_reward':
            if current_epoch >= max(1, selection_burnin_epochs):
                selection_score = val_reward
        else:
            if current_epoch >= max(selection_window, selection_burnin_epochs):
                window_vals = val_history[-selection_window:]
                mean_val = sum(window_vals) / len(window_vals)
                variance = sum((x - mean_val) ** 2 for x in window_vals) / len(window_vals)
                selection_score = mean_val - selection_stability_penalty * math.sqrt(variance)
        selection_history.append(float(selection_score) if selection_score is not None else None)

        # ── Save best ──
        improved = ''
        if selection_score is not None and selection_score > best_selection_score:
            best_selection_score = selection_score
            best_val_reward = val_reward
            best_epoch = epoch
            improved = ' *BEST*'

            torch.save({
                'model_state_dict': model.state_dict(),
                'model_type': 'iwm_direction_transformer',
                'state_dim': D,
                'n_cells': N_CELLS,
                'n_dirs': N_DIRS,
                'horizon': H,
                'd_model': mcfg['d_model'],
                'n_heads': mcfg['n_heads'],
                'n_layers': mcfg['n_layers'],
                'ff_mult': mcfg['ff_mult'],
                'dropout': mcfg['dropout'],
                'tau_init': mcfg['tau_init'],
                'tau_end': mcfg['tau_end'],
                'state_layout': layout['name'],
                'epoch': epoch,
                'val_reward': best_val_reward,
                'selection_metric': selection_mode,
                'selection_score': best_selection_score,
                'raw_best_val_reward': raw_best_val_reward,
                'raw_best_epoch': raw_best_epoch,
                'pos_mean': pos_mean.tolist(),
                'pos_std': pos_std.tolist(),
                'wp_mean': wp_mean.tolist(),
                'wp_std': wp_std.tolist(),
                'config': cfg,
            }, out_dir / 'best_model.pt')

        # Always save latest for monitor path viz
        torch.save({
            'model_state_dict': model.state_dict(),
            'model_type': 'iwm_direction_transformer',
            'state_dim': D,
            'n_cells': N_CELLS,
            'n_dirs': N_DIRS,
            'horizon': H,
            'd_model': mcfg['d_model'],
            'n_heads': mcfg['n_heads'],
            'n_layers': mcfg['n_layers'],
            'ff_mult': mcfg['ff_mult'],
            'dropout': mcfg['dropout'],
            'tau_init': mcfg['tau_init'],
            'tau_end': mcfg['tau_end'],
            'state_layout': layout['name'],
            'epoch': epoch,
            'val_reward': val_reward,
            'pos_mean': pos_mean.tolist(),
            'pos_std': pos_std.tolist(),
            'wp_mean': wp_mean.tolist(),
            'wp_std': wp_std.tolist(),
            'config': cfg,
        }, out_dir / 'latest_model.pt')

        display_best_val_reward = best_val_reward if best_selection_score > -float('inf') else raw_best_val_reward
        display_best_epoch = (best_epoch + 1) if best_selection_score > -float('inf') else (raw_best_epoch + 1)

        bc_str = f'bc_loss={train_bc_loss:.3f}  ' if w_bc > 0 else ''
        sel_str = f'  sel={selection_score:.3f}' if selection_score is not None else ''
        print(f'Ep {epoch+1:3d}/{total_epochs}  [{phase:5s}] '
              f'lr={lr_now:.1e} tau={tau_now:.3f}  '
              f'{bc_str}'
              f'train_r={train_reward:.2f}  '
              f'val_r={val_reward:.2f} (gt={gt_reward:.2f} ratio={ratio:.3f})  '
              f'eaten={val_eaten:.2f} p_alive={val_alive:.4f}  '
              f'H={val_entropy:.2f}'
              f'{sel_str}'
              f'{improved}', flush=True)

        # Progress JSON
        progress = {
            'experiment': cfg['experiment'],
            'epoch': epoch + 1,
            'total_epochs': total_epochs,
            'phase': phase,
            'train_reward': float(train_reward),
            'train_bc_loss': float(train_bc_loss),
            'val_reward': float(val_reward),
            'gt_reward': float(gt_reward),
            'ratio': float(ratio),
            'val_eaten': float(val_eaten),
            'val_p_alive': float(val_alive),
            'val_entropy': float(val_entropy),
            'tau': float(tau_now),
            'w_bc': float(w_bc),
            'w_fm': float(w_fm),
            'selection_metric': selection_mode,
            'selection_window': selection_window,
            'selection_burnin_epochs': selection_burnin_epochs,
            'selection_stability_penalty': selection_stability_penalty,
            'selection_score': float(selection_score) if selection_score is not None else None,
            'best_selection_score': float(best_selection_score) if best_selection_score > -float('inf') else None,
            'best_val_reward': float(display_best_val_reward),
            'best_epoch': display_best_epoch,
            'raw_best_val_reward': float(raw_best_val_reward),
            'raw_best_epoch': raw_best_epoch + 1,
            'lr': float(lr_now),
        }
        with open(out_dir / 'progress.json', 'w') as f:
            json.dump(progress, f, indent=2)

        # Save every epoch (if enabled)
        if save_every_epoch:
            torch.save({
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'model_type': 'iwm_direction_transformer',
                'state_dim': D,
                'n_cells': N_CELLS,
                'n_dirs': N_DIRS,
                'horizon': H,
                'd_model': mcfg['d_model'],
                'n_heads': mcfg['n_heads'],
                'n_layers': mcfg['n_layers'],
                'ff_mult': mcfg['ff_mult'],
                'dropout': mcfg['dropout'],
                'tau_init': mcfg['tau_init'],
                'tau_end': mcfg['tau_end'],
                'state_layout': layout['name'],
                'epoch': epoch,
                'best_val_reward': best_val_reward,
                'best_selection_score': best_selection_score,
                'raw_best_val_reward': raw_best_val_reward,
                'best_epoch': best_epoch,
                'raw_best_epoch': raw_best_epoch,
                'selection_metric': selection_mode,
                'val_reward': val_reward,
                'pos_mean': pos_mean.tolist(),
                'pos_std': pos_std.tolist(),
                'wp_mean': wp_mean.tolist(),
                'wp_std': wp_std.tolist(),
                'train_history': train_history,
                'val_history': val_history,
                'val_entropy_history': val_entropy_history,
                'selection_history': selection_history,
                'config': cfg,
            }, ckpt_dir / f'epoch_{epoch+1:03d}.pt')

        # Checkpoint every 50 epochs (legacy, for quick reference)
        if (epoch + 1) % 50 == 0:
            torch.save({
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'model_type': 'iwm_direction_transformer',
                'state_dim': D,
                'n_cells': N_CELLS,
                'n_dirs': N_DIRS,
                'horizon': H,
                'd_model': mcfg['d_model'],
                'n_heads': mcfg['n_heads'],
                'n_layers': mcfg['n_layers'],
                'ff_mult': mcfg['ff_mult'],
                'dropout': mcfg['dropout'],
                'tau_init': mcfg['tau_init'],
                'tau_end': mcfg['tau_end'],
                'state_layout': layout['name'],
                'epoch': epoch,
                'best_val_reward': best_val_reward,
                'best_selection_score': best_selection_score,
                'raw_best_val_reward': raw_best_val_reward,
                'best_epoch': best_epoch,
                'raw_best_epoch': raw_best_epoch,
                'selection_metric': selection_mode,
                'val_reward': val_reward,
                'pos_mean': pos_mean.tolist(),
                'pos_std': pos_std.tolist(),
                'wp_mean': wp_mean.tolist(),
                'wp_std': wp_std.tolist(),
                'train_history': train_history,
                'val_history': val_history,
                'val_entropy_history': val_entropy_history,
                'selection_history': selection_history,
                'config': cfg,
            }, out_dir / f'checkpoint_ep{epoch+1}.pt')

    # ── Final summary ──
    print(f'\n=== Training Complete ===')
    if best_selection_score > -float('inf'):
        print(f'Selected checkpoint ({selection_mode}): score={best_selection_score:.3f} @ epoch {best_epoch+1}')
        print(f'Selected val_reward: {best_val_reward:.2f}, ratio: {best_val_reward/max(gt_reward,1e-6):.3f}')
    else:
        print('No checkpoint satisfied selection criteria; no best_model.pt was selected.')
    print(f'Raw best val_reward: {raw_best_val_reward:.2f} @ epoch {raw_best_epoch+1}')
    print(f'GT reward: {gt_reward:.2f}')
    print(f'Output: {out_dir}')

    with open(out_dir / 'history.json', 'w') as f:
        json.dump({
            'train_reward': train_history,
            'val_reward': val_history,
            'val_entropy': val_entropy_history,
            'selection_score': selection_history,
        }, f)


if __name__ == '__main__':
    main()
