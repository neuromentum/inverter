"""
AntMan game state: pellets, ghosts, scoring, win/loss conditions.

The game runs on top of a D4RL antmaze grid. Ghosts are virtual (cell-grid
positions), the ant is physical (MuJoCo). Ghost personalities follow classic
Pac-Man rules (Blinky = chase, Pinky = ambush, Inky = flank).
"""

from dataclasses import dataclass, field
from collections import deque
from typing import List, Dict, Optional, Tuple

import numpy as np


# ═════════════════════════════════════════════════════════════════════════
# Constants
# ═════════════════════════════════════════════════════════════════════════

PELLET_EAT_DIST = 2.0       # world units — eat pellet when this close
GHOST_CATCH_DIST = 3.0       # world units — ghost catches ant
FRIGHT_DURATION = 100        # normalization/reference scale for fright timer
DEFAULT_FRIGHT_DURATION = 50 # default frightened steps per power pellet
GHOST_RESPAWN_DELAY = 30     # steps before eaten ghost reappears
MAX_STEPS = 3000             # per game

# Ghost starting positions (cells) — spread across the maze
GHOST_HOMES = {
    'blinky': (7, 1),    # bottom-left
    'pinky':  (1, 10),   # top-right
    'inky':   (7, 10),   # bottom-right
}
GHOST_ORDER = ['blinky', 'pinky', 'inky']

# Power pellet locations — 4 "corners" of the open maze area
POWER_PELLET_CELLS = [
    (1, 1),    # top-left
    (1, 10),   # top-right
    (7, 1),    # bottom-left
    (7, 10),   # bottom-right
]

# Scoring
SCORE_PELLET = 10
SCORE_POWER = 50
SCORE_GHOST = 200
SCORE_CLEAR_BONUS = 1000


# ═════════════════════════════════════════════════════════════════════════
# Data structures
# ═════════════════════════════════════════════════════════════════════════

@dataclass
class Pellet:
    row: int
    col: int
    world_xy: np.ndarray
    eaten: bool = False
    is_power: bool = False


@dataclass
class Ghost:
    name: str
    row: int
    col: int
    home_row: int
    home_col: int
    frightened: bool = False
    eaten: bool = False        # ghost eaten, waiting to respawn
    respawn_timer: int = 0
    # BFS path cache: list of (row, col) from current to target
    _path: list = field(default_factory=list)


# ═════════════════════════════════════════════════════════════════════════
# AntManGame
# ═════════════════════════════════════════════════════════════════════════

class AntManGame:
    """Manages pellets, ghosts, scoring, win/loss conditions."""

    def __init__(self, maze_map, scaling, torso_x, torso_y,
                 n_ghosts=1, ghost_move_interval=10,
                 fright_duration=DEFAULT_FRIGHT_DURATION, max_steps=MAX_STEPS):
        self.maze_map = maze_map
        self.scaling = scaling
        self.torso_x = torso_x
        self.torso_y = torso_y
        self.n_rows = len(maze_map)
        self.n_cols = len(maze_map[0])
        self.n_ghosts = min(n_ghosts, 3)
        self.ghost_move_interval = ghost_move_interval
        self.fright_duration = fright_duration
        self.max_steps = max_steps

        # Precompute open cells
        self._open_cells = []
        for r in range(self.n_rows):
            for c in range(self.n_cols):
                if maze_map[r][c] == 0:
                    self._open_cells.append((r, c))
        self._open_set = set(self._open_cells)

        # State (set by reset)
        self.pellets: List[Pellet] = []
        self.ghosts: List[Ghost] = []
        self._score = 0
        self._step = 0
        self.fright_remaining = 0
        self._caught = False
        self._ghosts_eaten_total = 0

        # Lookup: (row, col) → pellet index
        self._pellet_map: Dict[Tuple[int, int], int] = {}

    # ─── Coordinate helpers ─────────────────────────────────────────

    def cell_to_world(self, row, col):
        """Convert grid cell (row, col) to world xy at cell center."""
        x = col * self.scaling - self.torso_x
        y = row * self.scaling - self.torso_y
        return np.array([x, y], dtype=np.float32)

    def world_to_cell(self, xy):
        """Snap world xy to nearest open cell (row, col)."""
        best_dist = float('inf')
        best_rc = self._open_cells[0]
        for r, c in self._open_cells:
            center = self.cell_to_world(r, c)
            d = np.linalg.norm(xy - center)
            if d < best_dist:
                best_dist = d
                best_rc = (r, c)
        return best_rc

    def get_ant_cell(self, ant_xy):
        """Snap ant world position to grid cell."""
        return self.world_to_cell(ant_xy)

    def get_ant_heading(self, ant_vel_xy):
        """(vx, vy) → nearest cardinal direction as (dr, dc)."""
        vx, vy = float(ant_vel_xy[0]), float(ant_vel_xy[1])
        if abs(vx) < 0.01 and abs(vy) < 0.01:
            return (0, 1)  # default: right
        if abs(vx) >= abs(vy):
            return (0, 1) if vx > 0 else (0, -1)
        else:
            return (1, 0) if vy > 0 else (-1, 0)

    def nearest_open_cell(self, row, col):
        """Find the nearest open cell to (row, col), clamped to grid."""
        row = max(0, min(row, self.n_rows - 1))
        col = max(0, min(col, self.n_cols - 1))
        if (row, col) in self._open_set:
            return (row, col)
        best_dist = float('inf')
        best_rc = self._open_cells[0]
        for r, c in self._open_cells:
            d = abs(r - row) + abs(c - col)
            if d < best_dist:
                best_dist = d
                best_rc = (r, c)
        return best_rc

    # ─── BFS on cell grid ──────────────────────────────────────────

    def get_neighbors(self, r, c):
        """Return list of open cardinal neighbors."""
        nbrs = []
        for dr, dc in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
            nr, nc = r + dr, c + dc
            if (nr, nc) in self._open_set:
                nbrs.append((nr, nc))
        return nbrs

    def bfs_path(self, start_rc, goal_rc):
        """BFS shortest path on cell grid. Returns list of (row, col)."""
        if start_rc == goal_rc:
            return [start_rc]
        queue = deque([(start_rc, [start_rc])])
        visited = {start_rc}
        while queue:
            (r, c), path = queue.popleft()
            for nr, nc in self.get_neighbors(r, c):
                if (nr, nc) == goal_rc:
                    return path + [(nr, nc)]
                if (nr, nc) not in visited:
                    visited.add((nr, nc))
                    queue.append(((nr, nc), path + [(nr, nc)]))
        return None  # unreachable

    def bfs_farthest_from(self, src_rc):
        """BFS from src, return the farthest reachable open cell."""
        queue = deque([src_rc])
        visited = {src_rc}
        farthest = src_rc
        while queue:
            r, c = queue.popleft()
            farthest = (r, c)
            for nr, nc in self.get_neighbors(r, c):
                if (nr, nc) not in visited:
                    visited.add((nr, nc))
                    queue.append((nr, nc))
        return farthest

    # ─── Reset ──────────────────────────────────────────────────────

    def reset(self):
        """Place pellets at all open cells, ghosts at starting positions."""
        self._score = 0
        self._step = 0
        self.fright_remaining = 0
        self._caught = False
        self._ghosts_eaten_total = 0

        # Pellets — one per open cell
        self.pellets = []
        self._pellet_map = {}
        power_set = set(POWER_PELLET_CELLS)
        for i, (r, c) in enumerate(self._open_cells):
            p = Pellet(
                row=r, col=c,
                world_xy=self.cell_to_world(r, c),
                is_power=(r, c) in power_set,
            )
            self.pellets.append(p)
            self._pellet_map[(r, c)] = i

        # Ghosts
        self.ghosts = []
        for i in range(self.n_ghosts):
            name = GHOST_ORDER[i]
            hr, hc = GHOST_HOMES[name]
            self.ghosts.append(Ghost(
                name=name, row=hr, col=hc,
                home_row=hr, home_col=hc,
            ))

        return self.get_state()

    # ─── Ghost targeting (Step 2: personalities) ──────────────────

    def compute_ghost_targets(self, ant_cell, ant_heading):
        """Compute BFS target cell for each ghost based on personality.

        Returns dict: ghost_name → (row, col) target.
        """
        targets = {}
        blinky = None

        for ghost in self.ghosts:
            if ghost.eaten:
                # Eaten ghosts head home to respawn
                targets[ghost.name] = (ghost.home_row, ghost.home_col)
                if ghost.name == 'blinky':
                    blinky = ghost
                continue

            if self.fright_remaining > 0 and ghost.frightened:
                # Frightened: flee to farthest cell from ant
                targets[ghost.name] = self.bfs_farthest_from(ant_cell)
                if ghost.name == 'blinky':
                    blinky = ghost
                continue

            if ghost.name == 'blinky':
                # Direct chase — target ant's current cell
                targets['blinky'] = ant_cell
                blinky = ghost

            elif ghost.name == 'pinky':
                # Ambush — target 4 cells ahead of ant's heading
                dr, dc = ant_heading
                target_r = ant_cell[0] + 4 * dr
                target_c = ant_cell[1] + 4 * dc
                targets['pinky'] = self.nearest_open_cell(target_r, target_c)

            elif ghost.name == 'inky':
                # Flank — mirror Blinky through ant
                if blinky is not None:
                    vec_r = ant_cell[0] - blinky.row
                    vec_c = ant_cell[1] - blinky.col
                    target_r = ant_cell[0] + vec_r
                    target_c = ant_cell[1] + vec_c
                    targets['inky'] = self.nearest_open_cell(target_r, target_c)
                else:
                    # Fallback: direct chase (if Blinky not in game)
                    targets['inky'] = ant_cell

        return targets

    # ─── Ghost movement ────────────────────────────────────────────

    def _move_ghost(self, ghost, target_rc):
        """Move ghost one step toward target along BFS path."""
        if ghost.eaten:
            # Move toward home
            if (ghost.row, ghost.col) == (ghost.home_row, ghost.home_col):
                return  # wait for respawn timer
            target_rc = (ghost.home_row, ghost.home_col)

        current = (ghost.row, ghost.col)
        if current == target_rc:
            return

        path = self.bfs_path(current, target_rc)
        if path and len(path) >= 2:
            ghost.row, ghost.col = path[1]

    def step_ghosts(self, ant_cell, ant_heading):
        """Move each active ghost one cell toward its target."""
        targets = self.compute_ghost_targets(ant_cell, ant_heading)
        # Ghost movement happens only on ghost ticks, not every ant step.
        # When frightened we want half speed relative to those ghost ticks.
        ghost_tick = self._step // max(1, self.ghost_move_interval)
        for ghost in self.ghosts:
            if ghost.eaten and ghost.respawn_timer > 0:
                ghost.respawn_timer -= 1
                if ghost.respawn_timer <= 0:
                    # Respawn from home after the timeout expires.
                    ghost.eaten = False
                    ghost.frightened = False
                    ghost.row = ghost.home_row
                    ghost.col = ghost.home_col
                continue
            target = targets.get(ghost.name, ant_cell)
            # In frightened mode, ghosts move at half speed in ghost-tick space.
            if ghost.frightened and ghost_tick % 2 != 0:
                continue
            self._move_ghost(ghost, target)

    # ─── Pellet eating ─────────────────────────────────────────────

    def check_pellets(self, ant_xy):
        """Eat pellets within PELLET_EAT_DIST. Returns points scored."""
        points = 0
        activated_power = False
        for p in self.pellets:
            if p.eaten:
                continue
            dist = float(np.linalg.norm(ant_xy - p.world_xy))
            if dist < PELLET_EAT_DIST:
                p.eaten = True
                if p.is_power:
                    points += SCORE_POWER
                    activated_power = True
                else:
                    points += SCORE_PELLET

        if activated_power:
            self.fright_remaining = self.fright_duration
            for ghost in self.ghosts:
                if not ghost.eaten:
                    ghost.frightened = True

        return points, activated_power

    # ─── Ghost collision ───────────────────────────────────────────

    def check_ghost_collision(self, ant_xy):
        """Check if ant collides with any ghost.

        Returns: ('caught', ghost_name) | ('ate_ghost', ghost_name) | ('safe', None)
        """
        for ghost in self.ghosts:
            if ghost.eaten:
                continue
            ghost_xy = self.cell_to_world(ghost.row, ghost.col)
            dist = float(np.linalg.norm(ant_xy - ghost_xy))
            if dist < GHOST_CATCH_DIST:
                if ghost.frightened and self.fright_remaining > 0:
                    # Ant eats the ghost. We remove it from play immediately
                    # back to home so the simplified 55D state encoding remains
                    # semantically consistent without per-ghost eaten flags.
                    ghost.eaten = True
                    ghost.frightened = False
                    ghost.row = ghost.home_row
                    ghost.col = ghost.home_col
                    ghost.respawn_timer = GHOST_RESPAWN_DELAY
                    self._ghosts_eaten_total += 1
                    return ('ate_ghost', ghost.name)
                else:
                    # Ghost catches the ant
                    self._caught = True
                    return ('caught', ghost.name)
        return ('safe', None)

    # ─── Main per-step tick ────────────────────────────────────────

    def tick(self, ant_xy, ant_vel_xy, step_num):
        """Main per-step update.

        Move ghosts (if interval), eat pellets, check collisions.
        Returns event dict.
        """
        self._step = step_num
        events = {
            'ghost_moved': False,
            'pellet_eaten': False,
            'power_activated': False,
            'caught': False,
            'caught_by': None,
            'ate_ghost': False,
            'ate_ghost_name': None,
            'points_this_step': 0,
            'all_cleared': False,
        }

        # Decrement fright timer
        if self.fright_remaining > 0:
            self.fright_remaining -= 1
            if self.fright_remaining <= 0:
                for ghost in self.ghosts:
                    ghost.frightened = False

        # Move ghosts at their tick rate
        if self.ghost_move_interval > 0 and step_num % self.ghost_move_interval == 0:
            ant_cell = self.get_ant_cell(ant_xy)
            ant_heading = self.get_ant_heading(ant_vel_xy)
            self.step_ghosts(ant_cell, ant_heading)
            events['ghost_moved'] = True

        # Check pellets
        points, power = self.check_pellets(ant_xy)
        if points > 0:
            self._score += points
            events['pellet_eaten'] = True
            events['points_this_step'] += points
        if power:
            events['power_activated'] = True

        # Check ghost collision
        collision, ghost_name = self.check_ghost_collision(ant_xy)
        if collision == 'caught':
            events['caught'] = True
            events['caught_by'] = ghost_name
        elif collision == 'ate_ghost':
            self._score += SCORE_GHOST
            events['ate_ghost'] = True
            events['ate_ghost_name'] = ghost_name
            events['points_this_step'] += SCORE_GHOST

        # Check all pellets cleared
        if self.all_pellets_eaten():
            self._score += SCORE_CLEAR_BONUS
            events['all_cleared'] = True

        return events

    # ─── State queries ─────────────────────────────────────────────

    def all_pellets_eaten(self):
        return all(p.eaten for p in self.pellets)

    def is_over(self):
        return self._caught or self.all_pellets_eaten() or self._step >= self.max_steps

    @property
    def score(self):
        return self._score

    @property
    def pellets_remaining(self):
        return sum(1 for p in self.pellets if not p.eaten)

    @property
    def pellets_total(self):
        return len(self.pellets)

    def get_state(self):
        """Return current game state dict for logging / strategy."""
        return {
            'score': self._score,
            'step': self._step,
            'pellets_remaining': self.pellets_remaining,
            'pellets_total': self.pellets_total,
            'fright_remaining': self.fright_remaining,
            'caught': self._caught,
            'all_cleared': self.all_pellets_eaten(),
            'ghosts': [
                {
                    'name': g.name,
                    'row': g.row, 'col': g.col,
                    'frightened': g.frightened,
                    'eaten': g.eaten,
                }
                for g in self.ghosts
            ],
        }

    def ghost_world_positions(self):
        """Return ghost positions as (N, 2) world xy array."""
        positions = []
        for g in self.ghosts:
            if not g.eaten:
                positions.append(self.cell_to_world(g.row, g.col))
        return np.array(positions, dtype=np.float32) if positions else np.zeros((0, 2), dtype=np.float32)
