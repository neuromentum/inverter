"""
Cardinal BFS waypoint planner + IWM execution for antmaze.

Instead of building a dense graph from dataset trajectories, this planner
uses the known maze structure directly:
  1. BFS on the cell grid → shortest axis-aligned cell path
  2. Waypoints placed at corridor centers, spaced at 1.0 (matching IWM
     training mean displacement for L=8 chunks with md≥0.5 + z≥0.3 filters)
  3. All waypoints are strictly axis-aligned (right/left/up/down only)
  4. Snap-to-closest waypoint after each chunk (replan_every=1 style)

Motivation: The IWM training data displacement rose shows the ant moves
almost exclusively in cardinal directions (right, left, up). This planner
produces waypoint sequences that are perfectly aligned with those learned
movement directions.

Usage:
    export LD_LIBRARY_PATH="$HOME/.mujoco/mujoco210/bin:/usr/lib/nvidia"

    # umaze (default):
    python -u antmaze/navigate_cardinal.py --gpu 0 --n_episodes 100

    # medium:
    python -u antmaze/navigate_cardinal.py --env medium-play --gpu 0 --n_episodes 100

    # Custom IWM:
    python -u antmaze/navigate_cardinal.py --gpu 0 --n_episodes 100 \
        --iwm_path antmaze/umaze/iwm/L8/yawzero10.0_fid2.0_md0.5_notilt_20260401_135929/best_model.pt

    # Adjust spacing:
    python -u antmaze/navigate_cardinal.py --wp_spacing 1.0 --n_episodes 100
"""

import sys, os, argparse, json, time, subprocess
from pathlib import Path
from collections import deque

import numpy as np
import torch
import torch.nn as nn

# Project root must be on sys.path so the shared cardinal-BFS planner is
# importable when this script is run via its absolute path.
_PROJECT_ROOT = Path(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))
from common.cardinal_bfs_planner import CardinalBFSPlanner

# ─── Args ───────────────────────────────────────────────────────────────

parser = argparse.ArgumentParser(
    description='Cardinal BFS planner + IWM navigation for antmaze')
parser.add_argument('--env', type=str, default='umaze',
    choices=['umaze', 'umaze-diverse', 'medium-play', 'medium-diverse', 'large-play', 'large-diverse'],
    help='Maze variant (default: umaze)')
parser.add_argument('--gpu', type=int, default=0)
parser.add_argument('--seed', type=int, default=42)
parser.add_argument('--n_episodes', type=int, default=100)

# Model
parser.add_argument('--iwm_path', type=str, default='',
    help='Path to IWM checkpoint (auto-detected from --env if empty)')

# Planner
parser.add_argument('--wp_spacing', type=float, default=1.0,
    help='Distance between waypoints along corridor centers (default: 1.0 = IWM training mean)')
parser.add_argument('--occupancy_source', type=str, default='env',
    choices=['env', 'data'],
    help='How to determine free cells. "env" uses the hardcoded MAZE_MAP. '
         '"data" builds the occupancy grid from training trajectories only '
         '(no maze geometry knowledge).')
parser.add_argument('--data_states_path', type=str, default='',
    help='DataOccupancy: path to states.npy (auto from --env if empty).')
parser.add_argument('--data_resolution', type=float, default=1.0,
    help='DataOccupancy: grid cell size in world units (default 1.0).')
parser.add_argument('--data_min_visits', type=int, default=100,
    help='DataOccupancy: min training points per cell to count as free '
         '(filters wall-brush noise; default 100).')
parser.add_argument('--data_origin_mode', type=str, default='auto',
    choices=['auto', 'floor'],
    help='DataOccupancy: grid origin alignment ("auto" = align cell '
         'centers to data density peaks).')
parser.add_argument('--planner_impl', type=str, default='unified',
    choices=['legacy', 'unified'],
    help='Which planner implementation to use under --occupancy_source=data. '
         '"unified" (default) instantiates common.cardinal_bfs_planner.'
         'CardinalBFSPlanner. "legacy" instantiates the antmaze-local '
         'DataOccupancy class. Provided as an A/B switch for the '
         'unification regression sweep.')
parser.add_argument('--data_center_weight', type=float, default=1.0,
    help='DataOccupancy: enable centerline tie-breaking on the BFS shortest '
         'path (>0 = enabled, 0 = disabled). When enabled, BFS still finds '
         'a path of minimum number of steps, but among all equally-short '
         'paths it picks the one maximising the cumulative dist_to_wall — '
         'i.e. the one that stays maximally in the center of the data '
         'support. Default 1.0 (enabled).')

# Navigation
parser.add_argument('--wp_advance_dist', type=float, default=1.0,
    help='Advance to next waypoint when within this distance')
parser.add_argument('--wp_skip_dist', type=float, default=0.8,
    help='Skip ahead if within this dist of a later waypoint')
parser.add_argument('--goal_reached_dist', type=float, default=0.5,
    help='D4RL success threshold')
parser.add_argument('--stuck_threshold', type=int, default=10,
    help='Full replan after this many chunks without waypoint progress')
parser.add_argument('--max_replan', type=int, default=5,
    help='Max full replans per episode')
parser.add_argument('--replan_every', type=int, default=1,
    help='Snap to closest waypoint after each chunk (0=disabled)')
parser.add_argument('--target_dist_min', type=float, default=0.5,
    help='Min randomized target distance (0=disabled)')
parser.add_argument('--target_dist_max', type=float, default=1.5,
    help='Max randomized target distance (0=disabled)')

# Output
parser.add_argument('--exp_name', type=str, default='',
    help='Experiment name (creates output dir)')
parser.add_argument('--out_dir', type=str, default='',
    help='Override output directory')
parser.add_argument('--save_trajectories', action='store_true')
parser.add_argument('--no_save_trajectories', action='store_true', help='Override auto-save when exp_name is set (lightweight mode)')
parser.add_argument('--no_episode_plots', action='store_true',
    help='Skip per-episode detail plots in monitor')
parser.add_argument('--verbose_all', action='store_true',
    help='Verbose output for every episode')

PROJECT_ROOT = Path(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
HORIZON = 8  # default, overridden from checkpoint


# ═════════════════════════════════════════════════════════════════════════
# Maze configurations
# ═════════════════════════════════════════════════════════════════════════

MAZE_CONFIGS = {
    'umaze': {
        'gym_env': 'antmaze-umaze-v2',
        'maze_type': 'umaze',
        'maze_map': [
            [1, 1, 1, 1, 1],
            [1, 0, 0, 0, 1],
            [1, 1, 1, 0, 1],
            [1, 0, 0, 0, 1],
            [1, 1, 1, 1, 1],
        ],
        'scaling': 4.0, 'torso_x': 4.0, 'torso_y': 4.0,
        'default_iwm': 'antmaze/umaze/iwm/L8/yawzero10.0_fid2.0_md0.5_notilt_20260401_135929/best_model.pt',
    },
    'umaze-diverse': {
        'gym_env': 'antmaze-umaze-diverse-v2',
        'maze_type': 'umaze-diverse',
        'maze_map': [
            [1, 1, 1, 1, 1],
            [1, 0, 0, 0, 1],
            [1, 1, 1, 0, 1],
            [1, 0, 0, 0, 1],
            [1, 1, 1, 1, 1],
        ],
        'scaling': 4.0, 'torso_x': 4.0, 'torso_y': 4.0,
        'default_iwm': '',
    },
    'medium-play': {
        'gym_env': 'antmaze-medium-play-v2',
        'maze_type': 'medium',
        'maze_map': [
            [1, 1, 1, 1, 1, 1, 1, 1],
            [1, 0, 0, 1, 1, 0, 0, 1],
            [1, 0, 0, 1, 0, 0, 0, 1],
            [1, 1, 0, 0, 0, 1, 1, 1],
            [1, 0, 0, 1, 0, 0, 0, 1],
            [1, 0, 1, 0, 0, 1, 0, 1],
            [1, 0, 0, 0, 1, 0, 0, 1],
            [1, 1, 1, 1, 1, 1, 1, 1],
        ],
        'scaling': 4.0, 'torso_x': 4.0, 'torso_y': 4.0,
        'default_iwm': 'antmaze/medium/iwm/L8/yawzero10.0_fid2.0_md0.5_notilt_20260403_134742/best_model.pt',
    },
    'medium-diverse': {
        'gym_env': 'antmaze-medium-diverse-v2',
        'maze_type': 'medium',
        'maze_map': [
            [1, 1, 1, 1, 1, 1, 1, 1],
            [1, 0, 0, 1, 1, 0, 0, 1],
            [1, 0, 0, 1, 0, 0, 0, 1],
            [1, 1, 0, 0, 0, 1, 1, 1],
            [1, 0, 0, 1, 0, 0, 0, 1],
            [1, 0, 1, 0, 0, 1, 0, 1],
            [1, 0, 0, 0, 1, 0, 0, 1],
            [1, 1, 1, 1, 1, 1, 1, 1],
        ],
        'scaling': 4.0, 'torso_x': 4.0, 'torso_y': 4.0,
        'default_iwm': 'antmaze/medium/iwm/L8/yawzero10.0_fid2.0_md0.5_notilt_20260403_134742/best_model.pt',
    },
    'large-play': {
        'gym_env': 'antmaze-large-play-v2',
        'maze_type': 'large',
        'maze_map': [
            [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
            [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1],
            [1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1],
            [1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1],
            [1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1],
            [1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1],
            [1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1],
            [1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1],
            [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
        ],
        'scaling': 4.0, 'torso_x': 4.0, 'torso_y': 4.0,
        'default_iwm': '',
    },
    'large-diverse': {
        'gym_env': 'antmaze-large-diverse-v2',
        'maze_type': 'large',
        'maze_map': [
            [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
            [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1],
            [1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1],
            [1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1],
            [1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1],
            [1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1],
            [1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1],
            [1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1],
            [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
        ],
        'scaling': 4.0, 'torso_x': 4.0, 'torso_y': 4.0,
        'default_iwm': '',
    },
}

# Active maze config — set at startup from --env
MAZE_MAP = None
SCALING = 4.0
TORSO_X = 4.0
TORSO_Y = 4.0
N_ROWS = 0
N_COLS = 0
GYM_ENV = ''
MAZE_TYPE = ''


def _init_maze_config(env_name):
    """Initialize module-level maze constants from MAZE_CONFIGS."""
    global MAZE_MAP, SCALING, TORSO_X, TORSO_Y, N_ROWS, N_COLS, GYM_ENV, MAZE_TYPE
    cfg = MAZE_CONFIGS[env_name]
    MAZE_MAP = cfg['maze_map']
    SCALING = cfg['scaling']
    TORSO_X = cfg['torso_x']
    TORSO_Y = cfg['torso_y']
    N_ROWS = len(MAZE_MAP)
    N_COLS = len(MAZE_MAP[0])
    GYM_ENV = cfg['gym_env']
    MAZE_TYPE = cfg['maze_type']


class EnvOccupancy:
    """Occupancy from the hardcoded MAZE_MAP grid (uses geometry knowledge)."""

    def cell_to_world(self, row, col):
        x = col * SCALING - TORSO_X
        y = row * SCALING - TORSO_Y
        return np.array([x, y], dtype=np.float32)

    def world_to_cell(self, xy):
        """Snap world xy to nearest open cell (row, col)."""
        best_dist = float('inf')
        best_rc = (1, 1)
        for r in range(N_ROWS):
            for c in range(N_COLS):
                if MAZE_MAP[r][c] == 0:
                    center = self.cell_to_world(r, c)
                    d = np.linalg.norm(xy - center)
                    if d < best_dist:
                        best_dist = d
                        best_rc = (r, c)
        return best_rc

    def get_open_cells(self):
        cells = []
        for r in range(N_ROWS):
            for c in range(N_COLS):
                if MAZE_MAP[r][c] == 0:
                    cells.append((r, c))
        return cells

    def get_neighbors(self, r, c):
        nbrs = []
        for dr, dc in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
            nr, nc = r + dr, c + dc
            if 0 <= nr < N_ROWS and 0 <= nc < N_COLS and MAZE_MAP[nr][nc] == 0:
                nbrs.append((nr, nc))
        return nbrs

    def bfs_cell_path(self, start_rc, goal_rc):
        if start_rc == goal_rc:
            return [start_rc]
        queue = deque([(start_rc, [start_rc])])
        visited = {start_rc}
        while queue:
            (r, c), path = queue.popleft()
            for nr, nc in self.get_neighbors(r, c):
                if (nr, nc) == goal_rc:
                    return path + [(nr, nc)]
                if (nr, nc) not in visited:
                    visited.add((nr, nc))
                    queue.append(((nr, nc), path + [(nr, nc)]))
        return None


class DataOccupancy:
    """Occupancy derived purely from offline training trajectories.

    Snap dataset xy points to a grid; cells with at least `min_visits` points
    are free, all others are walls. Cell "centers" are the density-weighted
    mean xy of the points in that cell, so they sit on the corridor centerline
    learned from the data rather than on a geometric midline. No maze geometry
    is used.

    Public API matches EnvOccupancy so plan_cardinal_waypoints is unchanged.
    """

    def __init__(self, xy, resolution=1.0, min_visits=100, origin_mode='auto'):
        xy = np.asarray(xy, dtype=np.float32)[:, :2]
        self.res = float(resolution)
        self.min_visits = int(min_visits)
        self.origin_mode = str(origin_mode)

        if self.origin_mode == 'auto':
            def _phase_offset(vals):
                mods = np.mod(vals, self.res)
                bins = max(10, int(round(self.res / 0.02)))
                hist, edges = np.histogram(mods, bins=bins, range=(0.0, self.res))
                peak_phase = 0.5 * (edges[np.argmax(hist)] + edges[np.argmax(hist) + 1])
                return float((peak_phase - 0.5 * self.res) % self.res)
            x_phase = _phase_offset(xy[:, 0])
            y_phase = _phase_offset(xy[:, 1])
            x_min_adj = float(xy[:, 0].min()) - x_phase
            y_min_adj = float(xy[:, 1].min()) - y_phase
            self.x_origin = float(np.floor(x_min_adj / self.res) * self.res + x_phase)
            self.y_origin = float(np.floor(y_min_adj / self.res) * self.res + y_phase)
        else:
            self.x_origin = float(np.floor(xy[:, 0].min() / self.res) * self.res)
            self.y_origin = float(np.floor(xy[:, 1].min() / self.res) * self.res)

        col = np.floor((xy[:, 0] - self.x_origin) / self.res).astype(np.int64)
        row_from_bottom = np.floor((xy[:, 1] - self.y_origin) / self.res).astype(np.int64)
        self.ncols = int(col.max()) + 1
        self.nrows = int(row_from_bottom.max()) + 1
        # Use top-down row indexing (row 0 = top) to match EnvOccupancy convention,
        # though for this class internal consistency is what matters.
        row = self.nrows - 1 - row_from_bottom

        counts = np.zeros((self.nrows, self.ncols), dtype=np.int64)
        sum_x = np.zeros((self.nrows, self.ncols), dtype=np.float64)
        sum_y = np.zeros((self.nrows, self.ncols), dtype=np.float64)
        np.add.at(counts, (row, col), 1)
        np.add.at(sum_x, (row, col), xy[:, 0].astype(np.float64))
        np.add.at(sum_y, (row, col), xy[:, 1].astype(np.float64))
        self.counts = counts

        free_mask = counts >= self.min_visits
        self.free_mask = free_mask

        rr, cc = np.indices((self.nrows, self.ncols))
        # Density-weighted mean xy of points in each cell. This places the cell
        # "center" on the actual corridor centerline (where the data is densest)
        # rather than on a geometric grid point that may sit at a corridor edge.
        # Adopted from the maze2d recipe (data_resolution=0.5 + auto origin)
        # which matched env-mode performance on medium and large mazes.
        safe = np.maximum(counts, 1)
        mean_x = (sum_x / safe).astype(np.float32)
        mean_y = (sum_y / safe).astype(np.float32)
        geom_x = (self.x_origin + (cc + 0.5) * self.res).astype(np.float32)
        geom_y = (self.y_origin + (self.nrows - 1 - rr + 0.5) * self.res).astype(np.float32)
        self.centers = np.empty((self.nrows, self.ncols, 2), dtype=np.float32)
        # Free cells: density mean. Wall cells: geometric (only used as fallback).
        self.centers[..., 0] = np.where(free_mask, mean_x, geom_x)
        self.centers[..., 1] = np.where(free_mask, mean_y, geom_y)

        free_rc = np.argwhere(free_mask)
        self.free_cells = free_rc.astype(np.int32)
        self.free_centres = (self.centers[free_rc[:, 0], free_rc[:, 1]]
                             if len(free_rc) else np.zeros((0, 2), dtype=np.float32))

        # ── Distance-to-wall (cardinal, with grid border treated as wall) ──
        # Used by Dijkstra to prefer corridor-centerline routing. Cells in
        # the middle of a wide corridor have higher dist_to_wall, so Dijkstra
        # picks them over wall-adjacent cells on either edge of the corridor.
        from scipy.ndimage import distance_transform_cdt
        wall_mask = ~free_mask
        padded = np.pad(wall_mask, 1, mode='constant', constant_values=True)
        self.dist_to_wall = distance_transform_cdt(
            ~padded, metric='taxicab',
        )[1:-1, 1:-1].astype(np.int32)
        # Per-instance Dijkstra weight (set by caller via attribute)
        self.center_weight = 2.0

    def _raw_cell(self, xy):
        col = int(np.floor((xy[0] - self.x_origin) / self.res))
        row_from_bottom = int(np.floor((xy[1] - self.y_origin) / self.res))
        row = self.nrows - 1 - row_from_bottom
        return row, col

    def cell_to_world(self, row, col):
        return self.centers[row, col].copy()

    def world_to_cell(self, xy):
        r, c = self._raw_cell(xy)
        if 0 <= r < self.nrows and 0 <= c < self.ncols and self.free_mask[r, c]:
            return (r, c)
        if len(self.free_centres) == 0:
            return (0, 0)
        d = np.linalg.norm(self.free_centres - np.asarray(xy, dtype=np.float32), axis=1)
        idx = int(np.argmin(d))
        return (int(self.free_cells[idx, 0]), int(self.free_cells[idx, 1]))

    def get_open_cells(self):
        return [(int(r), int(c)) for r, c in self.free_cells]

    def get_neighbors(self, r, c):
        nbrs = []
        for dr, dc in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
            nr, nc = r + dr, c + dc
            if (0 <= nr < self.nrows and 0 <= nc < self.ncols
                    and self.free_mask[nr, nc]):
                nbrs.append((nr, nc))
        return nbrs

    def bfs_cell_path(self, start_rc, goal_rc):
        """Standard BFS shortest path with centerline tie-breaking.

        Uses uniform step cost (so the result is always a *shortest* path
        in number of steps — pure BFS). Among all equally-short paths,
        picks the one whose interior cells have the highest cumulative
        `dist_to_wall`. This stays in the *center* of the data support
        without trading length for centerline (Dijkstra would).

        With `center_weight=0` the tie-break is disabled (falls back to
        whichever shortest path BFS happens to find first).
        """
        if start_rc == goal_rc:
            return [start_rc]

        # ── Forward BFS: distances + every valid predecessor on a shortest path
        dist = {start_rc: 0}
        parents = {}  # cell → list of cells at depth-1 that lead here on a shortest path
        queue = deque([start_rc])
        goal_found = False
        while queue:
            u = queue.popleft()
            if u == goal_rc:
                goal_found = True
                # don't break: keep building parents for any goal-equivalent paths
            for v in self.get_neighbors(*u):
                if v not in dist:
                    dist[v] = dist[u] + 1
                    parents[v] = [u]
                    queue.append(v)
                elif dist[v] == dist[u] + 1:
                    parents[v].append(u)

        if not goal_found:
            return None

        # ── Centerline tie-break: among all shortest paths, find the one
        # maximising the cumulative dist_to_wall along the path. Implemented
        # as a single backward DP pass over the BFS layers.
        if float(self.center_weight) <= 0:
            # No tie-break — reconstruct any shortest path by greedy backwalk.
            path = [goal_rc]
            while path[-1] != start_rc:
                path.append(parents[path[-1]][0])
            return list(reversed(path))

        # Forward DP: best_score[u] = max over shortest paths start→u of
        #                              sum of dist_to_wall over interior cells
        best_score = {start_rc: 0.0}
        best_pred = {start_rc: None}
        # Process cells in BFS-depth order
        cells_by_depth = {}
        for cell, d in dist.items():
            cells_by_depth.setdefault(d, []).append(cell)
        for d in sorted(cells_by_depth):
            if d == 0:
                continue
            for u in cells_by_depth[d]:
                cands = parents[u]
                # pick the parent with the best cumulative score
                best_p = max(cands, key=lambda p: best_score[p])
                best_score[u] = best_score[best_p] + float(self.dist_to_wall[u[0], u[1]])
                best_pred[u] = best_p

        # Reconstruct from goal
        path = [goal_rc]
        while path[-1] != start_rc:
            path.append(best_pred[path[-1]])
        return list(reversed(path))


# Active occupancy source — set once at startup
OCC = None


def plan_cardinal_waypoints(start_xy, goal_xy, spacing=1.0):
    """
    Plan axis-aligned waypoints from start_xy to goal_xy through cell centers.

    1. Snap start/goal to nearest cells
    2. BFS for shortest cell sequence
    3. Convert to world coordinates (cell centers)
    4. Insert start_xy at front, goal_xy at end
    5. Resample each axis-aligned segment at `spacing` intervals

    Returns: (N, 2) array of waypoints
    """
    start_cell = OCC.world_to_cell(start_xy)
    goal_cell = OCC.world_to_cell(goal_xy)

    cell_path = OCC.bfs_cell_path(start_cell, goal_cell)
    if cell_path is None:
        return None

    # Turn-based extraction at the cell-INDEX level. The BFS is 4-connected,
    # so each step changes exactly one of (row, col) by ±1; a "turn" is an
    # index where that direction changes. Keeping only turn cells (plus start
    # and goal cells) collapses long straight cell-index runs to their
    # endpoints, which is essential when cells are smaller than wp_spacing —
    # otherwise the path is full of redundant collinear waypoints.
    if len(cell_path) >= 3:
        turn_cells = [cell_path[0]]
        for i in range(1, len(cell_path) - 1):
            prev_d = (cell_path[i][0] - cell_path[i - 1][0],
                      cell_path[i][1] - cell_path[i - 1][1])
            next_d = (cell_path[i + 1][0] - cell_path[i][0],
                      cell_path[i + 1][1] - cell_path[i][1])
            if prev_d != next_d:
                turn_cells.append(cell_path[i])
        turn_cells.append(cell_path[-1])
        cell_path = turn_cells

    cell_centers = np.array([OCC.cell_to_world(r, c) for r, c in cell_path],
                            dtype=np.float32)

    # ── Per-segment perpendicular snap ──────────────────────────────
    # Between consecutive turn cells the BFS travelled along exactly one axis
    # (one of (row, col) was constant). With density-weighted centers the
    # *xy* positions still jitter on the perpendicular axis, producing tiny
    # diagonal segments. Snap both endpoints of each segment to a shared
    # perpendicular coordinate (their average) so the segment becomes
    # exactly axis-aligned. Adjacent segments are perpendicular (turn-cell
    # extraction guarantees this), so they snap *different* axes of the
    # shared corner cell — no conflict.
    if len(cell_path) >= 2:
        snapped = cell_centers.copy()
        for i in range(len(cell_path) - 1):
            rA, cA = cell_path[i]
            rB, cB = cell_path[i + 1]
            if rA == rB:  # horizontal segment → share y
                shared_y = 0.5 * (snapped[i, 1] + snapped[i + 1, 1])
                snapped[i, 1] = shared_y
                snapped[i + 1, 1] = shared_y
            elif cA == cB:  # vertical segment → share x
                shared_x = 0.5 * (snapped[i, 0] + snapped[i + 1, 0])
                snapped[i, 0] = shared_x
                snapped[i + 1, 0] = shared_x
        cell_centers = snapped

    # Build the full piecewise-linear path:
    #   start_xy → first cell center → ... → last cell center → goal_xy
    # But skip cell center if start/goal is already very close to it
    keypoints = [start_xy.copy()]

    for i, cc in enumerate(cell_centers):
        # Skip if this cell center is very close to start (avoid doubling back)
        if i == 0 and np.linalg.norm(cc - start_xy) < 0.3:
            continue
        # Skip last cell center if goal is close to it
        if i == len(cell_centers) - 1 and np.linalg.norm(cc - goal_xy) < 0.3:
            continue
        keypoints.append(cc)

    keypoints.append(goal_xy.copy())

    # ── L-corner insertion: enforce strict cardinal segments ─────────
    # The ant IWM is trained on axis-aligned targets and only moves reliably
    # along the cardinal directions. Any two consecutive keypoints that
    # disagree on BOTH axes form a diagonal segment and must be split into
    # two perpendicular legs by inserting an explicit L-corner between them.
    # With density-mean cell centers this fires on essentially every corner
    # (because the means in adjacent cells jitter in both axes); with
    # geometric grid centers it only fires for the start→first-cell and
    # last-cell→goal bookend segments where start/goal aren't on the grid.
    TOL = 0.1
    orthogonal = [np.asarray(keypoints[0], dtype=np.float32)]
    for next_pt in keypoints[1:]:
        next_pt = np.asarray(next_pt, dtype=np.float32)
        current_pt = orthogonal[-1]
        dx = float(next_pt[0] - current_pt[0])
        dy = float(next_pt[1] - current_pt[1])
        if abs(dx) > TOL and abs(dy) > TOL:
            # Pick the corner that traverses the longer axis first; this
            # tends to avoid placing the corner inside a wall, since the
            # longer axis is the one the BFS just travelled along.
            if abs(dx) >= abs(dy):
                corner = np.array([next_pt[0], current_pt[1]], dtype=np.float32)
            else:
                corner = np.array([current_pt[0], next_pt[1]], dtype=np.float32)
            if np.linalg.norm(corner - current_pt) > 0.05:
                orthogonal.append(corner)
        if np.linalg.norm(next_pt - orthogonal[-1]) > 0.05:
            orthogonal.append(next_pt.copy())
    keypoints = orthogonal

    # ── Ensure the final approach is axis-aligned ───────────────────
    # If the segment last_keypoint → goal is diagonal, project the goal
    # onto the preceding axis-aligned segment and insert a turn point so
    # that the very last step is perpendicular (cardinal) to the goal.
    #
    # Example: path ends  ...→(4,8)→(0,8)→(0.9,8.4)  [goal]
    #   → replace (0,8) with (0.9,8) so path becomes
    #     ...→(4,8)→(0.9,8)→(0.9,8.4)  ✓ both segments axis-aligned
    if len(keypoints) >= 3:
        prev = keypoints[-3]
        last_kp = keypoints[-2]
        goal_kp = keypoints[-1]

        dx = abs(goal_kp[0] - last_kp[0])
        dy = abs(goal_kp[1] - last_kp[1])

        if dx > 0.05 and dy > 0.05:
            # Segment prev → last_kp should be axis-aligned; determine axis
            seg = last_kp - prev
            if abs(seg[0]) > abs(seg[1]):
                # Horizontal segment — turn at goal's x-coordinate
                turn_x = np.clip(goal_kp[0],
                                 min(prev[0], last_kp[0]),
                                 max(prev[0], last_kp[0]))
                turn_point = np.array([turn_x, last_kp[1]], dtype=np.float32)
            else:
                # Vertical segment — turn at goal's y-coordinate
                turn_y = np.clip(goal_kp[1],
                                 min(prev[1], last_kp[1]),
                                 max(prev[1], last_kp[1]))
                turn_point = np.array([last_kp[0], turn_y], dtype=np.float32)

            # Only replace if the turn point is meaningfully different
            if np.linalg.norm(turn_point - last_kp) > 0.05:
                keypoints[-2] = turn_point

    keypoints = np.array(keypoints, dtype=np.float32)

    # Resample at fixed spacing along the piecewise-linear path
    if spacing <= 0 or len(keypoints) < 2:
        return keypoints

    resampled = [keypoints[0]]
    for i in range(len(keypoints) - 1):
        seg_start = keypoints[i]
        seg_end = keypoints[i + 1]
        seg_vec = seg_end - seg_start
        seg_len = float(np.linalg.norm(seg_vec))

        if seg_len < 1e-6:
            continue

        seg_dir = seg_vec / seg_len
        # How many interior points at this spacing?
        n_pts = int(seg_len / spacing)
        for j in range(1, n_pts + 1):
            pt = seg_start + seg_dir * (j * spacing)
            resampled.append(pt)

        # Always include the segment endpoint (cell center or goal)
        if np.linalg.norm(resampled[-1] - seg_end) > 0.05:
            resampled.append(seg_end)

    # Ensure goal is the last waypoint
    if np.linalg.norm(resampled[-1] - goal_xy) > 0.05:
        resampled.append(goal_xy.copy())

    return np.array(resampled, dtype=np.float32)


# ═════════════════════════════════════════════════════════════════════════
# IWM Model (must match training architecture)
# ═════════════════════════════════════════════════════════════════════════

class AntMazeIWM(nn.Module):
    """Causal Transformer IWM — matches train_iwm_yawzero_notilt.py."""

    def __init__(self, state_dim=29, goal_dim=2, action_dim=8,
                 d_model=192, n_heads=6, n_layers=4, d_ff=576, dropout=0.0,
                 relative_xy=False, horizon=None):
        super().__init__()
        self.action_dim = action_dim
        self.d_model = d_model
        self.relative_xy = relative_xy
        H = horizon if horizon is not None else HORIZON

        self.cond_encoder = nn.Sequential(
            nn.Linear(state_dim + goal_dim, d_model),
            nn.GELU(),
            nn.LayerNorm(d_model),
            nn.Linear(d_model, d_model),
            nn.GELU(),
            nn.LayerNorm(d_model),
        )
        self.pos_embed = nn.Parameter(torch.randn(1, H, d_model) * 0.02)

        layer = nn.TransformerEncoderLayer(
            d_model=d_model, nhead=n_heads, dim_feedforward=d_ff,
            dropout=dropout, activation='gelu', batch_first=True,
            norm_first=True,
        )
        self.transformer = nn.TransformerEncoder(layer, num_layers=n_layers)
        self.output_proj = nn.Linear(d_model, action_dim)
        self.register_buffer(
            'causal_mask',
            torch.triu(torch.ones(H, H, dtype=torch.bool), diagonal=1),
        )

    def forward(self, state, goal_xy):
        goal_rel = goal_xy - state[:, :2]
        if self.relative_xy:
            state = state.clone()
            state[:, :2] = 0.0
        cond = torch.cat([state, goal_rel], dim=-1)
        c = self.cond_encoder(cond)
        x = c.unsqueeze(1) + self.pos_embed
        x = self.transformer(x, mask=self.causal_mask)
        return torch.tanh(self.output_proj(x))


class Navigator:
    """Wraps IWM model for inference: state + goal → actions."""

    def __init__(self, iwm_model, device='cuda'):
        self.iwm = iwm_model
        self.device = device
        self.iwm.eval()

    @torch.no_grad()
    def get_actions(self, obs_29d, goal_xy):
        s = torch.tensor(obs_29d, dtype=torch.float32, device=self.device).unsqueeze(0)
        g = torch.tensor(goal_xy, dtype=torch.float32, device=self.device).unsqueeze(0)
        actions = self.iwm(s, g)  # (1, H, 8)
        return actions[0].cpu().numpy()


# ═════════════════════════════════════════════════════════════════════════
# Episode navigation
# ═════════════════════════════════════════════════════════════════════════

def navigate_episode(env, navigator, args, verbose=False, ep_num=0):
    """Navigate one episode using cardinal BFS waypoints + IWM."""

    global HORIZON
    obs = env.reset()
    start_xy = obs[:2].copy()
    goal_xy = np.array(env.target_goal, dtype=np.float32)

    # Plan cardinal waypoints
    ep_t0 = time.perf_counter()  # episode wall-clock start
    bfs_t0 = time.perf_counter()
    waypoints = plan_cardinal_waypoints(start_xy, goal_xy,
                                         spacing=args.wp_spacing)
    bfs_time_total = time.perf_counter() - bfs_t0
    if waypoints is None:
        if verbose:
            print(f'  No path found!', flush=True)
        return {
            'success': False, 'reward': 0, 'steps': 0,
            'final_dist': float(np.linalg.norm(obs[:2] - goal_xy)),
            'n_waypoints': 0, 'n_replans': 0, 'wp_reached': 0,
        }

    n_wp = len(waypoints)
    if verbose:
        path_dist = sum(np.linalg.norm(waypoints[i+1] - waypoints[i])
                        for i in range(n_wp - 1))
        print(f'  Plan: {n_wp} waypoints, spacing={args.wp_spacing}, '
              f'path_dist={path_dist:.2f}', flush=True)

    # Navigation loop
    total_reward = 0
    steps = 0
    wp_idx = 1  # start at first waypoint after start position
    n_replans = 0
    chunks_since_advance = 0
    max_wp_reached = 0  # track furthest waypoint reached
    trajectory = [obs.copy()]
    actions_log = []
    wp_log = []
    all_plans = [{'step': 0, 'waypoints': waypoints.tolist()}]
    plan_times = []  # wall-clock time per IWM forward pass
    mujoco_time_total = 0.0  # cumulative env.step time

    max_steps = env._max_episode_steps  # 700

    while steps < max_steps:
        current_xy = obs[:2]
        dist_to_goal = float(np.linalg.norm(current_xy - goal_xy))

        # Check success
        if dist_to_goal < args.goal_reached_dist:
            if verbose:
                print(f'  GOAL REACHED at step {steps}, dist={dist_to_goal:.3f}',
                      flush=True)
            total_reward = 1.0
            break

        # Waypoint advancement / skipping
        while wp_idx < n_wp - 1:
            dist_to_wp = float(np.linalg.norm(current_xy - waypoints[wp_idx]))
            dist_to_next = (float(np.linalg.norm(current_xy - waypoints[wp_idx + 1]))
                           if wp_idx + 1 < n_wp else float('inf'))

            if dist_to_wp < args.wp_advance_dist:
                wp_idx += 1
                chunks_since_advance = 0
                max_wp_reached = max(max_wp_reached, wp_idx)
                if verbose:
                    print(f'    Step {steps}: advance to wp {wp_idx}/{n_wp-1} '
                          f'(dist={dist_to_wp:.2f})', flush=True)
            elif wp_idx + 1 < n_wp and dist_to_next < args.wp_skip_dist:
                wp_idx += 2
                wp_idx = min(wp_idx, n_wp - 1)
                chunks_since_advance = 0
                max_wp_reached = max(max_wp_reached, wp_idx)
                if verbose:
                    print(f'    Step {steps}: skip to wp {wp_idx}/{n_wp-1}',
                          flush=True)
            else:
                break

        # Stuck → full replan from current position
        if chunks_since_advance >= args.stuck_threshold and n_replans < args.max_replan:
            n_replans += 1
            bfs_t0 = time.perf_counter()
            new_wps = plan_cardinal_waypoints(current_xy, goal_xy,
                                               spacing=args.wp_spacing)
            bfs_time_total += time.perf_counter() - bfs_t0
            if new_wps is not None and len(new_wps) >= 2:
                waypoints = new_wps
                n_wp = len(waypoints)
                wp_idx = 1
                chunks_since_advance = 0
                all_plans.append({'step': steps, 'waypoints': waypoints.tolist()})
                if verbose:
                    print(f'    Step {steps}: REPLAN #{n_replans}, {n_wp} waypoints',
                          flush=True)

        # Current target waypoint
        target_xy = waypoints[min(wp_idx, n_wp - 1)].copy()

        # Randomized target distance along waypoint direction
        use_random_target = args.target_dist_min > 0 and args.target_dist_max > 0
        if use_random_target:
            direction = target_xy - current_xy
            dir_norm = float(np.linalg.norm(direction))
            if dir_norm > 0.01:
                direction = direction / dir_norm
                rand_dist = np.random.uniform(args.target_dist_min,
                                               args.target_dist_max)
                # Don't overshoot the final goal
                if wp_idx >= n_wp - 1:
                    rand_dist = min(rand_dist, dir_norm)
                target_xy = current_xy + direction * rand_dist

        # Generate actions with IWM
        t0 = time.perf_counter()
        actions = navigator.get_actions(obs, target_xy)
        plan_times.append(time.perf_counter() - t0)
        wp_log.append({
            'step': steps, 'wp_idx': wp_idx,
            'target': target_xy.tolist(),
            'pos': current_xy.tolist(),
        })

        # Execute actions in MuJoCo
        goal_reached_in_chunk = False
        for a in actions:
            a = np.clip(a, -1.0, 1.0)
            actions_log.append(a.copy())
            mj_t0 = time.perf_counter()
            obs, reward, done, info = env.step(a)
            mujoco_time_total += time.perf_counter() - mj_t0
            total_reward += reward
            steps += 1
            trajectory.append(obs.copy())

            if steps >= max_steps:
                break
            if reward > 0:
                goal_reached_in_chunk = True
                break
            # Early stop: don't overshoot past the goal
            if float(np.linalg.norm(obs[:2] - goal_xy)) < args.goal_reached_dist:
                total_reward = max(total_reward, 1.0)
                goal_reached_in_chunk = True
                break

        if goal_reached_in_chunk:
            if verbose:
                print(f'  GOAL REACHED (mid-chunk) at step {steps}, '
                      f'dist={float(np.linalg.norm(obs[:2] - goal_xy)):.3f}',
                      flush=True)
            break

        chunks_since_advance += 1

        # Snap-to-closest waypoint after each chunk (replan_every=1)
        if args.replan_every > 0 and \
           chunks_since_advance % args.replan_every == 0 and \
           steps < max_steps and total_reward == 0:
            best_snap_idx = wp_idx
            best_snap_dist = float(np.linalg.norm(
                obs[:2] - waypoints[min(wp_idx, n_wp - 1)]))
            for wi in range(wp_idx + 1, n_wp):
                d = float(np.linalg.norm(obs[:2] - waypoints[wi]))
                if d < best_snap_dist:
                    best_snap_dist = d
                    best_snap_idx = wi
            if best_snap_idx != wp_idx:
                old_wp = wp_idx
                wp_idx = best_snap_idx
                chunks_since_advance = 0
                max_wp_reached = max(max_wp_reached, wp_idx)
                if verbose:
                    print(f'    Step {steps}: snap wp {old_wp}→{wp_idx}/{n_wp-1} '
                          f'(dist={best_snap_dist:.2f})', flush=True)

            # If too far from all waypoints, do full replan
            elif best_snap_dist > args.wp_spacing * 3.0 and \
                 n_replans < args.max_replan:
                n_replans += 1
                bfs_t0 = time.perf_counter()
                new_wps = plan_cardinal_waypoints(obs[:2], goal_xy,
                                                   spacing=args.wp_spacing)
                bfs_time_total += time.perf_counter() - bfs_t0
                if new_wps is not None and len(new_wps) >= 2:
                    waypoints = new_wps
                    n_wp = len(waypoints)
                    wp_idx = 1
                    chunks_since_advance = 0
                    all_plans.append({
                        'step': steps, 'waypoints': waypoints.tolist(),
                        'type': 'replan_snap',
                    })
                    if verbose:
                        print(f'    Step {steps}: replan → {n_wp} wp',
                              flush=True)

    # Results
    final_dist = float(np.linalg.norm(obs[:2] - goal_xy))
    success = total_reward > 0

    # Compute yaw drift and z stats from trajectory
    traj_arr = np.array(trajectory)  # (T, 29)
    # Yaw from quaternion: atan2(2*(qw*qz + qx*qy), 1 - 2*(qy² + qz²))
    qw, qx, qy, qz = traj_arr[:, 3], traj_arr[:, 4], traj_arr[:, 5], traj_arr[:, 6]
    yaw = np.degrees(np.arctan2(2 * (qw * qz + qx * qy),
                                1 - 2 * (qy**2 + qz**2)))
    yaw_drift = np.abs(yaw - yaw[0])  # drift from initial yaw
    yaw_drift_max = float(np.max(yaw_drift))
    yaw_drift_final = float(yaw[-1] - yaw[0])

    z_vals = traj_arr[:, 2]

    # Timing stats for this episode
    ep_wall_ms = (time.perf_counter() - ep_t0) * 1000
    iwm_times_arr = np.array(plan_times) if plan_times else np.array([0.0])
    iwm_total_ms = float(np.sum(iwm_times_arr) * 1000)
    bfs_total_ms = bfs_time_total * 1000
    mujoco_total_ms = mujoco_time_total * 1000
    overhead_ms = ep_wall_ms - iwm_total_ms - bfs_total_ms - mujoco_total_ms

    result = {
        'success': success,
        'reward': float(total_reward),
        'steps': steps,
        'final_dist': final_dist,
        'n_waypoints': n_wp,
        'n_replans': n_replans,
        'wp_reached': max_wp_reached,
        'goal_xy': goal_xy.tolist(),
        'start_xy': start_xy.tolist(),
        'yaw_drift_max': yaw_drift_max,
        'yaw_drift_final': yaw_drift_final,
        'z_min': float(np.min(z_vals)),
        'z_mean': float(np.mean(z_vals)),
        # Timing breakdown (ms)
        'timing_ms': {
            'episode_wall': round(ep_wall_ms, 2),
            'bfs_planning': round(bfs_total_ms, 2),
            'iwm_forward_total': round(iwm_total_ms, 2),
            'iwm_forward_mean': round(float(np.mean(iwm_times_arr) * 1000), 3),
            'iwm_forward_std': round(float(np.std(iwm_times_arr) * 1000), 3),
            'iwm_forward_max': round(float(np.max(iwm_times_arr) * 1000), 3),
            'iwm_n_calls': len(plan_times),
            'mujoco_stepping': round(mujoco_total_ms, 2),
            'overhead': round(overhead_ms, 2),
        },
    }

    if args.save_trajectories:
        result['trajectory'] = traj_arr
        result['actions'] = np.array(actions_log)
        result['wp_log'] = wp_log
        result['all_plans'] = all_plans

    return result


# ═════════════════════════════════════════════════════════════════════════
# Main
# ═════════════════════════════════════════════════════════════════════════

if __name__ == '__main__':
    args = parser.parse_args()

    # Initialize maze config from --env
    _init_maze_config(args.env)
    print(f'Maze: {args.env} ({GYM_ENV}), {N_ROWS}x{N_COLS} grid', flush=True)

    # Resolve IWM path: use default for env if not specified
    if not args.iwm_path:
        args.iwm_path = MAZE_CONFIGS[args.env]['default_iwm']
        if not args.iwm_path:
            parser.error(f'No default IWM for {args.env}, specify --iwm_path')

    if args.gpu >= 0 and torch.cuda.is_available():
        DEVICE = f'cuda:{args.gpu}'
    else:
        DEVICE = 'cpu'
    print(f'Device: {DEVICE}', flush=True)

    timestamp = time.strftime('%Y%m%d_%H%M%S')

    # Output directory (route to correct maze subfolder)
    if args.out_dir:
        OUT_DIR = Path(args.out_dir)
    elif args.exp_name:
        OUT_DIR = PROJECT_ROOT / 'antmaze' / MAZE_TYPE / 'navigate' / \
                  f'{args.exp_name}_{timestamp}'
    else:
        OUT_DIR = PROJECT_ROOT / 'antmaze' / MAZE_TYPE / 'navigate' / \
                  f'cardinal_{timestamp}'
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    if args.exp_name and not args.save_trajectories and not args.no_save_trajectories:
        args.save_trajectories = True

    print(f'Output: {OUT_DIR}', flush=True)

    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(args.seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

    # ─── Build occupancy source ───────────────────────────────────────

    if args.occupancy_source == 'data':
        # Map env name → dataset subdir (matches data/antmaze layout)
        DATA_SUBDIR = {
            'umaze': 'umaze',
            'umaze-diverse': 'umaze_diverse',
            'medium-play': 'medium_play',
            'medium-diverse': 'medium_diverse',
            'large-play': 'large_play',
            'large-diverse': 'large_diverse',
        }
        if args.data_states_path:
            states_path = Path(args.data_states_path)
        else:
            states_path = (PROJECT_ROOT / 'data' / 'antmaze'
                           / DATA_SUBDIR[args.env] / 'states.npy')
        if not states_path.exists():
            parser.error(f'DataOccupancy: states.npy not found at {states_path}')
        print(f'\nDataOccupancy: loading {states_path}', flush=True)
        xy = np.load(states_path, mmap_mode='r')[:, :2].astype(np.float32)
        if args.planner_impl == 'unified':
            OCC = CardinalBFSPlanner(
                xy,
                resolution=args.data_resolution,
                min_visits=args.data_min_visits,
                origin_mode=args.data_origin_mode,
                center_weight=args.data_center_weight,
            )
        else:
            OCC = DataOccupancy(
                xy,
                resolution=args.data_resolution,
                min_visits=args.data_min_visits,
                origin_mode=args.data_origin_mode,
            )
            OCC.center_weight = args.data_center_weight
        print(f'  Planner impl: {args.planner_impl}', flush=True)
        n_free = int(OCC.free_mask.sum())
        print(f'  DataOccupancy: {OCC.nrows}×{OCC.ncols} grid, {n_free} free cells '
              f'(res={args.data_resolution}, min_visits={args.data_min_visits}, '
              f'origin={args.data_origin_mode}, '
              f'center_weight={args.data_center_weight}, '
              f'max_dist_to_wall={int(OCC.dist_to_wall.max())})', flush=True)
    else:
        OCC = EnvOccupancy()
        print(f'\nEnvOccupancy: {N_ROWS}x{N_COLS} hardcoded MAZE_MAP', flush=True)

    # ─── Verify connectivity ──────────────────────────────────────────

    open_cells = OCC.get_open_cells()
    print(f'  Open cells: {len(open_cells)}', flush=True)
    if args.occupancy_source == 'env':
        for r, c in open_cells:
            xy = OCC.cell_to_world(r, c)
            nbrs = OCC.get_neighbors(r, c)
            print(f'  ({r},{c}) → world ({xy[0]:.0f},{xy[1]:.0f}), '
                  f'{len(nbrs)} neighbors: {nbrs}', flush=True)

    # Test BFS between two open cells
    if len(open_cells) >= 2:
        test_start, test_end = open_cells[0], open_cells[-1]
        test_path = OCC.bfs_cell_path(test_start, test_end)
        n_test_path = len(test_path) if test_path is not None else 0
        print(f'  Test BFS {test_start}→{test_end}: '
              f'{n_test_path}-cell path', flush=True)
        start_w = OCC.cell_to_world(*test_start)
        end_w = OCC.cell_to_world(*test_end)
        test_wps = plan_cardinal_waypoints(start_w, end_w, spacing=1.0)
        n_test = len(test_wps) if test_wps is not None else 0
        print(f'  Test waypoints: {n_test} points', flush=True)

    # ─── Load IWM ─────────────────────────────────────────────────────

    iwm_path = PROJECT_ROOT / args.iwm_path
    print(f'\nLoading IWM from {iwm_path}', flush=True)
    iwm_ckpt = torch.load(iwm_path, map_location='cpu', weights_only=False)

    # Handle both formats: wrapped {'model_state_dict': ...} or raw state_dict
    if isinstance(iwm_ckpt, dict) and 'model_state_dict' in iwm_ckpt:
        state_dict = iwm_ckpt['model_state_dict']
        ckpt_meta = iwm_ckpt  # has .get('horizon'), .get('epoch'), etc.
    else:
        state_dict = iwm_ckpt
        ckpt_meta = {}  # raw state_dict, no metadata

    # Read config
    config_path = iwm_path.parent / 'config.json'
    if config_path.exists():
        with open(config_path) as f:
            cfg = json.load(f)
        model_cfg = cfg.get('model', {})
    else:
        model_cfg = {}
        cfg = {}

    # Override HORIZON from checkpoint
    ckpt_horizon = ckpt_meta.get('horizon',
                                  cfg.get('experiment', {}).get('horizon', 8))
    if ckpt_horizon != HORIZON:
        print(f'  Setting HORIZON = {ckpt_horizon} (from checkpoint)', flush=True)
        HORIZON = ckpt_horizon

    relative_xy = model_cfg.get('relative_xy', False)
    iwm = AntMazeIWM(
        d_model=model_cfg.get('d_model', 192),
        n_heads=model_cfg.get('n_heads', 6),
        n_layers=model_cfg.get('n_layers', 4),
        d_ff=model_cfg.get('d_ff', 576),
        dropout=model_cfg.get('dropout', 0.1),
        relative_xy=relative_xy,
        horizon=ckpt_horizon,
    ).to(DEVICE)

    iwm.load_state_dict(state_dict)
    iwm.eval()
    n_params = sum(p.numel() for p in iwm.parameters())
    print(f'  IWM: {n_params:,} params, HORIZON={ckpt_horizon}, '
          f'epoch {ckpt_meta.get("epoch", "?")}', flush=True)

    navigator = Navigator(iwm, device=DEVICE)

    # ─── Create D4RL environment ──────────────────────────────────────

    print(f'\nCreating MuJoCo env ({GYM_ENV})...', flush=True)
    import gym
    import d4rl  # noqa
    env = gym.make(GYM_ENV)
    env.seed(args.seed)
    print('  Env ready', flush=True)

    # ─── Write config.json ───────────────────────────────────────────

    exp_config = {
        'experiment': {
            'name': args.exp_name or 'cardinal',
            'created': time.strftime('%Y-%m-%dT%H:%M:%S'),
            'script': 'antmaze/navigate_cardinal.py',
            'planner': 'cardinal_bfs',
            'occupancy_source': args.occupancy_source,
            'env': GYM_ENV,
            'iwm_path': args.iwm_path,
            'horizon': ckpt_horizon,
            'gpu': args.gpu,
        },
        'navigation': {
            'n_episodes': args.n_episodes,
            'seed': args.seed,
            'wp_spacing': args.wp_spacing,
            'wp_advance_dist': args.wp_advance_dist,
            'wp_skip_dist': args.wp_skip_dist,
            'goal_reached_dist': args.goal_reached_dist,
            'stuck_threshold': args.stuck_threshold,
            'replan_every': args.replan_every,
            'max_replan': args.max_replan,
            'target_dist_min': args.target_dist_min,
            'target_dist_max': args.target_dist_max,
        },
        'maze': {
            'scaling': SCALING,
            'n_open_cells': len(open_cells),
            # only dump full cell list for env mode (small); data mode has hundreds
            'open_cells': open_cells if args.occupancy_source == 'env' else None,
        },
        'data_occupancy': ({
            'resolution': args.data_resolution,
            'min_visits': args.data_min_visits,
            'origin_mode': args.data_origin_mode,
            'center_weight': args.data_center_weight,
            'states_path': args.data_states_path or 'auto',
            'grid_shape': [int(OCC.nrows), int(OCC.ncols)],
            'x_origin': float(OCC.x_origin),
            'y_origin': float(OCC.y_origin),
            'max_dist_to_wall': int(OCC.dist_to_wall.max()),
        } if args.occupancy_source == 'data' else None),
        'iwm_model': {
            'type': type(iwm).__name__,
            'n_params': n_params,
            'epoch': ckpt_meta.get('epoch', None),
        },
        'raw_args': ' '.join(sys.argv[1:]),
    }
    (OUT_DIR / 'config.json').write_text(json.dumps(exp_config, indent=2))

    # ─── Auto-start monitor ───────────────────────────────────────────

    monitor_proc = None
    if args.exp_name:
        monitor_script = PROJECT_ROOT / 'antmaze' / 'monitor_navigate.py'
        if monitor_script.exists():
            monitor_log = OUT_DIR / 'monitor.log'
            monitor_cmd = [
                sys.executable, '-u', str(monitor_script),
                '--out_dir', str(OUT_DIR),
                '--interval', '10',
                '--n_episodes', str(args.n_episodes),
            ]
            if args.no_episode_plots:
                monitor_cmd.append('--no_episode_plots')
            monitor_proc = subprocess.Popen(
                monitor_cmd,
                stdout=open(monitor_log, 'w'), stderr=subprocess.STDOUT,
                start_new_session=True,  # detach from parent process group
            )
            print(f'  Auto-started monitor (PID {monitor_proc.pid})',
                  flush=True)

    # ─── Run evaluation episodes ──────────────────────────────────────

    print(f'\nRunning {args.n_episodes} episodes...', flush=True)
    print('=' * 70, flush=True)

    results = []
    successes = 0
    progress_file = OUT_DIR / 'progress.json'

    for ep in range(args.n_episodes):
        verbose = args.verbose_all or (ep < 5) or ((ep + 1) % 20 == 0)
        if verbose:
            print(f'\nEpisode {ep + 1}/{args.n_episodes}:', flush=True)

        result = navigate_episode(env, navigator, args,
                                  verbose=verbose, ep_num=ep + 1)
        # Don't store numpy arrays in JSON
        result_json = {k: v for k, v in result.items()
                       if not isinstance(v, np.ndarray)}
        results.append(result_json)

        if result['success']:
            successes += 1

        # Save trajectory + actions separately if requested
        if args.save_trajectories and 'trajectory' in result:
            traj_dir = OUT_DIR / 'trajectories'
            traj_dir.mkdir(exist_ok=True)
            np.save(traj_dir / f'ep_{ep+1:03d}.npy',
                    result['trajectory'])
            if 'actions' in result:
                act_dir = OUT_DIR / 'actions'
                act_dir.mkdir(exist_ok=True)
                np.save(act_dir / f'ep_{ep+1:03d}.npy',
                        result['actions'])

        # Incremental progress
        _progress = {
            'n_episodes': args.n_episodes,
            'completed': ep + 1,
            'successes': successes,
            'success_rate': successes / (ep + 1) * 100,
            'episodes': results,
        }
        try:
            progress_file.write_text(json.dumps(_progress))
        except Exception:
            pass

        if verbose:
            status = 'SUCCESS' if result['success'] else 'FAIL'
            print(f'  {status}: dist={result["final_dist"]:.3f}, '
                  f'steps={result["steps"]}, '
                  f'replans={result["n_replans"]}, '
                  f'wp_reached={result["wp_reached"]}/{result["n_waypoints"]-1}',
                  flush=True)

        # Running stats every 10 episodes
        if (ep + 1) % 10 == 0:
            rate = successes / (ep + 1) * 100
            avg_dist = np.mean([r['final_dist'] for r in results])
            avg_steps = np.mean([r['steps'] for r in results])
            print(f'  --- After {ep + 1} eps: {rate:.1f}% success, '
                  f'avg_dist={avg_dist:.3f}, avg_steps={avg_steps:.0f}',
                  flush=True)

    # ─── Summary ──────────────────────────────────────────────────────

    success_rate = successes / args.n_episodes * 100
    final_dists = [r['final_dist'] for r in results]
    steps_arr = [r['steps'] for r in results]
    replans_arr = [r['n_replans'] for r in results]
    succ_steps = [r['steps'] for r in results if r['success']]

    print('\n' + '=' * 70, flush=True)
    print(f'RESULTS: {args.n_episodes} episodes  [cardinal BFS planner]')
    print(f'  Success rate:  {success_rate:.1f}% ({successes}/{args.n_episodes})')
    print(f'  Final dist:    {np.mean(final_dists):.3f} ± {np.std(final_dists):.3f} '
          f'(med {np.median(final_dists):.3f})')
    if succ_steps:
        print(f'  Avg steps:     {np.mean(steps_arr):.0f} '
              f'(success: {np.mean(succ_steps):.0f})')
    else:
        print(f'  Avg steps:     {np.mean(steps_arr):.0f}')
    print(f'  Avg replans:   {np.mean(replans_arr):.1f}')
    print(f'  D4RL score:    {success_rate:.1f}')
    # ─── Timing breakdown ─────────────────────────────────────────────
    timing_results = [r['timing_ms'] for r in results if 'timing_ms' in r]
    if timing_results:
        ep_walls    = [t['episode_wall'] for t in timing_results]
        bfs_totals  = [t['bfs_planning'] for t in timing_results]
        iwm_totals  = [t['iwm_forward_total'] for t in timing_results]
        iwm_means   = [t['iwm_forward_mean'] for t in timing_results]
        iwm_n       = [t['iwm_n_calls'] for t in timing_results]
        mj_totals   = [t['mujoco_stepping'] for t in timing_results]
        overheads   = [t['overhead'] for t in timing_results]
        print(f'  ─── Timing (avg per episode) ───')
        print(f'  Episode wall:  {np.mean(ep_walls):.1f} ms '
              f'(total {np.sum(ep_walls)/1000:.1f} s)')
        print(f'    BFS plan:    {np.mean(bfs_totals):.2f} ms '
              f'({np.mean(bfs_totals)/np.mean(ep_walls)*100:.1f}%)')
        print(f'    IWM forward: {np.mean(iwm_totals):.2f} ms '
              f'({np.mean(iwm_totals)/np.mean(ep_walls)*100:.1f}%) — '
              f'{np.mean(iwm_means):.3f} ms/call × {np.mean(iwm_n):.1f} calls')
        print(f'    MuJoCo step: {np.mean(mj_totals):.1f} ms '
              f'({np.mean(mj_totals)/np.mean(ep_walls)*100:.1f}%)')
        print(f'    Overhead:    {np.mean(overheads):.1f} ms '
              f'({np.mean(overheads)/np.mean(ep_walls)*100:.1f}%)')
    print('=' * 70, flush=True)

    # ─── Save results ─────────────────────────────────────────────────

    summary = {
        'args': vars(args),
        'timestamp': timestamp,
        'planner': 'cardinal_bfs',
        'n_episodes': args.n_episodes,
        'success_rate': success_rate,
        'successes': successes,
        'mean_final_dist': float(np.mean(final_dists)),
        'median_final_dist': float(np.median(final_dists)),
        'std_final_dist': float(np.std(final_dists)),
        'mean_steps': float(np.mean(steps_arr)),
        'mean_success_steps': float(np.mean(succ_steps)) if succ_steps else None,
        'mean_replans': float(np.mean(replans_arr)),
        'd4rl_score': success_rate,
    }
    # Add aggregate timing stats
    if timing_results:
        summary['timing_avg_ms'] = {
            'episode_wall': round(float(np.mean(ep_walls)), 2),
            'bfs_planning': round(float(np.mean(bfs_totals)), 2),
            'iwm_forward_total': round(float(np.mean(iwm_totals)), 2),
            'iwm_forward_per_call': round(float(np.mean(iwm_means)), 3),
            'iwm_n_calls': round(float(np.mean(iwm_n)), 1),
            'mujoco_stepping': round(float(np.mean(mj_totals)), 2),
            'overhead': round(float(np.mean(overheads)), 2),
        }
    summary['episodes'] = results
    out_path = OUT_DIR / 'results.json'
    with open(out_path, 'w') as f:
        json.dump(summary, f, indent=2)
    print(f'\nResults saved to {out_path}', flush=True)

    # Wait for monitor to finish generating all plots (it self-exits when
    # n >= n_episodes).  Give it up to 10 minutes for large runs, then kill.
    if monitor_proc is not None:
        print(f'Waiting for monitor (PID {monitor_proc.pid}) to finish plots...',
              flush=True)
        try:
            monitor_proc.wait(timeout=600)  # 10 min max
            print(f'Monitor exited cleanly (PID {monitor_proc.pid})', flush=True)
        except subprocess.TimeoutExpired:
            print(f'Monitor timed out — terminating (PID {monitor_proc.pid})',
                  flush=True)
            monitor_proc.terminate()
            try:
                monitor_proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                monitor_proc.kill()
