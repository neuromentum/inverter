"""
Train Transformer-based FULL 29-DOF chunk forward model for AntMaze medium.

    F(s₀, [a₀, ..., a_{L-1}]) → [s₁, s₂, ..., s_L]     (all 29 state dims)

Based on antmaze/umaze/fm/unified/L8/train_fm_unified.py but for medium maze.
Uses episode-aware data sampling from medium_play dataset.

When --zscore_loss is set, each dimension GROUP gets its own running-σ normalisation,
so the optimiser sees unit-variance gradients from every group regardless of their
raw MSE scale.

    L_flat   = mean over (B, L, 29) of (pred - target)²     (original)
    L_zscore = Σ_g λ_g · MSE_g / σ_g                        (z-score mode)

Usage:
    # Original behaviour (flat MSE):
    python antmaze/medium/fm/L8/transformer/train_fm_unified.py --gpu 0

    # Z-score per-group normalisation:
    python antmaze/medium/fm/L8/transformer/train_fm_unified.py --gpu 0 --zscore_loss

    # Z-score with custom per-group lambdas:
    python antmaze/medium/fm/L8/transformer/train_fm_unified.py --gpu 0 --zscore_loss \\
        --lambda_xy 2.0 --lambda_z 2.0 --lambda_quat 2.0
"""

import sys, os, argparse, json, time, subprocess, math
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import torch
import torch.nn as nn
import numpy as np
from pathlib import Path
from datetime import datetime
from torch.utils.data import Dataset, DataLoader


# ─── Args ───────────────────────────────────────────────────────────────

parser = argparse.ArgumentParser()
parser.add_argument('--gpu', type=int, default=0)
parser.add_argument('--chunk_length', type=int, default=8)
parser.add_argument('--d_model', type=int, default=384,
                    help='Transformer hidden dimension')
parser.add_argument('--n_heads', type=int, default=6)
parser.add_argument('--n_layers', type=int, default=6)
parser.add_argument('--ff_mult', type=int, default=4,
                    help='FFN dimension multiplier')
parser.add_argument('--epochs', type=int, default=2000)
parser.add_argument('--batch_size', type=int, default=512)
parser.add_argument('--lr', type=float, default=3e-4)
parser.add_argument('--weight_decay', type=float, default=1e-4)
parser.add_argument('--dropout', type=float, default=0.1)
parser.add_argument('--s0_noise', type=float, default=0.01,
                    help='Std of Gaussian noise added to (normalized) s0')
parser.add_argument('--action_noise', type=float, default=0.0,
                    help='Std of Gaussian noise added to (normalized) actions')
parser.add_argument('--min_ep_len', type=int, default=20)
parser.add_argument('--n_train', type=int, default=800_000)
parser.add_argument('--n_val', type=int, default=80_000)
parser.add_argument('--seed', type=int, default=42)
parser.add_argument('--name', type=str, default=None)
parser.add_argument('--out_dir', type=str, default=None)
parser.add_argument('--data_dir', type=str, default=None)

# ─── Z-score loss args ──────────────────────────────────────────────────
parser.add_argument('--zscore_loss', action='store_true',
                    help='Enable per-group z-score loss normalisation')
parser.add_argument('--zscore_momentum', type=float, default=0.99,
                    help='EMA momentum for running σ')
parser.add_argument('--zscore_warmup', type=int, default=100,
                    help='Number of batches before σ normalisation activates')
# Resume from checkpoint
parser.add_argument('--resume', type=str, default=None,
                    help='Path to checkpoint.pt or output dir to resume from')
# Per-group lambdas (default 1.0 = equal importance in standardised space)
parser.add_argument('--lambda_xy', type=float, default=1.0)
parser.add_argument('--lambda_z', type=float, default=1.0)
parser.add_argument('--lambda_quat', type=float, default=1.0)
parser.add_argument('--lambda_jnt_ang', type=float, default=1.0)
parser.add_argument('--lambda_lin_vel', type=float, default=1.0)
parser.add_argument('--lambda_ang_vel', type=float, default=1.0)
parser.add_argument('--lambda_jnt_vel', type=float, default=1.0)

args = parser.parse_args()

os.environ['CUDA_VISIBLE_DEVICES'] = str(args.gpu)
DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'

PROJECT_ROOT = Path(__file__).resolve().parents[4]   # → iwbm-paper/
timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')

# Resolve resume path
resume_ckpt_path = None
if args.resume:
    rp = Path(args.resume)
    if rp.is_dir():
        resume_ckpt_path = rp / 'checkpoint.pt'
    else:
        resume_ckpt_path = rp
    if not resume_ckpt_path.exists():
        print(f'ERROR: checkpoint not found at {resume_ckpt_path}', flush=True)
        sys.exit(1)
    # When resuming, default out_dir to the resumed run's directory
    if args.out_dir is None:
        args.out_dir = str(resume_ckpt_path.parent)

if args.out_dir:
    OUT_DIR = Path(args.out_dir)
else:
    prefix = 'fm_zscore' if args.zscore_loss else 'fm_flat'
    exp_name = args.name or f'{prefix}_L{args.chunk_length}'
    OUT_DIR = Path(__file__).resolve().parent / f'{exp_name}_{timestamp}'
OUT_DIR.mkdir(parents=True, exist_ok=True)
run_name = OUT_DIR.name

STATE_DIM = 29
ACTION_DIM = 8

# Dimension groups for per-group loss & reporting
DIM_GROUPS = {
    'xy':       (0, 2),
    'z':        (2, 3),
    'quat':     (3, 7),
    'jnt_ang':  (7, 15),
    'lin_vel':  (15, 18),
    'ang_vel':  (18, 21),
    'jnt_vel':  (21, 29),
}

GROUP_DIMS = {k: hi - lo for k, (lo, hi) in DIM_GROUPS.items()}
TOTAL_DIMS = sum(GROUP_DIMS.values())  # 29

DIM_NAMES = [
    'x_pos', 'y_pos', 'z_height',
    'quat_w', 'quat_x', 'quat_y', 'quat_z',
    'hip1_ang', 'ankle1_ang', 'hip2_ang', 'ankle2_ang',
    'hip3_ang', 'ankle3_ang', 'hip4_ang', 'ankle4_ang',
    'vx', 'vy', 'vz', 'wx', 'wy', 'wz',
    'hip1_vel', 'ankle1_vel', 'hip2_vel', 'ankle2_vel',
    'hip3_vel', 'ankle3_vel', 'hip4_vel', 'ankle4_vel',
]


# ═══════════════════════════════════════════════════════════════════════
# Full 29D Transformer Forward Model (self-contained)
# ═══════════════════════════════════════════════════════════════════════

class AntMazeFull29TransformerFM(nn.Module):
    """
    Causal Transformer FM predicting all 29 state dimensions.
    Sequence: [s₀_token, a₀_token, ..., a_{L-1}_token]
    Output:   [s₁, ..., s_L] — s₀ + residuals
    """
    def __init__(self, state_dim=29, action_dim=8, chunk_length=8,
                 d_model=384, n_heads=6, n_layers=6, ff_mult=4, dropout=0.1):
        super().__init__()
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.chunk_length = chunk_length
        self.d_model = d_model
        self.n_heads = n_heads
        self.n_layers_tfm = n_layers
        self.ff_mult = ff_mult

        self.state_embed = nn.Sequential(
            nn.Linear(state_dim, d_model), nn.GELU(),
            nn.LayerNorm(d_model), nn.Linear(d_model, d_model),
        )
        self.action_embed = nn.Sequential(
            nn.Linear(action_dim, d_model), nn.GELU(),
            nn.LayerNorm(d_model), nn.Linear(d_model, d_model),
        )
        self.pos_embed = nn.Parameter(torch.randn(1, chunk_length + 1, d_model) * 0.02)
        self.type_embed = nn.Parameter(torch.randn(1, 2, d_model) * 0.02)

        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model, nhead=n_heads,
            dim_feedforward=d_model * ff_mult,
            dropout=dropout, activation='gelu',
            batch_first=True, norm_first=True,
        )
        self.transformer = nn.TransformerEncoder(
            encoder_layer, num_layers=n_layers,
            norm=nn.LayerNorm(d_model),
        )
        self.output_head = nn.Sequential(
            nn.Linear(d_model, d_model), nn.GELU(),
            nn.Dropout(dropout), nn.Linear(d_model, state_dim),
        )
        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
        nn.init.zeros_(self.output_head[-1].weight)
        nn.init.zeros_(self.output_head[-1].bias)

    def forward(self, state, actions):
        B = state.shape[0]
        L = self.chunk_length
        s_tok = self.state_embed(state).unsqueeze(1)
        a_tok = self.action_embed(actions)
        tokens = torch.cat([s_tok, a_tok], dim=1)
        tokens = tokens + self.pos_embed[:, :L + 1, :]
        type_ids = torch.zeros(B, L + 1, self.d_model, device=tokens.device)
        type_ids[:, 0, :] = self.type_embed[:, 0, :]
        type_ids[:, 1:, :] = self.type_embed[:, 1, :]
        tokens = tokens + type_ids
        causal_mask = torch.triu(
            torch.full((L + 1, L + 1), float('-inf'), device=tokens.device),
            diagonal=1,
        )
        out = self.transformer(tokens, mask=causal_mask)
        out_actions = out[:, 1:, :]
        deltas = self.output_head(out_actions)
        return state.unsqueeze(1) + deltas


# ═══════════════════════════════════════════════════════════════════════
# Dataset
# ═══════════════════════════════════════════════════════════════════════

class AntMazeFull29Dataset(Dataset):
    """Episode-aware dataset returning full 29D state targets."""
    def __init__(self, states, actions, ep_lens, chunk_length, n_samples,
                 min_ep_len, state_mean, state_std, action_mean, action_std,
                 seed=42):
        self.L = chunk_length
        self.n_samples = n_samples
        self.states_norm = ((states - state_mean) / state_std).astype(np.float32)
        self.actions_norm = ((actions - action_mean) / action_std).astype(np.float32)

        valid_starts = []
        ep_start = 0
        n_skipped_eps = 0
        n_skipped_steps = 0
        for ep_len in ep_lens:
            ep_len = int(ep_len)
            if ep_len < min_ep_len:
                n_skipped_eps += 1
                n_skipped_steps += ep_len
                ep_start += ep_len
                continue
            max_t = ep_start + ep_len - chunk_length
            if max_t > ep_start:
                valid_starts.append(np.arange(ep_start, max_t))
            ep_start += ep_len

        self.valid_starts = np.concatenate(valid_starts) if valid_starts else np.array([], dtype=np.int64)
        self.n_skipped_eps = n_skipped_eps
        self.n_skipped_steps = n_skipped_steps
        rng = np.random.RandomState(seed)
        self.indices = self.valid_starts[rng.randint(0, len(self.valid_starts), size=n_samples)]

    def __len__(self):
        return self.n_samples

    def __getitem__(self, idx):
        t = self.indices[idx]
        s0 = self.states_norm[t]
        actions = self.actions_norm[t:t + self.L]
        targets = self.states_norm[t + 1:t + 1 + self.L]
        return (torch.from_numpy(s0), torch.from_numpy(actions),
                torch.from_numpy(targets))


# ═══════════════════════════════════════════════════════════════════════
# RunningStd — EMA-based σ tracker (from IWM unified script)
# ═══════════════════════════════════════════════════════════════════════

class RunningStd:
    """EMA-based running standard deviation estimator.
    During the first `warmup` updates, returns 1.0 (no normalisation).
    """
    def __init__(self, momentum=0.99, warmup=100):
        self.momentum = momentum
        self.warmup = warmup
        self.n = 0
        self._mean = 0.0
        self._var = 0.0

    def update(self, x):
        self.n += 1
        alpha = min(1.0 - self.momentum, 1.0 / self.n)
        delta = x - self._mean
        self._mean += alpha * delta
        self._var = (1.0 - alpha) * (self._var + alpha * delta * delta)
        if self.n < self.warmup:
            return 1.0
        return max(self._var ** 0.5, 1e-8)

    @property
    def std(self):
        if self.n < self.warmup:
            return 1.0
        return max(self._var ** 0.5, 1e-8)

    @property
    def mean(self):
        return self._mean

    def state_dict(self):
        return {'n': self.n, 'mean': self._mean, 'var': self._var,
                'momentum': self.momentum, 'warmup': self.warmup}

    def load_state_dict(self, d):
        self.n = d['n']
        self._mean = d['mean']
        self._var = d['var']
        self.momentum = d['momentum']
        self.warmup = d['warmup']


# ═══════════════════════════════════════════════════════════════════════
# Load data
# ═══════════════════════════════════════════════════════════════════════

mode_str = 'Z-SCORE per-group' if args.zscore_loss else 'FLAT MSE (original)'
print(f'\n{"="*70}')
print(f'Training AntMaze Medium Full-29D Transformer FM  [{mode_str}]')
print(f'  Experiment: {run_name}')
print(f'  Output:     {OUT_DIR}')
print(f'{"="*70}')
print(f'Chunk L={args.chunk_length}, d_model={args.d_model}, heads={args.n_heads}, '
      f'layers={args.n_layers}, ff_mult={args.ff_mult}, '
      f'dropout={args.dropout}, wd={args.weight_decay}', flush=True)

if args.zscore_loss:
    lambdas = {g: getattr(args, f'lambda_{g}') for g in DIM_GROUPS}
    print(f'  Z-score: momentum={args.zscore_momentum}, warmup={args.zscore_warmup}')
    print(f'  Lambdas: {lambdas}', flush=True)

data_dir = Path(args.data_dir) if args.data_dir else PROJECT_ROOT / 'data' / 'antmaze' / 'large_diverse'
print(f'Loading data from {data_dir} ...', flush=True)

all_states = np.load(data_dir / 'states.npy').astype(np.float64)
all_actions = np.load(data_dir / 'actions.npy').astype(np.float64)
ep_lens = np.load(data_dir / 'episode_lengths.npy')

print(f'  States: {all_states.shape}, Actions: {all_actions.shape}')
print(f'  Episodes: {len(ep_lens):,}, total steps: {ep_lens.sum():,}')


# ─── Z-score normalization (input normalisation, same as original) ────

state_mean = all_states.mean(axis=0)
state_std = all_states.std(axis=0)
state_std[state_std < 1e-6] = 1.0

action_mean = all_actions.mean(axis=0)
action_std = all_actions.std(axis=0)
action_std[action_std < 1e-6] = 1.0

print(f'\n  Per-dimension normalization stats:')
print(f'  {"dim":>3s}  {"name":>14s}  {"mean":>8s}  {"std":>8s}  {"min":>8s}  {"max":>8s}')
for i, name in enumerate(DIM_NAMES):
    vals = all_states[:, i]
    print(f'  [{i:2d}]  {name:>14s}  {state_mean[i]:8.3f}  {state_std[i]:8.3f}  '
          f'{vals.min():8.3f}  {vals.max():8.3f}')

print(f'\n  Per-group std (governs z-score scale):')
for gname, (lo, hi) in DIM_GROUPS.items():
    stds = state_std[lo:hi]
    print(f'    {gname:>10s} [{lo:2d}-{hi:2d}): std_mean={stds.mean():.4f}  '
          f'std_range=[{stds.min():.4f}, {stds.max():.4f}]')

np.savez(OUT_DIR / 'norm_stats.npz',
         state_mean=state_mean, state_std=state_std,
         action_mean=action_mean, action_std=action_std)
with open(OUT_DIR / 'norm_stats.json', 'w') as f:
    json.dump({
        'state_mean': state_mean.tolist(), 'state_std': state_std.tolist(),
        'action_mean': action_mean.tolist(), 'action_std': action_std.tolist(),
    }, f, indent=2)
print(f'  Saved norm_stats to {OUT_DIR}', flush=True)


# ─── Datasets ─────────────────────────────────────────────────────────

L = args.chunk_length

train_ds = AntMazeFull29Dataset(
    all_states, all_actions, ep_lens, L, args.n_train,
    min_ep_len=args.min_ep_len,
    state_mean=state_mean, state_std=state_std,
    action_mean=action_mean, action_std=action_std,
    seed=args.seed,
)
val_ds = AntMazeFull29Dataset(
    all_states, all_actions, ep_lens, L, args.n_val,
    min_ep_len=args.min_ep_len,
    state_mean=state_mean, state_std=state_std,
    action_mean=action_mean, action_std=action_std,
    seed=args.seed + 1,
)

print(f'\n  Episode-aware sampling (min_ep_len={args.min_ep_len}):')
print(f'    Skipped {train_ds.n_skipped_eps:,} short episodes '
      f'({train_ds.n_skipped_steps:,} steps)')
print(f'    Valid starts: {len(train_ds.valid_starts):,}')
print(f'    Train: {len(train_ds):,}, Val: {len(val_ds):,}')

train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True,
                          num_workers=4, pin_memory=True, persistent_workers=True)
val_loader = DataLoader(val_ds, batch_size=args.batch_size * 2, shuffle=False,
                        num_workers=4, pin_memory=True, persistent_workers=True)


# ─── Model ────────────────────────────────────────────────────────────

model = AntMazeFull29TransformerFM(
    state_dim=STATE_DIM, action_dim=ACTION_DIM,
    chunk_length=L,
    d_model=args.d_model,
    n_heads=args.n_heads,
    n_layers=args.n_layers,
    ff_mult=args.ff_mult,
    dropout=args.dropout,
).to(DEVICE)

n_params = sum(p.numel() for p in model.parameters())
print(f'\n  Model: AntMazeFull29TransformerFM')
print(f'    Input:  s₀(29) → [s₀_tok, a₀_tok, ..., a_{{L-1}}_tok] = {L+1} tokens')
print(f'    Output: {L}×{STATE_DIM} = {L*STATE_DIM} values (full state residuals)')
print(f'    d_model={args.d_model}, heads={args.n_heads}, layers={args.n_layers}, '
      f'ff_dim={args.d_model * args.ff_mult}')
print(f'    Parameters: {n_params:,}', flush=True)

optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr,
                               weight_decay=args.weight_decay,
                               betas=(0.9, 0.95))


def get_lr(epoch, warmup_epochs=10, total_epochs=300, base_lr=3e-4, min_lr=1e-5):
    """Linear warmup + cosine decay."""
    if epoch < warmup_epochs:
        return base_lr * (epoch + 1) / warmup_epochs
    progress = (epoch - warmup_epochs) / max(1, total_epochs - warmup_epochs)
    return min_lr + 0.5 * (base_lr - min_lr) * (1 + math.cos(math.pi * progress))


# ─── Z-score: σ trackers ─────────────────────────────────────────────

sigma_trackers = None
if args.zscore_loss:
    sigma_trackers = {g: RunningStd(momentum=args.zscore_momentum,
                                     warmup=args.zscore_warmup)
                      for g in DIM_GROUPS}
    lambdas = {g: getattr(args, f'lambda_{g}') for g in DIM_GROUPS}


# ─── Config ───────────────────────────────────────────────────────────

config = {
    'experiment': {
        'name': run_name,
        'created': datetime.now().isoformat(timespec='seconds'),
        'script': str(Path(__file__).resolve().relative_to(PROJECT_ROOT)),
        'gpu': args.gpu,
        'python': sys.executable,
        'project_root': str(PROJECT_ROOT),
    },
    'training': {
        'chunk_length': args.chunk_length,
        'd_model': args.d_model,
        'n_heads': args.n_heads,
        'n_layers': args.n_layers,
        'ff_mult': args.ff_mult,
        'epochs': args.epochs,
        'batch_size': args.batch_size,
        'lr': args.lr,
        'weight_decay': args.weight_decay,
        'dropout': args.dropout,
        's0_noise': args.s0_noise,
        'action_noise': args.action_noise,
        'min_ep_len': args.min_ep_len,
        'n_train': args.n_train,
        'n_val': args.n_val,
        'seed': args.seed,
        'zscore_loss': args.zscore_loss,
    },
    'model': {
        'type': 'AntMazeFull29TransformerFM',
        'state_dim': STATE_DIM,
        'action_dim': ACTION_DIM,
        'output_dim': STATE_DIM,
        'n_params': n_params,
    },
    'data': {
        'env': 'antmaze-medium-play-v2',
        'data_dir': str(data_dir),
        'n_episodes': int(len(ep_lens)),
        'n_steps': int(ep_lens.sum()),
        'n_valid_starts': int(len(train_ds.valid_starts)),
    },
    'dim_groups': {k: list(v) for k, v in DIM_GROUPS.items()},
    'raw_args': sys.argv[1:],
}
if args.zscore_loss:
    config['training']['zscore_momentum'] = args.zscore_momentum
    config['training']['zscore_warmup'] = args.zscore_warmup
    config['training']['lambdas'] = {g: getattr(args, f'lambda_{g}')
                                     for g in DIM_GROUPS}

with open(OUT_DIR / 'config.json', 'w') as f:
    json.dump(config, f, indent=2)


# ─── Auto-start monitor ──────────────────────────────────────────────

monitor_proc = None
monitor_script = Path(__file__).resolve().parents[2] / 'monitor_fm_dark.py'
if monitor_script.exists():
    monitor_log = OUT_DIR / 'monitor.log'
    monitor_cmd = [
        sys.executable, '-u', str(monitor_script),
        '--out_dir', str(OUT_DIR),
        '--interval', '30',
    ]
    monitor_proc = subprocess.Popen(
        monitor_cmd,
        stdout=open(monitor_log, 'w'), stderr=subprocess.STDOUT,
        start_new_session=True,
    )
    print(f'  Auto-started monitor (PID {monitor_proc.pid}) → {monitor_log.name}', flush=True)
else:
    print(f'  Monitor script not found at {monitor_script}', flush=True)


# ═══════════════════════════════════════════════════════════════════════
# Training loop
# ═══════════════════════════════════════════════════════════════════════

# ─── Resume from checkpoint ───────────────────────────────────────────

start_epoch = 0
best_val_loss = float('inf')
best_epoch = 0
train_history = []
val_history = []

if resume_ckpt_path is not None:
    print(f'\nResuming from {resume_ckpt_path}', flush=True)
    ckpt = torch.load(resume_ckpt_path, map_location=DEVICE, weights_only=False)
    model.load_state_dict(ckpt['model_state_dict'])
    optimizer.load_state_dict(ckpt['optimizer_state_dict'])
    start_epoch = ckpt['epoch'] + 1  # checkpoint saves 0-indexed epoch
    best_val_loss = ckpt['best_val_loss']
    best_epoch = ckpt['best_epoch']
    train_history = ckpt.get('train_history', [])
    val_history = ckpt.get('val_history', [])
    if args.zscore_loss and 'sigma_trackers' in ckpt:
        for g in DIM_GROUPS:
            if g in ckpt['sigma_trackers']:
                sigma_trackers[g].load_state_dict(ckpt['sigma_trackers'][g])
    print(f'  Resumed at epoch {start_epoch}, best_val_loss={best_val_loss:.6f} '
          f'@ epoch {best_epoch}', flush=True)

print(f'\nTraining epochs {start_epoch}–{args.epochs-1} on {DEVICE} (GPU {args.gpu})...\n', flush=True)

t_start = time.time()

for epoch in range(start_epoch, args.epochs):
    # ── LR schedule ──
    lr_now = get_lr(epoch, warmup_epochs=10, total_epochs=args.epochs,
                    base_lr=args.lr, min_lr=1e-5)
    for pg in optimizer.param_groups:
        pg['lr'] = lr_now

    # ── Train ──
    model.train()
    epoch_losses = []
    epoch_group_losses = {k: [] for k in DIM_GROUPS}

    for s0, actions, targets in train_loader:
        s0 = s0.to(DEVICE, non_blocking=True)
        actions = actions.to(DEVICE, non_blocking=True)
        targets = targets.to(DEVICE, non_blocking=True)

        if args.s0_noise > 0:
            s0_noisy = s0 + args.s0_noise * torch.randn_like(s0)
        else:
            s0_noisy = s0

        if args.action_noise > 0:
            actions_noisy = actions + args.action_noise * torch.randn_like(actions)
        else:
            actions_noisy = actions

        pred = model(s0_noisy, actions_noisy)   # (B, L, 29)

        # ── Compute loss ──
        if args.zscore_loss:
            # Per-group MSE → z-score normalise → weighted sum
            group_mses = {}
            for gname, (lo, hi) in DIM_GROUPS.items():
                group_mses[gname] = ((pred[:, :, lo:hi] - targets[:, :, lo:hi]) ** 2).mean()

            # Update σ trackers with detached values
            sigmas_now = {}
            for gname in DIM_GROUPS:
                sigmas_now[gname] = sigma_trackers[gname].update(group_mses[gname].item())

            # Weighted z-score loss
            loss = sum(lambdas[gname] * group_mses[gname] / sigmas_now[gname]
                       for gname in DIM_GROUPS)
        else:
            # Original flat MSE
            loss = ((pred - targets) ** 2).mean()

        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()

        epoch_losses.append(loss.item())

        # Per-group tracking (detached, cheap)
        with torch.no_grad():
            for gname, (lo, hi) in DIM_GROUPS.items():
                if args.zscore_loss:
                    # Already computed above
                    epoch_group_losses[gname].append(group_mses[gname].item())
                else:
                    g_mse = ((pred[:, :, lo:hi] - targets[:, :, lo:hi]) ** 2).mean().item()
                    epoch_group_losses[gname].append(g_mse)

    avg_train_loss = float(np.mean(epoch_losses))
    avg_train_groups = {k: float(np.mean(v)) for k, v in epoch_group_losses.items()}

    # Train history entry
    train_entry = {'total': avg_train_loss, **avg_train_groups}
    if args.zscore_loss:
        for gname in DIM_GROUPS:
            train_entry[f'sigma_{gname}'] = sigma_trackers[gname].std
    train_history.append(train_entry)

    # ── Validate ──
    model.eval()
    val_losses = []
    val_group_losses = {k: [] for k in DIM_GROUPS}
    step_errors = {k: [[] for _ in range(L)] for k in DIM_GROUPS}

    with torch.no_grad():
        for s0, actions, targets in val_loader:
            s0 = s0.to(DEVICE, non_blocking=True)
            actions = actions.to(DEVICE, non_blocking=True)
            targets = targets.to(DEVICE, non_blocking=True)

            pred = model(s0, actions)

            # Always compute flat MSE for val (comparable with reference)
            flat_loss = ((pred - targets) ** 2).mean().item()

            # Per-group MSE
            for gname, (lo, hi) in DIM_GROUPS.items():
                g_mse = ((pred[:, :, lo:hi] - targets[:, :, lo:hi]) ** 2).mean().item()
                val_group_losses[gname].append(g_mse)
                for step in range(L):
                    se = ((pred[:, step, lo:hi] - targets[:, step, lo:hi]) ** 2).mean().item()
                    step_errors[gname][step].append(se)

            if args.zscore_loss:
                # Z-score val loss (using current σ, no update)
                zs_loss = sum(lambdas[gname] * np.mean(val_group_losses[gname]) / sigma_trackers[gname].std
                              for gname in DIM_GROUPS)
                val_losses.append(flat_loss)  # track flat for comparability
            else:
                val_losses.append(flat_loss)

    avg_val_loss = float(np.mean(val_losses))  # always flat MSE for best-model selection
    avg_val_groups = {k: float(np.mean(v)) for k, v in val_group_losses.items()}
    val_history.append({'total': avg_val_loss, **avg_val_groups})

    per_step_mse = {k: [float(np.mean(errs)) for errs in step_errors[k]]
                    for k in DIM_GROUPS}

    # Physical-scale RMSE for interpretable dims
    rmse_xy_phys = np.sqrt(avg_val_groups['xy']) * float(state_std[:2].mean())
    rmse_quat_phys = np.sqrt(avg_val_groups['quat']) * float(state_std[3:7].mean())

    # ── Checkpoint (best-model by flat val MSE) ──
    improved = ''
    if avg_val_loss < best_val_loss:
        best_val_loss = avg_val_loss
        best_epoch = epoch
        save_dict = {
            'model_state_dict': model.state_dict(),
            'model_type': 'antmaze_full29_transformer_fm',
            'state_dim': STATE_DIM,
            'action_dim': ACTION_DIM,
            'chunk_length': L,
            'd_model': args.d_model,
            'n_heads': args.n_heads,
            'n_layers': args.n_layers,
            'ff_mult': args.ff_mult,
            'dropout': args.dropout,
            'epoch': epoch,
            'val_loss': best_val_loss,
            'val_groups': avg_val_groups,
            'state_mean': state_mean.tolist(),
            'state_std': state_std.tolist(),
            'action_mean': action_mean.tolist(),
            'action_std': action_std.tolist(),
            'args': vars(args),
        }
        if args.zscore_loss:
            save_dict['sigma_trackers'] = {g: sigma_trackers[g].state_dict()
                                           for g in DIM_GROUPS}
        torch.save(save_dict, OUT_DIR / 'best_model.pt')
        improved = ' ★'

    ckpt = {
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'epoch': epoch,
        'best_val_loss': best_val_loss,
        'best_epoch': best_epoch,
        'train_history': train_history,
        'val_history': val_history,
    }
    if args.zscore_loss:
        ckpt['sigma_trackers'] = {g: sigma_trackers[g].state_dict()
                                  for g in DIM_GROUPS}
    torch.save(ckpt, OUT_DIR / 'checkpoint.pt')

    elapsed = time.time() - t_start
    epochs_done = epoch - start_epoch + 1
    eta = elapsed / epochs_done * (args.epochs - epoch - 1)

    # ── progress.json ──
    progress = {
        'experiment': run_name,
        'epoch': epoch + 1,
        'total_epochs': args.epochs,
        'train_loss': avg_train_loss,
        'val_loss': avg_val_loss,
        'best_val_loss': best_val_loss,
        'best_epoch': best_epoch,
        'elapsed_s': elapsed,
        'eta_s': eta,
        'lr': lr_now,
        'rmse_xy_phys': float(rmse_xy_phys),
        'rmse_quat_phys': float(rmse_quat_phys),
        'group_mse': avg_val_groups,
        'per_step_mse': per_step_mse,
        'zscore_loss': args.zscore_loss,
    }
    if args.zscore_loss:
        progress['sigmas'] = {g: sigma_trackers[g].std for g in DIM_GROUPS}
        progress['lambdas'] = lambdas
    with open(OUT_DIR / 'progress.json', 'w') as f:
        json.dump(progress, f, indent=2)

    # ── Logging ──
    if args.zscore_loss:
        sigma_str = ' '.join(f'σ_{k[:2]}:{sigma_trackers[k].std:.4f}'
                             for k in ['xy', 'z', 'quat', 'ang_vel'])
    else:
        sigma_str = ''

    if epoch % 5 == 0 or improved:
        group_str = '  '.join(f'{k}={v:.5f}' for k, v in avg_val_groups.items())
        print(f'  ep {epoch:3d}/{args.epochs}  '
              f'train={avg_train_loss:.5f}  val={avg_val_loss:.5f}  '
              f'best={best_val_loss:.5f}(@{best_epoch}){improved}  '
              f'xy_rmse={rmse_xy_phys:.4f}m  quat_rmse={rmse_quat_phys:.4f}  '
              f'lr={lr_now:.2e}  {sigma_str}  '
              f'[{elapsed/60:.0f}m, eta {eta/60:.0f}m]', flush=True)
        if epoch % 20 == 0:
            print(f'    groups: {group_str}', flush=True)

    if (epoch + 1) % 50 == 0:
        torch.save(model.state_dict(), OUT_DIR / f'model_ep{epoch+1}.pt')

    if (epoch + 1) % 10 == 0:
        with open(OUT_DIR / 'history.json', 'w') as f:
            json.dump({'train': train_history, 'val': val_history}, f)


# ─── Final ────────────────────────────────────────────────────────────

torch.save(model.state_dict(), OUT_DIR / 'final_model.pt')
with open(OUT_DIR / 'history.json', 'w') as f:
    json.dump({'train': train_history, 'val': val_history}, f)

total_time = time.time() - t_start
print(f'\n{"="*70}')
print(f'Training complete in {total_time/60:.1f} minutes')
print(f'Best val loss: {best_val_loss:.6f} at epoch {best_epoch}')
print(f'  Group MSE at best epoch:')
best_groups = val_history[best_epoch]
for gname, (lo, hi) in DIM_GROUPS.items():
    val = best_groups.get(gname, 0)
    rmse = np.sqrt(val) * float(state_std[lo:hi].mean())
    print(f'    {gname:>10s}: MSE={val:.6f}  RMSE(phys)={rmse:.4f}')
if args.zscore_loss:
    print(f'  Final σ values:')
    for gname in DIM_GROUPS:
        print(f'    {gname:>10s}: σ={sigma_trackers[gname].std:.6f}  '
              f'eff_λ={lambdas[gname]/sigma_trackers[gname].std:.2f}')
print(f'Output: {OUT_DIR}')
print(f'{"="*70}')

if monitor_proc is not None:
    monitor_proc.terminate()
    try:
        monitor_proc.wait(timeout=10)
    except subprocess.TimeoutExpired:
        monitor_proc.kill()
    print(f'  Monitor stopped.', flush=True)
