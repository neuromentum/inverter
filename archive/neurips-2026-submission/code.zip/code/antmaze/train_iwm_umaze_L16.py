"""
Unified IWM training for antmaze-umaze-v2 (healthy-29D architecture).

Identical to antmaze/train_iwm_healthy29d.py, with one addition:

    --zscore_loss   Normalise each raw loss by its running σ (EMA) before
                    applying λ.  This makes λ operate on unit-variance signals,
                    so the numbers become interpretable as "how many standard
                    deviations of gradient contribution".

Without --zscore_loss the behaviour is *exactly* the original script — every
code path, every number, every checkpoint format.  The z-score machinery only
activates when the flag is set.

Derivation:
    Original:   total = λ_t·L_t + λ_h·L_h + λ_f·L_f
    Z-scored:   total = λ_t·(L_t/σ_t) + λ_h·(L_h/σ_h) + λ_f·(L_f/σ_f)

    To reproduce the same gradient:  λ_z = λ_orig × σ_raw
    The ×100 rescaling is a cosmetic convention (keeps λ values in O(1–50)
    range for readability).

See NOTES.md in this directory for the full derivation and reference σ values.

Usage:
    # Baseline (identical to original h40 run):
    python antmaze/umaze/iwm/unified/train_iwm_unified.py --gpu 0 \\
        --fm_path antmaze/umaze/fm/L8/transformer/fm_full29_L8_20260401_075554/best_model.pt \\
        --name baseline_h40 --lambda_health 40.0

    # Z-score experiment (λ_z×100 from h40):
    python antmaze/umaze/iwm/unified/train_iwm_unified.py --gpu 0 \\
        --fm_path antmaze/umaze/fm/L8/transformer/fm_full29_L8_20260401_075554/best_model.pt \\
        --name zscore_h40 --zscore_loss \\
        --lambda_terminal 5.5150 --lambda_health 4.8767 --lambda_action_fidelity 7.2979
"""

import sys, os, argparse, json, time, subprocess, signal, atexit
from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from torch.utils.data import Dataset, DataLoader

# ─── Args ───────────────────────────────────────────────────────────────

parser = argparse.ArgumentParser()
parser.add_argument('--gpu', type=int, default=0)
parser.add_argument('--epochs', type=int, default=200)
parser.add_argument('--batch_size', type=int, default=256)
parser.add_argument('--lr', type=float, default=3e-4)
parser.add_argument('--weight_decay', type=float, default=1e-4)

# IWM architecture
parser.add_argument('--d_model', type=int, default=192)
parser.add_argument('--n_heads', type=int, default=6)
parser.add_argument('--n_layers', type=int, default=4)
parser.add_argument('--d_ff', type=int, default=576)
parser.add_argument('--dropout', type=float, default=0.1)
parser.add_argument('--warmup_epochs', type=int, default=10)

# FM
parser.add_argument('--fm_path', type=str, required=True,
                    help='Path to best_model.pt of trained full-29D FM')
parser.add_argument('--horizon', type=int, default=8,
                    help='Action horizon (must match FM chunk_length)')

# Loss
parser.add_argument('--lambda_terminal', type=float, default=1.0)
parser.add_argument('--lambda_health', type=float, default=10.0,
                    help='Health loss multiplier (global scale for per-dim health targets)')
parser.add_argument('--lambda_action_fidelity', type=float, default=2.0,
                    help='BC regularisation on actions')

# ── Z-score loss normalisation ──
parser.add_argument('--zscore_loss', action='store_true',
                    help='Normalise each raw loss component by its running σ (EMA) '
                         'before applying λ.  λ then operates on unit-variance signals.')
parser.add_argument('--zscore_momentum', type=float, default=0.99,
                    help='EMA momentum for running σ estimation (default: 0.99)')
parser.add_argument('--zscore_warmup', type=int, default=100,
                    help='Number of batches before z-score normalisation activates. '
                         'During warmup, raw (unnormalised) losses are used.')

# Health sub-weights (multiply with lambda_health for effective weight)
parser.add_argument('--w_z', type=float, default=10.0,
                    help='Per-dim weight for z-height health')
parser.add_argument('--w_qw', type=float, default=5.0,
                    help='Per-dim weight for qw → 1 (uprightness)')
parser.add_argument('--w_qx', type=float, default=2.0,
                    help='Per-dim weight for qx → 0')
parser.add_argument('--w_qy', type=float, default=2.0,
                    help='Per-dim weight for qy → 0')
parser.add_argument('--w_qz', type=float, default=3.0,
                    help='Per-dim weight for qz → 0 (yaw correction)')
parser.add_argument('--w_joints', type=float, default=0.5,
                    help='Per-dim weight for joint angles → data means')
parser.add_argument('--w_velocities', type=float, default=0.0,
                    help='Per-dim weight for velocities → 0 (0=skip)')

parser.add_argument('--uniform_health', action='store_true',
                    help='Use uniform weight=1.0 for ALL dims (except xy) instead '
                         'of manually specified per-group weights. Targets remain '
                         'the same HEALTHY_TARGETS_29D.  Overrides --w_z/qw/qx/... flags.')

# Data
parser.add_argument('--val_frac', type=float, default=0.1)
parser.add_argument('--min_displacement', type=float, default=0.5)
parser.add_argument('--min_z', type=float, default=0.3,
                    help='Tilt filter: exclude chunks with any z < min_z')

# Eval
parser.add_argument('--n_eval_episodes', type=int, default=10)

# Misc
parser.add_argument('--seed', type=int, default=42)
parser.add_argument('--name', type=str, required=True)
parser.add_argument('--out_dir', type=str, default=None)
parser.add_argument('--data_dir', type=str, default=None)
parser.add_argument('--relative_xy', action='store_true')
parser.add_argument('--no_monitor', action='store_true')
parser.add_argument('--monitor_interval', type=int, default=30)

PROJECT_ROOT = Path(os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))))

# ────────────────────────────────────────────────────────────────────────
# Healthy locomotion targets (from high-displacement ≥0.5 training data)
# ────────────────────────────────────────────────────────────────────────

# Per-dim targets derived from dataset analysis:
#   dim  0 [x    ]: position — no health target (terminal loss handles xy)
#   dim  1 [y    ]: position — no health target
#   dim  2 [z    ]: 0.574 ± 0.105 — critical health indicator
#   dim  3 [qw   ]: 0.901 → target 1.0 (identity quaternion for uprightness)
#   dim  4 [qx   ]: 0.007 → target 0.0
#   dim  5 [qy   ]: 0.006 → target 0.0
#   dim  6 [qz   ]: -0.083 → target 0.0 (yaw correction)
#   dim  7 [hip1 ]: 0.015 → ~0
#   dim  8 [ank1 ]: 0.721
#   dim  9 [hip2 ]: -0.002 → ~0
#   dim 10 [ank2 ]: -0.708
#   dim 11 [hip3 ]: -0.001 → ~0
#   dim 12 [ank3 ]: -0.703
#   dim 13 [hip4 ]: 0.000 → ~0
#   dim 14 [ank4 ]: 0.700
#   dim 15-28: velocities — means near 0, std 1-3, skip by default

HEALTHY_TARGETS_29D = np.array([
    0.0,     # 0: x (unused — weight=0)
    0.0,     # 1: y (unused — weight=0)
    0.574,   # 2: z-height
    1.0,     # 3: qw → identity
    0.0,     # 4: qx → 0
    0.0,     # 5: qy → 0
    0.0,     # 6: qz → 0
    0.0,     # 7: hip1 angle
    0.721,   # 8: ankle1 angle
    0.0,     # 9: hip2 angle
    -0.708,  # 10: ankle2 angle
    0.0,     # 11: hip3 angle
    -0.703,  # 12: ankle3 angle
    0.0,     # 13: hip4 angle
    0.700,   # 14: ankle4 angle
    0.0,     # 15: vx
    0.0,     # 16: vy
    0.0,     # 17: vz
    0.0,     # 18: wx
    0.0,     # 19: wy
    0.0,     # 20: wz
    0.0,     # 21: dhip1
    0.0,     # 22: dank1
    0.0,     # 23: dhip2
    0.0,     # 24: dank2
    0.0,     # 25: dhip3
    0.0,     # 26: dank3
    0.0,     # 27: dhip4
    0.0,     # 28: dank4
], dtype=np.float32)

DIM_NAMES = [
    'x', 'y', 'z', 'qw', 'qx', 'qy', 'qz',
    'hip1', 'ank1', 'hip2', 'ank2', 'hip3', 'ank3', 'hip4', 'ank4',
    'vx', 'vy', 'vz', 'wx', 'wy', 'wz',
    'dhip1', 'dank1', 'dhip2', 'dank2', 'dhip3', 'dank3', 'dhip4', 'dank4',
]

DIM_GROUPS = {
    'xy':       (0, 2),
    'z':        (2, 3),
    'quat':     (3, 7),
    'jnt_ang':  (7, 15),
    'lin_vel':  (15, 18),
    'ang_vel':  (18, 21),
    'jnt_vel':  (21, 29),
}


def build_health_weights(args) -> np.ndarray:
    """Build 29D per-dim weight vector from args.

    If --uniform_health is set, all dims except xy get weight=1.0.
    Otherwise, uses the manually specified per-group weights (w_z, w_qw, etc.).
    """
    w = np.zeros(29, dtype=np.float32)

    if getattr(args, 'uniform_health', False):
        # Uniform: all dims weighted equally (except xy handled by terminal loss)
        w[2:] = 1.0
        return w

    # Manual per-group weights (original behaviour)
    # xy: no health target (terminal loss handles these)
    w[2] = args.w_z         # z-height
    w[3] = args.w_qw        # qw
    w[4] = args.w_qx        # qx
    w[5] = args.w_qy        # qy
    w[6] = args.w_qz        # qz
    # Joint angles (8 dims)
    for d in range(7, 15):
        w[d] = args.w_joints
    # Velocities (14 dims)
    for d in range(15, 29):
        w[d] = args.w_velocities
    return w


# ═════════════════════════════════════════════════════════════════════════
# FM model class — Full 29D Transformer (frozen, self-contained copy)
# ═════════════════════════════════════════════════════════════════════════

class AntMazeFull29TransformerFM(nn.Module):
    """
    Causal Transformer forward model predicting all 29 state dimensions.

    Sequence: [s₀_token, a₀_token, ..., a_{L-1}_token]
    Output:   [s₁, ..., s_L] — full 29D states at each step (residuals from s₀)
    """

    def __init__(
        self,
        state_dim: int = 29,
        action_dim: int = 8,
        chunk_length: int = 8,
        d_model: int = 384,
        n_heads: int = 6,
        n_layers: int = 6,
        ff_mult: int = 4,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.chunk_length = chunk_length
        self.d_model = d_model
        self.n_heads = n_heads
        self.n_layers_tfm = n_layers
        self.ff_mult = ff_mult

        self.state_embed = nn.Sequential(
            nn.Linear(state_dim, d_model),
            nn.GELU(),
            nn.LayerNorm(d_model),
            nn.Linear(d_model, d_model),
        )
        self.action_embed = nn.Sequential(
            nn.Linear(action_dim, d_model),
            nn.GELU(),
            nn.LayerNorm(d_model),
            nn.Linear(d_model, d_model),
        )

        self.pos_embed = nn.Parameter(
            torch.randn(1, chunk_length + 1, d_model) * 0.02
        )
        self.type_embed = nn.Parameter(
            torch.randn(1, 2, d_model) * 0.02
        )

        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model, nhead=n_heads,
            dim_feedforward=d_model * ff_mult,
            dropout=dropout, activation='gelu',
            batch_first=True, norm_first=True,
        )
        self.transformer = nn.TransformerEncoder(
            encoder_layer, num_layers=n_layers,
            norm=nn.LayerNorm(d_model),
        )

        self.output_head = nn.Sequential(
            nn.Linear(d_model, d_model),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_model, state_dim),
        )

        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
        nn.init.zeros_(self.output_head[-1].weight)
        nn.init.zeros_(self.output_head[-1].bias)

    def forward(self, state: torch.Tensor, actions: torch.Tensor) -> torch.Tensor:
        """
        state:   (B, 29) normalised, actions: (B, L, 8) normalised
        Returns: (B, L, 29) predicted states (s₀ + residuals, normalised)
        """
        B = state.shape[0]
        L = self.chunk_length

        s_tok = self.state_embed(state).unsqueeze(1)
        a_tok = self.action_embed(actions)
        tokens = torch.cat([s_tok, a_tok], dim=1)
        tokens = tokens + self.pos_embed[:, :L + 1, :]

        type_ids = torch.zeros(B, L + 1, self.d_model, device=tokens.device)
        type_ids[:, 0, :] = self.type_embed[:, 0, :]
        type_ids[:, 1:, :] = self.type_embed[:, 1, :]
        tokens = tokens + type_ids

        causal_mask = torch.triu(
            torch.full((L + 1, L + 1), float('-inf'), device=tokens.device),
            diagonal=1,
        )

        out = self.transformer(tokens, mask=causal_mask)
        out_actions = out[:, 1:, :]
        deltas = self.output_head(out_actions)

        return state.unsqueeze(1) + deltas


# ═════════════════════════════════════════════════════════════════════════
# FM wrapper — z-score normalisation for full 29D output
# ═════════════════════════════════════════════════════════════════════════

class AntMazeFMWrapper29D(nn.Module):
    """Wraps frozen 29D FM with normalisation. Raw → physical coords (29D)."""

    def __init__(self, fm_model, state_mean, state_std, action_mean, action_std):
        super().__init__()
        self.fm = fm_model
        self.register_buffer('state_mean', torch.tensor(state_mean, dtype=torch.float32))
        self.register_buffer('state_std', torch.tensor(state_std, dtype=torch.float32))
        self.register_buffer('action_mean', torch.tensor(action_mean, dtype=torch.float32))
        self.register_buffer('action_std', torch.tensor(action_std, dtype=torch.float32))

    def forward(self, state_raw, actions_raw):
        """
        (B, 29) raw state, (B, L, 8) raw actions → (B, L, 29) physical states.
        """
        state_norm = (state_raw - self.state_mean) / self.state_std
        actions_norm = (actions_raw - self.action_mean) / self.action_std
        pred_norm = self.fm(state_norm, actions_norm)  # (B, L, 29)
        # Denormalize
        return pred_norm * self.state_std.unsqueeze(0) + self.state_mean.unsqueeze(0)


# ═════════════════════════════════════════════════════════════════════════
# IWM — Causal Transformer (same architecture as yawzero)
# ═════════════════════════════════════════════════════════════════════════

class AntMazeIWM_L16(nn.Module):
    """
    IWM for L-step horizon.
    Input:  s₀[29D], goal_xy[2D]
    Output: actions[L×8D], tanh-bounded to [-1, 1]
    """

    def __init__(self, state_dim=29, goal_dim=2, action_dim=8,
                 d_model=192, n_heads=6, n_layers=4, d_ff=576, dropout=0.0,
                 relative_xy=False, horizon=8):
        super().__init__()
        self.action_dim = action_dim
        self.d_model = d_model
        self.relative_xy = relative_xy
        self.horizon = horizon

        self.cond_encoder = nn.Sequential(
            nn.Linear(state_dim + goal_dim, d_model),
            nn.GELU(),
            nn.LayerNorm(d_model),
            nn.Linear(d_model, d_model),
            nn.GELU(),
            nn.LayerNorm(d_model),
        )

        self.pos_embed = nn.Parameter(torch.randn(1, horizon, d_model) * 0.02)

        layer = nn.TransformerEncoderLayer(
            d_model=d_model, nhead=n_heads, dim_feedforward=d_ff,
            dropout=dropout, activation='gelu', batch_first=True,
            norm_first=True,
        )
        self.transformer = nn.TransformerEncoder(layer, num_layers=n_layers)

        self.output_proj = nn.Linear(d_model, action_dim)
        nn.init.uniform_(self.output_proj.weight, -0.01, 0.01)
        nn.init.zeros_(self.output_proj.bias)

        self.register_buffer(
            'causal_mask',
            torch.triu(torch.ones(horizon, horizon, dtype=torch.bool), diagonal=1),
        )

    def forward(self, state, goal_xy):
        goal_rel = goal_xy - state[:, :2]
        if self.relative_xy:
            state = state.clone()
            state[:, :2] = 0.0
        cond = torch.cat([state, goal_rel], dim=-1)
        c = self.cond_encoder(cond)
        x = c.unsqueeze(1) + self.pos_embed
        x = self.transformer(x, mask=self.causal_mask)
        return torch.tanh(self.output_proj(x))

    def plan(self, state_np, goal_xy_np, fm_wrapper=None):
        """Inference-time: return actions + predicted 29D states."""
        device = next(self.parameters()).device
        s = torch.tensor(state_np, dtype=torch.float32, device=device).unsqueeze(0)
        g = torch.tensor(goal_xy_np, dtype=torch.float32, device=device).unsqueeze(0)
        with torch.no_grad():
            actions = self.forward(s, g)
            pred = None
            if fm_wrapper is not None:
                pred = fm_wrapper(s, actions)[0].cpu().numpy()  # (L, 29)
        return {
            'actions': np.clip(actions[0].cpu().numpy(), -1.0, 1.0),
            'predicted_xy': pred[:, :2] if pred is not None else None,
            'predicted_states': pred,
        }


# ═════════════════════════════════════════════════════════════════════════
# Dataset — sample L-step segments, goal = endpoint
# ═════════════════════════════════════════════════════════════════════════

def build_valid_indices(episode_lengths, horizon):
    """Return array of valid start indices (each has `horizon` future steps)."""
    indices = []
    ep_start = 0
    for ep_len in episode_lengths:
        ep_len = int(ep_len)
        for t in range(ep_start, ep_start + ep_len - horizon):
            indices.append(t)
        ep_start += ep_len
    return np.array(indices, dtype=np.int64)


class AntMazeL16Dataset(Dataset):
    def __init__(self, states, actions, indices, horizon):
        self.states = states
        self.actions = actions
        self.indices = indices
        self.horizon = horizon

    def __len__(self):
        return len(self.indices)

    def __getitem__(self, idx):
        t = self.indices[idx]
        s0 = self.states[t]
        goal_xy = self.states[t + self.horizon, :2]
        seg_actions = self.actions[t:t + self.horizon]
        return (
            torch.from_numpy(s0.astype(np.float32)),
            torch.from_numpy(goal_xy.astype(np.float32)),
            torch.from_numpy(seg_actions.astype(np.float32)),
        )


# ═════════════════════════════════════════════════════════════════════════
# Running standard deviation tracker (for z-score loss normalisation)
# ═════════════════════════════════════════════════════════════════════════

class RunningStd:
    """EMA-based running standard deviation estimator.

    During the first `warmup` updates, returns 1.0 (no normalisation)
    so the early noisy estimates don't create instability.
    After warmup, returns the EMA-tracked σ.
    """

    def __init__(self, momentum: float = 0.99, warmup: int = 100):
        self.momentum = momentum
        self.warmup = warmup
        self.n = 0
        self._mean = 0.0
        self._var = 0.0

    def update(self, x: float) -> float:
        """Update with new observation and return current σ estimate.

        Returns 1.0 during warmup (effectively disabling normalisation).
        """
        self.n += 1
        # Use 1/n blending at start for unbiased warmup, then switch to EMA
        alpha = min(1.0 - self.momentum, 1.0 / self.n)
        delta = x - self._mean
        self._mean += alpha * delta
        # Welford-style variance update adapted for EMA
        self._var = (1.0 - alpha) * (self._var + alpha * delta * delta)

        if self.n < self.warmup:
            return 1.0  # no normalisation during warmup
        return max(self._var ** 0.5, 1e-8)

    @property
    def std(self) -> float:
        if self.n < self.warmup:
            return 1.0
        return max(self._var ** 0.5, 1e-8)

    @property
    def mean(self) -> float:
        return self._mean

    def state_dict(self) -> dict:
        return {'n': self.n, 'mean': self._mean, 'var': self._var,
                'momentum': self.momentum, 'warmup': self.warmup}

    def load_state_dict(self, d: dict):
        self.n = d['n']
        self._mean = d['mean']
        self._var = d['var']
        self.momentum = d['momentum']
        self.warmup = d['warmup']


# ═════════════════════════════════════════════════════════════════════════
# Loss — terminal + health (29D) + fidelity through full FM
# ═════════════════════════════════════════════════════════════════════════

class Healthy29DShootingLoss(nn.Module):
    """
    IWM loss through the full 29D FM:

      L = λ_terminal * ||FM_final_xy - goal_xy||              (goal reaching)
        + λ_health   * Σ_d w_d * mean_t(pred_d[t] - target_d)²  (per-dim health)
        + λ_fidelity * ||a_iwm - a_data||²                     (BC regularisation)

    When zscore_loss=True, each raw loss is divided by its running σ before
    applying λ.  This normalises all losses to unit variance so λ values
    directly control the relative gradient contribution in standardised units.

    NOTE: The health loss uses per-dim weights (w_d) *inside* the loss
    computation.  The z-score σ is estimated on the *aggregate* health loss
    (after per-dim weighting), not per-dimension.
    """

    def __init__(self, iwm, fm_wrapper, health_targets, health_weights,
                 lambda_terminal=1.0, lambda_health=10.0, lambda_fidelity=2.0,
                 zscore_loss=False, zscore_momentum=0.99, zscore_warmup=100):
        super().__init__()
        self.iwm = iwm
        self.fm_wrapper = fm_wrapper
        self.lambda_terminal = lambda_terminal
        self.lambda_health = lambda_health
        self.lambda_fidelity = lambda_fidelity

        self.register_buffer('health_targets',
                             torch.tensor(health_targets, dtype=torch.float32))
        self.register_buffer('health_weights',
                             torch.tensor(health_weights, dtype=torch.float32))

        # ── Z-score normalisation ──
        self.zscore_loss = zscore_loss
        if zscore_loss:
            self._sigma_trackers = {
                'terminal': RunningStd(zscore_momentum, zscore_warmup),
                'health':   RunningStd(zscore_momentum, zscore_warmup),
                'fidelity': RunningStd(zscore_momentum, zscore_warmup),
            }

    def compute_loss(self, start_states, goal_xy, dataset_actions=None):
        """
        start_states:    (B, 29) raw
        goal_xy:         (B, 2) raw physical
        dataset_actions: (B, L, 8) ground-truth actions (optional)
        """
        # IWM → actions
        actions = self.iwm(start_states, goal_xy)  # (B, L, 8)

        # FM → predicted full 29D trajectory
        fm_pred = self.fm_wrapper(start_states, actions)  # (B, L, 29)

        pred_xy = fm_pred[:, :, :2]      # (B, L, 2)
        final_xy = pred_xy[:, -1, :]     # (B, 2)

        # ── Terminal loss: reach the goal xy ──
        terminal_loss = torch.norm(final_xy - goal_xy, dim=-1).mean()

        # ── Health loss: per-dim weighted MSE toward healthy targets ──
        # targets: (29,), weights: (29,) — broadcast over (B, L, 29)
        targets = self.health_targets.view(1, 1, 29)   # (1, 1, 29)
        weights = self.health_weights.view(1, 1, 29)   # (1, 1, 29)

        # Weighted per-dim squared error, averaged over batch and time
        health_err = weights * (fm_pred - targets) ** 2  # (B, L, 29)
        health_loss = health_err.mean()

        # Per-group health losses for diagnostics
        with torch.no_grad():
            health_per_group = {}
            for gname, (lo, hi) in DIM_GROUPS.items():
                health_per_group[f'health_{gname}'] = float(
                    health_err[:, :, lo:hi].mean().item())

        # ── Fidelity loss (BC) ──
        if self.lambda_fidelity > 0 and dataset_actions is not None:
            fidelity_loss = ((actions - dataset_actions) ** 2).mean()
        else:
            fidelity_loss = torch.tensor(0.0, device=start_states.device)

        # ── Z-score normalisation (optional) ──
        # Divide each raw loss by its running σ so λ operates on
        # unit-variance signals.  During warmup, σ=1.0 (no effect).
        if self.zscore_loss:
            with torch.no_grad():
                sigma_t = self._sigma_trackers['terminal'].update(terminal_loss.item())
                sigma_h = self._sigma_trackers['health'].update(health_loss.item())
                sigma_f = self._sigma_trackers['fidelity'].update(fidelity_loss.item())

            terminal_normed = terminal_loss / sigma_t
            health_normed   = health_loss   / sigma_h
            fidelity_normed = fidelity_loss / sigma_f

            total = (self.lambda_terminal * terminal_normed
                     + self.lambda_health * health_normed
                     + self.lambda_fidelity * fidelity_normed)
        else:
            sigma_t = sigma_h = sigma_f = 1.0  # unused, for logging
            total = (self.lambda_terminal * terminal_loss
                     + self.lambda_health * health_loss
                     + self.lambda_fidelity * fidelity_loss)

        # ── Diagnostics ──
        with torch.no_grad():
            dists = torch.norm(pred_xy - goal_xy.unsqueeze(1), dim=-1)  # (B, L)
            action_mag = actions.abs().mean()
            action_sat = (actions.abs() > 0.99).float().mean()
            start_xy = start_states[:, :2].unsqueeze(1)
            displacement = torch.norm(pred_xy - start_xy, dim=-1).mean()

            # Z-height diagnostic
            pred_z = fm_pred[:, :, 2]  # (B, L)
            z_mean = pred_z.mean()
            z_min = pred_z.min()

            # Yaw diagnostic: qw, qz from FM predictions
            pred_qw = fm_pred[:, -1, 3]
            pred_qz = fm_pred[:, -1, 6]
            init_qw = start_states[:, 3]
            init_qz = start_states[:, 6]
            pred_yaw = torch.atan2(2 * pred_qw * pred_qz,
                                   1 - 2 * pred_qz ** 2) * 180.0 / np.pi
            init_yaw = torch.atan2(2 * init_qw * init_qz,
                                   1 - 2 * init_qz ** 2) * 180.0 / np.pi
            yaw_drift = (pred_yaw - init_yaw).abs().mean()

            # Tilt angle: angle between quat and identity
            pred_quat = fm_pred[:, -1, 3:7]  # (B, 4) [qw, qx, qy, qz]
            tilt_angle = 2 * torch.acos(pred_quat[:, 0].clamp(-1, 1)) * 180.0 / np.pi
            tilt_mean = tilt_angle.mean()

        # raw_total = sum of active (non-zero-λ) raw losses, for checkpoint selection
        raw_total = (
            (terminal_loss.item() if self.lambda_terminal > 0 else 0.0)
            + (health_loss.item() if self.lambda_health > 0 else 0.0)
            + (fidelity_loss.item() if self.lambda_fidelity > 0 else 0.0)
        )

        loss_dict = {
            'total': total.item(),
            'raw_total': raw_total,
            'terminal': terminal_loss.item(),
            'health': health_loss.item(),
            'fidelity': fidelity_loss.item(),
            'final_dist': dists[:, -1].mean().item(),
            'min_dist': dists.min(dim=1).values.mean().item(),
            'action_mag': action_mag.item(),
            'action_sat': action_sat.item(),
            'displacement': displacement.item(),
            'yaw_drift_deg': yaw_drift.item(),
            'tilt_deg': tilt_mean.item(),
            'z_mean': z_mean.item(),
            'z_min': z_min.item(),
        }
        loss_dict.update(health_per_group)

        # Log running σ when z-score is active
        if self.zscore_loss:
            loss_dict['zscore_sigma_terminal'] = float(sigma_t)
            loss_dict['zscore_sigma_health'] = float(sigma_h)
            loss_dict['zscore_sigma_fidelity'] = float(sigma_f)

        return total, loss_dict

    def sigma_state_dict(self) -> dict:
        """Serialise running σ trackers for checkpointing."""
        if not self.zscore_loss:
            return {}
        return {k: v.state_dict() for k, v in self._sigma_trackers.items()}

    def load_sigma_state_dict(self, d: dict):
        """Restore running σ trackers from checkpoint."""
        if not self.zscore_loss or not d:
            return
        for k, v in d.items():
            if k in self._sigma_trackers:
                self._sigma_trackers[k].load_state_dict(v)


# ═════════════════════════════════════════════════════════════════════════
# Evaluation — sample segments, run IWM + FM + optionally MuJoCo sim
# ═════════════════════════════════════════════════════════════════════════

def run_segment_eval(iwm_model, fm_wrapper, states, actions, val_indices,
                     horizon, n_samples=10, seed=42, sim_env=None):
    rng = np.random.RandomState(seed)
    chosen = rng.choice(len(val_indices), size=min(n_samples, len(val_indices)),
                        replace=False)

    device = next(iwm_model.parameters()).device
    iwm_model.eval()
    results = []

    with torch.no_grad():
        for ci in chosen:
            t = val_indices[ci]
            s0 = states[t]
            goal_xy = states[t + horizon, :2]
            data_xy = states[t:t + horizon + 1, :2]

            s0_t = torch.tensor(s0, dtype=torch.float32, device=device).unsqueeze(0)
            g_t = torch.tensor(goal_xy, dtype=torch.float32, device=device).unsqueeze(0)

            iwm_actions = iwm_model(s0_t, g_t)
            fm_pred = fm_wrapper(s0_t, iwm_actions)  # (1, L, 29)
            fm_pred_np = fm_pred[0].cpu().numpy()
            fm_xy_np = fm_pred_np[:, :2]

            iwm_acts_np = iwm_actions[0].cpu().numpy()
            final_pred_xy = fm_xy_np[-1]
            final_dist = float(np.linalg.norm(final_pred_xy - goal_xy))

            # Health diagnostics from FM predictions
            z_traj = fm_pred_np[:, 2]
            qw_traj = fm_pred_np[:, 3]
            qz_traj = fm_pred_np[:, 6]

            sim_xy = None
            if sim_env is not None:
                sim_xy = _run_actions_in_sim(sim_env, s0, iwm_acts_np)

            result = {
                'start': s0[:2].tolist(),
                'goal': goal_xy.tolist(),
                'fm_plan': fm_xy_np.tolist(),
                'data_xy': data_xy.tolist(),
                'final_dist': final_dist,
                'action_sat': float((np.abs(iwm_acts_np) > 0.99).mean()),
                'action_mag': float(np.abs(iwm_acts_np).mean()),
                'z_min': float(z_traj.min()),
                'z_mean': float(z_traj.mean()),
                'qw_mean': float(qw_traj.mean()),
                'qz_abs_mean': float(np.abs(qz_traj).mean()),
            }
            if sim_xy is not None:
                result['sim_xy'] = sim_xy.tolist()
                result['sim_final_dist'] = float(
                    np.linalg.norm(sim_xy[-1] - goal_xy))

            results.append(result)

    return results


def _run_actions_in_sim(env, s0, actions_np):
    """Set MuJoCo state to s0, execute actions, return xy trajectory."""
    import mujoco_py

    qpos = s0[:15].copy()
    qvel = s0[15:].copy()

    env.reset()
    state = mujoco_py.MjSimState(
        env.sim.get_state().time, qpos, qvel,
        env.sim.get_state().act, env.sim.get_state().udd_state,
    )
    env.sim.set_state(state)
    env.sim.forward()

    xy_traj = [qpos[:2].copy()]
    for a in actions_np:
        a = np.clip(a, -1.0, 1.0)
        obs, _, _, _ = env.step(a)
        xy_traj.append(obs[:2].copy())

    return np.array(xy_traj, dtype=np.float32)


# ═════════════════════════════════════════════════════════════════════════
# Full MuJoCo navigation eval (CORL-style)
# ═════════════════════════════════════════════════════════════════════════

# Embedded umaze geometry for cardinal BFS planner
_MAZE_MAP = [
    [1, 1, 1, 1, 1],
    [1, 0, 0, 0, 1],
    [1, 1, 1, 0, 1],
    [1, 0, 0, 0, 1],
    [1, 1, 1, 1, 1],
]
_SCALING = 4.0
_TORSO_X = 4.0
_TORSO_Y = 4.0
_N_ROWS = len(_MAZE_MAP)
_N_COLS = len(_MAZE_MAP[0])


def _cell_to_world(row, col):
    return np.array([col * _SCALING - _TORSO_X, row * _SCALING - _TORSO_Y],
                    dtype=np.float32)


def _world_to_cell(xy):
    best_dist, best_rc = float('inf'), (1, 1)
    for r in range(_N_ROWS):
        for c in range(_N_COLS):
            if _MAZE_MAP[r][c] == 0:
                d = np.linalg.norm(xy - _cell_to_world(r, c))
                if d < best_dist:
                    best_dist, best_rc = d, (r, c)
    return best_rc


def _bfs_cell_path(start_rc, goal_rc):
    if start_rc == goal_rc:
        return [start_rc]
    from collections import deque
    queue = deque([(start_rc, [start_rc])])
    visited = {start_rc}
    while queue:
        (r, c), path = queue.popleft()
        for dr, dc in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
            nr, nc = r + dr, c + dc
            if 0 <= nr < _N_ROWS and 0 <= nc < _N_COLS and _MAZE_MAP[nr][nc] == 0:
                if (nr, nc) == goal_rc:
                    return path + [(nr, nc)]
                if (nr, nc) not in visited:
                    visited.add((nr, nc))
                    queue.append(((nr, nc), path + [(nr, nc)]))
    return None


def _plan_cardinal_waypoints(start_xy, goal_xy, spacing=1.0):
    """Compact cardinal waypoint planner (mirrors navigate_cardinal.py)."""
    cell_path = _bfs_cell_path(_world_to_cell(start_xy), _world_to_cell(goal_xy))
    if cell_path is None:
        return None

    cell_centers = np.array([_cell_to_world(r, c) for r, c in cell_path],
                            dtype=np.float32)
    keypoints = [start_xy.copy()]
    for i, cc in enumerate(cell_centers):
        if i == 0 and np.linalg.norm(cc - start_xy) < 0.3:
            continue
        if i == len(cell_centers) - 1 and np.linalg.norm(cc - goal_xy) < 0.3:
            continue
        keypoints.append(cc)
    keypoints.append(goal_xy.copy())

    # Ensure axis-aligned final approach
    if len(keypoints) >= 3:
        prev, last_kp, goal_kp = keypoints[-3], keypoints[-2], keypoints[-1]
        dx, dy = abs(goal_kp[0] - last_kp[0]), abs(goal_kp[1] - last_kp[1])
        if dx > 0.05 and dy > 0.05:
            seg = last_kp - prev
            if abs(seg[0]) > abs(seg[1]):
                turn_x = np.clip(goal_kp[0], min(prev[0], last_kp[0]),
                                 max(prev[0], last_kp[0]))
                turn_point = np.array([turn_x, last_kp[1]], dtype=np.float32)
            else:
                turn_y = np.clip(goal_kp[1], min(prev[1], last_kp[1]),
                                 max(prev[1], last_kp[1]))
                turn_point = np.array([last_kp[0], turn_y], dtype=np.float32)
            if np.linalg.norm(turn_point - last_kp) > 0.05:
                keypoints[-2] = turn_point

    keypoints = np.array(keypoints, dtype=np.float32)

    # Resample at fixed spacing
    resampled = [keypoints[0]]
    for i in range(len(keypoints) - 1):
        seg_vec = keypoints[i + 1] - keypoints[i]
        seg_len = float(np.linalg.norm(seg_vec))
        if seg_len < 1e-6:
            continue
        seg_dir = seg_vec / seg_len
        for j in range(1, int(seg_len / spacing) + 1):
            resampled.append(keypoints[i] + seg_dir * (j * spacing))
        if np.linalg.norm(resampled[-1] - keypoints[i + 1]) > 0.05:
            resampled.append(keypoints[i + 1])
    if np.linalg.norm(resampled[-1] - goal_xy) > 0.05:
        resampled.append(goal_xy.copy())

    return np.array(resampled, dtype=np.float32)


def _navigate_one_episode(env, iwm_model, device, horizon,
                          wp_spacing=1.0, wp_advance=1.0, goal_dist=0.5,
                          stuck_thresh=10, max_replan=5,
                          target_dmin=0.5, target_dmax=1.5):
    """Run one full MuJoCo navigation episode. Returns dict with 'success'."""
    obs = env.reset()
    goal_xy = np.array(env.target_goal, dtype=np.float32)
    start_xy = obs[:2].copy()

    waypoints = _plan_cardinal_waypoints(start_xy, goal_xy, spacing=wp_spacing)
    if waypoints is None:
        return {'success': False, 'steps': 0, 'final_dist': float('inf')}

    n_wp = len(waypoints)
    wp_idx = 1
    steps = 0
    n_replans = 0
    chunks_since_advance = 0
    total_reward = 0.0
    max_steps = env._max_episode_steps  # 700

    iwm_model.eval()

    while steps < max_steps:
        current_xy = obs[:2]
        dist_to_goal = float(np.linalg.norm(current_xy - goal_xy))
        if dist_to_goal < goal_dist:
            total_reward = 1.0
            break

        # Waypoint advancement
        while wp_idx < n_wp - 1:
            d_wp = float(np.linalg.norm(current_xy - waypoints[wp_idx]))
            if d_wp < wp_advance:
                wp_idx += 1
                chunks_since_advance = 0
            else:
                break

        # Stuck → replan
        if chunks_since_advance >= stuck_thresh and n_replans < max_replan:
            n_replans += 1
            new_wps = _plan_cardinal_waypoints(current_xy, goal_xy,
                                                spacing=wp_spacing)
            if new_wps is not None and len(new_wps) >= 2:
                waypoints, n_wp, wp_idx = new_wps, len(new_wps), 1
                chunks_since_advance = 0

        # Target with randomized distance
        target_xy = waypoints[min(wp_idx, n_wp - 1)].copy()
        direction = target_xy - current_xy
        dir_norm = float(np.linalg.norm(direction))
        if dir_norm > 0.01 and target_dmin > 0:
            direction /= dir_norm
            rand_dist = np.random.uniform(target_dmin, target_dmax)
            if wp_idx >= n_wp - 1:
                rand_dist = min(rand_dist, dir_norm)
            target_xy = current_xy + direction * rand_dist

        # IWM inference
        with torch.no_grad():
            s = torch.tensor(obs, dtype=torch.float32, device=device).unsqueeze(0)
            g = torch.tensor(target_xy, dtype=torch.float32, device=device).unsqueeze(0)
            actions = iwm_model(s, g)[0].cpu().numpy()  # (H, 8)

        # Execute in MuJoCo
        goal_reached = False
        for a in actions:
            obs, reward, done, info = env.step(np.clip(a, -1.0, 1.0))
            total_reward += reward
            steps += 1
            if steps >= max_steps:
                break
            if reward > 0 or float(np.linalg.norm(obs[:2] - goal_xy)) < goal_dist:
                total_reward = max(total_reward, 1.0)
                goal_reached = True
                break

        if goal_reached:
            break

        chunks_since_advance += 1

        # Snap to closest forward waypoint
        best_snap_idx, best_snap_dist = wp_idx, float(
            np.linalg.norm(obs[:2] - waypoints[min(wp_idx, n_wp - 1)]))
        for wi in range(wp_idx + 1, n_wp):
            d = float(np.linalg.norm(obs[:2] - waypoints[wi]))
            if d < best_snap_dist:
                best_snap_dist, best_snap_idx = d, wi
        if best_snap_idx != wp_idx:
            wp_idx = best_snap_idx
            chunks_since_advance = 0
        elif best_snap_dist > wp_spacing * 3.0 and n_replans < max_replan:
            n_replans += 1
            new_wps = _plan_cardinal_waypoints(obs[:2], goal_xy,
                                                spacing=wp_spacing)
            if new_wps is not None and len(new_wps) >= 2:
                waypoints, n_wp, wp_idx = new_wps, len(new_wps), 1
                chunks_since_advance = 0

    return {
        'success': total_reward > 0,
        'steps': steps,
        'final_dist': float(np.linalg.norm(obs[:2] - goal_xy)),
        'n_replans': n_replans,
    }


def run_mujoco_eval(env, iwm_model, device, horizon, n_episodes=10, seed=42):
    """Full CORL-style navigation eval: n_episodes full episodes, returns SR%."""
    rng_state = np.random.get_state()
    np.random.seed(seed)
    results = []
    for _ in range(n_episodes):
        r = _navigate_one_episode(env, iwm_model, device, horizon)
        results.append(r)
    np.random.set_state(rng_state)

    n_success = sum(r['success'] for r in results)
    sr = n_success / n_episodes * 100.0
    avg_steps = np.mean([r['steps'] for r in results])
    avg_dist = np.mean([r['final_dist'] for r in results])
    return {
        'sr': sr,
        'n_success': n_success,
        'n_episodes': n_episodes,
        'avg_steps': float(avg_steps),
        'avg_final_dist': float(avg_dist),
        'episodes': results,
    }


# ═════════════════════════════════════════════════════════════════════════
# Main
# ═════════════════════════════════════════════════════════════════════════

if __name__ == '__main__':
    args = parser.parse_args()
    HORIZON = args.horizon

    os.environ['MUJOCO_PY_FORCE_CPU'] = '1'
    mujoco_dir = os.environ.get('MUJOCO_DIR', os.path.expanduser('~/.mujoco/mujoco210'))
    os.environ['LD_LIBRARY_PATH'] = f'{mujoco_dir}/bin:/usr/lib/nvidia'
    os.environ['MUJOCO_GL'] = 'egl'

    os.environ['CUDA_VISIBLE_DEVICES'] = str(args.gpu)
    DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'

    DATA_DIR = Path(args.data_dir) if args.data_dir else PROJECT_ROOT / 'data' / 'antmaze' / 'umaze'

    timestamp = time.strftime('%Y%m%d_%H%M%S')
    if args.out_dir:
        OUT_DIR = Path(args.out_dir)
    else:
        OUT_DIR = PROJECT_ROOT / 'antmaze' / 'umaze' / 'iwm' / 'L16' / f'{args.name}_{timestamp}'
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    CKPT_DIR = OUT_DIR / 'checkpoints'
    CKPT_DIR.mkdir(exist_ok=True)

    # ─── Auto-launch monitor ──────────────────────────────────────

    monitor_proc = None
    monitor_fh = None

    def _cleanup_monitor():
        if monitor_proc is not None and monitor_proc.poll() is None:
            monitor_proc.terminate()
            try:
                monitor_proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                monitor_proc.kill()
            print(f'  Monitor stopped (PID {monitor_proc.pid})', flush=True)
        if monitor_fh is not None:
            try:
                monitor_fh.close()
            except Exception:
                pass

    def _signal_handler(signum, frame):
        print(f'\nReceived signal {signum}, cleaning up...', flush=True)
        _cleanup_monitor()
        sys.exit(128 + signum)

    signal.signal(signal.SIGTERM, _signal_handler)
    signal.signal(signal.SIGINT, _signal_handler)
    atexit.register(_cleanup_monitor)

    if not args.no_monitor:
        if args.zscore_loss:
            monitor_script = PROJECT_ROOT / 'antmaze' / 'monitor_zscore.py'
        else:
            monitor_script = PROJECT_ROOT / 'antmaze' / 'monitor_iwm.py'
        monitor_log = OUT_DIR / 'monitor.log'
        if monitor_script.exists():
            monitor_env = os.environ.copy()
            monitor_cmd = [
                sys.executable, str(monitor_script),
                '--out_dir', str(OUT_DIR),
                '--interval', str(args.monitor_interval),
            ]
            monitor_fh = open(monitor_log, 'w')
            monitor_proc = subprocess.Popen(
                monitor_cmd, stdout=monitor_fh, stderr=subprocess.STDOUT,
                env=monitor_env,
            )
            print(f'  Monitor started (PID {monitor_proc.pid}) → {monitor_log}', flush=True)
        else:
            print(f'  Warning: monitor script not found at {monitor_script}', flush=True)

    torch.manual_seed(args.seed)
    np.random.seed(args.seed)

    # ─── Load data ─────────────────────────────────────────────────────

    print(f'Loading data from {DATA_DIR}/', flush=True)
    all_states = np.load(DATA_DIR / 'states.npy').astype(np.float32)
    all_actions = np.load(DATA_DIR / 'actions.npy').astype(np.float32)
    ep_lengths = np.load(DATA_DIR / 'episode_lengths.npy')
    print(f'  States:   {all_states.shape}', flush=True)
    print(f'  Actions:  {all_actions.shape}', flush=True)
    print(f'  Episodes: {len(ep_lengths)} (mean len {ep_lengths.mean():.0f})', flush=True)

    # Build valid indices and train/val split
    valid_idx = build_valid_indices(ep_lengths, horizon=HORIZON)
    n_all_valid = len(valid_idx)

    # Filter by minimum displacement
    if args.min_displacement > 0:
        xy = all_states[:, :2]
        displacements = np.linalg.norm(xy[valid_idx + HORIZON] - xy[valid_idx], axis=1)
        keep = displacements >= args.min_displacement
        valid_idx = valid_idx[keep]
        print(f'  min_displacement={args.min_displacement:.2f}: '
              f'{n_all_valid:,} → {len(valid_idx):,} segments '
              f'({len(valid_idx)/n_all_valid:.1%} kept)', flush=True)

    # Filter out tilted chunks (any step with z < min_z)
    if args.min_z > 0:
        n_before_tilt = len(valid_idx)
        z_col = all_states[:, 2]
        keep_tilt = np.ones(len(valid_idx), dtype=bool)
        for offset in range(HORIZON + 1):
            keep_tilt &= z_col[valid_idx + offset] >= args.min_z
        valid_idx = valid_idx[keep_tilt]
        print(f'  min_z={args.min_z:.2f} (tilt filter): '
              f'{n_before_tilt:,} → {len(valid_idx):,} segments '
              f'({len(valid_idx)/n_before_tilt:.1%} kept)', flush=True)

    n_valid = len(valid_idx)
    rng = np.random.RandomState(args.seed)
    perm = rng.permutation(n_valid)
    n_val = int(n_valid * args.val_frac)
    n_train = n_valid - n_val
    train_idx = valid_idx[perm[:n_train]]
    val_idx = valid_idx[perm[n_train:]]

    train_ds = AntMazeL16Dataset(all_states, all_actions, train_idx, HORIZON)
    val_ds = AntMazeL16Dataset(all_states, all_actions, val_idx, HORIZON)

    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True,
                              num_workers=4, pin_memory=True, persistent_workers=True)
    val_loader = DataLoader(val_ds, batch_size=args.batch_size * 2, shuffle=False,
                            num_workers=4, pin_memory=True, persistent_workers=True)

    print(f'  Valid segments: {n_valid:,}  →  Train: {n_train:,}, Val: {n_val:,}', flush=True)

    # ─── Load frozen 29D FM ────────────────────────────────────────────

    fm_path = PROJECT_ROOT / args.fm_path
    print(f'Loading full-29D FM from {fm_path}...', flush=True)
    fm_ckpt = torch.load(fm_path, map_location='cpu', weights_only=False)

    # ─── Handle both checkpoint formats ──────────────────────────────
    # Format A: wrapped dict with model_state_dict + metadata (best_model.pt)
    # Format B: raw state_dict (model_ep*.pt snapshots)
    if 'model_state_dict' in fm_ckpt:
        fm_state_dict = fm_ckpt['model_state_dict']
        fm_meta = fm_ckpt
    else:
        # Raw state dict — load metadata from config.json + norm_stats in same dir
        fm_state_dict = fm_ckpt
        fm_dir = fm_path.parent
        fm_config = json.loads((fm_dir / 'config.json').read_text())
        fm_t = fm_config['training']
        fm_m = fm_config.get('model', {})
        # Load norm stats from companion file
        norm_stats = np.load(fm_dir / 'norm_stats.npz')
        fm_meta = {
            'state_dim': fm_m.get('state_dim', 29),
            'action_dim': fm_m.get('action_dim', 8),
            'output_dim': fm_m.get('output_dim', 29),
            'chunk_length': fm_t.get('chunk_length', HORIZON),
            'd_model': fm_t.get('d_model', 384),
            'n_heads': fm_t.get('n_heads', 6),
            'n_layers': fm_t.get('n_layers', 6),
            'ff_mult': fm_t.get('ff_mult', 4),
            'dropout': fm_t.get('dropout', 0.1),
            'state_mean': torch.from_numpy(norm_stats['state_mean'].astype(np.float32)),
            'state_std': torch.from_numpy(norm_stats['state_std'].astype(np.float32)),
            'action_mean': torch.from_numpy(norm_stats['action_mean'].astype(np.float32)),
            'action_std': torch.from_numpy(norm_stats['action_std'].astype(np.float32)),
            'val_loss': '?',
            'epoch': fm_path.stem.replace('model_ep', ''),
        }
        print(f'  (loaded norm stats + config from {fm_dir.name}/)', flush=True)

    fm_state_dim = fm_meta.get('state_dim', 29)
    fm_output_dim = fm_meta.get('output_dim', fm_state_dim) or fm_state_dim
    assert fm_output_dim == 29, \
        f'Expected 29D FM, got output_dim={fm_output_dim}. This script requires the full 29D FM.'

    fm_model = AntMazeFull29TransformerFM(
        state_dim=fm_meta.get('state_dim', 29),
        action_dim=fm_meta.get('action_dim', 8),
        chunk_length=fm_meta.get('chunk_length', HORIZON),
        d_model=fm_meta.get('d_model', 384),
        n_heads=fm_meta.get('n_heads', 6),
        n_layers=fm_meta.get('n_layers', 6),
        ff_mult=fm_meta.get('ff_mult', 4),
        dropout=fm_meta.get('dropout', 0.1),
    )
    fm_model.load_state_dict(fm_state_dict)
    fm_model.eval()
    for p in fm_model.parameters():
        p.requires_grad = False

    print(f'  FM: Full 29D Transformer d={fm_meta.get("d_model", 384)}, '
          f'{fm_meta.get("n_heads", 6)}H, {fm_meta.get("n_layers", 6)}L',
          flush=True)
    fm_n_params = sum(p.numel() for p in fm_model.parameters())
    print(f'  FM params: {fm_n_params:,}', flush=True)
    print(f'  FM val_loss: {fm_meta.get("val_loss", "?")} '
          f'@epoch {fm_meta.get("epoch", "?")}', flush=True)

    fm_wrapper = AntMazeFMWrapper29D(
        fm_model,
        state_mean=fm_meta['state_mean'],
        state_std=fm_meta['state_std'],
        action_mean=fm_meta['action_mean'],
        action_std=fm_meta['action_std'],
    ).to(DEVICE)

    # ─── Build IWM ────────────────────────────────────────────────────

    iwm = AntMazeIWM_L16(
        d_model=args.d_model, n_heads=args.n_heads,
        n_layers=args.n_layers, d_ff=args.d_ff,
        dropout=args.dropout,
        relative_xy=args.relative_xy,
        horizon=HORIZON,
    ).to(DEVICE)

    n_params = sum(p.numel() for p in iwm.parameters())
    print(f'  IWM: {n_params:,} params', flush=True)

    # ─── Build health targets and weights ─────────────────────────────

    health_weights = build_health_weights(args)
    health_targets = HEALTHY_TARGETS_29D.copy()

    print(f'\n  Health targets & weights:', flush=True)
    for d in range(29):
        if health_weights[d] > 0:
            print(f'    dim{d:2d} [{DIM_NAMES[d]:5s}]: '
                  f'target={health_targets[d]:7.3f}, weight={health_weights[d]:.1f}',
                  flush=True)

    n_active_health_dims = (health_weights > 0).sum()
    print(f'  Active health dims: {n_active_health_dims}/29', flush=True)
    print(f'  Effective health weights (λ_health × w_d):')
    for d in range(29):
        if health_weights[d] > 0:
            eff = args.lambda_health * health_weights[d]
            print(f'    {DIM_NAMES[d]:5s}: {eff:.1f}', flush=True)

    # ─── Loss & optimizer ─────────────────────────────────────────────

    shooting = Healthy29DShootingLoss(
        iwm=iwm, fm_wrapper=fm_wrapper,
        health_targets=health_targets,
        health_weights=health_weights,
        lambda_terminal=args.lambda_terminal,
        lambda_health=args.lambda_health,
        lambda_fidelity=args.lambda_action_fidelity,
        zscore_loss=args.zscore_loss,
        zscore_momentum=args.zscore_momentum,
        zscore_warmup=args.zscore_warmup,
    ).to(DEVICE)

    if args.zscore_loss:
        print(f'\n  Z-SCORE LOSS ENABLED', flush=True)
        print(f'    momentum={args.zscore_momentum}, warmup={args.zscore_warmup} batches', flush=True)
        print(f'    Each raw loss is divided by running σ before applying λ.', flush=True)
        print(f'    λ values operate on unit-variance signals.', flush=True)

    optimizer = torch.optim.AdamW(iwm.parameters(), lr=args.lr,
                                  weight_decay=args.weight_decay)
    warmup_sched = torch.optim.lr_scheduler.LinearLR(
        optimizer, start_factor=1e-3, end_factor=1.0, total_iters=args.warmup_epochs)
    cosine_sched = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=max(1, args.epochs - args.warmup_epochs))
    scheduler = torch.optim.lr_scheduler.SequentialLR(
        optimizer, schedulers=[warmup_sched, cosine_sched],
        milestones=[args.warmup_epochs])

    # ─── Save config ──────────────────────────────────────────────────

    config = {
        'experiment': {
            'name': args.name,
            'created': time.strftime('%Y-%m-%dT%H:%M:%S'),
            'script': 'antmaze/umaze/iwm/L16/train_iwm_unified.py',
            'gpu': args.gpu,
            'horizon': HORIZON,
        },
        'training': {
            'epochs': args.epochs,
            'batch_size': args.batch_size,
            'lr': args.lr,
            'weight_decay': args.weight_decay,
            'val_frac': args.val_frac,
            'n_train': n_train,
            'n_val': n_val,
            'lambda_terminal': args.lambda_terminal,
            'lambda_health': args.lambda_health,
            'lambda_action_fidelity': args.lambda_action_fidelity,
            'min_displacement': args.min_displacement,
            'min_z': args.min_z,
            'warmup_epochs': args.warmup_epochs,
            'seed': args.seed,
            'fm_path': args.fm_path,
            'zscore_loss': args.zscore_loss,
            'zscore_momentum': args.zscore_momentum if args.zscore_loss else None,
            'zscore_warmup': args.zscore_warmup if args.zscore_loss else None,
        },
        'model': {
            'type': 'AntMazeIWM_L16_Healthy29D',
            'd_model': args.d_model,
            'n_heads': args.n_heads,
            'n_layers': args.n_layers,
            'd_ff': args.d_ff,
            'dropout': args.dropout,
            'relative_xy': args.relative_xy,
            'n_params': n_params,
        },
        'health': {
            'targets': health_targets.tolist(),
            'weights': health_weights.tolist(),
            'dim_names': DIM_NAMES,
            'uniform_health': args.uniform_health,
            'w_z': args.w_z,
            'w_qw': args.w_qw,
            'w_qx': args.w_qx,
            'w_qy': args.w_qy,
            'w_qz': args.w_qz,
            'w_joints': args.w_joints,
            'w_velocities': args.w_velocities,
        },
    }
    (OUT_DIR / 'config.json').write_text(json.dumps(config, indent=2))

    # ─── Training loop ────────────────────────────────────────────────

    print(f'\nTraining healthy-29D IWM for {args.epochs} epochs on GPU {args.gpu}', flush=True)
    print(f'  λ_terminal={args.lambda_terminal}, λ_health={args.lambda_health}, '
          f'λ_fidelity={args.lambda_action_fidelity}', flush=True)
    if args.zscore_loss:
        print(f'  Z-score loss: ON (λ values operate on normalised losses)', flush=True)
    print(f'  Arch: d={args.d_model}, {args.n_heads}H, {args.n_layers}L, ff={args.d_ff}',
          flush=True)
    print(f'  Output: {OUT_DIR}', flush=True)
    print(flush=True)

    progress_file = OUT_DIR / 'progress.json'
    history_file = OUT_DIR / 'history.json'

    best_val_loss = float('inf')
    best_eval_dist = float('inf')
    best_epoch = 0
    best_score_dist = float('inf')   # CORL-style: best sim dist
    best_score_epoch = 0
    best_nav_sr = 0.0                  # CORL-style: best navigation SR
    best_nav_sr_epoch = 0
    train_history = []
    val_history = []
    eval_dist_history = []
    eval_sim_dist_history = []
    nav_sr_history = []                # full MuJoCo nav SR per epoch
    start_epoch = 0

    # Resume
    resume_ckpt = OUT_DIR / 'checkpoint.pt'
    if resume_ckpt.exists():
        print('  Resuming from checkpoint...', flush=True)
        ckpt = torch.load(resume_ckpt, map_location=DEVICE, weights_only=False)
        iwm.load_state_dict(ckpt['model_state_dict'])
        optimizer.load_state_dict(ckpt['optimizer_state_dict'])
        scheduler.load_state_dict(ckpt['scheduler_state_dict'])
        start_epoch = ckpt['epoch'] + 1
        best_val_loss = ckpt['best_val_loss']
        best_eval_dist = ckpt.get('best_eval_dist', float('inf'))
        best_epoch = ckpt['best_epoch']
        train_history = ckpt['train_history']
        val_history = ckpt['val_history']
        eval_dist_history = ckpt.get('eval_dist_history', [])
        eval_sim_dist_history = ckpt.get('eval_sim_dist_history', [])
        best_score_dist = ckpt.get('best_score_dist', float('inf'))
        best_score_epoch = ckpt.get('best_score_epoch', 0)
        best_nav_sr = ckpt.get('best_nav_sr', 0.0)
        best_nav_sr_epoch = ckpt.get('best_nav_sr_epoch', 0)
        nav_sr_history = ckpt.get('nav_sr_history', [])
        # Restore z-score σ trackers
        if args.zscore_loss and 'sigma_state' in ckpt:
            shooting.load_sigma_state_dict(ckpt['sigma_state'])
        print(f'  Resumed at epoch {start_epoch}/{args.epochs}', flush=True)

    # ─── Create MuJoCo env for sim eval ─────────────────────────────

    sim_env = None
    try:
        import gym
        import d4rl  # noqa
        sim_env = gym.make('antmaze-umaze-v2')
        sim_env.reset()
        print('  MuJoCo sim env created for eval', flush=True)
    except Exception as e:
        print(f'  Warning: Could not create MuJoCo env: {e}', flush=True)

    t_start = time.time()

    for epoch in range(start_epoch, args.epochs):
        # ── Train ──
        iwm.train()
        epoch_losses = []

        for s0, goal_xy, data_actions in train_loader:
            s0 = s0.to(DEVICE, non_blocking=True)
            goal_xy = goal_xy.to(DEVICE, non_blocking=True)
            data_actions = data_actions.to(DEVICE, non_blocking=True)

            loss, loss_dict = shooting.compute_loss(s0, goal_xy, data_actions)

            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(iwm.parameters(), 1.0)
            optimizer.step()

            epoch_losses.append(loss_dict)

        scheduler.step()
        avg_train = {k: float(np.mean([d[k] for d in epoch_losses])) for k in epoch_losses[0]}
        train_history.append(avg_train)

        # ── Validate ──
        iwm.eval()
        val_losses = []
        with torch.no_grad():
            for s0, goal_xy, data_actions in val_loader:
                s0 = s0.to(DEVICE, non_blocking=True)
                goal_xy = goal_xy.to(DEVICE, non_blocking=True)
                data_actions = data_actions.to(DEVICE, non_blocking=True)
                _, loss_dict = shooting.compute_loss(s0, goal_xy, data_actions)
                val_losses.append(loss_dict)

        avg_val = {k: float(np.mean([d[k] for d in val_losses])) for k in val_losses[0]}
        val_history.append(avg_val)

        # ── Segment eval ──
        eval_results = run_segment_eval(
            iwm, fm_wrapper, all_states, all_actions, val_idx,
            horizon=HORIZON, n_samples=args.n_eval_episodes,
            seed=args.seed + epoch * 100, sim_env=sim_env,
        )
        eval_mean_dist = float(np.mean([e['final_dist'] for e in eval_results]))
        eval_mean_sim_dist = float(np.mean([
            e['sim_final_dist'] for e in eval_results if 'sim_final_dist' in e
        ])) if any('sim_final_dist' in e for e in eval_results) else -1.0
        eval_mean_z = float(np.mean([e['z_mean'] for e in eval_results]))
        eval_mean_qw = float(np.mean([e['qw_mean'] for e in eval_results]))
        (OUT_DIR / 'eval_episodes.json').write_text(json.dumps(eval_results, indent=2))

        eval_dist_history.append(eval_mean_dist)
        eval_sim_dist_history.append(eval_mean_sim_dist)

        # ── Full MuJoCo navigation eval (CORL-style) ──
        nav_eval = None
        if sim_env is not None:
            nav_eval = run_mujoco_eval(
                sim_env, iwm, DEVICE, HORIZON,
                n_episodes=args.n_eval_episodes,
                seed=args.seed + epoch * 1000,
            )
            nav_sr = nav_eval['sr']
            nav_sr_history.append(nav_sr)
        else:
            nav_sr = -1.0
            nav_sr_history.append(-1.0)

        # ── Checkpoint (use raw_total, not z-score total) ──
        val_raw = avg_val['raw_total']
        is_best = val_raw < best_val_loss
        if is_best:
            best_val_loss = val_raw
            best_epoch = epoch

        if is_best:
            save_dict = {
                'model_state_dict': iwm.state_dict(),
                'epoch': epoch,
                'val_loss': val_raw,
                'eval_mean_dist': eval_mean_dist,
                'args': vars(args),
                'horizon': HORIZON,
                'fm_path': args.fm_path,
                'health_targets': health_targets.tolist(),
                'health_weights': health_weights.tolist(),
            }
            if args.zscore_loss:
                save_dict['sigma_state'] = shooting.sigma_state_dict()
            torch.save(save_dict, OUT_DIR / 'best_model.pt')

        if eval_mean_dist >= 0 and eval_mean_dist < best_eval_dist:
            best_eval_dist = eval_mean_dist

        # ── CORL-style best sim dist tracking ──
        if eval_mean_sim_dist >= 0 and eval_mean_sim_dist < best_score_dist:
            best_score_dist = eval_mean_sim_dist
            best_score_epoch = epoch
            save_dict = {
                'model_state_dict': iwm.state_dict(),
                'epoch': epoch,
                'val_loss': avg_val['raw_total'],
                'eval_mean_sim_dist': eval_mean_sim_dist,
                'selection_method': 'best_sim_dist',
                'args': vars(args),
                'horizon': HORIZON,
                'fm_path': args.fm_path,
                'health_targets': health_targets.tolist(),
                'health_weights': health_weights.tolist(),
            }
            if args.zscore_loss:
                save_dict['sigma_state'] = shooting.sigma_state_dict()
            torch.save(save_dict, OUT_DIR / 'best_score_model.pt')

        # ── CORL-style best navigation SR tracking ──
        if nav_sr >= 0 and nav_sr > best_nav_sr:
            best_nav_sr = nav_sr
            best_nav_sr_epoch = epoch
            save_dict = {
                'model_state_dict': iwm.state_dict(),
                'epoch': epoch,
                'val_loss': avg_val['raw_total'],
                'nav_sr': nav_sr,
                'selection_method': 'best_nav_sr',
                'args': vars(args),
                'horizon': HORIZON,
                'fm_path': args.fm_path,
                'health_targets': health_targets.tolist(),
                'health_weights': health_weights.tolist(),
            }
            if args.zscore_loss:
                save_dict['sigma_state'] = shooting.sigma_state_dict()
            torch.save(save_dict, OUT_DIR / 'best_sr_model.pt')

        ckpt_dict = {
            'model_state_dict': iwm.state_dict(),
            'optimizer_state_dict': optimizer.state_dict(),
            'scheduler_state_dict': scheduler.state_dict(),
            'epoch': epoch,
            'best_val_loss': best_val_loss,
            'best_eval_dist': best_eval_dist,
            'best_epoch': best_epoch,
            'train_history': train_history,
            'val_history': val_history,
            'eval_dist_history': eval_dist_history,
            'eval_sim_dist_history': eval_sim_dist_history,
            'best_score_dist': best_score_dist,
            'best_score_epoch': best_score_epoch,
            'nav_sr_history': nav_sr_history,
            'best_nav_sr': best_nav_sr,
            'best_nav_sr_epoch': best_nav_sr_epoch,
        }
        if args.zscore_loss:
            ckpt_dict['sigma_state'] = shooting.sigma_state_dict()
        torch.save(ckpt_dict, OUT_DIR / 'checkpoint.pt')

        # ── Logging ──
        elapsed = time.time() - t_start
        epochs_done = epoch - start_epoch + 1
        eta = elapsed / epochs_done * (args.epochs - epoch - 1) if epochs_done > 0 else 0

        progress = {
            'epoch': epoch + 1,
            'total_epochs': args.epochs,
            'train': avg_train,
            'val': avg_val,
            'eval_mean_dist': eval_mean_dist,
            'eval_mean_sim_dist': eval_mean_sim_dist,
            'eval_mean_z': eval_mean_z,
            'eval_mean_qw': eval_mean_qw,
            'best_val_loss': best_val_loss,
            'best_eval_dist': best_eval_dist,
            'best_score_dist': best_score_dist,
            'best_score_epoch': best_score_epoch + 1,
            'nav_sr': nav_sr,
            'best_nav_sr': best_nav_sr,
            'best_nav_sr_epoch': best_nav_sr_epoch + 1,
            'best_epoch': best_epoch + 1,
            'elapsed_s': round(elapsed, 1),
            'eta_s': round(eta, 1),
            'lr': scheduler.get_last_lr()[0],
        }
        progress_file.write_text(json.dumps(progress, indent=2))
        history_file.write_text(json.dumps({
            'train': train_history,
            'val': val_history,
            'eval_dist_history': eval_dist_history,
            'eval_sim_dist_history': eval_sim_dist_history,
            'nav_sr_history': nav_sr_history,
            'best_score_dist': best_score_dist,
            'best_score_epoch': best_score_epoch,
            'best_nav_sr': best_nav_sr,
            'best_nav_sr_epoch': best_nav_sr_epoch,
        }))

        if (epoch + 1) % 5 == 0 or epoch == 0:
            sim_str = f' sim:{eval_mean_sim_dist:.3f}' if eval_mean_sim_dist >= 0 else ''
            nav_str = f' SR:{nav_sr:.0f}%' if nav_sr >= 0 else ''
            zscore_str = ''
            if args.zscore_loss and 'zscore_sigma_terminal' in avg_train:
                zscore_str = (f' σ_t:{avg_train["zscore_sigma_terminal"]:.4f}'
                              f' σ_h:{avg_train["zscore_sigma_health"]:.4f}'
                              f' σ_f:{avg_train["zscore_sigma_fidelity"]:.4f}')
            print(
                f'Ep {epoch+1:3d}/{args.epochs} | '
                f'Train: {avg_train["total"]:.4f} '
                f'(term:{avg_train["terminal"]:.3f} '
                f'hlth:{avg_train["health"]:.4f} '
                f'fid:{avg_train["fidelity"]:.3f}) | '
                f'Val: {avg_val["total"]:.4f} | '
                f'act_sat:{avg_val["action_sat"]:.1%} '
                f'disp:{avg_val["displacement"]:.3f} | '
                f'fm_dist:{eval_mean_dist:.3f} '
                f'z:{eval_mean_z:.3f} '
                f'qw:{eval_mean_qw:.3f} '
                f'tilt:{avg_val["tilt_deg"]:.1f}°{sim_str}{nav_str}{zscore_str} | '
                f'Best:{best_val_loss:.4f} @{best_epoch+1} | '
                f'ETA: {eta/60:.0f}min',
                flush=True,
            )

        if (epoch + 1) % 50 == 0:
            torch.save(iwm.state_dict(), CKPT_DIR / f'model_ep{epoch+1}.pt')

    # ─── Done ──────────────────────────────────────────────────────────

    total_time = time.time() - t_start
    torch.save(iwm.state_dict(), OUT_DIR / 'final_model.pt')
    history_file.write_text(json.dumps({
        'train': train_history,
        'val': val_history,
        'eval_dist_history': eval_dist_history,
        'eval_sim_dist_history': eval_sim_dist_history,
            'nav_sr_history': nav_sr_history,
            'best_score_dist': best_score_dist,
            'best_score_epoch': best_score_epoch,
            'best_nav_sr': best_nav_sr,
            'best_nav_sr_epoch': best_nav_sr_epoch,
    }))

    _cleanup_monitor()

    print(f'\nDone! {total_time/60:.1f} min', flush=True)
    print(f'  Best val loss: {best_val_loss:.4f} @ epoch {best_epoch+1}', flush=True)
    print(f'  Best eval dist: {best_eval_dist:.4f}', flush=True)
    print(f'  Best sim dist (CORL): {best_score_dist:.4f} @ epoch {best_score_epoch+1}', flush=True)
    print(f'  Best nav SR (CORL): {best_nav_sr:.0f}% @ epoch {best_nav_sr_epoch+1}', flush=True)
    print(f'  Output: {OUT_DIR}', flush=True)
